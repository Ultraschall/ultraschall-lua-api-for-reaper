dofile(reaper.GetResourcePath().."/UserPlugins/ultraschall_api.lua")

reaper.CF_ShellExecute(ultraschall.Api_Path.."/Documentation")
reaper.CF_ShellExecute(ultraschall.Api_Path.."/misc/misc_docs")
