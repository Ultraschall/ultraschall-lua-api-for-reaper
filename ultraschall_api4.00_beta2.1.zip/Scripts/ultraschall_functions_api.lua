--[[
################################################################################
# 
# Copyright (c) 2014-2017 Ultraschall (http://ultraschall.fm)
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# 
################################################################################
]] 

-- Ultraschall Functions-API
-- include the following lines (without the -- comment-characters of course ;) )
-- to get access to the Ultraschall functions API within your script:
--
-- local info = debug.getinfo(1,'S');
-- script_path = info.source:match[[^@?(.*[\/])[^\/]-$]]
-- US_API = dofile(script_path .. "ultraschall_functions_api.lua")

--TODO: !! Bugfixing of \\ which is Windows only, while Mac uses /


-------------------------------------
--- ULTRASCHALL - API - FUNCTIONS ---
-------------------------------------

--[[
ultraschall={}

if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    -- user_folder = buf --"C:\\Users\\[username]" -- need to be test
    ultraschall.Separator = "\\"
  else
    -- user_folder = "/USERS/[username]" -- Mac OS. Not tested on Linux.
    ultraschall.Separator = "/"
  end
--]]  

--------------------------------------------------
------ ULTRASCHALL FRAMEWORK 4.00 BETA 1 ---------
--------------------------------------------------

---------------------------
---- US Little Helpers ----
---------------------------

function ultraschall.Msg(val)
-- prints a message to the Reaper Console
-- val - your message as a string

  reaper.ShowConsoleMsg(tostring(val).."\n")
end


function ultraschall.RoundNumber(num)
    if tonumber(num)==nil then return nil end
    num=tonumber(num)
    return num % 1 >= 0.5 and math.ceil(num) or math.floor(num)
end


function ultraschall.ApiFunctionTest()
  reaper.MB("Ultraschall Functions API works","Ultraschall-API",0)
end


function ultraschall.GetPath(str,sep)
-- return the path of a filename-string
-- -1 if it doesn't work
local  result=str:match("(.*"..sep..")")
  if result==nil then result="-1" end
  return result
end


function ultraschall.GetPartialString(str,sep1,sep2)
-- returns the part of a string between sep1 and sep2
--
-- str-string to be processed
-- sep1 - separator on the "left" side of the string
-- sep2 - separator on the "right" side of the string
-- returns -1 if it doesn't work, no sep1 or sep2 exist

  if str==nil or sep1==nil or sep2==nil then return nil end
    local start=sep1:len()
    local stop=sep2:len()
  if sep1=="%" then sep1="%%" end
  if sep2=="%" then sep2="%%" end
  if sep1=="." then sep1="%." end
  if sep2=="." then sep2="%." end
    
   local result=str:match("("..sep1..".*"..sep2..")")
  if result==nil then result="" end

   local endresult=result:sub(1+start,-1-stop)
    
  if endresult==nil then endresult="-1" end
      return endresult
  end
  

function ultraschall.SecondsToTime(pos)
-- converts timeposition in seconds(pos) to a timestring (h)hh:mm:ss.ms
  local hours=0
  local minutes=0
  local seconds=0
  local milliseconds=0
  local temp=0
  local tempo=0
  local tempo2=0
  local trailinghour=""
  local trailingminute=""
  local trailingsecond="" 
  local trailingmilli=""
  
      if pos>=3600 then temp=tostring(pos/3600) hours=tonumber(temp:match("%d*")) pos=pos-(3600*hours) end
        if pos>=60 then temp=tostring(pos/60) minutes=tonumber(temp:match("(%d*)")) pos=pos-(60*minutes) end
        temp=tostring(pos)
        seconds=pos
        tempo=tostring(seconds)
        tempo2=tempo:match("%.%d*")
        if tempo2==nil then tempo2=".0" end
        milliseconds=tempo2:sub(2,4)
        if milliseconds:len()==2 then milliseconds=milliseconds.."0" end
        if milliseconds:len()==1 then milliseconds=milliseconds.."00" end
        if seconds==nil then seconds=0.0 end        
        if hours<10 then trailinghour="0" else trailinghour="" end
        if minutes<10 then trailingminute="0" else trailingminute="" end
        if seconds<10 then trailingsecond="0" else trailingsecond="" end
        seconds=tostring(seconds)
        seconds=seconds:match("%d*.")
        if seconds:sub(-1,-1)=="." then seconds=seconds:sub(1,-2) end
    return trailinghour..hours..":"..trailingminute..minutes..":"..trailingsecond..seconds.."."..milliseconds
end


function ultraschall.TimeToSeconds(timestring)
-- converts a timestring (h)hh:mm:ss.ms to timeposition in seconds
local hour=""
local milliseconds=""
local minute=""
local seconds=""
local time=""

if timestring==nil then return -1 end
if tonumber(timestring)~=nil then return -1 end
    hour=timestring:match("%d*:")
    if hour==nil then return -1 end
    hour=hour:sub(1,-2)
    if hour=="" then return -1 end
  
    minute=timestring:match(":%d*:")
    if minute==nil then return -1 end
    minute=minute:sub(2,-2)
    if minute=="" then return -1 end
  
    seconds=timestring:match(":%d*%.")
    if seconds==nil then return -1 end
    seconds=seconds:sub(2,-2)
    if seconds=="" then return -1 end

    milliseconds=timestring:match("%.%d*")
    if milliseconds==nil then milliseconds=0 end
    if milliseconds=="" then milliseconds=".0 " end
    if milliseconds=="0" then milliseconds=".0 " end
    if milliseconds==0 then milliseconds=".0 " end
    if milliseconds=="." then milliseconds=0 end
    
    time=(hour*3600)+(minute*60)+seconds+milliseconds
    if time<0 then return -1 end
    return time
end


function ultraschall.RunCommand(actioncommand_id)  
-- runs a command by its ActionCommandID(instead of the CommandID-number)

  local command_id = reaper.NamedCommandLookup(actioncommand_id)
  reaper.Main_OnCommand(command_id,0) 

end


function ultraschall.Notes2CSV()
-- returns the project's notes as a CSV(retval)
  local csv = ""
  local linenumber=1
  local notes = reaper.GetSetProjectNotes(0, false, "")
    for line in notes:gmatch"[^\n]*" do
      csv = csv .. "," .. line --escapeCSV(line)
    end
    
    local retval= string.sub(csv, 2) -- remove first ","
  return retval
end


function ultraschall.CSV2Line(csv_line)
-- converts a csv to a "clean" line without the ,-separators
  if csv_line==nil then return nil end
  if tonumber(csv_line)~=nil then return tostring(csv_line) end
  local clean=""
  local result=csv_line
  local countcomma=0

  for i=1, result:len() do
    if result:sub(i,i)~="," then clean=clean..result:sub(i,i) 
    else countcomma=countcomma+1 
    end
  end

  return clean
end


--ALABAMA=ultraschall.CSV2Line("13")

function ultraschall.RGB2Num(red, green, blue)
-- converts individual rgb values to an integer
-- negative values are allowed, so you can use this function to subtract colorvalues
-- MAC OR WINDOWS?  
if tonumber(red)==nil then return nil end
if tonumber(green)==nil then return nil end
if tonumber(blue)==nil then return nil end
  
  green = green * 256
  blue = blue * 256 * 256
  
  return red + green + blue

end


function ultraschall.CSV2IndividualLinesAsArray(csv_line)
-- converts a csv to an array with all individual values without the ,-separators as well as
-- the number of entries in the array(beginning with 1)
  if csv_line==nil then return nil end

  local result=tostring(csv_line)
  local temp=""
  local count=1
  local comma_pos=0
  local line_array={}
  local pos_array={}

--reaper.MB(result,csv_line,0)

for i=1, result:len() do
  if result:sub(i,i)~="," then 
    if result:sub(i,i)~=nil then temp=temp..result:sub(i,i) 
    else line_array[count]=""
    end
  else line_array[count]=temp count=count+1 comma_pos=i temp=""
  end
end
line_array[count]=result:sub(comma_pos+1,-1)
--reaper.MB("","",0)
  return line_array, count
end

--B,BB=ultraschall.CSV2IndividualLinesAsArray("8")

function ultraschall.RGB2Grayscale(red,green,blue)
--converts rgb to a grayscale value
-- Parameters: 
-- red - red-color-value 0-255
-- green - green-color-value 0-255
-- blue - blue-color-value 0-255

  if tonumber(red)==nil or tonumber(red)<0 or tonumber(red)>255 then return -1 end
  if tonumber(green)==nil or tonumber(green)<0 or tonumber(green)>255 then return -1 end
  if tonumber(blue)==nil or tonumber(blue)<0 or tonumber(blue)>255 then return -1 end

  local gray=red+green+blue
  gray=ultraschall.RoundNumber(gray/3)
  local gray_color=reaper.ColorToNative(gray,gray,gray)
return ultraschall.RoundNumber(gray_color)
end


function ultraschall.IsItemInTrack(tracknumber, itemIDX)
--returns true, if the itemIDX is part of track tracknumber, false if not, -1 if no such itemIDX or Tracknumber available
-- itemIDX - the number of the Item to check of
-- integer tracknumber - the number of the track to check in

if tonumber(itemIDX)==nil then return -1 end
if tonumber(tracknumber)==nil then return -1 end

--reaper.MB(tracknumber,itemIDX,0)

local itemIDX=tonumber(itemIDX)
local tracknumber=tonumber(tracknumber)

if tracknumber>reaper.CountTracks(0) or tracknumber<0 then return -1 end
if itemIDX>reaper.CountMediaItems(0)-1 or itemIDX<0 then return -1 end

local MediaTrack=reaper.GetTrack(0, tracknumber)

local MediaItem=reaper.GetMediaItem(0, itemIDX)
local MediaTrack2=reaper.GetMediaItem_Track(MediaItem)

if MediaTrack==MediaTrack2 then return true end
if MediaTrack~=MediaTrack2 then return false end


end

--AA=ultraschall.IsItemInTrack(0, 1)

function ultraschall.WriteValueToFile(filename_with_path, value, binarymode)
  -- Writes value to filename_with_path
  -- Keep in mind, that you need to escape \ by writing \\, or it will not work
  -- binarymode
  if filename_with_path == nil then return -1 end
  if value==nil then return -1 end
     local binary
  if binarymode==nil or binarymode==true then binary="b" else binary="" end
  local file=io.open(filename_with_path,"w"..binary)
  if file==nil then return -1 end
  file:write(value)
  file:close()
  return 1
end

--  content="%SystemRoot%\\syswow64\\chcp.com\ntestballon"
--  stringthing=string.format('%q', content)
  
--A=ultraschall.WriteValueToFile("c:\\hui.bat",content)

function ultraschall.WinColorToMacColor()
end

function ultraschall.MacColorToWinColor()
end

function ultraschall.CreateShownoteArray()
--creates and returns a shownotearray with no entry set
  return ShownoteArray
end

function ultraschall.CreateTrackNumbersString(firstnumber, lastnumber, step)
-- returns a string with the all numbers from firstnumber to lastnumber, separated by a ,
-- e.g. firstnumber=4, lastnumber=8 -> 4,5,6,7,8
-- firstnumber - the number, with which the string starts
-- lastnumber - the number, with which the string ends
-- step - how many numbers shall be skipped inbetween. Can lead to a different lastnumber, if not 1 ! nil=1
  if tonumber(firstnumber)==nil then return nil end
  if tonumber(lastnumber)==nil then return nil end
  if tonumber(step)==nil then step=1 end
    
  firstnumber=tonumber(firstnumber)
  lastnumber=tonumber(lastnumber)
  step=tonumber(step)
  
  local trackstring=""
  for i=firstnumber, lastnumber, step do
    trackstring=trackstring..","..tostring(i)
  end
  return trackstring:sub(2,-1)
end



------------------------------------
---- Ultraschall.ini Management ----
------------------------------------

--reaper.MB(ultraschall.Separator,"",0)

function ultraschall.SetUSExternalState(section, key, value)
-- stores value into ultraschall.ini
-- returns true if sucessful, false if unsucessful
  if section==nil then return false end
  if key==nil then return false end
  if value==nil then return false end

  if section:match(".*%=.*") then return false end

  return reaper.BR_Win32_WritePrivateProfileString(section, key, value, reaper.GetResourcePath()..ultraschall.Separator.."ultraschall.ini")
end

--A=ultraschall.SetUSExternalState("tes10to","cowb[sfijdfd]oy bebop2","Howde[]eho")
--AA=ultraschall.SetUSExternalState("tes89to","cafdfaaowbsfijdfdoy bebop2","Howdeeho")

function ultraschall.GetUSExternalState(section, key)
-- gets a value from ultraschall.ini
-- returns length of entry(integer) and the entry itself(string)
  if section==nil then return false end
  if key==nil then return false end
  
  return reaper.BR_Win32_GetPrivateProfileString(section, key, -1, reaper.GetResourcePath()..ultraschall.Separator.."\\ultraschall.ini")
end

--A,AA=ultraschall.GetUSExternalState("tes89to","cafdfaaowbsfijdfdoy bebop2")

function ultraschall.CountUSExternalState_sec()
--count number of sections in the ultraschall.ini
  local count=0
  
  for line in io.lines(reaper.GetResourcePath()..ultraschall.Separator.."ultraschall.ini") do
    local check=line:match(".*=.*")
    if check~=nil then check="" count=count+1 end
  end
  return count
end

--A=ultraschall.CountUSExternalState_sec()

function ultraschall.CountUSExternalState_key(section)
--count number of keys in the section in ultraschall.ini
  local count=0
  local startcount=0
  
  for line in io.lines(reaper.GetResourcePath()..ultraschall.Separator.."ultraschall.ini") do
   local check=line:match("%[.*.%]")
    if startcount==1 and line:match(".*=.*") then
      count=count+1
    else
      startcount=0
    if "["..section.."]" == check then startcount=1 end
    if check==nil then check="" end
    end

  end
  return count
end

--A=ultraschall.CountUSExternalState_key("tes89to")

function ultraschall.EnumerateUSExternalState_sec(number)
-- returns name of the numberth section in ultraschall.ini or nil, if invalid
  if tonumber(number)==nil then return nil end
  local number=tonumber(number)
  if number<=0 then return nil end
  if number>ultraschall.CountUSExternalState_sec() then return nil end
  
  local count=0
    for line in io.lines(reaper.GetResourcePath()..ultraschall.Separator.."ultraschall.ini") do
      local check=line:match(".*=.*")
      if check==nil then count=count+1 end
      if count==number then return line end
    end
end

--A=ultraschall.EnumerateUSExternalState_sec(1)

function ultraschall.EnumerateUSExternalState_key(section, number)
-- returns name of a numberth key within a section in ultraschall.ini or nil if invalid or not existing

  if section==nil then return nil end
  local count=0
  local startcount=0
  
    for line in io.lines(reaper.GetResourcePath()..ultraschall.Separator.."ultraschall.ini") do
     local check=line:match("%[.*.%]")
        if startcount==1 and line:match(".*=.*") then
        count=count+1
        if count==number then local temp=line:match(".*=") return temp:sub(1,-2) end
     else
        startcount=0
        if "["..section.."]" == check then startcount=1 end
        if check==nil then check="" end
    end

  end
  return nil
end


--ALAMO=ultraschall.EnumerateUSExternalState_key("tes89to",1)


--ALABAMSA=ultraschall.CountUSExternalState_key("tes6to")


--------------------------
---- Get Track States ----
--------------------------

-- TODO:
--<FXCHAIN
--<FXCHAIN_REC
--HWOUT a b c d e f g h:U i - HW-destination, as set in the routing-matrix, as well as in the Destination "Controls for Track"-dialogue. There are as many HWOuts as outputchannels.
--                            a - outputchannel, with 1024+x the individual hw-outputchannels, 0,2,4,etc stereo output channels
--                            b - 0-post-fader(post pan), 1-preFX, 3-pre-fader(Post-FX), as set in the Destination "Controls for Track"-dialogue
--                            c - volume, as set in the Destination "Controls for Track"-dialogue
--                            d - pan, as set in the Destination "Controls for Track"-dialogue
--                            e - mute, 1-on, 0-off, as set in the Destination "Controls for Track"-dialogue
--                            f - Phase, 1-on, 0-off, as set in the Destination "Controls for Track"-dialogue
--                            g - source, as set in the Destination "Controls for Track"-dialogue
--                                    -1 - None
--                                     0 - Stereo Source 1/2
--                                     4 - Stereo Source 5/6
--                                    12 - New Channels On Sending Track Stereo Source Channel 13/14
--                                    1024 - Mono Source 1
--                                    1029 - Mono Source 6
--                                    1030 - New Channels On Sending Track Mono Source Channel 7
--                                    1032 - New Channels On Sending Track Mono Source Channel 9
--                                    2048 - MultiChannel 4 Channels 1-4
--                                    2050 - Multichannel 4 Channels 3-6
--                                    3072 - Multichannel 6 Channels 1-6
--                            h - unknown, standard set to -1:U
--                            i - automation mode, as set in the Destination "Controls for Track"-dialogue
--                                    -1 - Track Automation Mode
--                                     0 - Trim/Read
--                                     1 - Read
--                                     2 - Touch
--                                     3 - Write
--                                     4 - Latch
--                                     5 - Latch Preview
--
--AUXRECV a b c d e f g h i j:U k l m - Auxreceive as set in the routing-matrix as well as in the "Routing for Track x"-dialogue(Receives). 
--                                      Can be more than one. Works also for Send to Track...
--                                      Must be defined in the track that receives, NOT the track that sends!
--                                    a - Tracknumber, from where to receive the audio from
--                                    b - 0-PostFader, 1-PreFX, 3-Pre-Fader
--                                    c - Volume
--                                    d - pan; -=left, +=right, 0=center
--                                    e - Mute this send(1) or not(0)
--                                    f - Mono(1), Stereo(0)
--                                    g - Phase of this send on(1) or off(0)
--                                    h - Audio-Channel Source
--                                        -1 - None
--                                        0 - Stereo Source 1/2
--                                        1 - Stereo Source 2/3
--                                        2 - Stereo Source 3/4
--                                        1024 - Mono Source 1
--                                        1025 - Mono Source 2
--                                        2048 - Multichannel Source 4 Channels 1-4
--                                    i - send to channel
--                                        0 - Stereo 1/2
--                                        1 - Stereo 2/3
--                                        2 - Stereo 3/4
--
--                                        1024 - Mono Channel 1
--                                        1025 - Mono Channel 2
--                                    j - unknown, default is -1:U
--                                    k - MIDI-Channel-Management, Bitfield
--                                        0 - All Midi Tracks
--                                        1 to 16 - Midi Channel 1 to 16
--                                        32 - send to Midi Channel 1
--                                        64 - send to MIDI Channel 2
--                                        96 - send to MIDI Channel 3
--                                        512 - send to MIDI Channel 16
--                                        4194304 - send to MIDI-Bus B1
--                                        send to MIDI-Bus B1 + send to MIDI Channel nr = MIDIBus B1 1/nr
--                                        16384 - BusB1
--                                        BusB1+1 to 16 - BusB1-Channel 1 to 16
--                                        32768 - BusB2
--                                        BusB2+1 to 16 - BusB2-Channel 1 to 16
--                                        49152 - BusB3
--                                        BusB3+1 to 16 - BusB3-Channel 1 to 16
--                                        262144 - BusB16
--                                        BusB16+1 to 16 - BusB16-Channel 1 to 16
--
--                                        1024 - Add that value to switch MIDI On
--                                        4177951 - MIDI - None
--                                         
--                                    l - Automation Mode
--                                       -1 - Track Automation Mode
--                                        0 - Trim/Read
--                                        1 - Read
--                                        2 - Touch
--                                        3 - Write
--                                        4 - Latch
--                                        5 - Latch Preview
--                                     

--MediaTrack=reaper.GetTrack(0, 0)
--retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
-- RECCFGNR_test=str:match("<RECCFG ("..nummer..")%c")
--reaper.ShowConsoleMsg(str)

--MediaTrack=reaper.GetTrack(0, 0)
--retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
--ALABAMA=ultraschall.WriteValueToFile("c:\\testomat2.txt",str)

function ultraschall.GetTrackName(tracknumber)
-- returns the trackname as a string
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
--  Track_PeakCol=str:match("PEAKCOL.-%a") Track_PeakCol=Track_PeakCol:sub(9,-2)
  local Track_Name=str:match("NAME.-%c") Track_Name=Track_Name:sub(6,-2)
  return Track_Name
end

--A=ultraschall.GetTrackName(0)

function ultraschall.GetTrackPeakColorState(tracknumber)
-- returns a color-number as a string
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
--  Track_PeakCol=str:match("PEAKCOL.-%a") Track_PeakCol=Track_PeakCol:sub(9,-2)
  local Track_PeakCol=str:match("PEAKCOL.-%c") Track_PeakCol=Track_PeakCol:sub(9,-2)
  return Track_PeakCol
end

--A=ultraschall.GetTrackPeakColorState(0)

function ultraschall.GetTrackBeatState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
  local Track_Beat=str:match("BEAT.-%c") Track_Beat=Track_Beat:sub(6,-2)
  return tonumber(Track_Beat)
end

--A=ultraschall.GetTrackBeatState(0)

function ultraschall.GetTrackAutoRecArmState(tracknumber)
-- returns nil, if it's unset
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_AutoRecarm=str:match("AUTO_RECARM.-%c") 
  if Track_AutoRecarm==nil then return nil end 
  Track_AutoRecarm=Track_AutoRecarm:sub(13,-2)
  return tonumber(Track_AutoRecarm)
end

--A=ultraschall.GetTrackAutoRecArmState(0)
  
function ultraschall.GetTrackMuteSoloState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_Mutesolo=str:match("MUTESOLO.-%c") Track_Mutesolo=Track_Mutesolo:sub(9,-2)
  local Track_Mutesolo1=Track_Mutesolo:match("%b  ") Track_Mutesolo=Track_Mutesolo:match(".(%s.*)")
  local Track_Mutesolo2=Track_Mutesolo:match("%b  ") Track_Mutesolo=Track_Mutesolo:match(".(%s.*)")
  local Track_Mutesolo3=Track_Mutesolo
  return tonumber(Track_Mutesolo1), tonumber(Track_Mutesolo2), tonumber(Track_Mutesolo3)
end

--A1,A2,A3 = ultraschall.GetTrackMuteSoloState(0)
  
function ultraschall.GetTrackIPhaseState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_Iphase=str:match("%IPHASE.-%c") Track_Iphase=Track_Iphase:sub(7,-2)
  return tonumber(Track_Iphase)
end

--A=ultraschall.GetTrackIPhaseState(0)

function ultraschall.GetTrackIsBusState(tracknumber)
-- for folder-management
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
  local Track_Isbus=str:match("ISBUS.-%c") Track_Isbus=Track_Isbus:sub(6,-2)
  local Track_Isbus1=Track_Isbus:match("%b  ") Track_Isbus=Track_Isbus:match(".(%s.*)")
  local Track_Isbus2=Track_Isbus
  return tonumber(Track_Isbus1), tonumber(Track_Isbus2)
end

--A1,A2=ultraschall.GetTrackIsBusState(1)

function ultraschall.GetTrackBusCompState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_Buscomp=str:match("BUSCOMP%s.-%c") Track_Buscomp=Track_Buscomp:sub(8,-2)
  local Track_Buscomp1=Track_Buscomp:match("%b  ") Track_Buscomp=Track_Buscomp:match(".(%s.*)")
  local Track_Buscomp2=Track_Buscomp
  return tonumber(Track_Buscomp1), tonumber(Track_Buscomp)
end

--A,A2=ultraschall.GetTrackBusCompState(0)

function ultraschall.GetTrackShowInMixState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_ShowinMix=str:match("SHOWINMIX.-%c") Track_ShowinMix=Track_ShowinMix:sub(10,-2)
  local Track_ShowinMix1=Track_ShowinMix:match("%b  ") Track_ShowinMix=Track_ShowinMix:match(".(%s.*)")
  local Track_ShowinMix2=Track_ShowinMix:match("%b  ") Track_ShowinMix=Track_ShowinMix:match(".(%s.*)")
  local Track_ShowinMix3=Track_ShowinMix:match("%b  ") Track_ShowinMix=Track_ShowinMix:match(".(%s.*)")
  local Track_ShowinMix4=Track_ShowinMix:match("%b  ") Track_ShowinMix=Track_ShowinMix:match(".(%s.*)")
  local Track_ShowinMix5=Track_ShowinMix:match("%b  ") Track_ShowinMix=Track_ShowinMix:match(".(%s.*)")
  local Track_ShowinMix6=Track_ShowinMix:match("%b  ") Track_ShowinMix=Track_ShowinMix:match(".(%s.*)")
  local Track_ShowinMix7=Track_ShowinMix:match("%b  ") Track_ShowinMix=Track_ShowinMix:match(".(%s.*)")
  local Track_ShowinMix8=Track_ShowinMix
  return tonumber(Track_ShowinMix1),tonumber(Track_ShowinMix2),tonumber(Track_ShowinMix3),tonumber(Track_ShowinMix4),tonumber(Track_ShowinMix5),tonumber(Track_ShowinMix6),tonumber(Track_ShowinMix7),tonumber(Track_ShowinMix8)
end  

--A1,A2,A3,A4,A5,A6,A7,A8=ultraschall.GetTrackShowInMixState(0)

function ultraschall.GetTrackFreeModeState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_FreeMode=str:match("FREEMODE.-%c") Track_FreeMode=Track_FreeMode:sub(10,-2)
  return tonumber(Track_FreeMode)
end

--A=ultraschall.GetTrackFreeModeState(0)

function ultraschall.GetTrackRecState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_Rec=str:match("REC.-%c") Track_Rec=Track_Rec:sub(4,-2)
  local Track_Rec1=Track_Rec:match("(%b  )") Track_Rec=Track_Rec:match(".(%s.*)")
  local Track_Rec2=Track_Rec:match("(%b  )") Track_Rec=Track_Rec:match(".(%s.*)")
  local Track_Rec3=Track_Rec:match("(%b  )") Track_Rec=Track_Rec:match(".(%s.*)")
  local Track_Rec4=Track_Rec:match("(%b  )") Track_Rec=Track_Rec:match(".(%s.*)")
  local Track_Rec5=Track_Rec:match("(%b  )") Track_Rec=Track_Rec:match(".(%s.*)")
  local Track_Rec6=Track_Rec:match("(%b  )") Track_Rec=Track_Rec:match(".(%s.*)")
  local Track_Rec7=Track_Rec
  return tonumber(Track_Rec1), tonumber(Track_Rec2), tonumber(Track_Rec3), tonumber(Track_Rec4), tonumber(Track_Rec5), tonumber(Track_Rec6), tonumber(Track_Rec7)
end

--A1,A2,A3,A4,A5,A6,A7=ultraschall.GetTrackRecState(0)

function ultraschall.GetTrackVUState(tracknumber)
-- returns 0 if MultiChannelMetering is off
-- returns 2 if MultichannelMetering is on
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
   retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
--ultraschall.ExportOutputTo("c:\\testomat",str)
  Track_Vu=str:match("VU.-%c") 
  if Track_Vu~=nil then  Track_Vu=Track_Vu:sub(4,-2) end
  if Track_VU==nil then Track_Vu=0 end
  return tonumber(Track_Vu)
end

--A=ultraschall.GetTrackVUState(0)

function ultraschall.GetTrackHeightState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_Trackheight=str:match("TRACKHEIGHT.-%c") Track_Trackheight=Track_Trackheight:sub(12,-2)
  local Track_Trackheight1=Track_Trackheight:match("%b  ")
  local Track_Trackheight2=Track_Trackheight:match(".(%s.*)")
  return tonumber(Track_Trackheight1), tonumber(Track_Trackheight2)
end
  
--A1,A2=ultraschall.GetTrackHeightState(0)
  
function ultraschall.GetTrackINQState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_INQ=str:match("INQ.-%c") Track_INQ=Track_INQ:sub(4,-2)
  local Track_INQ1=Track_INQ:match("(%b  )") Track_INQ=Track_INQ:match(".(%s.*)")
  local Track_INQ2=Track_INQ:match("(%b  )") Track_INQ=Track_INQ:match(".(%s.*)")
  local Track_INQ3=Track_INQ:match("(%b  )") Track_INQ=Track_INQ:match(".(%s.*)")
  local Track_INQ4=Track_INQ:match("(%b  )") Track_INQ=Track_INQ:match(".(%s.*)")
  local Track_INQ5=Track_INQ:match("(%b  )") Track_INQ=Track_INQ:match(".(%s.*)")
  local Track_INQ6=Track_INQ:match("(%b  )") Track_INQ=Track_INQ:match(".(%s.*)")
  local Track_INQ7=Track_INQ:match("(%b  )") Track_INQ=Track_INQ:match(".(%s.*)")
  local Track_INQ8=Track_INQ
  
  return tonumber(Track_INQ1),tonumber(Track_INQ2),tonumber(Track_INQ3),tonumber(Track_INQ4),tonumber(Track_INQ5),tonumber(Track_INQ6),tonumber(Track_INQ7),tonumber(Track_INQ8)
end
--]]
--A1,A2,A3,A4,A5,A6,A7,A8=ultraschall.GetTrackINQState(0)

function ultraschall.GetTrackNChansState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  local Track_Nchan=str:match("NCHAN.-%c") Track_Nchan=Track_Nchan:sub(7,-2)
  return tonumber(Track_Nchan)
end

--A=ultraschall.GetTrackNChansState(1)

function ultraschall.GetTrackBypFXState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  local Track_FX=str:match("FX.-%c") Track_FX=Track_FX:sub(4,-2)
  return tonumber(Track_FX)
end

--A=ultraschall.GetTrackBypFXState(1)

function ultraschall.GetTrackPerfState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  local Track_Perf=str:match("PERF.-%c") Track_Perf=Track_Perf:sub(6,-2)
  return tonumber(Track_Perf)
end

--A=ultraschall.GetTrackPerfState(0)

function ultraschall.GetTrackMIDIOutState(tracknumber)
-- -1 no output
-- 416 - microsoft GS wavetable synth - send to original channels
-- 417-432 - microsoft GS wavetable synth - send to channel state-416
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  MediaTrack=reaper.GetTrack(0, tracknumber)
  retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  Track_MIDIOut=str:match("MIDIOUT.-%a") Track_MIDIOut=Track_MIDIOut:sub(8,-2)
  return Track_MIDIOut
end

--A=ultraschall.GetTrackMIDIOutState(0)

function ultraschall.GetTrackMainSendState(tracknumber)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)

  local Track_TrackMainSend=str:match("MAINSEND.-%c") Track_TrackMainSend=Track_TrackMainSend:sub(9,-2)
  local Track_TrackMainSend1=Track_TrackMainSend:match("%b  ")
  local Track_TrackMainSend2=Track_TrackMainSend:match(".(%s.*)")
  return tonumber(Track_TrackMainSend1), tonumber(Track_TrackMainSend2)
end

-- A,AA= ultraschall.GetTrackMainSendState(0)

function ultraschall.GetTrackGroupFlagsState(tracknumber)
--[[returns a 23bit flagvalue as well as an array with 32 individual 23bit-flagvalues. You must use bitoperations to get the individual values.
GroupState_as_Flags - returns a flagvalue with 23 bits, that tells you, which grouping-flag is set in at least one of the 32 groups available.
returns -1 in case of failure

the following flags are available:
2^0 - Volume Master
2^1 - Volume Slave
2^2 - Pan Master
2^3 - Pan Slave
2^4 - Mute Master
2^5 - Mute Slave
2^6 - Solo Master
2^7 - Solo Slave
2^8 - Record Arm Master
2^9 - Record Arm Slave
2^10 - Polarity/Phase Master
2^11 - Polarity/Phase Slave
2^12 - Automation Mode Master
2^13 - Automation Mode Slave
2^14 - Reverse Volume
2^15 - Reverse Pan
2^16 - Do not master when slaving
2^17 - Reverse Width
2^18 - Width Master
2^19 - Width Slave
2^20 - VCA Master
2^21 - VCA Slave
2^22 - VCA pre-FX slave

IndividualGroupState_Flags - returns an array with 23 entries. Every entry represents one of the GroupState_as_Flags, but it's value is a flag, that describes, in which of the 32 Groups a certain flag is set.
e.g. If Volume Master is set only in Group 1, entry 1 in the array will be set to 1. If Volume Master is set on Group 2 and Group 4, the first entry in the array will be set to 10.
refer to the upper GroupState_as_Flags list to see, which entry in the array is for which set flag, e.g. array[22] is VCA pre-F slave, array[16] is Do not master when slaving, etc
As said before, the values in each entry is a flag, that tells you, which of the groups is set with a certain flag. The following flags determine, in which group a certain flag is set:
2^0 - Group 1
2^1 - Group 2
2^2 - Group 3
2^3 - Group 4
...
2^30 - Group 31
2^31 - Group 32

parameter:
tracknumber - number of the track, beginning with 0
--]]
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local tempretval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  local retval=0
  local Tracktable={}
  local Track_TrackGroupFlags1=0
  local Track_TrackGroupFlags2=0
   local Track_TrackGroupFlags3=0
   local Track_TrackGroupFlags4=0
   local Track_TrackGroupFlags5=0
   local Track_TrackGroupFlags6=0
   local Track_TrackGroupFlags7=0
   local Track_TrackGroupFlags8=0
   local Track_TrackGroupFlags9=0
   local Track_TrackGroupFlags10=0
   local Track_TrackGroupFlags11=0
   local Track_TrackGroupFlags12=0
   local Track_TrackGroupFlags13=0
   local Track_TrackGroupFlags14=0
   local Track_TrackGroupFlags15=0
   local Track_TrackGroupFlags16=0
   local Track_TrackGroupFlags17=0
   local Track_TrackGroupFlags18=0
   local Track_TrackGroupFlags19=0
   local Track_TrackGroupFlags20=0
   local Track_TrackGroupFlags21=0
   local Track_TrackGroupFlags22=0
   local Track_TrackGroupFlags23=0

local Track_TrackGroupFlags=str:match("GROUP_FLAGS.-%c") 
  if Track_TrackGroupFlags==nil then return -1 end
  Track_TrackGroupFlags=Track_TrackGroupFlags:sub(13,-1)
--  reaper.MB(Track_TrackGroupFlags,"",0)
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags1=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags2=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags3=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags4=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags5=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags6=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags7=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags8=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags9=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags10=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags11=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags12=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags13=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags14=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags15=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags16=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags17=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags18=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags19=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags20=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags21=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags22=Track_TrackGroupFlags:match("%d*") Track_TrackGroupFlags=Track_TrackGroupFlags:match(".(%s.*)") if Track_TrackGroupFlags:len()-1>0 then Track_TrackGroupFlags=Track_TrackGroupFlags:sub(2,-1) else Track_TrackGroupFlags=nil end end
  if Track_TrackGroupFlags~=nil then  Track_TrackGroupFlags23=Track_TrackGroupFlags end
  if tonumber(Track_TrackGroupFlags1)>=1 then retval=retval+2^0 Tracktable[0]=tonumber(Track_TrackGroupFlags1) else Tracktable[0]=0 end
  if tonumber(Track_TrackGroupFlags2)>=1 then retval=retval+2^1 Tracktable[1]=tonumber(Track_TrackGroupFlags2) else Tracktable[1]=0 end
  if tonumber(Track_TrackGroupFlags3)>=1 then retval=retval+2^2 Tracktable[2]=tonumber(Track_TrackGroupFlags3) else Tracktable[2]=0 end
  if tonumber(Track_TrackGroupFlags4)>=1 then retval=retval+2^3 Tracktable[3]=tonumber(Track_TrackGroupFlags4) else Tracktable[3]=0 end
  if tonumber(Track_TrackGroupFlags5)>=1 then retval=retval+2^4 Tracktable[4]=tonumber(Track_TrackGroupFlags5) else Tracktable[4]=0 end
  if tonumber(Track_TrackGroupFlags6)>=1 then retval=retval+2^5 Tracktable[5]=tonumber(Track_TrackGroupFlags6) else Tracktable[5]=0 end
  if tonumber(Track_TrackGroupFlags7)>=1 then retval=retval+2^6 Tracktable[6]=tonumber(Track_TrackGroupFlags7) else Tracktable[6]=0 end
  if tonumber(Track_TrackGroupFlags8)>=1 then retval=retval+2^7 Tracktable[7]=tonumber(Track_TrackGroupFlags8) else Tracktable[7]=0 end
  if tonumber(Track_TrackGroupFlags9)>=1 then retval=retval+2^8 Tracktable[8]=tonumber(Track_TrackGroupFlags9) else Tracktable[8]=0 end
  if tonumber(Track_TrackGroupFlags10)>=1 then retval=retval+2^9 Tracktable[9]=tonumber(Track_TrackGroupFlags10) else Tracktable[9]=0 end
  if tonumber(Track_TrackGroupFlags11)>=1 then retval=retval+2^10 Tracktable[10]=tonumber(Track_TrackGroupFlags11) else Tracktable[10]=0 end
  if tonumber(Track_TrackGroupFlags12)>=1 then retval=retval+2^11 Tracktable[11]=tonumber(Track_TrackGroupFlags12) else Tracktable[11]=0 end
  if tonumber(Track_TrackGroupFlags13)>=1 then retval=retval+2^12 Tracktable[12]=tonumber(Track_TrackGroupFlags13) else Tracktable[12]=0 end
  if tonumber(Track_TrackGroupFlags14)>=1 then retval=retval+2^13 Tracktable[13]=tonumber(Track_TrackGroupFlags14) else Tracktable[13]=0 end
  if tonumber(Track_TrackGroupFlags15)>=1 then retval=retval+2^14 Tracktable[14]=tonumber(Track_TrackGroupFlags15) else Tracktable[14]=0 end
  if tonumber(Track_TrackGroupFlags16)>=1 then retval=retval+2^15 Tracktable[15]=tonumber(Track_TrackGroupFlags16) else Tracktable[15]=0 end
  if tonumber(Track_TrackGroupFlags17)>=1 then retval=retval+2^16 Tracktable[16]=tonumber(Track_TrackGroupFlags17) else Tracktable[16]=0 end
  if tonumber(Track_TrackGroupFlags18)>=1 then retval=retval+2^17 Tracktable[17]=tonumber(Track_TrackGroupFlags18) else Tracktable[17]=0 end
  if tonumber(Track_TrackGroupFlags19)>=1 then retval=retval+2^18 Tracktable[18]=tonumber(Track_TrackGroupFlags19) else Tracktable[18]=0 end
  if tonumber(Track_TrackGroupFlags20)>=1 then retval=retval+2^19 Tracktable[19]=tonumber(Track_TrackGroupFlags20) else Tracktable[19]=0 end
  if tonumber(Track_TrackGroupFlags21)>=1 then retval=retval+2^20 Tracktable[20]=tonumber(Track_TrackGroupFlags21) else Tracktable[20]=0 end
  if tonumber(Track_TrackGroupFlags22)>=1 then retval=retval+2^21 Tracktable[21]=tonumber(Track_TrackGroupFlags22) else Tracktable[21]=0 end
  if tonumber(Track_TrackGroupFlags23)>=1 then retval=retval+2^22 Tracktable[22]=tonumber(Track_TrackGroupFlags23) else Tracktable[22]=0 end
  --reaper.MB(retval,"",0)
--  ultraschall.ExportValueToFile("c:\\testomat2",str)
  return retval, Tracktable
end

--B=2^22
--A,A1=ultraschall.GetTrackGroupFlagsState(0)
--A=2^2

-- GROUP_FLAGS 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 1 1

function ultraschall.GetTrackLockState(tracknumber)
-- Get the state of, if the track has locked controls(1) or not(0)
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
--  Track_PeakCol=str:match("PEAKCOL.-%a") Track_PeakCol=Track_PeakCol:sub(9,-2)
    local Track_Name=str:match("LOCK.-%c.*TRACKHEIGHT")
    if Track_Name~=nil then Track_Name=Track_Name:sub(6,-1)
    Track_Name=Track_Name:match("%d") 
    else Track_Name=0 
    end
   --ultraschall.ExportOutputTo("c:\\testomat2",str)
  return tonumber(Track_Name)
end

--A=ultraschall.GetTrackLockState(0)

function ultraschall.GetTrackLayoutNames(tracknumber)
-- Get the state of the current TrackLayout-names. Returns the name of the current 
-- TCP and the current MCP-layout or nil if default is selected.
  if tonumber(tracknumber)==nil then return nil end
  local tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  local Track_LayoutTCP=nil
  local Track_LayoutMCP=nil
  
--  Track_PeakCol=str:match("PEAKCOL.-%a") Track_PeakCol=Track_PeakCol:sub(9,-2)
    local Track_Layout=str:match("LAYOUTS.-%c")
    if Track_Layout~=nil then Track_Layout=Track_Layout:sub(9,-2)
      if Track_Layout:sub(1,1)=="\"" then 
        Track_LayoutTCP=Track_Layout:match("\".-\"")
        Track_LayoutTCP=Track_LayoutTCP:sub(2,-2)
      end
      if Track_Layout:sub(-1,-1)=="\"" then 
        Track_LayoutMCP=Track_Layout:match(".*(\".-\")")
        Track_LayoutMCP=Track_LayoutMCP:sub(2,-2)
      end
      if Track_LayoutTCP==nil then Track_LayoutTCP=Track_Layout:match(".-%s") Track_LayoutTCP=Track_LayoutTCP:sub(1,-2)end
      if Track_LayoutMCP==nil then Track_LayoutMCP=Track_Layout:match(".*(%s.*)") Track_LayoutMCP=Track_LayoutMCP:sub(2,-1)end
            

    end
  -- ultraschall.ExportOutputTo("c:\\testomat2",str)
  return Track_LayoutTCP, Track_LayoutMCP
end

--A,AA=ultraschall.GetTrackLayoutsState(0)

function ultraschall.GetTrackAutomodeState(tracknumber)
-- returns current state of Automation-Mode
-- 0 - trim/read, 1 - read, 2 - touch, 3 - write, 4 - latch

  if tonumber(tracknumber)==nil then return nil end
  local tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
   local Track_Automode=str:match("AUTOMODE.-%c") Track_Automode=Track_Automode:sub(9,-2)
  return tonumber(Track_Automode)
end

--A=ultraschall.GetTrackAutomodeState(0)

function ultraschall.GetTrackIcon_Filename(tracknumber)
-- Get the path and filename of the current track-icon
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
--  Track_PeakCol=str:match("PEAKCOL.-%a") Track_PeakCol=Track_PeakCol:sub(9,-2)
    local Track_Image=str:match("TRACKIMGFN.-%c")
    if Track_Image~=nil then Track_Image=Track_Image:sub(13,-3)
    end
   --ultraschall.ExportOutputTo("c:\\testomat2",str)
  return Track_Image
end

--A,A2=ultraschall.GetTrackIcon_Filename(0)

function ultraschall.GetTrackRecCFG(tracknumber)
  --returns the Rec-configuration-string, with which recordings are made
  --
  --tracknumber - the number of the track
  --cfg_nr - the number of the reccfg, beginning with 0(there can be more than one)
  if tonumber(tracknumber)==nil then return nil end
  local tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  reaper.ShowConsoleMsg(str)
--  local RECCFGNR=str:match("<RECCFG ("..cfg_nr..")%c")
  local RECCFGNR=str:match("<RECCFG (.-)%c")
  if RECCFGNR==nil then return nil end
  local RECCFG=str:match("<RECCFG.-%c(.-)%c")
  
  return RECCFG
end

--A=ultraschall.GetTrackRecCFG(0)

function ultraschall.GetTrackMidiInputChanMap(tracknumber)
--returns the Midi Input Channel Map-state or nil, if not existing
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
--  Track_PeakCol=str:match("PEAKCOL.-%a") Track_PeakCol=Track_PeakCol:sub(9,-2)
  local Track_MidiChanMap=str:match("MIDI_INPUT_CHANMAP (.-)%c")
  return tonumber(Track_MidiChanMap)
end

--A=ultraschall.GetTrackMidiInputChanMap(0)

function ultraschall.GetTrackMidiCTL(tracknumber)
--returns the Midi CTL-state, or nil if not existing
-- returns LinkedToMidiChannel, unknown value
  if tonumber(tracknumber)==nil then return nil end
  tracknumber=tonumber(tracknumber)
  if tracknumber<0 then return nil end
  if tracknumber>reaper.CountTracks()-1 then return nil end
  local MediaTrack=reaper.GetTrack(0, tracknumber)
  local retval, str = reaper.GetTrackStateChunk(MediaTrack, "test", false)
  
--  Track_PeakCol=str:match("PEAKCOL.-%a") Track_PeakCol=Track_PeakCol:sub(9,-2)
  local Track_LinkedToMidiChannel=str:match("MIDICTL (.-)%s.-%c")
  local Track_unknown=str:match("MIDICTL .-%s(.-)%c")
  return tonumber(Track_LinkedToMidiChannel), tonumber(Track_unknown)
end

--A,A2=ultraschall.GetTrackMidiCTL(0)

--------------------------
---- Set Track States ----
--------------------------

function ultraschall.SetTrackName(tracknumber, name)
--Sets Name of the Track
-- tracknumber - counted from 0
-- name - new name of the track
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  local str="NAME \""..name.."\""
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)NAME")
  local B3=AA:match("NAME.-%c(.*)")

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackName(0,"testofon66")

function ultraschall.SetTrackPeakColorState(tracknumber, colorvalue)
--Sets Color of the Track
-- tracknumber - counted from 0
-- colorvalue - a colorvalue that colors this track
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(colorvalue)==nil then return false end
  local str="PEAKCOL "..colorvalue
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)PEAKCOL")
  local B3=AA:match("PEAKCOL.-%c(.*)")

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackPeakColorState(0,"9999999")

function ultraschall.SetTrackBeatState(tracknumber, beatstate)
--Sets BEAT of a track.
-- tracknumber - counted from 0
-- beatstate - tracktimebase for this track; -1 - Project time base, 0 - Time, 1 - Beats position, length, rate, 2 - Beats position only
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(beatstate)==nil then return false end
  local str="BEAT "..beatstate
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)BEAT")
  local B3=AA:match("BEAT.-%c(.*)")

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackBeatState(0,-1)

function ultraschall.SetTrackAutoRecArmState(tracknumber, autorecarmstate)
--Sets Autorecarmstate of the Track
-- tracknumber - counted from 0
-- autorecarmstate - 1 - autorecarm on, <> than 1 - off
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(autorecarmstate)==nil then return false end
  local str=""
  if tonumber(autorecarmstate)==1 then str="AUTO_RECARM "..autorecarmstate end
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)AUTO_RECARM")
  local B3=AA:match("AUTO_RECARM.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
  -- reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackAutoRecArmState(0,0)

function ultraschall.SetTrackMuteSoloState(tracknumber, Mute, Solo, SoloDefeat)
--Sets Mute, Solo and SoloDefeat of the Track
-- tracknumber - counted from 0
-- Mute - 0 - Mute off, <> than 0 - on
-- Solo - 0 - off, <> than 0 - on
-- Solo Defeat - 0 - off, <> than 0 - on
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(Mute)==nil then return false end
  if tonumber(Solo)==nil then return false end
  if tonumber(SoloDefeat)==nil then return false end
  local str="MUTESOLO "..Mute.." "..Solo.." "..SoloDefeat
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)MUTESOLO")
  local B3=AA:match("MUTESOLO.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackMuteSoloState(0,0,0,0)

function ultraschall.SetTrackIPhaseState(tracknumber, iphasestate)
--Sets IPhase, the Phase-Buttonstate of the Track
-- tracknumber - counted from 0
-- iphasestate - 0 - off, <> than 0 - on
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(iphasestate)==nil then return false end
  local str="IPHASE "..iphasestate
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)IPHASE")
  local B3=AA:match("IPHASE.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
--  reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackIPhaseState(0,0)

function ultraschall.SetTrackIsBusState(tracknumber, busstate1, busstate2)
--Sets ISBUS-state of the Track, if it's a folder track
-- tracknumber - counted from 0
-- track is no folder: busstate1=0, busstate2=0
-- track is a folder: busstate1=1, busstate2=1
-- track is a folder but view of all subtracks not compactible: busstate1=1, busstate2=2
-- track is last track in folder(no tracks of subfolders follow): busstate1=2, busstate2=-1  
  
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(busstate1)==nil then return false end
  if tonumber(busstate2)==nil then return false end
  local str="ISBUS "..busstate1.." "..busstate2
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)ISBUS")
  local B3=AA:match("ISBUS.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackIsBusState(0,0,0)

function ultraschall.SetTrackBusCompState(tracknumber, buscompstate1, buscompstate2)
--Sets BUSCOMP-state of the Track, if tracks in a folder are compacted or not
-- tracknumber - counted from 0
-- BusCompState1:
-- 0 - no compacting
-- 1 - compacted tracks
-- 2 - minimized tracks

-- BusCompState2:
-- 0 - unknown
-- 1 - unknown  
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(buscompstate1)==nil then return false end
  if tonumber(buscompstate2)==nil then return false end
  local str="BUSCOMP "..buscompstate1.." "..buscompstate2
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)BUSCOMP")
  local B3=AA:match("BUSCOMP.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackBusCompState(0,0,0)

function ultraschall.SetTrackShowInMixState(tracknumber, MCPvisible, MCP_FX_visible, MCP_TrackSendsVisible, TCPvisible, ShowInMix5, ShowInMix6, ShowInMix7, ShowInMix8)
-- Sets SHOWINMIX, that sets visibility of track in MCP and TCP
-- MCPvisible - 0 invisible, 1 visible
-- MCP_FX_visible - 0 visible, 1 FX-Parameters visible, 2 invisible
-- MCPTrackSendsVisible - 0 & 1.1 and higher TrackSends in MCP visible, every other number makes them invisible
-- TCPvisible - 0 track is invisible in TCP, 1 track is visible in TCP
-- ShowInMix5 - unknown
-- ShowInMix6 - unknown
-- ShowInMix7 - unknown
-- ShowInMix8 - unknown

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(MCPvisible)==nil then return false end
  if tonumber(MCP_FX_visible)==nil then return false end
  if tonumber(MCP_TrackSendsVisible)==nil then return false end
  if tonumber(TCPvisible)==nil then return false end
  if tonumber(ShowInMix5)==nil then return false end
  if tonumber(ShowInMix6)==nil then return false end
  if tonumber(ShowInMix7)==nil then return false end
  if tonumber(ShowInMix8)==nil then return false end
  local str="SHOWINMIX "..MCP_FX_visible.." "..MCP_FX_visible.." "..MCP_TrackSendsVisible.." "..TCPvisible.." "..ShowInMix5.." "..ShowInMix6.." "..ShowInMix7.." "..ShowInMix8
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)SHOWINMIX")
  local B3=AA:match("SHOWINMIX.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
  --reaper.ShowConsoleMsg(AA)
  return B
end


--ATA=ultraschall.SetTrackShowInMixState(0,1,1,1,1,1,1,1,1)

function ultraschall.SetTrackFreeModeState(tracknumber, freemodestate)
--Sets FREEMODE-State of the track
-- tracknumber - counted from 0
-- freemodestate- 0 - off, 1 - on
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(freemodestate)==nil then return false end
  local str="FREEMODE "..freemodestate
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)FREEMODE")
  local B3=AA:match("FREEMODE.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackFreeModeState(0,1)

function ultraschall.SetTrackRecState(tracknumber, ArmState, InputChannel, MonitorInput, RecInput, MonitorWhileRec, presPDCdelay, RecordingPath)
-- sets REC-State
-- tracknumber - counted from 0
--[[
ArmState - returns 1(armed) or 0(unarmed)

InputChannel - returns the InputChannel
-1 - No Input
1-16(more?) - Mono Input Channel
1024 - Stereo Channel 1 and 2
1026 - Stereo Channel 3 and 4
1028 - Stereo Channel 5 and 6
...
5056 - Virtual MIDI Keyboard all Channels
5057 - Virtual MIDI Keyboard Channel 1
...
5072 - Virtual MIDI Keyboard Channel 16
5088 - All MIDI Inputs - All Channels
5089 - All MIDI Inputs - Channel 1
...
5104 - All MIDI Inputs - Channel 16

Monitor Input - 0 monitor off, 1 monitor on, 2 monitor on tape audio style

RecInput - returns rec-input type
0 input(Audio or Midi), 
1 Record Output Stereo
2 Disabled, Input Monitoring Only
3 Record Output Stereo, Latency Compensated
4 Record Output MIDI
5 Record Output Mono
6 Record Output Mono, Latency Compensated
7 MIDI overdub, 
8 MIDI replace, 
9 MIDI touch replace, 
10 Record Output Multichannel
11 Record Output Multichannel, Latency Compensated 
12 Record Input Force Mono
13 Record Input Force Stereo
14 Record Input Force Multichannel
15 Record Input Force MIDI
16 MIDI latch replace

MonitorWhileRec - Monitor Trackmedie when recording, 0 is off, 1 is on

presPDCdelay - preserve PDC delayed monitoring in media items

RecordingPath - 0 Primary Recording-Path only, 1 Secondary Recording-Path only, 2 Primary Recording Path and Secondary Recording Path(for invisible backup)]]--

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(ArmState)==nil then return false end
  if tonumber(InputChannel)==nil then return false end
  if tonumber(MonitorInput)==nil then return false end
  if tonumber(RecInput)==nil then return false end
  if tonumber(MonitorWhileRec)==nil then return false end
  if tonumber(presPDCdelay)==nil then return false end
  if tonumber(RecordingPath)==nil then return false end
  local str="REC "..ArmState.." "..InputChannel.." "..MonitorInput.." "..RecInput.." "..MonitorWhileRec.." "..presPDCdelay.." "..RecordingPath
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)REC")
  local B3=AA:match("REC.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ShowConsoleMsg(AA)
  return B
end


--ATA=ultraschall.SetTrackRecState(0,0,1,1,1,1,1,1)


function ultraschall.SetTrackVUState(tracknumber, VUState)
--Sets VU-State
-- tracknumber - counted from 0
-- VUState - 0 if MultiChannelMetering is off, 2 if MultichannelMetering is on, 3 Metering is off
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(VUState)==nil then return false end
  local str="VU "..VUState
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)VU")
  local B3=AA:match("VU.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackVUState(0,0)

function ultraschall.SetTrackHeightState(tracknumber, heightstate1, heightstate2)
-- sets TRACKHEIGHT
-- tracknumber - number of the track, starting by 0
-- heightstate1 - 24 up to 443
-- heightstate2 - 0 - use height, 1 - compact the track and ignore the height
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(heightstate1)==nil then return false end
  if tonumber(heightstate2)==nil then return false end
  local str="TRACKHEIGHT "..heightstate1.." "..heightstate2
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)TRACKHEIGHT")
  local B3=AA:match("TRACKHEIGHT.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ShowConsoleMsg(AA)
  return B
end

--ultraschall.SetTrackHeightState(0, 120, 0)

function ultraschall.SetTrackINQState(tracknumber, INQ1, INQ2, INQ3, INQ4, INQ5, INQ6, INQ7, INQ8)
-- sets INQ
-- tracknumber - number of the track, starting by 0
-- INQ1 - unknown
-- INQ2 - unknown
-- INQ3 - unknown
-- INQ4 - unknown
-- INQ5 - unknown
-- INQ6 - unknown
-- INQ7 - unknown
-- INQ8 - unknown
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(INQ1)==nil then return false end
  if tonumber(INQ2)==nil then return false end
  if tonumber(INQ3)==nil then return false end
  if tonumber(INQ4)==nil then return false end
  if tonumber(INQ5)==nil then return false end
  if tonumber(INQ6)==nil then return false end
  if tonumber(INQ7)==nil then return false end
  if tonumber(INQ8)==nil then return false end
  local str="INQ "..INQ1.." "..INQ2.." "..INQ3.." "..INQ4.." "..INQ5.." "..INQ6.." "..INQ7.." "..INQ8
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)INQ")
  local B3=AA:match("INQ.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackINQState(0, 1000,1000,1000,100,2000,2000,2000,200)


function ultraschall.SetTrackNChansState(tracknumber, NChans)
--Sets NCHANS, the number of channels for this track, as set in the routing
-- tracknumber - counted from 0
-- NChans - 2 to 64, counted every second channel (2,4,6,8,etc) with stereo-tracks. Unknown, if Multichannel and Mono-tracks count differently
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(NChans)==nil then return false end
  local str="NCHAN "..NChans
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)NCHAN")
  local B3=AA:match("NCHAN.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackNChansState(0,9)



function ultraschall.SetTrackBypFXState(tracknumber, FXBypassState)
--Sets FX, FX-Bypass-state
-- tracknumber - counted from 0
-- FXBypassState - 0 bypass, 1 activate fx; has only effect, if FX or instruments are added to this track
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(FXBypassState)==nil then return false end
  local str="FX "..FXBypassState
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)FX")
  local B3=AA:match("FX.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackBypFXState(0,0)

function ultraschall.SetTrackPerfState(tracknumber, Perf)
--Sets PERF, TrackPerformance-State
-- tracknumber - counted from 0
-- Perf - 0 - allow anticipative FX + allow media buffering<br>
-- 1 - allow anticipative FX + prevent media buffering <br>
-- 2 - prevent anticipative FX + allow media buffering<br>
-- 3 - prevent anticipative FX + prevent media buffering<br>
--settings seem to repeat with higher numbers (e.g. 4(like 0) - allow anticipative FX + allow media buffering), but to be safe keep it between 0 and 3

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(Perf)==nil then return false end
  local str="PERF "..Perf
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)PERF")
  local B3=AA:match("PERF.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
--  reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackPerfState(0,0)

function ultraschall.SetTrackMIDIOutState(tracknumber, MIDIOutState)
--Sets MIDIOut-State
-- tracknumber - counted from 0
-- MIDIOutState - 
--  -1 no output
-- 416 - microsoft GS wavetable synth - send to original channels
-- 417-432 - microsoft GS wavetable synth - send to channel state minus 416
-- -31 - no Output, send to original channel 1
-- -16 - no Output, send to original channel 16

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(MIDIOutState)==nil then return false end
  local str="MIDIOUT "..MIDIOutState
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)MIDIOUT")
  local B3=AA:match("MIDIOUT.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackMIDIOutState(0,-1)


function ultraschall.SetTrackMainSendState(tracknumber, MainSendOn, ParentChannels)
-- sets MAINSEND-state
-- tracknumber - number of the track, starting by 0
-- MainSendOn - on(1) or off(0)
-- ParentChannels - the ParentChannels(0-64), interpreted as beginning with ParentChannels to ParentChannels+NCHAN
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(MainSendOn)==nil then return false end
  if tonumber(ParentChannels)==nil then return false end
  local str="MAINSEND "..MainSendOn.." "..ParentChannels
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)MAINSEND")
  local B3=AA:match("MAINSEND.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
  --reaper.ShowConsoleMsg(AA)
  return B
end

--A=ultraschall.SetTrackMainSendState(0, 1, 2)

function ultraschall.SetTrackLockState(tracknumber, LockedState)
--Sets LOCK-State, as set by the menu entry Lock Track Controls
-- tracknumber - counted from 0
-- LockedState - 1 - locked, 0 - unlocked

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(LockedState)==nil then return false end
  local str="LOCK "..LockedState
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)LOCK")
  local B3=AA:match("LOCK.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
--  reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackLockedState(0,0)

function ultraschall.SetTrackLayoutNames(tracknumber, TCP_Layoutname, MCP_Layoutname)
--Sets LAYOUTS, the MCP and TCP-layout by name of the layout as defined in the theme.
-- tracknumber - counted from 0
-- TCP_Layoutname - name of the TrackControlPanel-Layout from the theme to use
-- MCP_Layoutname - name of the MixerControlPanel-Layout from the theme to use
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if TCP_Layoutname==nil then TCP_Layoutname="" end
  if MCP_Layoutname==nil then MCP_Layoutname="" end
  local str="LAYOUTS \""..TCP_Layoutname.."\" \""..MCP_Layoutname.."\""
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)LAYOUTS")
  local B3=AA:match("LAYOUTS.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
  --reaper.ShowConsoleMsg(AA)
  return B
end

--A=ultraschall.SetTrackLayoutName(0,"Ultraschall 2",nil)


function ultraschall.SetTrackAutomodeState(tracknumber, automodestate)
--Sets Automode-State, as set by the menu entry Set Track Automation Mode
-- tracknumber - counted from 0
-- automodestate - 0 - trim/read, 1 - read, 2 - touch, 3 - write, 4 - latch.

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(automodestate)==nil then return false end
  local str="AUTOMODE "..automodestate
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)AUTOMODE")
  local B3=AA:match("AUTOMODE.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
--  reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackAutomodeState(0,0)

function ultraschall.SetTrackIcon_Filename(tracknumber, Iconfilename_with_path)
--Sets TRACKIMGFN, the trackicon-filename
-- tracknumber - counted from 0
-- Iconfilename_with_path - filename with path

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if Iconfilename_with_path==nil then Iconfilename_with_path="" end
  local str="TRACKIMGFN \""..Iconfilename_with_path.."\""
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)TRACKIMGFN")
  local B3=AA:match("TRACKIMGFN.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
--  reaper.ShowConsoleMsg(AA)
  return B
end


--A=ultraschall.SetTrackIcon_Filename(0,"c:\\us.png")


function ultraschall.SetTrackMidiInputChanMap(tracknumber, InputChanMap)
--Sets MIDI_INPUT_CHANMAP, as set in the Input-MIDI->Map Input to Channel menu.
-- tracknumber - counted from 0
-- InputChanMap - 0 for channel 1, 2 for channel 2, etc. -1 if not existing.

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(InputChanMap)==nil then return false end
  local str="MIDI_INPUT_CHANMAP "..InputChanMap
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)MIDI_INPUT_CHANMAP")
  local B3=AA:match("MIDI_INPUT_CHANMAP.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
  --reaper.ShowConsoleMsg(AA)
  return B
end

--ATA=ultraschall.SetTrackMidiInputChanMap(0,-1)


function ultraschall.SetTrackMidiCTL(tracknumber, LinkedToMidiChannel, unknown)
-- sets MIDICTL-state
-- tracknumber - number of the track, starting by 0
-- Parameters:
-- LinkedToMidiChannel
-- unknown - ?
  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if tonumber(LinkedToMidiChannel)==nil then return false end
  if tonumber(unknown)==nil then return false end
  local str="MIDICTL "..LinkedToMidiChannel.." "..unknown
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)MIDICTL")
  local B3=AA:match("MIDICTL.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ShowConsoleMsg(AA)
  return B
end

--A=ultraschall.SetTrackMidiCTL(0, -1, -1)


function ultraschall.SetTrackMIDIColorMapFn(tracknumber, Colormapfilename_with_path)
--TODO - GetTrackMIDICOlorMapFn() and ... what the heck does this function?
--Sets MIDICOLORMAPFN
-- tracknumber - counted from 0
-- Colormapfilename_with_path - filename with path

  if tonumber(tracknumber)==nil then return false end
  if tonumber(tracknumber)<0 then return false end
  tracknumber=tonumber(tracknumber)
  if Colormapfilename_with_path==nil then Colormapfilename_with_path="" end
  local str="MIDICOLORMAPFN \""..Colormapfilename_with_path.."\""
  local Mediatrack=reaper.GetTrack(0,tracknumber)
  local A,AA=reaper.GetTrackStateChunk(Mediatrack,str,false)

  local B1=AA:match("(.-)MIDICOLORMAPFN")
  local B3=AA:match("MIDICOLORMAPFN.-%c(.*)")
  if B1==nil then B1=AA:match("(.-TRACK)") B3=AA:match(".-TRACK(.*)") end

  local B=reaper.SetTrackStateChunk(Mediatrack,B1.."\n"..str.."\n"..B3,false)
--  reaper.ClearConsole()
  --reaper.ShowConsoleMsg(AA)
  return B
end

--A=ultraschall.SetTrackMIDIColorMapFn(0, "us.png")


------------------------------
---- Meta Data Management ----
------------------------------

function ultraschall.SetID3TagsForCurrentProject(title, artist, album, track, year, genre, comment, date, involved_people, language, coverfilename_and_path, coverfilename_and_path2, coverfilename_and_path3)
-- sets project-states with the ID3-Tags. Use nil, if you don't want to change an already set ID3-Tag
-- sets the following tags:
-- Title, Artist, Album, Track, Years, Genre, Comment, Date, Involved_People, Language, Coverfilename_And_Path, Cover2filename_And_Path, Cover3filename_And_Path

    if title~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Title", title) end
    if artist~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Artist", artist) end
    if album~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Album", album) end
    if track~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Track", track) end
    if year~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Year", year) end
    if genre~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Genre", genre) end
    if comment~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Comment", comment) end
    if date~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Date", date) end
    if involved_people~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Involved_People", involved_people) end
    if language~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Language", language) end
    if coverfilename_and_path~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Coverfilename_And_Path", coverfilename_and_path) end        
    if coverfilename_and_path2~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Coverfilename_And_Path2", coverfilename_and_path2) end        
    if coverfilename_and_path3~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Coverfilename_And_Path3", coverfilename_and_path3) end        
end

--ultraschall.SetID3TagsForCurrentProject("tit","art","alb","tr","yr","gen","com","dat","inv","lang","coverf1","coverf2","coverf3")

function ultraschall.SetID3TagsForCurrentProject_PodcastTags(podcast, podcast_category, podcast_description, podcast_id, podcast_keywords, podcast_url)
-- sets project-states with the ID3-Tags specifically for Podcasts. Use nil, if you don't want to change an already set ID3-Tag
-- sets the following tags:
--Podcasttags for Podcast, Category, Description, ID, Keywords, URL
    if podcast~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Podcast", podcast) end
    if podcast_category~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Podcast_Category", podcast_category) end
    if podcast_description~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Podcast_Description", podcast_description) end
    if podcast_id~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Podcast_ID", podcast_id) end
    if podcast_keywords~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Podcast_Keywords", podcast_keywords) end
    if podcast_url~=nil then reaper.SetProjExtState(0, "US_ID3_Tags", "Podcast_Url", podcast_url) end
end

--ultraschall.SetID3TagsForCurrentProject_PodcastTags("A","A","A","A","A","A","A","A","A","A","A","A","A")

function ultraschall.GetID3TagsFromCurrentProject()
   --returns project-states with the ID3-Tags for
   -- Title, Artist, Album, Track, Years, Genre, Comment, Date, Involved_People, Language, Coverfilename_And_Path, Cover2filename_And_Path, Cover3filename_And_Path
   --
   -- returns empty string(s) for each ID3-Tag that's unset
    local retval, title=reaper.GetProjExtState(0, "US_ID3_Tags", "Title")
    local retval, artist=reaper.GetProjExtState(0, "US_ID3_Tags", "Artist")
    local retval, album=reaper.GetProjExtState(0, "US_ID3_Tags", "Album")
    local retval, track=reaper.GetProjExtState(0, "US_ID3_Tags", "Track")
    local retval, year=reaper.GetProjExtState(0, "US_ID3_Tags", "Year")
    local retval, genre=reaper.GetProjExtState(0, "US_ID3_Tags", "Genre")
    local retval, comment=reaper.GetProjExtState(0, "US_ID3_Tags", "Comment")
    local retval, date=reaper.GetProjExtState(0, "US_ID3_Tags", "Date")
    local retval, involved_people=reaper.GetProjExtState(0, "US_ID3_Tags", "Involved_People")
    local retval, language=reaper.GetProjExtState(0, "US_ID3_Tags", "Language")
    local retval, coverfilename_and_path=reaper.GetProjExtState(0, "US_ID3_Tags", "Coverfilename_And_Path")
    local retval, coverfilename_and_path2=reaper.GetProjExtState(0, "US_ID3_Tags", "Coverfilename_And_Path2")
    local retval, coverfilename_and_path3=reaper.GetProjExtState(0, "US_ID3_Tags", "Coverfilename_And_Path3")
    return title, artist, album, track, year, genre, comment, date, involved_people, language, coverfilename_and_path, coverfilename_and_path2, coverfilename_and_path3
end

--A,B,C,D,E,F,G,H,I,J,K=ultraschall.GetID3TagsFromCurrentProject()

function ultraschall.GetID3TagsFromCurrentProject_PodcastTags()
  --returns returns project-states with the ID3-tags specifically for podcasts for 
  -- Podcast, Category, Description, ID, Keywords, URL
  --
  -- returns empty string(s) for each ID3-Tag that's unset

    local retval, podcast=reaper.GetProjExtState(0, "US_ID3_Tags", "Podcast")
    local retval, podcast_category=reaper.GetProjExtState(0, "US_ID3_Tags", "Podcast_Category")
    local retval, podcast_description=reaper.GetProjExtState(0, "US_ID3_Tags", "Podcast_Description")
    local retval, podcast_id=reaper.GetProjExtState(0, "US_ID3_Tags", "Podcast_ID")
    local retval, podcast_keywords=reaper.GetProjExtState(0, "US_ID3_Tags", "Podcast_Keywords")
    local retval, podcast_url=reaper.GetProjExtState(0, "US_ID3_Tags", "Podcast_Url")
    return podcast, podcast_category, podcast_description, podcast_id, podcast_keywords, podcast_url
end

--ultraschall.SetID3TagsForProject("Mach den Affen weg","FreakShow","FreakShowAlbum","76","2011","techtalk","Kommentare","march2011","tim,hukl,dennis,roddi","german","c:\\freakshow.png", "cover2", "cover3")
--ultraschall.SetID3TagsForProject_PodcastTags("podcast", "podcast_category","podcast_description","podcast_id","podcast_keywords","podcast_url")
--ultraschall.SetID3TagsForProject_PodcastTags("a","b","c","d","e","f")
--a,b,c,d,e,f,g,h,i,j,k,l,m=ultraschall.GetID3TagsFromCurrentProject_PodcastTags()
--reaper.ShowConsoleMsg(a.."."..b.."."..c.."."..d.."."..e.."."..f.." end\n")
--if a=="" then reaper.MB("nilalarm","",0) end



--------------------
---- Navigation ----
--------------------

function ultraschall.ToggleScrollingDuringPlayback(scrolling_switch, move_editcursor)
-- integer scrolling_switch - 1-on, 0-off
-- integer move_editcursor - when scrolling stops, shall the editcursor be moved to current position of the playcursor(1) or not(0)
-- changes, if necessary, the state of the actions 41817 and 40036
  local Aretval=reaper.GetToggleCommandState(41817)
  local editcursor=reaper.GetCursorPosition()
  local playcursor=reaper.GetPlayPosition()

  if reaper.GetToggleCommandState(40036)~=scrolling_switch then
    reaper.Main_OnCommand(40036,0)
  end

  if reaper.GetToggleCommandState(41817)~=scrolling_switch then
    reaper.Main_OnCommand(41817,0)
  end

  reaper.SetEditCurPos(playcursor, true, false)

  if move_editcursor==1 then
    reaper.SetEditCurPos(playcursor, true, false)
  else
    reaper.SetEditCurPos(editcursor, false, false)
  end

end

--ultraschall.ToggleScrollingDuringPlayback(0,0)

function ultraschall.SetPlayCursor_WhenPlaying(position)--, move_view)--, length_of_view)
-- changes position of the play-cursor, when playing
-- changes view to new playposition
-- has no effect during recording, when paused or stop and returns -1 in these cases!
if reaper.GetPlayState()~=1 then return -1 end
  local editcursor=reaper.GetCursorPosition()
  local playcursor=reaper.GetPlayPosition()
  if move_view==true then move_view=false
  elseif move_view==false then move_viev=true end
  reaper.SetEditCurPos(position, true, true) 
   if reaper.GetPlayState()==2 then
     reaper.Main_OnCommand(1007,0)
     reaper.SetEditCurPos(editcursor, false, false)  
     reaper.Main_OnCommand(1008,0)
--    reaper.SetEditCurPos(editcursor, false, false) 
    else
    reaper.SetEditCurPos(editcursor, false, false)  
    end
end

--    reaper.SetEditCurPos(10, false, false)  
--ultraschall.SetPlayCursor_WhenPlaying(10)

function ultraschall.SetPlayAndEditCursor_WhenPlaying(position)--, move_view)--, length_of_view)
-- changes position of the play-cursor and the edit-cursor, when playing
-- changes view to new playposition
-- has no effect during recording, when paused or stop!
if reaper.GetPlayState()==0 then return -1 end
  local editcursor=reaper.GetCursorPosition()
  local playcursor=reaper.GetPlayPosition()
  if move_view==true then move_view=false
  elseif move_view==false then move_viev=true end
  reaper.SetEditCurPos(position, true, true) 
--  reaper.SetEditCurPos(editcursor, false, false)  
end

--ultraschall.SetPlayAndEditCursor_WhenPlaying(12)

function ultraschall.JumpForwardBy(seconds)
--jumps forward by seconds
-- returns -1 if seconds is invalid or negative
if tonumber(seconds)==nil then return -1 end
seconds=tonumber(seconds)
if seconds<0 then return -1 end
  local editcursor=reaper.GetCursorPosition()
  local playcursor=reaper.GetPlayPosition()
  
  if reaper.GetPlayState()==0 then 
--  reaper.MB("test","",0)
    reaper.SetEditCurPos(editcursor+seconds, true, true) 
    --ultraschall.SetPlayAndCursor_WhenPlaying(reaper.GetPlayPosition()+10,false)--, 10)
  elseif reaper.GetPlayState()==5 or reaper.GetPlayState()==6 then
    reaper.SetEditCurPos(editcursor+seconds, true, true)
  else
    reaper.SetEditCurPos(playcursor+seconds, true, true)
  end
end

--A=ultraschall.JumpForwardBy(1)

function ultraschall.JumpBackwardBy(seconds)
--jumps backwards by seconds
-- returns -1 if seconds is invalid or negative
if tonumber(seconds)==nil then return -1 end
seconds=tonumber(seconds)
if seconds<0 then return -1 end
  local editcursor=reaper.GetCursorPosition()
  local playcursor=reaper.GetPlayPosition()
  
  if reaper.GetPlayState()==0 then 
--  reaper.MB("test","",0)
    reaper.SetEditCurPos(editcursor-seconds, true, true) 
    --ultraschall.SetPlayAndCursor_WhenPlaying(reaper.GetPlayPosition()+10,false)--, 10)
  elseif reaper.GetPlayState()==5 or reaper.GetPlayState()==6 then
    reaper.SetEditCurPos(editcursor-seconds, true, true)
  else
    reaper.SetEditCurPos(playcursor-seconds, true, true)
  end
end

--A=ultraschall.JumpBackwardBy(1)

function ultraschall.JumpForwardBy_Recording(seconds)
--jumps forward by seconds and restarts recording on new position
-- returns -1 if seconds is invalid or negative or if not recording
if tonumber(seconds)==nil then return -1 end
seconds=tonumber(seconds)
if seconds<0 then return -1 end
  local editcursor=reaper.GetCursorPosition()
  local playcursor=reaper.GetPlayPosition()
  
  if reaper.GetPlayState()==5 then 
    reaper.Main_OnCommand(1016,0)
    reaper.SetEditCurPos(playcursor+seconds, true, true) 
    reaper.Main_OnCommand(1013,0)
  elseif reaper.GetPlayState()==6 then
    reaper.Main_OnCommand(1016,0)
    reaper.SetEditCurPos(playcursor+seconds, true, true) 
    reaper.Main_OnCommand(1013,0)
    reaper.Main_OnCommand(1008,0)    
  else
    return -1
  end
end

--A=ultraschall.JumpForwardBy_Recording(5)

function ultraschall.JumpBackwardBy_Recording(seconds)
--jumps forward by seconds and restarts recording on new position
-- returns -1 if seconds is invalid or negative or if not recording
if tonumber(seconds)==nil then return -1 end
seconds=tonumber(seconds)
if seconds<0 then return -1 end
  local editcursor=reaper.GetCursorPosition()
  local playcursor=reaper.GetPlayPosition()
  
  if reaper.GetPlayState()==5 then 
    reaper.Main_OnCommand(1016,0)
    reaper.SetEditCurPos(playcursor-seconds, true, true) 
    reaper.Main_OnCommand(1013,0)
  elseif reaper.GetPlayState()==6 then
    reaper.Main_OnCommand(1016,0)
    reaper.SetEditCurPos(playcursor-seconds, true, true) 
    reaper.Main_OnCommand(1013,0)
    reaper.Main_OnCommand(1008,0)
  else
    return -1
  end
end

--A=ultraschall.JumpBackwardBy_Recording(10)

function ultraschall.GetNextClosestItemEdge(tracks, cursor_type, time_position)
-- returns time and item-object of the next closest item-start or item-end within the chosen tracks, as well as "beg" for begin and "end" for end of the returned item
-- can become slow when having thousands of items
-- string tracks - tracknumbers, separated by a comma. Negative Values will be ignored.
-- integer cursor_type - 0-edit_cursor, 1-play_cursor, 2-mouse-cursor, 3-timeposition
-- number time_position - only when cursor_type=3, else it will be ignored. time_position to check from for the next item.

local cursortime=0
if tonumber(time_position)==nil and reaper.GetPlayState()==0 then
  time_position=reaper.GetCursorPosition()
elseif tonumber(time_position)==nil and reaper.GetPlayState~=0 then
  time_position=reaper.GetPlayPosition()
end
if tonumber(cursor_type)==nil then return -1 end
if tonumber(cursor_type)==0 then cursortime=reaper.GetCursorPosition() end
if tonumber(cursor_type)==1 then cursortime=reaper.GetPlayPosition() end
if tonumber(cursor_type)==2 then 
    reaper.BR_GetMouseCursorContext() 
    cursortime=reaper.BR_GetMouseCursorContext_Position() 
    if cursortime==-1 then return -1 end
end
if tonumber(cursor_type)==3 then
    if tonumber(time_position)==nil then return -1 end
    cursortime=tonumber(time_position)
end
if tonumber(cursor_type)>3 or tonumber(cursor_type)<0 then return -1 end

if tracks==nil then return 0 end
local tracks=tostring(tracks)

local TrackArray = ultraschall.CSV2IndividualLinesAsArray(tracks)

local TrackArray2={}
--for i=0,reaper.CountTracks() do
  for k=0, reaper.CountTracks() do
    if TrackArray[k]~=nil then TrackArray2[tonumber(TrackArray[k])]=TrackArray[k]
--    reaper.MB(tostring(TrackArray[k]),"",0)
    end
  end
--end
local closest_item=reaper.GetProjectLength(0)
local found_item=nil
local position=""
--reaper.MB("","",0)
for i=0, reaper.CountMediaItems(0)-1 do
  for j=0, reaper.CountTracks(0) do

--  reaper.ShowConsoleMsg(tostring(TrackArray2[j]))
  if TrackArray2[j]~=nil and tonumber(tracks)~=-1 then  
  --reaper.MB("hui","",0)
     if ultraschall.IsItemInTrack(j,i)==true then
    local MediaItem=reaper.GetMediaItem(0, i)
    local ItemStart=reaper.GetMediaItemInfo_Value(MediaItem, "D_POSITION")
    local ItemEnd=reaper.GetMediaItemInfo_Value(MediaItem, "D_POSITION")+reaper.GetMediaItemInfo_Value(MediaItem, "D_LENGTH")
    if ItemStart>cursortime and ItemStart<closest_item then
        closest_item=ItemStart
        found_item=MediaItem
        position="beg"
    end
    if ItemEnd>cursortime and ItemEnd<closest_item then
        closest_item=ItemEnd
        position="end"
        found_item=MediaItem
    end
  end
  end
end
end
if found_item~=nil then return closest_item
else return -1
end

end

--A=reaper.CountMediaItems()
--A1,A2,A3=ultraschall.GetNextClosestItemEdge(0,3,222)


function ultraschall.GetPreviousClosestItemEdge(tracks, cursor_type, time_position)
-- returns time and item-object of the previous closest item-start or item-end within the chosen tracks, as well as "beg" for begin and "end" for end of the returned item
-- can become slow when having thousands of items
-- string tracks - tracknumbers, separated by a comma. A single -1 means all tracks. Negative Values will be ignored.
-- integer cursor_type - 0-edit_cursor, 1-play_cursor, 2-mouse-cursor, 3-timeposition
-- number time_position - only when cursor_type=3, else it will be ignored. time_position to check from for the previous item.

local cursortime=0
if tonumber(time_position)==nil and reaper.GetPlayState()==0 then
  time_position=reaper.GetCursorPosition()
elseif tonumber(time_position)==nil and reaper.GetPlayState~=0 then
  time_position=reaper.GetPlayPosition()
end

if tonumber(cursor_type)==nil then return -1 end
if tonumber(cursor_type)==0 then cursortime=reaper.GetCursorPosition() end
if tonumber(cursor_type)==1 then cursortime=reaper.GetPlayPosition() end
if tonumber(cursor_type)==2 then 
    reaper.BR_GetMouseCursorContext() 
    cursortime=reaper.BR_GetMouseCursorContext_Position() 
    if cursortime==-1 then return -1 end
end
if tonumber(cursor_type)==3 then
    if tonumber(time_position)==nil then return -1 end
    cursortime=tonumber(time_position)
end
if tonumber(cursor_type)>3 or tonumber(cursor_type)<0 then return -1 end

if tracks==nil then return 0 end
local tracks=tostring(tracks)

local TrackArray = ultraschall.CSV2IndividualLinesAsArray(tracks)

local TrackArray2={}
--for i=0,reaper.CountTracks() do
  for k=0, reaper.CountTracks() do
    if TrackArray[k]~=nil then TrackArray2[tonumber(TrackArray[k])]=TrackArray[k]
--    reaper.MB(tostring(TrackArray[k]),"",0)
    end
  end
--end

local closest_item=-1
local found_item=nil
local position=""
--reaper.MB("","",0)
for i=0, reaper.CountMediaItems(0)-1 do
  for j=0, reaper.CountTracks(0) do

--  reaper.ShowConsoleMsg(tostring(TrackArray2[j]))
  if TrackArray2[j]~=nil and tonumber(tracks)~=-1 then  
  --reaper.MB("hui","",0)
     if ultraschall.IsItemInTrack(j,i)==true then
    local MediaItem=reaper.GetMediaItem(0, i)
    local Aretval, Astr = reaper.GetItemStateChunk(MediaItem,"<ITEMPOSITION",false)
local ItemStart=reaper.GetMediaItemInfo_Value(MediaItem, "D_POSITION")
local ItemEnd=reaper.GetMediaItemInfo_Value(MediaItem, "D_POSITION")+reaper.GetMediaItemInfo_Value(MediaItem, "D_LENGTH")
--    reaper.MB(ItemEnd.."\n","",0)
    if ItemStart<cursortime and ItemStart>closest_item then
--    reaper.MB("ping","",0)
        closest_item=ItemStart
        found_item=MediaItem
        position="beg"
    end
    if ItemEnd<cursortime and ItemEnd>closest_item then
        closest_item=ItemEnd
        position="end"
        found_item=MediaItem
    end
  end
  end
end
end
if found_item~=nil then return closest_item
else return -1
end

end

--A1,A2,A3=ultraschall.GetPreviousClosestItemEdge("0", 3, 202)

function ultraschall.GetClosestNextMarker(cursor_type, time_position)
-- returns idx, position(in seconds) and name of the next closest marker

local cursortime=0
local retposition=reaper.GetProjectLength(0)--*200000000 --Working Hack, but isn't elegant....
local retindexnumber=-1
local retmarkername=""

if tonumber(time_position)==nil and reaper.GetPlayState()==0 then
  time_position=reaper.GetCursorPosition()
elseif tonumber(time_position)==nil and reaper.GetPlayState~=0 then
  time_position=reaper.GetPlayPosition()
else
  time_position=tonumber(time_position)
end

if tonumber(cursor_type)==nil then return -1 end
if tonumber(cursor_type)==0 then cursortime=reaper.GetCursorPosition() end
if tonumber(cursor_type)==1 then cursortime=reaper.GetPlayPosition() end
if tonumber(cursor_type)==2 then 
    reaper.BR_GetMouseCursorContext() 
    cursortime=reaper.BR_GetMouseCursorContext_Position() 
    if cursortime==-1 then return -1 end
end
if tonumber(cursor_type)==3 then
    if tonumber(time_position)==nil then return -1 end
    cursortime=tonumber(time_position)
end
if tonumber(cursor_type)>3 or tonumber(cursor_type)<0 then return -1 end

local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)

for i=0,retval do
local  retval2, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)

  if isrgn==false then
    if pos>time_position and pos<retposition then
      retposition=pos
      retindexnumber=markrgnindexnumber
      retmarkername=name
    end
  end
end
  return retindexnumber,retposition, retmarkername
end

--A,AA,AAA=ultraschall.GetClosestNextMarker(3,144)

function ultraschall.GetClosestPreviousMarker(cursor_type, time_position)
-- returns idx, position(in seconds) and name of the next closest marker
local cursortime=0
local retposition=0
local retindexnumber=-1
local retmarkername=""

if tonumber(time_position)==nil and reaper.GetPlayState()==0 then
  time_position=reaper.GetCursorPosition()
elseif tonumber(time_position)==nil and reaper.GetPlayState~=0 then
  time_position=reaper.GetPlayPosition()
else
  time_position=tonumber(time_position)
end

if tonumber(cursor_type)==nil then return -1 end
if tonumber(cursor_type)==0 then cursortime=reaper.GetCursorPosition() end
if tonumber(cursor_type)==1 then cursortime=reaper.GetPlayPosition() end
if tonumber(cursor_type)==2 then 
    reaper.BR_GetMouseCursorContext() 
    cursortime=reaper.BR_GetMouseCursorContext_Position() 
    if cursortime==-1 then return -1 end
end
if tonumber(cursor_type)==3 then
    if tonumber(time_position)==nil then return -1 end
    cursortime=tonumber(time_position)
end
if tonumber(cursor_type)>3 or tonumber(cursor_type)<0 then return -1 end

local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)

for i=0,retval do
  local retval2, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)

  if isrgn==false then
    if pos<time_position and pos>retposition then
      retposition=pos
      retindexnumber=markrgnindexnumber
      retmarkername=name
    end
  end
end
  return retindexnumber,retposition, retmarkername

end

--A,AA,AAA=ultraschall.GetClosestPreviousMarker(3,143)

function ultraschall.GetClosestNextRegion(cursor_type, time_position)
-- returns idx, position(in seconds) and name of the next closest marker
local cursortime=0
local retposition=reaper.GetProjectLength()--*200000000 --Working Hack, but isn't elegant....
local retindexnumber=-1
local retmarkername=""

if tonumber(time_position)==nil and reaper.GetPlayState()==0 then
  time_position=reaper.GetCursorPosition()
elseif tonumber(time_position)==nil and reaper.GetPlayState~=0 then
  time_position=reaper.GetPlayPosition()
else
  time_position=tonumber(time_position)
end

if tonumber(cursor_type)==nil then return -1 end
if tonumber(cursor_type)==0 then cursortime=reaper.GetCursorPosition() end
if tonumber(cursor_type)==1 then cursortime=reaper.GetPlayPosition() end
if tonumber(cursor_type)==2 then 
    reaper.BR_GetMouseCursorContext() 
    cursortime=reaper.BR_GetMouseCursorContext_Position() 
    if cursortime==-1 then return -1 end
end
if tonumber(cursor_type)==3 then
    if tonumber(time_position)==nil then return -1 end
    cursortime=tonumber(time_position)
end
if tonumber(cursor_type)>3 or tonumber(cursor_type)<0 then return -1 end

 local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)

for i=0,retval do
   local retval2, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
--reaper.MB(name,tostring(isrgn),0)
  if isrgn==true then
    if pos>time_position and pos<retposition then
      retposition=pos
      retindexnumber=markrgnindexnumber
      retmarkername=name
    end
    if rgnend>time_position and rgnend<retposition then
      retposition=rgnend
      retindexnumber=markrgnindexnumber
      retmarkername=name
    end
  end
end
  return retindexnumber,retposition, retmarkername

end

--A,AA,AAA=ultraschall.GetClosestNextRegion(3,188)

function ultraschall.GetClosestPreviousRegion(cursor_type, time_position)
-- returns idx, position(in seconds) and name of the next closest marker
local cursortime=0
local retposition=0
local retindexnumber=-1
local retmarkername=""

if tonumber(time_position)==nil and reaper.GetPlayState()==0 then
  time_position=reaper.GetCursorPosition()
elseif tonumber(time_position)==nil and reaper.GetPlayState~=0 then
  time_position=reaper.GetPlayPosition()
else
  time_position=tonumber(time_position)
end

if tonumber(cursor_type)==nil then return -1 end
if tonumber(cursor_type)==0 then cursortime=reaper.GetCursorPosition() end
if tonumber(cursor_type)==1 then cursortime=reaper.GetPlayPosition() end
if tonumber(cursor_type)==2 then 
    reaper.BR_GetMouseCursorContext() 
    cursortime=reaper.BR_GetMouseCursorContext_Position() 
    if cursortime==-1 then return -1 end
end
if tonumber(cursor_type)==3 then
    if tonumber(time_position)==nil then return -1 end
    cursortime=tonumber(time_position)
end
if tonumber(cursor_type)>3 or tonumber(cursor_type)<0 then return -1 end

local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)

for i=0,retval do
  local retval2, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)

  if isrgn==true then
    if pos<time_position and pos>retposition then
      retposition=pos
      retindexnumber=markrgnindexnumber
      retmarkername=name
    end
    if rgnend<time_position and rgnend>retposition then
      retposition=rgnend
    end
  end
end
  return retindexnumber,retposition, retmarkername

end

--A,AA,AAA=ultraschall.GetClosestPreviousRegion(3,170)

function ultraschall.GetClosestGoToPoints(tracks, time_position)
-- what are the closest markers/regions/item starts/itemends to position and within the chosen tracks
-- string tracks - tracknumbers, separated by a comma.
-- position - position in seconds
--
-- returns position of previous element, type of the element, elementnumber, position of next element, type of the element, elementnumber
-- positions - in seconds
-- type - can be "Item", "Marker", "Region", "ProjectStart", "ProjectEnd"
-- elementnumber - is either the number of the item or the number of the region/marker, -1 if it's an Item.

--reaper.MB(time_position,"",0)
if tonumber(time_position)==-1 and reaper.GetPlayState()==0 then
  time_position=reaper.GetCursorPosition()
elseif tonumber(time_position)==nil and reaper.GetPlayState()~=0 then
  time_position=reaper.GetPlayPosition()
else
  time_position=tonumber(time_position)
end
--reaper.MB(time_position,"",0)

local elementposition_prev, elementtype_prev, number_prev, elementposition_next, elementtype_next, number_next=nil

local nextmarkerid,nextmarkerpos,nextmarkername=ultraschall.GetClosestNextMarker(3, time_position)
local prevmarkerid,prevmarkerpos,prevmarkername=ultraschall.GetClosestPreviousMarker(3,time_position)

local nextitempos=ultraschall.GetNextClosestItemEdge(tracks,3,time_position)
local previtempos=ultraschall.GetPreviousClosestItemEdge(tracks,3,time_position)

local nextrgnID, nextregion=ultraschall.GetClosestNextRegion(3,time_position)
local prevrgnID, prevregion=ultraschall.GetClosestPreviousRegion(3,time_position)

if nextmarkerpos<nextitempos then elementposition_next=nextmarkerpos elementtype_next="Marker" number_next=nextmarkerid
elseif nextitempos==-1 then elementposition_next=nextmarkerpos elementtype_next="Marker" number_next=nextmarkerid
else elementposition_next=nextitempos elementtype_next="Item" number_next=-1 end

if prevmarkerpos>previtempos then elementposition_prev=prevmarkerpos elementtype_prev="Marker" number_prev=prevmarkerid
else elementposition_prev=previtempos elementtype_prev="Item" number_prev=-1 end

if prevregion>elementposition_prev then elementposition_prev=prevregion elementtype_prev="Region" number_prev=prevrgnID end
if nextregion<elementposition_next then elementposition_next=nextregion elementtype_next="Region" number_next=nextrgnID end

if elementposition_prev<=0 then elementposition_prev=0 elementtype_prev="ProjectStart" end
if elementposition_next>=reaper.GetProjectLength() then elementtype_next="ProjectEnd" end

return elementposition_prev, elementtype_prev, number_prev, elementposition_next, elementtype_next, number_next
end

--Aprev1,Aprev2,Aprev3,Anext1,Anext2,Anext3 = ultraschall.GetClosestGoToPoints(0,20)

-----------------------------
---- Muting/Cough Button ----
-----------------------------

function ultraschall.ToggleMute(track, position, state)
-- state 0=mute, 1=unmute
  if tonumber(track)==nil or tonumber(track)<0 or tonumber(track)>reaper.CountTracks(0)-1 then return -1 end  
  if tonumber(position)==nil or tonumber(position)<0 then return -1 end
  if tonumber(state)==nil or tonumber(state)<0 or tonumber(state)>1 then return -1 end
  
  local Track=reaper.GetTrack(0, track)
  local MuteEnvelopeTrack=reaper.GetTrackEnvelopeByName(Track, "Mute")
  local C=reaper.InsertEnvelopePoint(MuteEnvelopeTrack, position, state, 1, 0, 0)
  reaper.UpdateArrange()
  return 0
end

--ultraschall.ToggleMute(0,reaper.GetPlayPosition(),1)

function ultraschall.ToggleMute_TrackObject(trackobject, position, state)
-- state 0=mute, 1=unmute
-- returns -1 when it didn't work
  if trackobject==nil then return -1 end
  local Aretval=reaper.ValidatePtr2(0, trackobject, "MediaTrack*")
    if Aretval==false then return -1 end
  if tonumber(position)==nil or tonumber(position)<0 then return -1 end
  if tonumber(state)==nil or tonumber(state)<0 or tonumber(state)>1 then return -1 end
  
  local numtracks=reaper.CountTracks(0)-1
  local itworked=-1
  
  for i=0,numtracks do
    if trackobject==reaper.GetTrack(0,i) then 
        local MuteEnvelopeTrack=reaper.GetTrackEnvelopeByName(trackobject, "Mute")
        local C=reaper.InsertEnvelopePoint(MuteEnvelopeTrack, position, state, 1, 0, 0)
        itworked=0
    end
  end
  return itworked
end

--Track=reaper.GetTrack(0, 0)
--A,AA,AAA=ultraschall.ToggleMute_TrackObject(Track,reaper.GetPlayPosition(),0)
--Track="MackieMesser"
--CC=ultraschall.ToggleMute(0,0,1)
--CC=ultraschall.ToggleMute_TrackObject(Track,80,1)

function ultraschall.GetNextMuteState(track, position)
-- returns the next mute-envelope-point, it's value and it's time
-- Envelope-Points numbering starts with 0!
-- returns -1 if not existing
  if tonumber(track)==nil then return -1 end
  if tonumber(position)==nil then return -1 end
  local retval, time, value, shape, tension, selected 
  local MediaTrack=reaper.GetTrack(0, track)
  if MediaTrack==nil then return -1 end
  local TrackEnvelope=reaper.GetTrackEnvelopeByName(MediaTrack, "Mute")
  if TrackEnvelope==nil then return -1 end
  local Ainteger=reaper.GetEnvelopePointByTime(TrackEnvelope, position)
  if Ainteger==-1 then retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(TrackEnvelope, 0) Ainteger=-1
  else retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(TrackEnvelope, Ainteger+1) 
  end
  if Ainteger+1>reaper.CountEnvelopePoints(TrackEnvelope)-1 then return -1 end
  return Ainteger+1, value, time
end

--A,AA,AAA,AAAA=ultraschall.GetNextMuteState(0,reaper.GetPlayPosition())

function ultraschall.GetPreviousMuteState(track, position)
-- returns the previous mute-envelope-point, it's value and it's time
-- Envelope-Points numbering starts with 0!
-- returns -1 if not existing
  if tonumber(track)==nil then return -1 end
  if tonumber(position)==nil then return -1 end
  local MediaTrack=reaper.GetTrack(0, track)
  if MediaTrack==nil then return -1 end
  local TrackEnvelope=reaper.GetTrackEnvelopeByName(MediaTrack, "Mute")
  if TrackEnvelope==nil then return -1 end
  local Ainteger=reaper.GetEnvelopePointByTime(TrackEnvelope, position)
  local retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(TrackEnvelope, Ainteger)
  return Ainteger, value, time
end

--A,AA,AAA,AAAA=ultraschall.GetPreviousMuteState(0,reaper.GetPlayPosition())

function ultraschall.GetNextMuteState_TrackObject(MediaTrack, position)
-- returns the next mute-envelope-point, it's value and it's time
-- Envelope-Points numbering starts with 0!
-- returns -1 if not existing
  if reaper.ValidatePtr2(0, MediaTrack, "MediaTrack*")==false then return -1 end
  local retval, time, value, shape, tension, selected
  if tonumber(position)==nil then return -1 end
  position=tonumber(position)
  if position<0 then return -1 end
  local Aretval=reaper.ValidatePtr2(0, MediaTrack, "MediaTrack*")
  if Aretval==false then return -1 end
  local TrackEnvelope=reaper.GetTrackEnvelopeByName(MediaTrack, "Mute")
  if TrackEnvelope==nil then return -1 end
  local Ainteger=reaper.GetEnvelopePointByTime(TrackEnvelope, position)
  if Ainteger==-1 then retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(TrackEnvelope, 0) Ainteger=-1
  else retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(TrackEnvelope, Ainteger+1) 
  end
  if Ainteger+1>reaper.CountEnvelopePoints(TrackEnvelope)-1 then return -1 end
  return Ainteger+1, value, time
end

--a=reaper.GetTrack(0,0)
--B,BB,BBB=ultraschall.GetNextMuteState_TrackObject(1,1)

function ultraschall.GetPreviousMuteState_TrackObject(MediaTrack, position)
-- returns the previous mute-envelope-point, it's value and it's time
-- Envelope-Points numbering starts with 0!
-- returns -1 if not existing
  if reaper.ValidatePtr2(0, MediaTrack, "MediaTrack*")==false then return -1 end
  if tonumber(position)==nil then return -1 end
  position=tonumber(position)
  if position<0 then return -1 end
  local Aretval=reaper.ValidatePtr2(0, MediaTrack, "MediaTrack*")
  if Aretval==false then return -1 end
  local TrackEnvelope=reaper.GetTrackEnvelopeByName(MediaTrack, "Mute")
  if TrackEnvelope==nil then return -1 end
  local Ainteger=reaper.GetEnvelopePointByTime(TrackEnvelope, position)
  local retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(TrackEnvelope, Ainteger)
  return Ainteger, value, time
end

--  MediaTrack=reaper.GetTrack(0, 0)
--  A,AA,AAA=ultraschall.GetNextMuteState_TrackObject(MediaTrack,"10")
  
function ultraschall.CountMuteEnvelopePoints(track)
--returns the number of the envelope-points in the Mute-lane of track "track"
  if tonumber(track)==nil then return -1 end
  track=tonumber(track)
  if track<0 then return -1 end
  local MediaTrack=reaper.GetTrack(0, track)
  local TrackEnvelope=reaper.GetTrackEnvelopeByName(MediaTrack, "Mute")
  if TrackEnvelope==nil then return -1 end
  return reaper.CountEnvelopePoints(TrackEnvelope)
end

--A=ultraschall.CountMuteEnvelopePoints(0)

-------------------------------
---- Toggle States&Buttons ----
-------------------------------

function ultraschall.ToggleStateAction(section, actioncommand_id, state)
-- Toggles state of an actioncommand_id
-- returns current state of the action after toggling
--
-- section - section (usually 0 for main)
-- actioncommand_id - the ActionCommandID of the Action you'll want to toggle
-- state - 0 for off, 1 for on
--
-- If you have a button associated, you'll need to use RefreshToolbar() later!

  if actioncommand_id==nil then return -1 end
  if tonumber(state)==nil then return -1 end
  if tonumber(section)==nil then return -1 end
  local command_id = reaper.NamedCommandLookup(actioncommand_id)
  reaper.SetToggleCommandState(section, command_id, state)
  return reaper.GetToggleCommandState(command_id)
end



function ultraschall.RefreshToolbar_Action(section, actioncommand_id)
-- Refreshes a toolbarbutton with an ActionCommandID
--
-- section - section
-- actioncommand_id - ActionCommandID of the action, associated with the toolbarbutton

  if actioncommand_id==nil then return -1 end
  if tonumber(section)==nil then return -1 end
  
  local command_id = reaper.NamedCommandLookup(actioncommand_id)
  reaper.RefreshToolbar2(0, command_id)
  return 0
end


function ultraschall.ToggleStateButton(section, actioncommand_id, state)
-- Toggles state and refreshes the button of an actioncommand_id
-- section - section (usually 0 for main)
-- actioncommand_id - the ActionCommandID of the Action you'll want to toggle
-- state - 0 for off, 1 for on

  if actioncommand_id==nil then return false end
  if tonumber(state)==nil then return false end
  if tonumber(section)==nil then return false end

  local command_id = reaper.NamedCommandLookup(actioncommand_id)
  local stater=reaper.SetToggleCommandState(section, command_id, state)
  reaper.RefreshToolbar(command_id)
  return stater
end

--ultraschall.ToggleStateButton(0,"_Ultraschall_OnAir" ,0)


---------------------
---- Add Markers ----
---------------------

function ultraschall.AddNormalMarker(position, shown_number, markertitle)
-- Adds a normal Marker, not specifically for shownotes or chapter, etc
-- position - position in seconds; must be positive value
-- shown_number - the indexnumber shown in Reaper for this marker
-- markertitle - the title of the marker

  local noteID=0
  if tonumber(position)==nil then return -1 end
  if tonumber(shown_number)==nil then return -1 end
  if markertitle==nil then markertitle="" end

  if position>=0 then noteID=reaper.AddProjectMarker2(0, false, position, 0, markertitle, shown_number, 0)
  else noteID=-1
end
  return noteID
end


function ultraschall.AddPodRangeRegion(startposition, endposition)
-- creates a region that marks the begin and end of the podcast with a _PodRange:-region.
-- only one _PodRange:-region is allowed, all others will be deleted by this function!
-- helps find the right offsets for correct positioning of the chapters/shownote/markers 
-- in the exportfile
--
-- startposition - starting-position of the range in seconds; must be a positive value
-- endposition - end-position of the range in seconds; must be bigger than endposition
-- returns -1 if it fails

local color=0
local retval=0
local isrgn=true
local pos=0
local rgnend=0
local name=""
local markrgnindexnumber=""
local noteID=0

  local os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFFFFFF|0x1000000
    else
      color = 0xFFFFFF|0x1000000
    end

  local a,nummarkers,numregions=reaper.CountProjectMarkers(0)
  local count=0
  startposition=tonumber(startposition)
  endposition=tonumber(endposition)
  if startposition==nil then return -1 end
  if endposition==nil then return -1 end
  if startposition<0 then return -1 end
  if endposition<startposition then return -1 end
  
  for i=nummarkers+numregions, 0, -1 do
    retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,10)=="_PodRange:" and isrgn==true then count=count+1 reaper.DeleteProjectMarkerByIndex(0,i) end 
  end
  
  noteID=reaper.AddProjectMarker2(0, 1, startposition, endposition, "_PodRange:", 0, color)

return noteID
end

--ultraschall.AddPodRangeRegion(20,30)

function ultraschall.AddChapterMarker(position, shown_number, chaptertitle)
-- Adds a Chaptermarker. 
-- position - is time in seconds, 
-- shown_number - the number shown with the marker in Reaper
-- chaptertitle - a string of the title of this chapter
-- If no chaptertitle is given, it will write "_Chapter:" only
-- returns -1 if position isn't a valid value
  local color=0
  local noteID=0
  local os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x0000FF|0x1000000
    else
      color = 0xFF0000|0x1000000
    end

  position=tonumber(position)
  shown_number=tonumber(shown_number)
  if position==nil then return -1 end
  if shown_number==nil then return -1 end
  if chaptertitle==nil then chaptertitle="" end

  if position>=0 then noteID=reaper.AddProjectMarker2(0, false, position, 0, "_Chapter:"..chaptertitle, shown_number, color) -- set yellow-chapter-marker
  else noteID=-1
  end
  
  return noteID
end

--ultraschall.AddChapterMarker(1,20,"hui")

function ultraschall.AddShownoteMarker(position, shownotetitle, URL)
--!! TODO - local machen der Variablen!!

-- Adds a Shownotemarker. 
-- position - is time in seconds, 
-- shown_number - the number shown with the marker in Reaper, 
-- shownotetitle - a string for the title of the shownote, 
-- URL - a string for the URL.
--
-- If no shownotetitle is given, it will write "_Shownote:" only, if no URL is given, it will add --<>--
-- returns -1 if position isn't a valid value
  numShownotes=ultraschall.CountShownoteMarkers()
  shown_number=0
  for i=1,numShownotes+1 do
    A,shown_numbertemp=ultraschall.EnumerateShownoteMarkers(i)
--    reaper.MB(shown_number,shown_numbertemp,0)
    if tonumber(shown_numbertemp)~=nil then
      if shown_number<tonumber(shown_numbertemp) then shown_number=tonumber(shown_numbertemp) end
    end
  end

  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x00AA00|0x1000000
    else
      color = 0x00AA00|0x1000000
    end

  if position==nil then position=-1 end
  if URL==nil then URL="" end
  if shownotetitle==nil then shownotetitle="" end

  if position>=0 then noteID=reaper.AddProjectMarker2(0, false, position, 0, "_Shownote: "..shownotetitle.." URL:"..URL, shown_number+1, color) -- set green shownote-marker
                      reaper.SetProjExtState(0, "Ultraschall_Shownotes", "TITLE"..shown_number+1, shownotetitle)
                      reaper.SetProjExtState(0, "Ultraschall_Shownotes", "URL"..shown_number+1, URL)
  else noteID=-1
  end

  return noteID
end



function ultraschall.test()
--C,CC,CCC,CCCC= ultraschall.AddShownoteMarker(19,"Testomat3000","achherrje.de")
--A,AA=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "TITLE".."29")
--B,BB=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "URL".."29")
end


function ultraschall.AddEditMarker(position, shown_number, edittitle)
-- Adds an Editmarker. 
-- position - is time in seconds, 
-- shown_number - the number shown with the Edit-Marker in Reaper
-- edittitle - a string of a description for this Edit-marker
--
-- If no chaptertitle is given, it will write "_Edit:" only
-- returns -1 if position isn't a valid value

  local color=0
  local noteID=0
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFF0000|0x1000000
    else
      color = 0x0000FF|0x1000000
    end

  position=tonumber(position)
  shown_number=tonumber(shown_number)
  if position==nil then return -1 end
  if shown_number==nil then return -1 end
  if edittitle==nil then edittitle="" end

  if position>=0 then noteID=reaper.AddProjectMarker2(0, false, position, 0, "_Edit:"..edittitle, shown_number, color) -- set red edit-marker
  else noteID=-1
  end

  return noteID
end

--ultraschall.AddEditMarker(13,20,"hui")


function ultraschall.AddDummyMarker(position, shown_number, dummytitle)
-- Adds a Dummymarker. 
-- position - is time in seconds, 
-- shown_number - the number shown with the Dummy-Marker in Reaper
-- edittitle - a string of a description for this Dummy-marker
--
-- If no chaptertitle is given, it will write "_Dummy:" only
-- returns -1 if position isn't a valid value

  local color=0
  local noteID=0
  
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x999999|0x1000000
    else
      color = 0x999999|0x1000000
    end

  position=tonumber(position)
  shown_number=tonumber(shown_number)
  if position==nil then return -1 end
  if shown_number==nil then return -1 end
  if dummytitle==nil then dummytitle="" end

  if position>=0 then noteID=reaper.AddProjectMarker2(0, false, position, 0, "_Dummy:"..dummytitle, shown_number, color)
  else noteID=-1
  end

  return noteID
end

--ultraschall.AddDummyMarker(9,20,"hui")

-----------------------
---- Count Markers ----
-----------------------

function ultraschall.CountNormalMarkers()
-- returns number of normal markers in the project
  local nix=""
  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  local count=0
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name==nil then name="" end
    if name:sub(1,10)=="_Shownote:" or name:sub(1,9)=="_Chapter:" or name:sub(1,6)=="_Edit:" or name:sub(1,7)=="_PodStart:" or name:sub(1,5)=="_End:" or name:sub(1,10)=="_LiveEdit:" or name:sub(1,7)=="_Dummy:" then nix="1"
    else count=count+1 
    end
    end 

  return count
end


function ultraschall.CountShownoteMarkers()
-- returns number of _Shownote: markers in the project

  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  local count=0
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,10)=="_Shownote:" then count=count+1 end
  end

  return count
end

--A=ultraschall.CountShownoteMarkers()

function ultraschall.CountChapterMarkers()
-- returns number of _Chapter: markers in the project

  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  local count=0
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,9)=="_Chapter:" then count=count+1 end 
  end

  return count
end

--A=ultraschall.CountChapterMarkers()

function ultraschall.CountEditMarkers()
-- returns number of _Edit: markers in the project

  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  local count=0
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,6)=="_Edit:" then count=count+1 end 
  end

  return count
end

--A=ultraschall.CountEditMarkers()

function ultraschall.CountDummyMarkers()
-- returns number of _Dummy: markers in the project

  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  local count=0
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,7)=="_Dummy:" then count=count+1 end 
  end

  return count
end

--A=ultraschall.CountDummyMarkers()

---------------------------
---- Enumerate Markers ----
---------------------------

function ultraschall.GetPodRangeRegion()
-- returns startposition and endposition of the PodRange-Region.
-- only one _PodRange:-region is allowed, if there are more, it will return -1

  local color=0
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFFFFFF|0x1000000
    else
      color = 0xFFFFFF|0x1000000
    end

  local a,nummarkers,numregions=reaper.CountProjectMarkers(0)
  local startposition=0
  local endposition=0
  local count=0
  
  for i=nummarkers+numregions, 0, -1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,10)=="_PodRange:" and isrgn==true then startposition=pos endposition=rgnend count=count+1 end 
  end
  
  if count>1 then return -1, -1
  else return startposition, endposition
  end
end

--A,AA=ultraschall.GetPodRangeRegion()

function ultraschall.EnumerateNormalMarkers(number)
-- returns number of markers in general(not chaptermarker!), the shown marker-number,chaptername-name of the marker

  number=tonumber(number)
  if number==nil then return -1 end
  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  if tonumber(number)==nil then return -1,-1,-1,-1 end
  local number=number-1
  local wentfine=0
  local count=-1
  local retnumber=0
  local retidxnum=""
  local markername=""
  local position=0
  local smile=""
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if isrgn==false then
--    reaper.MB(name:sub(1,10),tostring(nummarkers),0)
      if name:sub(1,10)=="_Shownote:" or name:sub(1,9)=="_Chapter:" or name:sub(1,6)=="_Edit:" or name:sub(1,10)=="_LiveEdit:" or name:sub(1,7)=="_Dummy:" then smile=""
      else count=count+1  
      end
    end
    if number>=0 and wentfine==0 and count==number then
--    reaper.MB(name:sub(1,10),"",0)
        retnumber=retval 
        markername=name
        retidxnum=markrgnindexnumber
        position=pos
        wentfine=1
    end
  end
  
  if wentfine==1 then return retnumber, retidxnum, position, markername
  else return -1, ""
  end
end


function ultraschall.EnumerateChapterMarkers(number)
-- Get the data of a _Chapter: marker
-- returns number, ID, position(in seconds) and the chaptername

  number=tonumber(number)
  if number==nil then return -1 end
  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  local number=number-1
  local wentfine=0
  local count=-1
  local retnumber=0
  local retidxnum=""
  local chaptername=""
  local position=0
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,9)=="_Chapter:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        retnumber=retval 
        chaptername=name :sub(10,-1)
        retidxnum=markrgnindexnumber
        position=pos
        wentfine=1
    end
  end
  
  if wentfine==1 then return retnumber, retidxnum, position, chaptername
  else return -1, ""
  end
end

--A=ultraschall.AddChapterMarker(4,4,"DD")
--A,A2,A3,A4=ultraschall.EnumerateChapterMarkers("1")

function ultraschall.EnumerateDummyMarkers(number)
-- Get the data of a _Dummy: marker
-- returns number, ID, position(in seconds) and the dummyname

  number=tonumber(number)
  if number==nil then return -1 end
  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  local number=number-1
  local wentfine=0
  local count=-1
  local retnumber=0
  local retidxnum=""
  local chaptername=""
  local position=0
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,7)=="_Dummy:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        retnumber=retval 
        chaptername=name :sub(8,-1)
        retidxnum=markrgnindexnumber
        position=pos
        wentfine=1
    end
  end
  
  if wentfine==1 then return retnumber, retidxnum, position, chaptername
  else return -1, ""
  end
end

--A=ultraschall.AddDummyMarker(4,4,"D")
--A,AA,AAA,AAAA=ultraschall.EnumerateDummyMarkers(1)

function ultraschall.EnumerateShownoteMarkers(number)
-- !TODO : local machen von variablen

-- Get the data of a _Shownote marker
-- returns number, ID, position(in seconds), shownotename and the URL

  if number==nil then return -1 end
  c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=number-1
  wentfine=0
  count=-1
  retnumber=0
  tempo=-4
  retidxnum=""
  shownotename=""
  for i=0, c-1 do
    retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,10)=="_Shownote:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        retnumber=retval
        shownotename=name--:match("(_Shownote:.*--<)")
        if shownotename==nil then shownotename="_Shownote:" tempo=-1 end--shownotename=name:match("(_Shownote:.*)") tempo=-1 end
        shown_number_temp=markrgnindexnumber
        retidxnum=markrgnindexnumber
        position=pos
        URL=name:match("(--<.*>--)")
        if URL==nil then URL="" end
        wentfine=1
    end
  end

  
  if wentfine==1 then 
    A,TITLE_State=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "TITLE"..tostring(shown_number_temp))
    B,URL_State=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "URL"..tostring(shown_number_temp))
    return retnumber, retidxnum, position, shownotename:sub(11,-1), TITLE_State, URL_State
  else return -1, ""
  end
end

--A=ultraschall.AddShownoteMarker(301,"vier","vier.de")
--ret,retid,pos,name,tit,urlst=ultraschall.EnumerateShownoteMarkers(2)

function ultraschall.EnumerateShownoteMarkers_ByShownNumber(shown_number)
-- !TODO : local machen von variablen

-- Get the data of a _Shownote marker
-- returns number, ID, position(in seconds), shownotename and the URL

  number=tonumber(number)
  if number==nil then return -1 end
  c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=number-1
  wentfine=0
  count=-1
  retnumber=0
  tempo=-4
  retidxnum=""
  shownotename=""
  for i=0, c-1 do
    retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,10)=="_Shownote:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        retnumber=retval
        shownotename=name--:match("(_Shownote:.*--<)")
        if shownotename==nil then shownotename="_Shownote:" tempo=-1 end--shownotename=name:match("(_Shownote:.*)") tempo=-1 end
        shown_number_temp=markrgnindexnumber
        retidxnum=markrgnindexnumber
        position=pos
        URL=name:match("(--<.*>--)")
        if URL==nil then URL="" end
        wentfine=1
    end
  end

  
  if wentfine==1 then 
    A,TITLE_State=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "TITLE"..tostring(shown_number_temp))
    B,URL_State=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "URL"..tostring(shown_number_temp))
    return retnumber, retidxnum, position, shownotename:sub(11,-1), TITLE_State, URL_State
  else return -1, ""
  end
end


function ultraschall.EnumerateEditMarkers(number)
-- Get the data of an _Edit marker
-- returns number, ID, position(in seconds) and the editmarker-name

  number=tonumber(number)
  if number==nil then return -1 end
  local a,nummarkers,b=reaper.CountProjectMarkers(0)
  local number=number-1
  local wentfine=0
  local count=-1
  local retnumber=0
  local retidxnum=""
  local editname=""
  local position=0
  for i=0, a-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
  if isrgn==false then
    if name:sub(1,6)=="_Edit:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
    --  reaper.MB(tostring(count),tostring(number),0)
        retnumber=retval 
        editname=name :sub(7,-1)
        retidxnum=markrgnindexnumber
        position=pos
        wentfine=1
    end
  end
  --reaper.MB(name,tostring(count),0)
  end
  if wentfine==1 then return retnumber, retidxnum, position, editname
  else return -1, ""
  end
end

--A=ultraschall.AddEditMarker(4,4,"titleD")
--A,AA,AAA,AAAA=ultraschall.EnumerateEditMarkers("1")


function ultraschall.GetAllChapterMarkers()
--returns the number of chapters and an array of each chaptermarker in the format:
-- chaptermarkersarray [index] [0-position;1-chaptername]
  local count=ultraschall.CountChapterMarkers()
  local numnums=count
  
  local chaptermarkersarray = {}
  for i=1, count do
    chaptermarkersarray[i]={}
    local a,b,position,name=ultraschall.EnumerateChapterMarkers(i)
    chaptermarkersarray[i][0]=position
    chaptermarkersarray[i][1]=name
  end

return numnums, chaptermarkersarray
end

--A,AA=ultraschall.GetAllChapterMarkers()

function ultraschall.GetAllShownoteMarkers()
--TODO: local machen von variablen

--returns the number of shownotes and an array of each shownote in the format:
-- shownotemarkersarray[index] [0-position;1-shownotename]
  local count=ultraschall.CountShownoteMarkers()
  local numnums=count

  local shownotemarkersarray = {}
  for i=1, count do
    shownotemarkersarray[i]={}
    local a,b,position,name=ultraschall.EnumerateShownoteMarkers(i)
    shownotemarkersarray[i][0]=position
    shownotemarkersarray[i][1]=name
  end

return numnums, shownotemarkersarray
end

--A,AA=ultraschall.GetAllShownoteMarkers()


function ultraschall.GetAllEditMarkers()
--returns the number of edits and an array of each editmarker in the format:
-- editmarkersarray [index] [0-position;1-editname]
  local count=ultraschall.CountEditMarkers()
  local numnums=count

  local editmarkersarray = {}
  for i=1, count do
    editmarkersarray[i]={}
    local a,b,position,name=ultraschall.EnumerateEditMarkers(i)
    editmarkersarray[i][0]=position
    editmarkersarray[i][1]=name
  end

return numnums, editmarkersarray
end

--A,AA=ultraschall.GetAllEditMarkers()

function ultraschall.GetAllNormalMarkers()
--returns the number of normal markers and an array of each normal marker in the format:
-- normalmarkersarray [index] [0-position;1-normalmarkername]
  local count=ultraschall.CountNormalMarkers()
  local numnums=count
  
  local normalmarkersarray = {}
  for i=1, count do
    normalmarkersarray[i]={}
    local a,b,position,name=ultraschall.EnumerateNormalMarkers(i)
    normalmarkersarray[i][0]=position
    normalmarkersarray[i][1]=name
  end

return numnums, normalmarkersarray
end

--A,AA=ultraschall.GetAllNormalMarkers()

function ultraschall.GetAllMarkers()
-- count - number of markers
-- markersarray - an array with all names excluding _edit:, _shownote:, _chapter:. Switching between markername, type of marker, markername, type of maker
  local count,aa,bb= reaper.CountProjectMarkers(0)

  local markersarray = {}
  local numnums=count
  for i=1, count do
    markersarray[i]={}
    local a,b,position,name=ultraschall.EnumerateNormalMarkers(i)
    local retval, isrgn, position, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, i)
    markersarray[i][0]=position
    markersarray[i][1]=name
  end

return numnums, markersarray
end

--A,AA=ultraschall.GetAllMarkers()

----------------------
---- Set Markers -----
----------------------

function ultraschall.SetNormalMarker(number, position, shown_number, markertitle)
-- Sets values of a normal Marker(no _Chapter:, _Shownote:, etc)
-- number - number of the marker, 1 to current number of markers
-- position - position in seconds; -1 - keep the old value
-- shown_number - the number shown with the marker in Reaper; -1 - keep the old value
-- markertitle - title of the marker; nil - keep the old value
--
-- returns true if successful and false if not(i.e. marker doesn't exist)

  local color=0
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFF0000|0x1000000
    else
      color = 0x0000FF|0x1000000
    end
  if tonumber(position)==nil then position=-1 end
  if tonumber(position)<0 then position=-1 end
  if tonumber(shown_number)==nil then shown_number=-1 end
  if tonumber(number)==nil then return false end
  
  local nix=""
  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)-1
  local wentfine=0
  local count=-1
  local retnumber=0
  for i=0, c-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if isrgn==false then
      if name:sub(1,10)=="_Shownote:" or name:sub(1,9)=="_Chapter:" or name:sub(1,6)=="_Edit:" or name:sub(1,10)=="_LiveEdit:" or name:sub(1,7)=="_Dummy:" then nix="1"
      else count=count+1
      end
    end
    if number>=0 and wentfine==0 and count==number then
        if tonumber(position)==-1 or position==nil then position=pos end
        if tonumber(shown_number)<=-1 or shown_number==nil then shown_number=markrgnindexnumber end
        if markertitle==nil then markertitle=name end
        retnumber=i
        wentfine=1
    end
  end
  
  if markertitle==nil then markertitle="" end
  
  if wentfine==1 then return reaper.SetProjectMarkerByIndex(0, retnumber, 0, position, 0, shown_number, markertitle, 0)
  else return false
  end
end

--A=ultraschall.SetNormalMarker(1,2,33,"hurtz")

function ultraschall.SetEditMarker(number, position, shown_number, edittitle)
-- Sets values of an Edit-Marker
-- number - number of the _Edit-marker, 1 to current number of _Edit-markers
-- position - position in seconds; -1 - keep the old value
-- shown_number - the number shown with the marker in Reaper; -1 - keep the old value
-- edittitle - title of the editmarker; nil - keep the old value
--
-- returns true if successful and false if not(i.e. marker doesn't exist)

  local color=0
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFF0000|0x1000000
    else
      color = 0x0000FF|0x1000000
    end
  if tonumber(position)==nil then position=-1 end
  if tonumber(position)<0 then position=-1 end
  if tonumber(shown_number)==nil then shown_number=-1 end
  if tonumber(number)==nil then return false end
  
  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)-1
  local wentfine=0
  local count=-1
  local retnumber=0
  for i=0, c-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
  if isrgn==false then
    if name:sub(1,6)=="_Edit:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        if tonumber(position)==-1 or position==nil then position=pos end
        if tonumber(shown_number)<=-1 or shown_number==nil then shown_number=markrgnindexnumber end
        if edittitle==nil then edittitle=name:match("(_Edit:.*)") edittitle=edittitle:sub(7,-1) end
        retnumber=i
        wentfine=1
    end
  end
  end
  
  if edittitle==nil then edittitle="" end
  
  if wentfine==1 then return reaper.SetProjectMarkerByIndex(0, retnumber, 0, position, 0, shown_number, "_Edit:" .. edittitle, color)
  else return false
  end
end

--A=ultraschall.SetEditMarker(1,6,10,"Editmarke1")

function ultraschall.SetChapterMarker(number, position, shown_number, chaptertitle)
-- Sets values of a Chapter-Marker
-- number - number of the _Chapter-marker, 1 to current number of _Chapter-markers
-- position - position in seconds; -1 - keep the old value
-- shown_number - the number shown with the marker in Reaper; -1 - keep the old value
-- chaptertitle - title of the chapter; nil - keep the old value
--
-- returns true if successful and false if not(i.e. marker doesn't exist)

  local color=0
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x0000FF|0x1000000
    else
      color = 0xFF0000|0x1000000
    end 

  if tonumber(position)==nil then position=-1 end
  if tonumber(position)<0 then position=-1 end
  if tonumber(shown_number)==nil then shown_number=-1 end
  if tonumber(number)==nil then return false end
  
  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)-1
  local wentfine=0
  local count=-1
  local retnumber=0
  for i=0, c-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,9)=="_Chapter:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        if tonumber(position)==-1 or position==nil then position=pos end
        if tonumber(shown_number)<=-1 or shown_number==nil then shown_number=markrgnindexnumber end
        if chaptertitle==nil then chaptertitle=name:match("(_Chapter:.*)") chaptertitle=chaptertitle:sub(10,-1) end
        retnumber=i
        wentfine=1
    end
  end
  
  if chaptertitle==nil then chaptertitle="" end
  
  if wentfine==1 then return reaper.SetProjectMarkerByIndex(0, retnumber, 0, position, 0, shown_number, "_Chapter:" .. chaptertitle, color)
  else return false
  end
end

--A=ultraschall.AddChapterMarker(1,10,10,"Kapitel")
--A=ultraschall.SetChapterMarker(1,2,11,"Kapitel6")


function ultraschall.SetShownoteMarker(number, position, shownotetitle, URL)
-- TODO: local machen von variablen

-- Sets values of a Shownote-Marker
-- number - number of the _Shownote-marker, 1 to current number of _Shownote-markers
-- position - position in seconds; -1 - keep the old value
-- shown_number - the number shown with the marker in Reaper; -1 - keep the old value
-- shownotetitle - title of the shownote; nil - keep the old value
-- URL - URL for the title; nil - keep the old value
--
-- returns true if successful and false if not(i.e. marker doesn't exist)

  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x00AA00|0x1000000
    else
      color = 0x00AA00|0x1000000
    end

  if tonumber(position)==nil then position=-1 end
  if tonumber(position)<0 then position=-1 end
  if tonumber(shown_number)==nil then shown_number=-1 end
  if tonumber(number)==nil then return false end
  
  c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)-1
  wentfine=0
  count=-1
  retnumber=0
  for i=0, c-1 do
    retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,10)=="_Shownote:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
    shown_number_temp=markrgnindexnumber
        if tonumber(position)==-1 or position==nil then position=pos end
        if tonumber(shown_number)<=-1 or shown_number==nil then shown_number=markrgnindexnumber end
        if shownotetitle==nil then shownotetitle=name:match("(_Shownote:.*)") shownotetitle=shownotetitle:sub(11,-1) end
        if URL==nil then 
--        A,TITLE_State=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "TITLE"..tostring(shown_number_temp))
        B,URL=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "URL"..tostring(shown_number_temp))
        end
        retnumber=i
        wentfine=1
    end
  end
  
  if URL==nil then 
  B,URL=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "URL"..tostring(shown_number_temp))
  end
  if shownotetitle==nil then shownotetitle="" end
  
  if wentfine==1 then reaper.SetProjExtState(0, "Ultraschall_Shownotes", "TITLE"..tostring(shown_number_temp), shownotetitle)
                      reaper.SetProjExtState(0, "Ultraschall_Shownotes", "URL"..tostring(shown_number_temp), URL)
                      return reaper.SetProjectMarkerByIndex(0, retnumber, 0, position, 0, shown_number, "_Shownote:" .. shownotetitle, color)
  else return false
  end
end

--ultraschall.AddShownoteMarker(10,"Truddle","fuddle.de")
--ultraschall.SetShownoteMarker(2,nil,nil,nil)
--A,AA,AAA,AAAA,AAAAA,AAAAAA=ultraschall.EnumerateShownoteMarkers(3)

function ultraschall.SetPodRangeRegion(startposition, endposition)
-- Sets _PodRange:-Marker
-- startposition - startposition in seconds, must be positive value
-- endposition - endposition in seconds, must be bigger than startposition
-- returns -1 if it fails

  return ultraschall.AddPodRangeRegion(startposition, endposition)
end

--A,AA,AAA=ultraschall.SetPodRangeRegion(2,10)

-------------------------
---- Delete Markers -----
-------------------------

function ultraschall.DeletePodRangeRegion()
-- deletes the PodRange-Region
  local a,nummarkers,numregions=reaper.CountProjectMarkers(0)
  local count=0
  local itworked=-1
  for i=nummarkers+numregions, 0, -1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,10)=="_PodRange:" and isrgn==true then reaper.DeleteProjectMarkerByIndex(0,i) itworked=1 end 
  end
  return itworked
end

--A=ultraschall.AddPodRangeRegion(2,10)
--A2=ultraschall.DeletePodRangeRegion()

function ultraschall.DeleteNormalMarker(number)
-- Deletes a Normal-Marker
-- number - number of the _Normal-marker, 1 to current number of _Normal-markers
-- returns true if successful and false if not(i.e. marker doesn't exist)

  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)
  if number==nil then return -1 end
  local number=number-1
  local wentfine=0
  local count=-1
  local retnumber=0
  local nix=""
  for i=0, c-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if isrgn==false then
      if name:sub(1,10)=="_Shownote:" or name:sub(1,9)=="_Chapter:" or name:sub(1,6)=="_Edit:" or name:sub(1,10)=="_LiveEdit:" or name:sub(1,7)=="_Dummy:" then nix="1"
      else count=count+1
      end
    end
    if number>=0 and wentfine==0 and count==number then
        retnumber=i
        wentfine=1
    end
  end
  
  if wentfine==1 then return reaper.DeleteProjectMarkerByIndex(0, retnumber)
  else return false
  end
end

--A=ultraschall.AddNormalMarker(3,10,"marke")
--A2=ultraschall.DeleteNormalMarker("1")

function ultraschall.DeleteShownoteMarker(number)
--TODO local machen von Variablen

-- Deletes a Shownote-Marker
-- number - number of the _Shownote-marker, 1 to current number of _Shownote-markers
-- returns true if successful and false if not(i.e. marker doesn't exist)

  c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)
  if number==nil then return -1 end
  number=number-1
  wentfine=0
  count=-1
  retnumber=0
  for i=0, c-1 do
    retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,10)=="_Shownote:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        shown_number_temp=markrgnindexnumber
        retnumber=i
        wentfine=1
    end
  end
  
  if wentfine==1 then 
    reaper.SetProjExtState(0, "Ultraschall_Shownotes", "TITLE"..tostring(shown_number_temp), "")
    reaper.SetProjExtState(0, "Ultraschall_Shownotes", "URL"..tostring(shown_number_temp), "")
    return reaper.DeleteProjectMarkerByIndex(0, retnumber)
  else return false
  end
end

--A,AA,AAA=ultraschall.AddShownoteMarker(10,"ofseroad2","middle2")
--A,AA=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "TITLE1")
--B,BB=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "URL1")
--ultraschall.DeleteShownoteMarker(1)

function ultraschall.DeleteChapterMarker(number)
-- Deletes a Chapter-Marker
-- number - number of the _Chapter-marker, 1 to current number of _Chapter-markers
-- returns true if successful and false if not(i.e. marker doesn't exist)

  c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)
  if number==nil then return -1 end
  number=number-1
  wentfine=0
  count=-1
  retnumber=0
  for i=0, c-1 do
    retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,9)=="_Chapter:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        retnumber=i
        wentfine=1
    end
  end
  
  if wentfine==1 then return reaper.DeleteProjectMarkerByIndex(0, retnumber)
  else return false
  end
end

--A=ultraschall.AddChapterMarker(3,10,"markel")
--A2=ultraschall.DeleteChapterMarker("1")

function ultraschall.DeleteEditMarker(number)
-- Deletes a Edit-Marker
-- number - number of the _Edit-marker, 1 to current number of _Edit-markers
-- returns true if successful and false if not(i.e. marker doesn't exist)

  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)
  if number==nil then return -1 end
  number=number-1
  local wentfine=0
  local count=-1
  local retnumber=0
  for i=0, c-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,6)=="_Edit:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        retnumber=i
        wentfine=1
    end
  end
  
  if wentfine==1 then return reaper.DeleteProjectMarkerByIndex(0, retnumber)
  else return false
  end
end

--A=ultraschall.AddEditMarker(3,10,"markel")
--A2=ultraschall.DeleteEditMarker(1)

function ultraschall.DeleteDummyMarker(number)
-- Deletes a Dummy-Marker
-- number - number of the _Dummy-marker, 1 to current number of _Dummy-markers
-- returns true if successful and false if not(i.e. marker doesn't exist)

  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)
  if number==nil then return -1 end
  number=number-1
  local wentfine=0
  local count=-1
  local retnumber=0
  for i=0, c-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if name:sub(1,7)=="_Dummy:" then count=count+1 end 
    if number>=0 and wentfine==0 and count==number then 
        retnumber=i
        wentfine=1
    end
  end
  
  if wentfine==1 then return reaper.DeleteProjectMarkerByIndex(0, retnumber)
  else return false
  end
end

--A=ultraschall.AddDummyMarker(1,1,"dummyone")
--A2=ultraschall.DeleteDummyMarker("1")

-------------------------
---- Export Markers -----
-------------------------

function ultraschall.ExportShownotesToFile(filename_with_path, PodRangeStart, PodRangeEnd)
--ToDo local machen der variables

--Export Shownote-Markers to File
--filename_with_path - filename of the file where the markers shall be exported to
--PodRangeStart - start of the Podcast;markers earlier of that will not be exported;markers exported will be markerposition minus PodRangeStart
--                must be a positive value; nil=0
--PodRangeEnd - end of the Podcast; markers later of that will not be exported; 
--              must be a positive value; nil=end of project  
-- return -1 in case of error

if filename_with_path == nil then return -1 end
PodRangeStart=tonumber(PodRangeStart)
PodRangeEnd=tonumber(PodRangeEnd)
if PodRangeStart==nil then PodRangeStart=0 end
if PodRangeStart<0 then return -1 end
if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
if PodRangeEnd<PodRangeStart then return -1 end
  number=ultraschall.CountShownoteMarkers()
  timestring="00:00:00.000"
  
  file=io.open(filename_with_path,"w")
  
  if file==nil then return -1 end
    for i=1,number do
      idx,shown_number,pos,name,URL = ultraschall.EnumerateShownoteMarkers(i)
      if pos>=PodRangeStart and pos<=PodRangeEnd then
        pos=pos-PodRangeStart
        timestring=ultraschall.SecondsToTime(pos)
        tempomat, TITLE=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "TITLE"..shown_number)
        tempomat, URL=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "URL"..shown_number)
        file:write(timestring.." \""..name.."\"-->Title:\""..TITLE.."\"-->URL:\""..URL.."\"-->END\n")
      end
    end
  fileclose=io.close(file)
  return 1
end


--A,AA,AAA=ultraschall.AddShownoteMarker(10,"test1","URL3000.com")
--A,AA,AAA=ultraschall.AddShownoteMarker(20,"test2","URL4000.com")
--A,AA,AAA=ultraschall.AddShownoteMarker(30,"test3","URL5000.com")
--APACHEN=ultraschall.ExportShownotesToFile("c:\\test.txt")

function ultraschall.ExportShownotesToFile_Filerequester(PodRangeStart,PodRangeEnd)
--ToDo local machen der variables

--Export Shownote-Markers to File(must be an existing file or the requester runs into troubles!)
--PodRangeStart - start of the Podcast;markers earlier of that will not be exported;markers exported will be markerposition minus PodRangeStart
--                must be a positive value; nil=0
--PodRangeEnd - end of the Podcast; markers later of that will not be exported; 
--              must be a positive value; nil=end of project  
-- return -1 in case of error

if PodRangeStart==nil then PodRangeStart=0 end
if PodRangeStart<0 then return -1 end
if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
if PodRangeEnd<PodRangeStart then return -1 end
  number=ultraschall.CountShownoteMarkers()
  
  retval, filename_with_path = reaper.GetUserFileNameForRead("ShownoteMarkers.shownotes.txt", "Export Shownote-Markers", "*.shownotes.txt")
  if retval==false then return -1 end

  timestring="00:00:00.000"
  
  file=io.open(filename_with_path,"w")
  
  if file==nil then return -1 end
    for i=1,number do
      idx,shown_number,pos,name,URL = ultraschall.EnumerateShownoteMarkers(i)
      if pos>=PodRangeStart and pos<=PodRangeEnd then
        pos=pos-PodRangeStart
        timestring=ultraschall.SecondsToTime(pos)
        tempomat, TITLE=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "TITLE"..shown_number)
        tempomat, URL=reaper.GetProjExtState(0, "Ultraschall_Shownotes", "URL"..shown_number)
        file:write(timestring.." \""..name.."\"-->Title:\""..TITLE.."\"-->URL:\""..URL.."\"-->END\n")
      end
    end
  fileclose=io.close(file)
  return 1
end

--APACHEN=ultraschall.ExportShownotesToFile_Filerequester()

function ultraschall.ExportChapterMarkersToFile(filename_with_path,PodRangeStart,PodRangeEnd)
--Export Chapter-Markers to filename_with_path
--filename_with_path - filename of the file where the markers shall be exported to
--PodRangeStart - start of the Podcast;markers earlier of that will not be exported;markers exported will be markerposition minus PodRangeStart
--                must be a positive value; nil=0
--PodRangeEnd - end of the Podcast; markers later of that will not be exported; 
--              must be a positive value; nil=end of project
--
-- returns -1 in case of error

if filename_with_path == nil then return -1 end
if PodRangeStart==nil then PodRangeStart=0 end
if PodRangeStart<0 then return -1 end
if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
if PodRangeEnd<PodRangeStart then return -1 end
  local number=ultraschall.CountChapterMarkers()
    
  local timestring="00:00:00.000"
  
  local file=io.open(filename_with_path,"w")
  
  if file==nil then return -1 end
    for i=1,number do
      local idx,shown_number,pos,name, URL=ultraschall.EnumerateChapterMarkers(i)
      if pos>=PodRangeStart and pos<=PodRangeEnd then
        pos=pos-PodRangeStart
        timestring=ultraschall.SecondsToTime(pos)
        file:write(timestring.." "..name.."\n")
      end
    end
  local fileclose=io.close(file)
  return 1
end

--A,AA=ultraschall.AddChapterMarker(10,10,"A")
--A,AA=ultraschall.AddChapterMarker(20,20,"B")
--A,AA=ultraschall.AddChapterMarker(30,30,"C")
--APPALACHEN=ultraschall.ExportChapterMarkersToFile("c:\\test.txt",1,300)


function ultraschall.ExportChapterMarkersToFile_Filerequester(PodRangeStart, PodRangeEnd)
--Export Chapter-Markers to File(must be an existing file or the requester runs into troubles!)
--PodRangeStart - start of the Podcast;markers earlier of that will not be exported;markers exported will be markerposition minus PodRangeStart
--                must be a positive value; nil=0
--PodRangeEnd - end of the Podcast; markers later of that will not be exported; 
--              must be a positive value; nil=end of project  
-- return -1 in case of error

if PodRangeStart==nil then PodRangeStart=0 end
PodRangeStart=tonumber(PodRangeStart)
PodRangeEnd=tonumber(PodRangeEnd)
if PodRangeStart<0 then return -1 end
if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
if PodRangeEnd<PodRangeStart then return -1 end
  local number=ultraschall.CountChapterMarkers()

  local retval, filename_with_path = reaper.GetUserFileNameForRead("ChapterMarkers.chapters.txt", "Export Chapter-Markers", "*.chapters.txt")
  if retval==false then return -1 end

  local timestring="00:00:00.000"
  
  local file=io.open(filename_with_path,"w")
  
  if file==nil then return -1 end
    for i=1,number do
      local idx,shown_number,pos,name, URL=ultraschall.EnumerateChapterMarkers(i)
      if pos>=PodRangeStart and pos<=PodRangeEnd then
        pos=pos-PodRangeStart
        timestring=ultraschall.SecondsToTime(pos)
        file:write(timestring.." "..name.."\n")
      end
    end
  local fileclose=io.close(file)
  return 1
end

--APACHEN=ultraschall.ExportChapterMarkersToFile_Filerequester()

function ultraschall.ExportEditMarkersToFile(filename_with_path,PodRangeStart, PodRangeEnd)
--Export Edit-Markers to filename_with_path
--filename_with_path - filename of the file where the markers shall be exported to
--PodRangeStart - start of the Podcast;markers earlier of that will not be exported;markers exported will be markerposition minus PodRangeStart
--                must be a positive value; nil=0
--PodRangeEnd - end of the Podcast; markers later of that will not be exported; 
--              must be a positive value; nil=end of project
--
-- returns -1 in case of error

if filename_with_path == nil then return -1 end
PodRangeStart=tonumber(PodRangeStart)
PodRangeEnd=tonumber(PodRangeEnd)
if PodRangeStart==nil then PodRangeStart=0 end
if PodRangeStart<0 then return -1 end
if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
if PodRangeEnd<PodRangeStart then return -1 end
  local number=ultraschall.CountEditMarkers()  
  local timestring="00:00:00.000"
  
  local file=io.open(filename_with_path,"w")
  
  if file==nil then return -1 end
    for i=1,number do
      local idx,shown_number,pos,name, URL=ultraschall.EnumerateEditMarkers(i)
      if pos>=PodRangeStart and pos<=PodRangeEnd then
        pos=pos-PodRangeStart
        timestring=ultraschall.SecondsToTime(pos)
        file:write(timestring.." "..name.."\n")
      end
    end
  local fileclose=io.close(file)
  return 1
end

--A,AA=ultraschall.AddEditMarker(10,10,"ed10")
--A,AA=ultraschall.AddEditMarker(20,20,"ed20")
--A,AA=ultraschall.AddEditMarker(30,30,"ed30")
--APACHEN=ultraschall.ExportEditMarkersToFile("c:\\test.txt")
--Mespotine

function ultraschall.ExportEditMarkersToFile_Filerequester(PodRangeStart, PodRangeEnd)
--Export Markers to File(must be an existing file or the requester runs into troubles!)
--PodRangeStart - start of the Podcast;markers earlier of that will not be exported;markers exported will be markerposition minus PodRangeStart
--                must be a positive value; nil=0
--PodRangeEnd - end of the Podcast; markers later of that will not be exported; 
--              must be a positive value; nil=end of project  
-- return -1 in case of error

if PodRangeStart==nil then PodRangeStart=0 end
PodRangeStart=tonumber(PodRangeStart)
PodRangeEnd=tonumber(PodRangeEnd)
if PodRangeStart<0 then return -1 end
if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
if PodRangeEnd<PodRangeStart then return -1 end
  local number=ultraschall.CountEditMarkers()

  local retval, filename_with_path = reaper.GetUserFileNameForRead("EditMarkers.edit.txt", "Export Edit-Markers", "*.edit.txt")
  if retval==false then return -1 end

  local timestring="00:00:00.000"
  
  local file=io.open(filename_with_path,"w")
  
  if file==nil then return -1 end
    for i=1,number do
      local idx,shown_number,pos,name, URL=ultraschall.EnumerateEditMarkers(i)
      if pos>=PodRangeStart and pos<=PodRangeEnd then
        pos=pos-PodRangeStart
        timestring=ultraschall.SecondsToTime(pos)
        file:write(timestring.." "..name.."\n")
      end
    end
  local fileclose=io.close(file)
  return 1
end

--ALASKA=ultraschall.ExportEditMarkersToFile_Filerequester()

function ultraschall.ExportNormalMarkersToFile(filename_with_path, PodRangeStart, PodRangeEnd)
--Export Markers to filename_with_path
--filename_with_path - filename of the file where the markers shall be exported to
--PodRangeStart - start of the Podcast;markers earlier of that will not be exported;markers exported will be markerposition minus PodRangeStart
--                must be a positive value; nil=0
--PodRangeEnd - end of the Podcast; markers later of that will not be exported; 
--              must be a positive value; nil=end of project  
--
-- return -1 in case of error
  
  if filename_with_path == nil then return -1 end
  PodRangeStart=tonumber(PodRangeStart)
  PodRangeEnd=tonumber(PodRangeEnd)
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
  if PodRangeEnd<PodRangeStart then return -1 end  
  local number=ultraschall.CountNormalMarkers()
    
  local timestring="00:00:00.000"
  
  local file=io.open(filename_with_path,"w")
  
  if file==nil then return -1 end
    for i=1,number do
      local idx,shown_number,pos,name, URL=ultraschall.EnumerateNormalMarkers(i)
      if pos>=PodRangeStart and pos<=PodRangeEnd then
        pos=pos-PodRangeStart
        timestring=ultraschall.SecondsToTime(pos)
        file:write(timestring.." "..name.."\n")
      end
    end
  local fileclose=io.close(file)
  return 1
end 
--A,AA=ultraschall.AddNormalMarker(10,10,"10mark")
--A,AA=ultraschall.AddNormalMarker(30,30,"30mark")
--A,AA=ultraschall.AddNormalMarker(20,20,"20mark")
--APPALACHEN=ultraschall.ExportNormalMarkersToFile("c:\\test.txt")


function ultraschall.ExportNormalMarkersToFile_Filerequester(PodRangeStart, PodRangeEnd)
--Export Markers to File(must be an existing file or the requester runs into troubles!)
--PodRangeStart - start of the Podcast;markers earlier of that will not be exported;markers exported will be markerposition minus PodRangeStart
--                must be a positive value; nil=0
--PodRangeEnd - end of the Podcast; markers later of that will not be exported; 
--              must be a positive value; nil=end of project  
-- return -1 in case of error
  
  if PodRangeStart==nil then PodRangeStart=0 end
  PodRangeStart=tonumber(PodRangeStart)
  PodRangeEnd=tonumber(PodRangeEnd)
  if PodRangeStart<0 then return -1 end
  if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
  if PodRangeEnd<PodRangeStart then return -1 end
  
  local number=ultraschall.CountNormalMarkers()
  local retval, filename_with_path = reaper.GetUserFileNameForRead("Markerfile.markers.txt", "Export Markers", "*.markers.txt")
  if retval==false then return -1 end
  local timestring="00:00:00.000"
  
  local file=io.open(filename_with_path,"w")
  
  if file==nil then return -1 end
    for i=1,number do
      local idx,shown_number,pos,name, URL=ultraschall.EnumerateNormalMarkers(i)
      if pos>=PodRangeStart and pos<=PodRangeEnd then
        pos=pos-PodRangeStart
        timestring=ultraschall.SecondsToTime(pos)
        file:write(timestring.." "..name.."\n")
      end
    end
  local fileclose=io.close(file)
  return 1
end
--ultraschall.ExportMarkersToFile_Filerequester(7,9999999999)

-------------------------
---- Import Markers -----
-------------------------

function ultraschall.ImportShownotesFromFile(filename_with_path)
--!!NEW FORMAT! NEEDS TO BE IMPLEMENTED FIRST!!!

-- returns an array fo the imported values
-- first entry, time1 in seconds, second entry markername1, third entry time2 in seconds, fourth entry markername2, etc
--
-- filename_with_path - filename with path of the file to import
--[[
  if filename_with_path == nil then return -1 end
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
  if PodRangeEnd<PodRangeStart then return -1 end  number=ultraschall.CountNormalMarkers()
  
  file=io.open(filename_with_path,"r")
  if file==nil then return -1 end
  fileclose=io.close(file) 
    
  markername=""
  entry=0

table = {}
    
  for line in io.lines(filename_with_path) do
    entry=entry+1
    table[entry]={}
    time=ultraschall.TimeToSeconds(line:match("%d*:%d*:%d*.%d*"))
    markername=line:match("%s.*")

    if markername==nil then markername="" end
    if time<0 then return -1 end

    table[entry][0]=time
    table[entry][1]=markername
  end

  return table]]
end

--A=ultraschall.ImportShownotesFromFile("c:\\test.txt")

function ultraschall.ImportShownotesFromFile_Filerequester()
--!!NEW FORMAT! NEEDS TO BE IMPLEMENTED FIRST!!!

-- returns an array fo the imported values
-- first entry, time1 in seconds, second entry markername1, third entry time2 in seconds, fourth entry markername2, etc
--
-- filename_with_path - filename with path of the file to import
--[[
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  if PodRangeEnd==nil then PodRangeEnd=reaper.GetProjectLength(0) end
  if PodRangeEnd<PodRangeStart then return -1 end  number=ultraschall.CountNormalMarkers()
  
  retval, filename_with_path = reaper.GetUserFileNameForRead("Shownotemarkers.shownotess.txt", "Import Shownote-Markers", "*.shownotes.txt")
  if retval==false then return -1 end 
  
    file=io.open(filename_with_path,"r")
    if file==nil then return -1 end
    fileclose=io.close(file) 
      
    markername=""
    entry=0
  
  table = {}
      
    for line in io.lines(filename_with_path) do
      entry=entry+1
      table[entry]={}
      time=ultraschall.TimeToSeconds(line:match("%d*:%d*:%d*.%d*"))
      markername=line:match("%s.*")
  
      if markername==nil then markername="" end
      if time<0 then return -1 end
  
      table[entry][0]=time
      table[entry][1]=markername
    end
  
    return table]]
  end
  

--APPACHEN=ultraschall.ImportShownotesFromFile_Filerequester()

function ultraschall.ImportChaptersFromFile(filename_with_path,PodRangeStart)
-- Imports chapterentries from a file and returns an array of the imported values.
-- array[markernumber1][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber1][1] - name of the marker
-- array[markernumber2][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber2][1] - name of the marker
-- array[markernumberx][0] - position of the marker in seconds+PodRangeStart
-- array[markernumberx][1] - name of the marker

-- Parameters:
-- filename_with_path - filename with path of the file to import
-- Podrangestart - the start of the podcast in seconds. Will be added to the time-positions of each chaptermarker. 
--    Podrangestart=0 gives you the timepositions, as they were stored in the chapter-marker-import-file.

  if filename_with_path == nil then return -1 end
  PodRangeStart=tonumber(PodRangeStart)
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  local number=ultraschall.CountNormalMarkers()
  
  local file=io.open(filename_with_path,"r")
  if file==nil then return -1 end
  local fileclose=io.close(file) 
    
  local markername=""
  local entry=0

local table = {}
    
  for line in io.lines(filename_with_path) do
    entry=entry+1
    table[entry]={}
    time=ultraschall.TimeToSeconds(line:match("%d*:%d*:%d*.%d*"))+PodRangeStart
    markername=line:match("%s.*")

    if markername==nil then markername="" end
    if time<0 then return -1 end

    table[entry][0]=time
    table[entry][1]=markername
  end

  return table
end

--ALABAMA=ultraschall.ImportChaptersFromFile("c:\\test.txt",10)

--reaper.MB(ALABAMA[1][1],"0",0)

function ultraschall.ImportChaptersFromFile_Filerequester(PodRangeStart)
-- Opens a filerequester to choose the importfile with. Imports chapterentries from the chosen file and returns 
-- an array of the imported values.
-- array[markernumber1][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber1][1] - name of the marker
-- array[markernumber2][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber2][1] - name of the marker
-- array[markernumberx][0] - position of the marker in seconds+PodRangeStart
-- array[markernumberx][1] - name of the marker

-- Parameters:
-- Podrangestart - the start of the podcast in seconds. Will be added to the time-positions of each chaptermarker. Podrangestart=0 gives you the timepositions, as they were stored in the chapter-marker-import-file.

  local retval, filename_with_path = reaper.GetUserFileNameForRead("Markers.markers.txt", "Import Markers", "*.markers.txt")
  if retval==false then return -1 end 
  PodRangeStart=tonumber(PodRangeStart)
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  local number=ultraschall.CountNormalMarkers()
  
  local file=io.open(filename_with_path,"r")
  if file==nil then return -1 end
  local fileclose=io.close(file) 
    
  local markername=""
  local entry=0

local table = {}
    
  for line in io.lines(filename_with_path) do
    entry=entry+1
    table[entry]={}
    local time=ultraschall.TimeToSeconds(line:match("%d*:%d*:%d*.%d*"))+PodRangeStart
    markername=line:match("%s.*")

    if markername==nil then markername="" end
    if time<0 then return -1 end

    table[entry][0]=time
    table[entry][1]=markername
  end

  return table
end


--ALPPACHEN=ultraschall.ImportChaptersFromFile_Filerequester()


function ultraschall.ImportEditFromFile(filename_with_path,PodRangeStart)
-- Imports editentries from a file and returns an array of the imported values.
-- array[markernumber1][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber1][1] - name of the marker
-- array[markernumber2][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber2][1] - name of the marker
-- array[markernumberx][0] - position of the marker in seconds+PodRangeStart
-- array[markernumberx][1] - name of the marker

-- Parameters:
-- filename_with_path - filename with path of the file to import
-- Podrangestart - the start of the podcast in seconds. Will be added to the time-positions of each chaptermarker. 
--    Podrangestart=0 gives you the timepositions, as they were stored in the chapter-marker-import-file.

  if filename_with_path == nil then return -1 end
  PodRangeStart=tonumber(PodRangeStart)
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  local number=ultraschall.CountNormalMarkers()
  
  local file=io.open(filename_with_path,"r")
  if file==nil then return -1 end
  local fileclose=io.close(file) 
    
  local markername=""
  local entry=0

local table = {}
    
  for line in io.lines(filename_with_path) do
    entry=entry+1
    table[entry]={}
    time=ultraschall.TimeToSeconds(line:match("%d*:%d*:%d*.%d*"))+PodRangeStart
    markername=line:match("%s.*")

    if markername==nil then markername="" end
    if time<0 then return -1 end

    table[entry][0]=time
    table[entry][1]=markername
  end

  return table
end

--ABAMA=ultraschall.ImportEditFromFile("c:\\test.txt",10)

function ultraschall.ImportEditFromFile_Filerequester(PodRangeStart)
-- Opens a filerequester to choose the importfile with. Imports editentries from the chosen file and returns 
-- an array of the imported values.
-- array[markernumber1][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber1][1] - name of the marker
-- array[markernumber2][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber2][1] - name of the marker
-- array[markernumberx][0] - position of the marker in seconds+PodRangeStart
-- array[markernumberx][1] - name of the marker

-- Parameters:
-- Podrangestart - the start of the podcast in seconds. Will be added to the time-positions of each chaptermarker. Podrangestart=0 gives you the timepositions, as they were stored in the chapter-marker-import-file.

  local retval, filename_with_path = reaper.GetUserFileNameForRead("Markers.markers.txt", "Import Markers", "*.markers.txt")
  if retval==false then return -1 end 
  PodRangeStart=tonumber(PodRangeStart)
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  local number=ultraschall.CountNormalMarkers()
  
  local file=io.open(filename_with_path,"r")
  if file==nil then return -1 end
  local fileclose=io.close(file) 
    
  local markername=""
  local entry=0

local table = {}
    
  for line in io.lines(filename_with_path) do
    entry=entry+1
    table[entry]={}
    local time=ultraschall.TimeToSeconds(line:match("%d*:%d*:%d*.%d*"))+PodRangeStart
    markername=line:match("%s.*")

    if markername==nil then markername="" end
    if time<0 then return -1 end

    table[entry][0]=time
    table[entry][1]=markername
  end

  return table
end


--APPACHEN=ultraschall.ImportEditFromFile_Filerequester()

function ultraschall.ImportMarkersFromFile(filename_with_path,PodRangeStart)
-- Imports markerentries from a file and returns an array of the imported values.
-- array[markernumber1][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber1][1] - name of the marker
-- array[markernumber2][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber2][1] - name of the marker
-- array[markernumberx][0] - position of the marker in seconds+PodRangeStart
-- array[markernumberx][1] - name of the marker

-- Parameters:
-- filename_with_path - filename with path of the file to import
-- Podrangestart - the start of the podcast in seconds. Will be added to the time-positions of each chaptermarker. 
--    Podrangestart=0 gives you the timepositions, as they were stored in the chapter-marker-import-file.

  if filename_with_path == nil then return -1 end
  PodRangeStart=tonumber(PodRangeStart)
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  local number=ultraschall.CountNormalMarkers()
  
  local file=io.open(filename_with_path,"r")
  if file==nil then return -1 end
  local fileclose=io.close(file) 
    
  local markername=""
  local entry=0

local table = {}
    
  for line in io.lines(filename_with_path) do
    entry=entry+1
    table[entry]={}
    time=ultraschall.TimeToSeconds(line:match("%d*:%d*:%d*.%d*"))+PodRangeStart
    markername=line:match("%s.*")

    if markername==nil then markername="" end
    if time<0 then return -1 end

    table[entry][0]=time
    table[entry][1]=markername
  end

  return table
end

--APPALACHEN=ultraschall.ImportMarkersFromFile("c:\\test.txt")

--A,AA,AAA,AAAA=ultraschall.EnumerateNormalMarkers(4)
--APPALACHEN=ultraschall.ExportMarkersToFile("c:\\test.txt",0,99999999)

function ultraschall.ImportMarkersFromFile_Filerequester(PodRangeStart)
-- Opens a filerequester to choose the importfile with. Imports markerentries from the chosen file and returns 
-- an array of the imported values.
-- array[markernumber1][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber1][1] - name of the marker
-- array[markernumber2][0] - position of the marker in seconds+PodRangeStart
-- array[markernumber2][1] - name of the marker
-- array[markernumberx][0] - position of the marker in seconds+PodRangeStart
-- array[markernumberx][1] - name of the marker

-- Parameters:
-- Podrangestart - the start of the podcast in seconds. Will be added to the time-positions of each chaptermarker. Podrangestart=0 gives you the timepositions, as they were stored in the chapter-marker-import-file.

  local retval, filename_with_path = reaper.GetUserFileNameForRead("Markers.markers.txt", "Import Markers", "*.markers.txt")
  if retval==false then return -1 end 
  PodRangeStart=tonumber(PodRangeStart)
  if PodRangeStart==nil then PodRangeStart=0 end
  if PodRangeStart<0 then return -1 end
  local number=ultraschall.CountNormalMarkers()
  
  local file=io.open(filename_with_path,"r")
  if file==nil then return -1 end
  local fileclose=io.close(file) 
    
  local markername=""
  local entry=0

local table = {}
    
  for line in io.lines(filename_with_path) do
    entry=entry+1
    table[entry]={}
    local time=ultraschall.TimeToSeconds(line:match("%d*:%d*:%d*.%d*"))+PodRangeStart
    markername=line:match("%s.*")

    if markername==nil then markername="" end
    if time<0 then return -1 end

    table[entry][0]=time
    table[entry][1]=markername
  end

  return table
end

--APPACHEN=ultraschall.ImportMarkersFromFile_Filerequester()


-------------------------
---- Convert Markers ----
-------------------------

function ultraschall.MarkerToEditMarker(number)

number=tonumber(number)
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
local color=0
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFF0000|0x1000000
    else
      color = 0x0000FF|0x1000000
    end 

    local idx, shownmarker, position, markername = ultraschall.EnumerateNormalMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Edit:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.MarkerToEditMarker(1)


function ultraschall.MarkerToChapterMarker(number)
number=tonumber(number)
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
local color=0
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x0000FF|0x1000000
    else
      color = 0xFF0000|0x1000000
    end 
    
    local idx, shownmarker, position, markername = ultraschall.EnumerateNormalMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Chapter:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.MarkerToChapterMarker(1)

function ultraschall.MarkerToDummyMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x999999|0x1000000
    else
      color = 0x999999|0x1000000
    end 
    
    local idx, shownmarker, position, markername = ultraschall.EnumerateNormalMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Dummy:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.MarkerToDummyMarker("1")

function ultraschall.MarkerToShownoteMarker(number)
--TODO: New implementation and localize variables
--reaper.MB("test","test",0)
-- test --<URL>--
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x00AA00|0x1000000
    else
      color = 0x00AA00|0x1000000
    end
        
    idx, shownmarker, position, markername = ultraschall.EnumerateNormalMarkers(number)
--    reaper.MB(tostring(idx),markername,0)
    if idx==-1 then return -1 end
    URL=markername:match("(--<.*>--)")
    if URL==nil then URL="--<>--" end
    Atempname=markername:sub(1,-(URL:len()+1))
    itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Shownote:"..Atempname..URL, color)
--  end
return idx, shownmarker, position, markername
end

--A, AA, AAA, AAAA=ultraschall.EnumerateNormalMarkers(1)
--A,AA,AAA,AAAA=ultraschall.MarkerToShownoteMarker(1)


function ultraschall.ShownoteToEditMarker(number)
--TODO: New implementation and localize variables
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFF0000|0x1000000
    else
      color = 0x0000FF|0x1000000
    end 
            
    idx, shownmarker, position, markername,URL = ultraschall.EnumerateShownoteMarkers(number)
    if idx==-1 then return -1 end
    itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Edit:"..markername.."--<"..URL..">--", color)
--  end
return idx, shownmarker, position, markername
end


function ultraschall.ShownoteToChapterMarker(number)
--TODO: New implementation and localize variables
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x0000FF|0x1000000
    else
      color = 0xFF0000|0x1000000
    end 
                
    idx, shownmarker, position, markername,URL = ultraschall.EnumerateShownoteMarkers(number)
    if idx==-1 then return -1 end
    itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Chapter:"..markername.."--<"..URL..">--", color)
--  end
return idx, shownmarker, position, markername
end


function ultraschall.ShownoteToDummyMarker(number)
--TODO: New implementation and localize variables
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x999999|0x1000000
    else
      color = 0x999999|0x1000000
    end 
                
    idx, shownmarker, position, markername,URL = ultraschall.EnumerateShownoteMarkers(number)
    if idx==-1 then return -1 end
    itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Dummy:"..markername.."--<"..URL..">--", color)
--  end
return idx, shownmarker, position, markername
end


function ultraschall.ShownoteToMarker(number)
--TODO: New implementation and localize variables
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x888888|0x0000000
    else
      color = 0x888888|0x0000000
    end 
                
    idx, shownmarker, position, markername,URL = ultraschall.EnumerateShownoteMarkers(number)
    if idx==-1 then return -1 end
--    itworks=ultraschall.DeleteShownoteMarker(number)
--    itworks2=ultraschall.AddNormalMarker(position, shownmarker, markername.."--<"..URL..">--")
    itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, markername.."--<"..URL..">--", color)
--  end
return idx, shownmarker, position, markername
end

--ultraschall.AddShownoteMarker(10,10,"test","URL.com")
--AA,AAA,AAA,AAAA = ultraschall.ShownoteToMarker(1)
--ultraschall.MarkerToShownoteMarker(1)

function ultraschall.ChapterToEditMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
 os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFF0000|0x1000000
    else
      color = 0x0000FF|0x1000000
    end
        
    local idx, shownmarker, position, markername = ultraschall.EnumerateChapterMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Edit:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.ChapterToEditMarker(1)
--A,AA,AAA,AAAA=ultraschall.EditToChapterMarker(1)

function ultraschall.ChapterToShownoteMarker(number)
--Needs reimplementation and localizing variables
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x00AA00|0x1000000
    else
      color = 0x00AA00|0x1000000
    end
        
    idx, shownmarker, position, markername = ultraschall.EnumerateChapterMarkers(number)
--    reaper.MB(tostring(idx),markername,0)
    if idx==-1 then return -1 end
    URL=markername:match("(--<.*>--)")
    if URL==nil then URL="--<>--" end
    Atempname=markername:sub(1,-(URL:len()+1))
    itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Shownote:"..Atempname..URL, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.ChapterToShownoteMarker(1)
--A,AA,AAA,AAAA=ultraschall.ShownoteToChapterMarker(1)

function ultraschall.ChapterToDummyMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x999999|0x1000000
    else
      color = 0x999999|0x1000000
    end 
    
    local idx, shownmarker, position, markername = ultraschall.EnumerateChapterMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Dummy:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.ChapterToDummyMarker(1)
--A,AA,AAA,AAAA=ultraschall.DummyToChapterMarker(1)

function ultraschall.ChapterToMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x888888|0x0000000
    else
      color = 0x888888|0x0000000
    end 
    
    local idx, shownmarker, position, markername = ultraschall.EnumerateChapterMarkers(number)
    if idx==-1 then return -1 end
  if markername=="" then itworks=reaper.SetProjectMarkerByIndex2(0, idx-1, false, position, 0, shownmarker, ""..markername, color,1)
    else local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, ""..markername, color)
    end
    --  end
return idx, shownmarker, position, markername
end

--ultraschall.AddChapterMarker(12,12,"chapter")
--A,AA,AAA,AAAA=ultraschall.ChapterToMarker(1)
--A,AA,AAA,AAAA=ultraschall.MarkerToChapterMarker(1)

function ultraschall.EditToChapterMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x0000FF|0x1000000
    else
      color = 0xFF0000|0x1000000
    end 
     
    local idx, shownmarker, position, markername = ultraschall.EnumerateEditMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Chapter:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.EditToChapterMarker("1")
--A,AA,AAA,AAAA=ultraschall.ChapterToEditMarker(1)

function ultraschall.EditToShownoteMarker(number)
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x00AA00|0x1000000
    else
      color = 0x00AA00|0x1000000
    end
        
    idx, shownmarker, position, markername = ultraschall.EnumerateEditMarkers(number)
--    reaper.MB(tostring(idx),markername,0)
    if idx==-1 then return -1 end
    URL=markername:match("(--<.*>--)")
    if URL==nil then URL="--<>--" end
    Atempname=markername:sub(1,-(URL:len()+1))
    itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Shownote:"..Atempname..URL, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.EditToShownoteMarker(1)
--A,AA,AAA,AAAA=ultraschall.ShownoteToEditMarker(1)

function ultraschall.EditToDummyMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x888888|0x0000000
    else
      color = 0x888888|0x0000000
    end 
     
    local idx, shownmarker, position, markername = ultraschall.EnumerateEditMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Dummy:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.EditToDummyMarker(1)

function ultraschall.EditToMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x888888|0x0000000
    else
      color = 0x888888|0x0000000
    end 
    
    local idx, shownmarker, position, markername = ultraschall.EnumerateEditMarkers(number)
    if idx==-1 then return -1 end
    if markername=="" then itworks=reaper.SetProjectMarkerByIndex2(0, idx-1, false, position, 0, shownmarker, ""..markername, color,1)
    else local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, ""..markername, color)
    end
--  end
return idx, shownmarker, position, markername
end

--A=ultraschall.AddEditMarker(9,7,"edittitle")
--A,AA,AAA,AAAA=ultraschall.EditToMarker(1)
--A,AA,AAA,AAAA=ultraschall.MarkerToEditMarker(1)
--mespotine
function ultraschall.DummyToChapterMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x0000FF|0x1000000
    else
      color = 0xFF0000|0x1000000
    end
         
    local idx, shownmarker, position, markername = ultraschall.EnumerateDummyMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Chapter:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.DummyToChapterMarker(1)
--A,AA,AAA,AAAA=ultraschall.ChapterToDummyMarker(1)


function ultraschall.DummyToShownoteMarker(number)
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.DummyToShownoteMarker(1)
--A,AA,AAA,AAAA=ultraschall.ShownoteToDummyMarker(1)

function ultraschall.DummyToEditMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
     color = 0xFF0000|0x1000000
    else
      color = 0x0000FF|0x1000000
    end
         
    local idx, shownmarker, position, markername = ultraschall.EnumerateDummyMarkers(number)
    if idx==-1 then return -1 end
    local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, "_Edit:"..markername, color)
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.DummyToEditMarker(1)
--A,AA,AAA,AAAA=ultraschall.EditToDummyMarker(1)

function ultraschall.DummyToMarker(number)
number=tonumber(number)
local color=0
if number==nil then return -1 end
if number<1 then return -1 end
--  retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
--  for i=retval,0,-1 do
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0x888888|0x0000000
    else
      color = 0x888888|0x0000000
    end 
    
    local idx, shownmarker, position, markername = ultraschall.EnumerateDummyMarkers(number)
    if idx==-1 then return -1 end
    if markername=="" then itworks=reaper.SetProjectMarkerByIndex2(0, idx-1, false, position, 0, shownmarker, ""..markername, color,1)
    else local itworks=reaper.SetProjectMarkerByIndex(0, idx-1, false, position, 0, shownmarker, ""..markername, color)
    end
--  end
return idx, shownmarker, position, markername
end

--A,AA,AAA,AAAA=ultraschall.DummyToMarker(1)
--A,AA,AAA,AAAA=ultraschall.MarkerToDummyMarker(1)







--function ultraschall.test() end

--[[
<ApiDocBlocFunc>
<slug>
US1.Introduction
</slug>
<chaptername>
1. Introduction
</chaptername>
<description>
The Ultraschall-Extension is intended to be an extension for the DAW Reaper, that enhances it with podcast functionalities. Most DAWs are intended to be used by musicians, for music, but podcasters have their own needs to be fulfilled. In fact, in some places their needs differ from the needs of a musician heavily. Ultraschall is intended to optimise the workflows of a podcaster in Reaper, by reworking it with functionalities for the special needs of podcasters.
The Ultraschall-Framework itself is intended to include a set of functions, that help creating such functionalities. By giving programmers helper functions for cough-buttons, chapter-marker management, giving additional ways to navigate through a project and to get access to each and every corner of Reaper. That way, extending Ultraschall is more comfortable to do.
</description>
<semanticcontext>
API-For Lua in Reaper
Programmer's Manual
</semanticcontext>
<begin></begin>
<tags>
Introduction
</tags>
</ApiDocBlocFunc>
--]]
--[[
<ApiDocBlocFunc>
<slug>
US2.Setup
</slug>
<chaptername>
2. Setup
</chaptername>
<description>
From Ultraschall 4.0 on, the framework will be delivered together with the installation-package of Ultraschall. Up until then, you can download the latest versions of it here on this page as a zip-archive.

From Ultraschall 4.0 on, the framework will be delivered together with the installation-package of Ultraschall. Up until then, you can download the latest versions of it here on this page as a zip-archive.

<a href="http://www.mespotine.de/Ultraschall/Framework/US_Framework4_00_beta2.zip">DOWNLOADLINK for Ultraschall Framework 4.0 - Beta2.1 - 30th of August 2017</a>

earlier releases:
<a href="http://www.mespotine.de/Ultraschall/Framework/US_Framework4_00_beta2.zip">DOWNLOADLINK for Ultraschall Framework 4.0 - Beta2 - 20th of August 2017</a>
<a href="http://www.mespotine.de/Ultraschall/Framework/US_Framework4_00_beta1.zip">DOWNLOADLINK for Ultraschall Framework 4.0 - Beta1 - 11th of July 2017</a>

Requirements: Reaper 5.40 and SWS extension 2.8.8

Step 1: When you've downloaded the archive, open it. You'll find in it a directory called "Scripts", a license-file, this documentation and the file "reaper-kb.txt".
Step 2: Copy the files, that are inside the "Scripts"-directory into the Scripts-directory of your Reaper-Ressources-Folder.
Step 3: Open the file "reaper-kb.ini" from the ressources-folder of Reaper with a texteditor. Open the file "reaper-kb.txt" from the downloaded archive as well in a texteditor.
Step 4: Copy the entries from the "reaper-kb.TXT" and paste them into the "reaper-kb.INI" file AFTER the SCR-Entries and BEFORE the KEY entries. If they are already existing, replace them. Save the file.
Step 5: Start Reaper.

</description>
<semanticcontext>
API-For Lua in Reaper
Programmer's Manual
</semanticcontext>
<tags>
Introduction
</tags>
</ApiDocBlocFunc>

--]]
--[[
<ApiDocBlocFunc>
<slug>
US3.How2Use
</slug>
<chaptername>
3. How to use the API in your LUA-Script
</chaptername>
<description>
If you want to use the Ultraschall Framework-Functions in your script, just add the following lines at the beginning(!):
<pre style="background-color:#DDDDDD;">
<code>
-- Ultraschall Functions-API
-- include the following lines

ultraschall={}

ultraschall.US_Functions="ON"                -- Turn OFF, if you don't want the Functions-API
                                              -- Turn ON, if you want the Functions-API
ultraschall.US_DataStructures="ON"           -- Turn OFF, if you don't want the DataStructures-API
                                              -- Turn ON, if you want the DataStructures-API
ultraschall.US_GraphicsFunctionsLibrary="ON" -- Turn OFF, if you don't want the Graphics-Library-API
                                              -- Turn ON, if you want the Graphics-Library-API
ultraschall.US_SoundFunctionsLibrary="ON"    -- Turn OFF, if you don't want the Graphics-Library-API
                                              -- Turn ON, if you want the Graphics-Library-API      
ultraschall.US_VideoFunctionsLibrary="ON"    -- Turn OFF, if you don't want the Graphics-Library-API
                                              -- Turn ON, if you want the Graphics-Library-API                              
ultraschall.US_BetaFunctions="ON"           -- Only has an effect, if ultraschall_functions_api_Beta.lua exists in Scripts-folder
                                               -- Turn OFF, if you don't want BETA-Api-Functions
                                               -- Turn ON, if you want BETA-Api-Functions
                                    
if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
  ultraschall.Script_Path=reaper.GetResourcePath().."\\Scripts\\"
elseif reaper.GetOS() == "OSX32" or reaper.GetOS()== "OSX64" then
  ultraschall.Script_Path=reaper.GetResourcePath().."/Scripts/"
end

US_API = dofile(ultraschall.Script_Path .. "ultraschall_api.lua")  
-- now you can program the API
</code>
</pre>As you can see, the Framework contains several parts, that you can turn ON or OFF, depending on if you need them or not. Though: only US_Functions is implemented yet, the others will follow over time.

Now that you've included the necessary API-lines, we can test, if the framework was successfully installed by calling the function:
<pre style="background-color:#DDDDDD;">
<code>
ultraschall.ApiTest()
</code>
</pre>directly under(!) the ultraschall.API-lines. Run the script by saving it with Ctrl-S. If everything worked right, several messageboxes will appear that tell you, if the API-works and which of the API-parts you've turned on or off.

Voila: now you can program the Ultraschall-Framework.

</description>
<semanticcontext>
API-For Lua in Reaper
Programmer's Manual
</semanticcontext>
<tags>
How 2 to use
</tags>
</ApiDocBlocFunc>

--]]
--[[
<ApiDocBlocFunc>
<slug>
US4.How2UseBeta
</slug>
<chaptername>
4. How to use Beta Functions
</chaptername>
<description>
Before new functions will be released with a next Ultraschall-Release, they are in beta-stage. They will be available at DOWNLOADLINK. Just download the archive, open it, put the .lua-scripts into the "Scripts"-folder with the ressources-folder of Reaper.

Voila, you can use these new Beta-Functions, if you turned them ON in the variable "US_BetaFunctions" (see "How to use the API in your LUA-Script").

Keep in mind: they are beta. They will change behavior, maybe change their parameters or disappear at all in the final release!

</description>
<semanticcontext>
API-For Lua in Reaper
Programmer's Manual
</semanticcontext>
<tags>
Beta Functions
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
US5.Bugreporting
</slug>
<chaptername>
5. Bugreporting, Feature-requests and all the rest
</chaptername>
<description>
If you find any bugs or itches and want to report them, I suggest you the following procedure:
a) Make notes of: what operating-system you use(Mac, Win, Linux), which Reaper-version, which SWS-Version and which Ultraschall-Framework-Version.
b) Write down, what you wanted to do, what you expected to happen and what has happened instead. Make it as detailed as possible(a screenvideo i.e. would be perfect), as more information helps to find out, where the problem lies. It's always better to write too much, than the other way around.
c) Send these notes as eMail: lspmp3@yahoo.de(for framework-related stuff only!!) or go to <a href="http://www.sendegate.de">sendegate.de</a> into the Ultraschall-section.

Bugreports that contain only a "it doesn't work" and "I expected it to work" will be ignored gracefully ;)

If you have feature-requests, we have open ears. Keep in mind, not everything you find a good idea actually is one. So we may or may not take on your idea, change and rework it into a way, that benefits all, not just your particular use-case. When in doubt, just try it!
Keep also in mind: there are limitations. Some cool features we all would love to have, simply aren't implementable. Que sera, sera...

For your comments just send a mail at: lspmp3@yahoo.de(for framework-related stuff only!!) or go to <a href="http://www.sendegate.de">sendegate.de</a> into the Ultraschall-section.

PS: If you know how to implement impossible things or do things better than the current implementation, you are welcome to donate your improved codes. :)

</description>
<semanticcontext>
API-For Lua in Reaper
Programmer's Manual
</semanticcontext>
<tags>
Beta Functions
</tags>
</ApiDocBlocFunc>

<ApiDocBlocFunc>
<slug>
US6.License
</slug>
<chaptername>
6. License
</chaptername>
<description>
################################################################################
# 
# Copyright (c) 2014-2017 Ultraschall (http://ultraschall.fm)
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# 
################################################################################

Reaper and the Reaper-Logo are trademarks of cockos inc and can be found at <a href="http://www.reaper.fm">reaper.fm</a>

The SWS-logo has been taken from the SWS-extension-project, which can be found at <a href="http://www.sws-extension.org/">sws-extension.org</a>

</description>
<semanticcontext>
API-For Lua in Reaper
Programmer's Manual
</semanticcontext>
<tags>
Beta Functions
</tags>
</ApiDocBlocFunc>


<ApiDocBlocFunc>
<slug>
Render1.Introduction
</slug>
<chaptername>
1. Introduction to Renderfunctions
</chaptername>
<description>
The Render-Functions within the Ultraschall Framework allow you to render audio/video without having to use the Rendering-dialog.
That way, you can program things like e.g. queue-rendering into multiple formats of a project or rendering a project to one project and another rendering into a "backup-folder" and such.
To make that possible, it is necessary to know some things, on how it works, as rendering in Reaper, with all the options it provides, is quite complex.
But don't panic.

The rendering functions allow you to render a project, which means: 
 1) you can choose an RPP-projectfile to be rendered, 
 2) the renderfilename, where the audio/video shall be rendered to
 3) format-specific parameters, like kilobits/second or rendering quality, etc.
 
When rendering starts, the rendering function does the following things:<div style="padding-left:4%;">
 1) It checks, whether the parameters are valid. If not, it returns -1 as error value.
 2) It checks, whether the current project is saved. If not, it returns -2 as error value, as all rendering-functions need the current project to be saved.
 3) It creates a copy of the rpp-file as ultraschall-temp.rpp in the projectfolder of the rpp-file you choose. Returns -3 if it already exists to prevent accidental overwriting.
 4) It inserts the necessary render-settings into the ultraschall-temp.rpp
 5) It loads the ultraschall-temp.rpp as current project, closing the former current project
 6) It starts the action 41824 - "File: Render project, using the most recent render settings" which renders the file
 7) It reopens the former project, that was the current project before rendering
 </div>
That means, you need to take care of the fact, that the current project is saved before rendering, as well as that the ultraschall-temp.rpp doesn't exist in the project-folder of the project, that shall be rendered, or you'll get an error message.

If you want to render the current project, you need to save the project using reaper.Main_SaveProject.
After that, you get the filename.rpp and project-path using the functions reaper.GetProjectName and reaper.GetProjectPath. Keep in mind, that GetProjectPath isn't just the path to the projectfile, but to the subfolder for the recordings. 
You can change it to the rpp-project-file-folder itself, by manipulating the return-value of the GetProjectPath-function: 

On windows:
<pre style="background-color:#DDDDDD;"><code>buf=buf:match("(.*)\\")</code></pre>or
<pre style="background-color:#DDDDDD;"><code>Path=reaper.GetProjectPath(""):match("(.*)\\")</code></pre>
On Mac:
<pre style="background-color:#DDDDDD;"><code>buf=buf:match("(.*)/")</code></pre>or
<pre style="background-color:#DDDDDD;"><code>Path=reaper.GetProjectPath(""):match("(.*)/")</code></pre>

Otherwise, you look into the wrong folder for the projectfile!
Now you just need to use that filename+path as parameter for the render-function you want to use.

In the likely case, that you want to influence more things for rendering, like samplerate, stereo or mono, etc, you make a copy of the rpp-file using you want to render using <a href="#MakeCopyOfFile">MakeCopyOfFile</a>. The copy must have a different name and be in the same folder, as the original rpp-file!
Now you can alter the copied-file using the following Ultraschall-Framework-functions, that represent certain elements from Reaper's Render-Dialog:

<a href="#SetProject_RenderFilename">SetProject_RenderFilename</a> (File name), <a href="#SetProject_RenderPattern">SetProject_RenderPattern</a> (File name, when using Wildcards), <a href="#SetProject_RenderDitherState">SetProject_RenderDitherState</a> (Master mix: Dither/Noise shaping checkboxes), <a href="SetProject_RenderFreqNChans">SetProject_RenderFreqNChans</a> (Sample rate in Hz, Channels), <a href="#SetProject_RenderRange">SetProject_RenderRange</a> (Bounds, Time bounds, Tail), <a href="#SetProject_RenderResample">SetProject_RenderResample</a> (Resample mode (if needed), <a href="#SetProject_RenderSpeed">SetProject_RenderSpeed</a>, <a href="#SetProject_RenderStems">SetProject_RenderStems</a> (Source)

The altered projectfile can be used now as parameter for the rendering-functions.
</description>
<semanticcontext>
Rendering of Project
About Rendering Projects
</semanticcontext>
<tags>
</tags>
</ApiDocBlocFunc>


<ApiDocBlocFunc>
<slug>
Render2.How2Use
</slug>
<chaptername>
2. How to Use Rendering Functions (examples)
</chaptername>
<description>
Using the rendering-functions is quite easy. Let's use MP3 as an example(needs LAME-encoder to be installed into Reaper!)
On Windows:
<pre style="background-color:#DDDDDD;"><code>
retval = ultraschall.RenderProjectToMP3_CBR("path\\filename.rpp", "path\\filename.mp3", 128, 5)
</code>
</pre>

On Mac:
<pre style="background-color:#DDDDDD;"><code>
retval = ultraschall.RenderProjectToMP3_CBR("path/filename.rpp", "path/filename.mp3", 128, 5)
</code>
</pre>

That way, you will render the file "filename.rpp" in "path" into an MP3 called "filename.mp3". This MP3 will be encoded with a bitrate of 128kbps, while encode speed is 5 which means slow but best quality.

If you want to render the current project as mp3 with the same quality-settings as above, you can use the following snippet:
<pre style="background-color:#DDDDDD;"><code>
    --Get the correct Separator for a Windows or a Mac-system
sep=ultraschall.Separator

    --Save current Project
reaper.Main_SaveProject(0, false)

    --Get Projectpath and Projectname
ProjectPath = reaper.GetProjectPath("")
ProjectName = reaper.GetProjectName(0, "")

    -- Create a string with the ProjectFilename with path
    -- As "ProjectPath" includes the folder for the recordings themselves, we get rid of it, using match, as otherwise we 
    -- look in the wrong folder for the project, not the one, where the rpp-projectfile lies
ProjectFilename=ProjectPath:match("(.*)"..sep)..sep..ProjectName

    -- Create a string with the MP3Filename with path
    -- As "ProjectPath" includes the folder for the recordings themselves, we get rid of it, using match, as otherwise we 
    -- save the MP3 in the recordings-folder, rather than the folder, where the rpp-projectfile lies
MP3Filename=ProjectPath:match("(.*)"..sep)..sep..ProjectName:sub(1,-5)..".mp3" -- The MP3-Filename

    -- Render the project as constant-bitrate-MP3 with
    -- 128 kbps and rendering speed 5 (best quality but slowest)
Retval = ultraschall.RenderProjectToMP3_CBR(ProjectFilename, MP3Filename, 128, 5) 
</code></pre>
If you want to alter the rendersettings first, you can use the following snippet as a template. It changes the render-range, before rendering:
<pre style="background-color:#DDDDDD;"><code>
    --Get the correct Separator for a Windows or a Mac-system
sep=ultraschall.Separator

    -- Save current Project
reaper.Main_SaveProject(0, false)

    -- Get Projectpath and Projectname
ProjectPath = reaper.GetProjectPath("")
ProjectName = reaper.GetProjectName(0, "")

    -- Create a string with the ProjectFilename with path
    -- As "ProjectPath" includes the folder for the recordings themselves, we get rid of it, using match, as otherwise we 
    -- look in the wrong folder for the project
ProjectFilename=ProjectPath:match("(.*)"..sep)..sep..ProjectName

    -- Create a string with the temporary-ProjectFilename with path, which must be in the same folder, 
    -- as the original project-file.
    -- As "ProjectPath" includes the folder for the recordings themselves, we get rid of it, using match,
    -- as otherwise we look in the wrong folder for the project.
    -- DON'T USE "Ultraschall-temp.rpp", as that name will be used by the rendering-function itself!
TempProjectFilename=ProjectPath:match("(.*)"..sep)..sep.."This-Is-A-Temporary-Project-File.rpp"

    -- To prevent accidental overwriting of an already existing file with the same name as
    -- TempProjectFilename, we check it's existence. If true, we end right here.
if reaper.file_exists(TempProjectFilename)==true then return -1 end

    -- Let's create a temporary copy of the project-file. 
Retval = ultraschall.MakeCopyOfFile(ProjectFilename, TempProjectFilename)

    -- Now we alter the render-settings in the temporary(!)-projectfile.
    -- We will do the the render-range, but you can use other ultraschall.SetProject_RenderXXXX-functions here as well
    -- Setting the Renderrange. The parameters are:
      -- TempProjectFilename - the temporary-project-filename
      -- 0 for Custom Time Range
      -- 10, which is the beginning of the render-range in seconds
      -- 20, which is the end of the render-range in seconds
      -- 0 for tail off for all bounds
      -- 0 for the taillength
Retval = ultraschall.SetProject_RenderRange(TempProjectFilename, 0, 10, 20, 0, 0)

    -- Create a string with the MP3Filename with path
    -- As "ProjectPath" includes the folder for the recordings themselves, we get rid of it, using match, as otherwise we 
    -- save the MP3 in the recordings-folder, rather than the folder, where the rpp-projectfile lies
MP3Filename=ProjectPath:match("(.*)"..sep)..sep..ProjectName:sub(1,-5)..".mp3" -- The MP3-Filename

    -- Render the project as constant-bitrate-MP3 with
    -- 128 kbps and rendering speed 5 (best quality but slowest)
Retval = ultraschall.RenderProjectToMP3_CBR(TempProjectFilename, MP3Filename, 128, 5) 

    --let's remove the temporary file again.
os.remove(TempProjectFilename)

    -- Hooray, Rendering, successfully accomplished! Congratulations!
</code>
</pre>
Read the accompanying Api-documentation entries for the functions, as they'll give you even more stuff to work with.

</description>
<semanticcontext>
Rendering of Project
About Rendering Projects
</semanticcontext>
<tags>
</tags>
</ApiDocBlocFunc>



--[[
<ApiDocBlocFunc>
<slug>
ApiTest
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.ApiTest()
</functionname>
<description>
Displays messages to show, which parts of the Ultraschall-API are turned on and which are turned off.
</description>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
help,api,test
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
Msg
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.Msg(string val)
</functionname>
<description>
prints a message to the Reaper Console
</description>
<parameters>
string val - your message as a string 
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
message,console
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetPath
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string path = ultraschall.GetPath(string str, string sep)
</functionname>
<description>
returns the path of a filename-string

returns nil in case of error 
</description>
<retvals>
string path  - the path as a string
</retvals>
<parameters>
string str - the path with filename you want to process
string sep - a separator, with which the function knows, how to separate filename from path
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
filemanagement,path,separator
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetPartialString
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string partial_string = ultraschall.GetPartialString(string str, string sep1, string sep2)
</functionname>
<description>
returns the part of a filename-string between sep1 and sep2

returns -1 if it doesn't work, no sep1 or sep2 exist 
</description>
<retvals>
string partial_string  - the partial string between sep1 and sep2
</retvals>
<parameters>
string str - string to be processed
string sep1 - separator on the "left" side of the partial string
string sep2 - separator on the "right" side of the partial string
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
string,separator
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SecondsToTime
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string time_string = ultraschall.SecondsToTime(number pos)
</functionname>
<description>
converts timeposition in seconds(pos) to a timestring (h)hh:mm:ss.mss
</description>
<retvals>
string time_string  - timestring in (h)hh:mm:ss.mss
</retvals>
<parameters>
number pos - timeposition in seconds
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
timestring, converter, seconds, string
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
TimeToSeconds
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number position = ultraschall.TimeToSeconds(string timestring)
</functionname>
<description>
converts timestring (h)hh:mm:ss.mss to a time in seconds(pos)
</description>
<retvals>
number position  - the converted position
</retvals>
<parameters>
string timestring - a string like: (h)hh:mm:ss.mss
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
timestring, converter, seconds, string
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
RunCommand
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.RunCommand(string actioncommand_id)  
</functionname>
<description>
runs a command by its ActionCommandID(instead of the CommandID-number)
</description>
<parameters>
string actioncommand_id - the ActionCommandID of the Command/Script/Action you want to run.
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
command,commandid,actioncommandid,action,run
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ToggleStateAction
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.ToggleStateAction(integer section, string actioncommand_id, integer state)
</functionname>
<description>
Toggles state of an action using the actioncommand_id(instead of the CommandID-number)

returns current state of the action after toggling
</description>
<retvals>
boolean retval  - state if the action, after it has been toggled
</retvals>
<parameters>
integer section - the section of the action(see ShowActionlist-dialog)
string actioncommand_id - the ActionCommandID of the action to toggle
integer state - 1 or 0
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
command,commandid,actioncommandid,action,run,state,section
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
RefreshToolbar_Action
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 ultraschall.RefreshToolbar_Action(integer section, string actioncommand_id)
</functionname>
<description>
Refreshes a toolbarbutton with an ActionCommandID(instead of the CommandID-number)
</description>
<parameters>
integer section - section
string actioncommand_id - ActionCommandID of the action, associated with the toolbarbutton 
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
command,commandid,actioncommandid,action,run,toolbar,refresh
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ToggleStateButton
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.ToggleStateButton(integer section, string actioncommand_id, integer state)
</functionname>
<description>
Toggles state and refreshes the button of an actioncommand_id
</description>
<retvals>
boolean retval  - state of the State-Button, after toggling
</retvals>
<parameters>
integer section - the section of the action(see ShowActionlist-dialog)
string actioncommand_id - the ActionCommandID of the action to toggle
integer state - 1 or 0
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
command,commandid,actioncommandid,action,run,toolbar,toggle,button
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
Notes2CSV
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
csv retval = ultraschall.Notes2CSV()
</functionname>
<description>
Gets the project's notes and returns it as a CSV.
</description>
<retvals>
csv retval  - the project notes, returned as a csv-string; entries separated by a comma
</retvals>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
notes,csv,converter,string
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CSV2Line
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string values = ultraschall.CSV2Line (string csv_line)
</functionname>
<description>
converts a string of csv-values into a string with all values and without the ,-separators

returns nil in case of error
</description>
<retvals>
string values  - all values in one string
</retvals>
string csv_line - the csv-line, values separated by commas
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
notes,csv,converter,string
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CSV2IndividualLinesAsArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
array individual_values = ultraschall.CSV2IndividualLinesAsArray(string csv_line)
</functionname>
<description>
convert a csv-string to an array of the individual values

returns nil in case or error
</description>
<retvals>
array individual_values  - all values, each in an individual array-position
</retvals>
<parameters>
string csv_line - a string as a csv, with all values included and separated by 
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
notes,csv,converter,string,array
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
RGB2Num
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer combined_colorvalue = ultraschall.RGB2Num(integer red, integer green, integer blue)
</functionname>
<description>
convert r,g,b into one integer-value that will be returned.

returns nil in case or error
</description>
<retvals>
integer combined_colorvalue  - one colorvalue, that can be used for color-operations. Exchange red and blue on Mac!
</retvals>
<parameters>
integer red - red-value betweeen 0 and 255. Can be negative to creative colorvalues for subtraction
integer green - green-value betweeen 0 and 255. Can be negative to creative colorvalues for subtraction
integer blue - blue-value betweeen 0 and 255. Can be negative to creative colorvalues for subtraction
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
colorvalues,rgb
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
RGB2Grayscale
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer graycolor = ultraschall.RGB2Grayscale(integer red, integer green, integer blue)
</functionname>
<description>
converts rgb to a grayscale value. Works native on Mac as well on Windows, no color conversion needed.
</description>
<parameters>
integer red - red-value between 0 and 255.
integer green - red-value between 0 and 255.
integer blue - red-value between 0 and 255.
</parameters>
<retvals>
integer graycolor  - the gray color-value, generated from red,blue and green.
</retvals>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
colorvalues,rgb,gray,grayscale,grey,greyscale
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
RoundNumber
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RoundNumber(number number)
</functionname>
<description>
returns a rounded value of the parameter number. %.5 and higher rounds up, lower than %.5 round down.
</description>
<retvals>
integer retval  - the rounded number
</retvals>
<parameters>
number - the floatingpoint number, you'd like to have rounded.
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
number, rounding
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
IsItemInTrack
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.IsItemInTrack(integer tracknumber, integer itemIDX)
</functionname>
<description>
checks, whether a given item is part of the track tracknumber

returns true, if the itemIDX is part of track tracknumber, false if not, -1 if no such itemIDX or Tracknumber available
</description>
<retvals>
boolean retval - true, if item is in track, false if item isn't in track
</retvals>
<parameters>
integer itemIDX - the number of the item to check of
integer tracknumber - the number of the track to check in
</parameters>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
itemmanagement,item,track,existence
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
WriteValueToFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retval = ultraschall.WriteValueToFile(string filename_with_path, string/integer/number value, boolean binarymode)
</functionname>
<description>
Writes value to filename_with_path. Will replace any previous content of the file! Returns -1 in case of failure, 1 in case of success.

Keep in mind, that on Windows, you need to escape \ by writing \\, or it will not work
</description>
<retvals>
integer retval  - -1 in case of failure, 1 in case of success
</retvals>
<parameters>
string filename_with_path - the filename with it's path
string value - the value to export, can be a long string that includes newlines and stuff. nil is not allowed!
boolean binarymode - true - it will store the value as binary-file; false will store it as textstring
</parameters>
<semanticcontext>
File Management
Write Files
</semanticcontext>
<tags>
filemanagement,export,write,file,textfile,binary
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CreateTrackNumbersString
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string trackstring = ultraschall.CreateTrackNumbersString(integer firstnumber, integer lastnumber, integer step)
</functionname>
<description>
returns a string with the all numbers from firstnumber to lastnumber, separated by a ,
e.g. firstnumber=4, lastnumber=8 -> 4,5,6,7,8
</description>
<parameters>
integer firstnumber - the number, with which the string starts
integer lastnumber - the number, with which the string ends
integer step - how many numbers shall be skipped inbetween. Can lead to a different lastnumber, if not 1 ! nil=1
</parameters>
<retvals>
string trackstring - a string with all tracknumbers, separated by a ,
</retvals>
<semanticcontext>
Track Management
Assistance functions
</semanticcontext>
<tags>
trackstring, track, create
</tags>
</ApiDocBlocFunc>


--[[
<ApiDocBlocFunc>
<slug>
SetUSExternalState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetUSExternalState(string section, string key, string value)
</functionname>
<description>
stores values into ultraschall.ini. Returns true if successful, false if unsuccessful.
</description>
<retvals>
boolean retval - true, if successful, false if unsuccessful.
</retvals>
<parameters>
string section - section within the ini-file
string key - key within the section
string value - the value itself
</parameters>
<semanticcontext>
Configuration-Files Management
Ultraschall.ini
</semanticcontext>
<tags>
configurationmanagement, value, insert, store
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetUSExternalState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer value_length, string value = ultraschall.GetUSExternalState(string section, string key)
</functionname>
<description>
gets a value from ultraschall.ini. Returns length of value(integer) and the value itself(string).
</description>
<retvals>
integer value_length - the number of characters of the value
string value  - the value itself
</retvals>
<parameters>
string section - the section of the ultraschall.ini.
string key - the key of which you want it's value.
</parameters>
<semanticcontext>
Configuration-Files Management
Ultraschall.ini
</semanticcontext>
<tags>
configurationmanagement, value, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CountUSExternalState_sec
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer section_count = ultraschall.CountUSExternalState_sec()
</functionname>
<description>
returns the number of [sections] in the ultraschall.ini
</description>
<retvals>
integer section_count  - the number of section in the ultraschall.ini
</retvals>
<semanticcontext>
Configuration-Files Management
Ultraschall.ini
</semanticcontext>
<tags>
configurationmanagement, count, section
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CountUSExternalState_key
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer key_count = ultraschall.CountUSExternalState_key(string section)
</functionname>
<description>
returns the number of keys in the given [section] in ultraschall.ini
</description>
<retvals>
integer key_count  - the number of keys within an ultraschall.ini-section
</retvals>
<parameters>
string section - the section of the ultraschall.ini, of which you want the number of keys.
</parameters>
<semanticcontext>
Configuration-Files Management
Ultraschall.ini
</semanticcontext>
<tags>
configurationmanagement, count, key
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EnumerateUSExternalState_sec
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string section_name = ultraschall.EnumerateUSExternalState_sec(integer number)
</functionname>
<description>
returns name of the numberth section in ultraschall.ini or nil if invalid
</description>
<retvals>
string section_name  - the name of the numberth section within ultraschall.ini
</retvals>
<parameters>
integer number - the number of section, whose name you want to know
</parameters>
<semanticcontext>
Configuration-Files Management
Ultraschall.ini
</semanticcontext>
<tags>
configurationmanagement, enumerate, section
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EnumerateUSExternalState_key
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string key_name = ultraschall.EnumerateUSExternalState_key(string section, string number)
</functionname>
<description>
returns name of a numberth key within a section in ultraschall%.ini or nil if invalid or not existing
</description>
<retvals>
string key_name  - the name ob the numberth key in ultraschall.ini.
</retvals>
<parameters>
string section - the section within ultraschall.ini, where the key is stored.
string number - the number of the key, whose name you want to know.
</parameters>
<semanticcontext>
Configuration-Files Management
Ultraschall.ini
</semanticcontext>
<tags>
configurationmanagement, enumerate, key
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackName
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string trackname = ultraschall.GetTrackName(integer tracknumber)
</functionname>
<description>
returns name of the track.
</description>
<retvals>
string trackname  - the name of the track
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, name, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackPeakColorState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string PeakColorState = ultraschall.GetTrackPeakColorState(integer tracknumber)
</functionname>
<description>
returns state of the PeakColor-number, which is the trackcolor. Will be returned as string, to avoid losing trailing or preceding zeros.
</description>
<retvals>
string PeakColorState  - the color of the track
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, trackcolor, color, get, state
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackBeatState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number BeatState = ultraschall.GetTrackBeatState(integer tracknumber)
</functionname>
<description>
returns Track-BeatState. 
</description>
<retvals>
number BeatState  - -1 - Project time base; 0 - Time; 1 - Beats position, length, rate; 2 - Beats position only
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, beat, get, state
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackAutoRecArmState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer AutoRecArmState = ultraschall.GetTrackAutoRecArmState(integer tracknumber)
</functionname>
<description>
returns if the track is in AutoRecArm, when selected. Returns nil if not.
</description>
<retvals>
integer AutoRecArmState  - state of autorecarm
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, autorecarm, rec, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackMuteSoloState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer Mute, integer Solo, integer SoloDefeat = ultraschall.GetTrackMuteSoloState(integer tracknumber)
</functionname>
<description>
returns states of Mute and Solo-Buttons.

</description>
<retvals>
integer Mute - Mute set to 0 - Mute off, 1 - Mute On
 integer Solo - Solo set to 0 - Solo off, 1 - Solo ignore routing, 2 - Solo on
 integer SoloDefeat  - SoloDefeat set to 0 - off, 1 - on
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, mute, solo, solodefeat, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackIPhaseState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number IPhase = ultraschall.GetTrackIPhaseState(integer tracknumber)
</functionname>
<description>
returns state of the IPhase. If the Phase-button is pressed, it will return 1, else it will return 0.
</description>
<retvals>
number IPhase  - state of the phase-button
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, iphase, phase, button, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackIsBusState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer busstate1, integer busstate2 = ultraschall.GetTrackIsBusState(integer tracknumber)
</functionname>
<description>
returns busstate of the track, means: if it's a folder track
</description>
<retvals>
integer busstate1=0, integer busstate2=0 - track is no folder
- or
integer busstate1=1, integer busstate2=1 - track is a folder
- or
integer busstate1=1, integer busstate2=2 - track is a folder but view of all subtracks not compactible
- or
integer busstate1=2, integer busstate2=-1 - track is last track in folder(no tracks of subfolders follow)
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, busstate, folder, subfolders, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackBusCompState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number BusCompState1, number BusCompState2 = ultraschall.GetTrackBusCompState(integer tracknumber)
</functionname>
<description>
returns BusCompState, if the tracks in a folder are compacted or not.
</description>
<retvals>
number BusCompState1 - 0 - no compacting, 1 - compacted tracks, 2 - minimized tracks
number BusCompState2 - 0 - unknown,1 - unknown
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, busstate, folder, subfolders, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackShowInMixState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer MCPvisible, number MCP_FX_visible, number MCPTrackSendsVisible, integer TCPvisible, number ShowInMix5, number ShowInMix6, number ShowInMix7, number ShowInMix8 = ultraschall.GetTrackShowInMixState(integer tracknumber)
</functionname>
<description>
returns Show in Mix-state.
</description>
<retvals>
integer MCPvisible - 0 invisible, 1 visible
 number MCP_FX_visible - 0 visible, 1 FX-Parameters visible, 2 invisible
 number MCPTrackSendsVisible - 0 & 1.1 and higher TrackSends in MCP visible, every other number makes them invisible
 integer TCPvisible - 0 track is invisible in TCP, 1 track is visible in TCP
 number ShowInMix5 - unknown
 number ShowInMix6 - unknown
 number ShowInMix7 - unknown
 number ShowInMix8  - unknown
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, mixer, show, mcp, tcp, fx, visible, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackFreeModeState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer FreeModeState = ultraschall.GetTrackFreeModeState(integer tracknumber)
</functionname>
<description>
returns if the track has track free item positioning enabled(1) or not(0).
</description>
<retvals>
integer FreeModeState  - 1 - enabled, 0 - not enabled
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, trackfreemode, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackRecState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer ArmState, integer InputChannel, integer MonitorInput, integer RecInput, integer MonitorWhileRec, integer presPDCdelay, integer RecordingPath = ultraschall.GetTrackRecState(integer tracknumber)
</functionname>
<description>
returns Track Rec State.
</description>
<retvals>
integer ArmState - returns 1(armed) or 0(unarmed)

 integer InputChannel - returns the InputChannel
--1 - No Input
-1-16(more?) - Mono Input Channel
-1024 - Stereo Channel 1 and 2
-1026 - Stereo Channel 3 and 4
-1028 - Stereo Channel 5 and 6
-...
-5056 - Virtual MIDI Keyboard all Channels
-5057 - Virtual MIDI Keyboard Channel 1
-...
-5072 - Virtual MIDI Keyboard Channel 16
-5088 - All MIDI Inputs - All Channels
-5089 - All MIDI Inputs - Channel 1
-...
-5104 - All MIDI Inputs - Channel 16

 integer MonitorInput - 0 monitor off, 1 monitor on, 2 monitor on tape audio style
 
 integer RecInput - returns rec-input type
-0 input(Audio or Midi)
-1 Record Output Stereo
-2 Disabled, Input Monitoring Only
-3 Record Output Stereo, Latency Compensated
-4 Record Output MIDI
-5 Record Output Mono
-6 Record Output Mono, Latency Compensated
-7 MIDI overdub
-8 MIDI replace
-9 MIDI touch replace
-10 Record Output Multichannel
-11 Record Output Multichannel, Latency Compensated 
-12 Record Input Force Mono
-13 Record Input Force Stereo
-14 Record Input Force Multichannel
-15 Record Input Force MIDI
-16 MIDI latch replace

 integer MonitorWhileRec - Monitor Trackmedia when recording, 0 is off, 1 is on

 integer presPDCdelay - preserve PDC delayed monitoring in media items

 integer RecordingPath  - recording path used 
-0 - Primary Recording-Path only
-1 - Secondary Recording-Path only
-2 - Primary Recording Path and Secondary Recording Path(for invisible backup)
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, midi, recordingpath, path, input, recinput, pdc, monitor, arm, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackVUState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer VUState = ultraschall.GetTrackVUState(integer tracknumber)
</functionname>
<description>
returns VUState. 
</description>
<retvals>
integer VUState  - 0 if MultiChannelMetering is off, 2 if MultichannelMetering is on, 3 Metering is off
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, vu, metering, meter, multichannel, state, get
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackHeightState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer height, number heightstate2 = ultraschall.GetTrackHeightState(integer tracknumber)
</functionname>
<description>
returns height of the track.
</description>
<retvals>
integer height - 24 up to 443
 number heightstate2 - 0 - use height, 1 - compact the track and ignore the height
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, height, compact
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackINQState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer INQ1, integer INQ2, integer INQ3, number INQ4, integer INQ5, integer INQ6, integer INQ7, integer INQ8 =  ultraschall.GetTrackINQState(integer tracknumber)
</functionname>
<description>
returns INQ-state of the track.
</description>
<retvals>
integer INQ1 - unknown
integer INQ2 - unknown
integer INQ3 - unknown
number INQ4 - unknown
integer INQ5 - unknown
integer INQ6 - unknown
integer INQ7 - unknown
integer INQ8 - unknown
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, inq
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackNChansState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer channelnumber = ultraschall.GetTrackNChansState(integer tracknumber)
</functionname>
<description>
returns the number of channels for this track, as set in the routing.
</description>
<retvals>
integer channelnumber  - number of channels for this track
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, channels
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackBypFXState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer FXState = ultraschall.GetTrackBypFXState(integer tracknumber)
</functionname>
<description>
returns the off/bypass(0) or nobypass(1) state of the FX-Chain
</description>
<retvals>
integer FXState - off/bypass(0) or nobypass(1)
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, bypass, fx
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackPerfState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer TrackPerfState = ultraschall.GetTrackPerfState(integer tracknumber)
</functionname>
<description>
returns TrackPerformance-state
</description>
<retvals>
integer TrackPerfState  - TrackPerformance-state
-0 - allow anticipative FX + allow media buffering
-1 - allow anticipative FX + prevent media buffering 
-2 - prevent anticipative FX + allow media buffering
-3 - prevent anticipative FX + prevent media buffering
-settings seem to repeat with higher numbers (e.g. 4(like 0) - allow anticipative FX + allow media buffering)
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, trackperformance, fx, buffering, media, anticipative
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackMIDIOutState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer MidiOutState = ultraschall.GetTrackMIDIOutState(integer tracknumber)
</functionname>
<description>
returns MIDI_Out-State, as set in the Routing-Settings
</description>
<retvals>
integer MidiOutState  - MIDI_Out-State, as set in the Routing-Settings
--1 no output
-416 - microsoft GS wavetable synth - send to original channels
-417-432 - microsoft GS wavetable synth - send to channel state minus 416
--31 - no Output, send to original channel 1
--16 - no Output, send to original channel 16
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, midi, outstate, routing
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackMainSendState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer MainSendOn, integer ParentChannels = ultraschall.GetTrackMainSendState(integer tracknumber)
</functionname>
<description>
returns, if Main-Send is on(1) or off(0) and the ParentChannels(0-63), as set in the Routing-Settings.
</description>
<retvals>
integer MainSendOn - Main-Send is on(1) or off(0)
integer ParentChannels  - ParentChannels(0-63)
</retvals>
<parameters>
tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, parent, channel, send, main, routing
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackGroupFlagsState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer GroupState_as_Flags, array IndividualGroupState_Flags = ultraschall.GetTrackGroupFlagsState(integer tracknumber)
</functionname>
<description>
returns the state of the group-flags, as set in the menu Track Grouping Parameters. Returns a 23bit flagvalue as well as an array with 32 individual 23bit-flagvalues. You must use bitoperations to get the individual values.
</description>
<retvals>
integer GroupState_as_Flags - returns a flagvalue with 23 bits, that tells you, which grouping-flag is set in at least one of the 32 groups available.
-returns -1 in case of failure
-
-the following flags are available:
-2^0 - Volume Master
-2^1 - Volume Slave
-2^2 - Pan Master
-2^3 - Pan Slave
-2^4 - Mute Master
-2^5 - Mute Slave
-2^6 - Solo Master
-2^7 - Solo Slave
-2^8 - Record Arm Master
-2^9 - Record Arm Slave
-2^10 - Polarity/Phase Master
-2^11 - Polarity/Phase Slave
-2^12 - Automation Mode Master
-2^13 - Automation Mode Slave
-2^14 - Reverse Volume
-2^15 - Reverse Pan
-2^16 - Do not master when slaving
-2^17 - Reverse Width
-2^18 - Width Master
-2^19 - Width Slave
-2^20 - VCA Master
-2^21 - VCA Slave
-2^22 - VCA pre-FX slave

 array IndividualGroupState_Flags  - returns an array with 23 entries. Every entry represents one of the GroupState_as_Flags, but it's value is a flag, that describes, in which of the 32 Groups a certain flag is set.
-e.g. If Volume Master is set only in Group 1, entry 1 in the array will be set to 1. If Volume Master is set on Group 2 and Group 4, the first entry in the array will be set to 10.
-refer to the upper GroupState_as_Flags list to see, which entry in the array is for which set flag, e.g. array[22] is VCA pre-F slave, array[16] is Do not master when slaving, etc
-As said before, the values in each entry is a flag, that tells you, which of the groups is set with a certain flag. The following flags determine, in which group a certain flag is set:
-2^0 - Group 1
-2^1 - Group 2
-2^2 - Group 3
-2^3 - Group 4
-...
-2^30 - Group 31
-2^31 - Group 32
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get,group,groupstate,individual
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackLockState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer lockedstate = ultraschall.GetTrackLockState(integer tracknumber)
</functionname>
<description>
returns, if the track-controls of this track are locked(1) or not(0).
</description>
<retvals>
integer lockedstate  - locked(1) or not(0)
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, lockstate, locked
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackLayoutNames
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string TCP_Layoutname, string MCP_Layoutname = ultraschall.GetTrackLayoutNames(integer tracknumber)
</functionname>
<description>
returns the current selected layouts for TrackControlPanel and MixerControlPanel for this track as strings. Returns nil, if default is set.
</description>
<retvals>
string TCP_Layoutname - name of the TCP-Layoutname
string MCP_Layoutname  - name of the MCP-Layoutname
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, theme, layout, name, mcp, tcp
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackAutomodeState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer automodestate = ultraschall.GetTrackAutomodeState(integer tracknumber)
</functionname>
<description>
returns, if the automation-mode for envelopes of this track
</description>
<retvals>
integer automodestate  - is set to 0 - trim/read, 1 - read, 2 - touch, 3 - write, 4 - latch.
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, automode, envelopes, automation
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackIcon_Filename
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string filename_with_path = ultraschall.GetTrackIcon_Filename(integer tracknumber)
</functionname>
<description>
returns the filename with path for the track-icon of the current track. Returns nil, if no trackicon has been set.
</description>
<retvals>
string filename_with_path  - filename with path for the current track-icon.
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, graphics, image, icon, trackicon
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackMidiInputChanMap
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer MidiInputChanMap_state = ultraschall.GetTrackMidiInputChanMap(integer tracknumber)
</functionname>
<description>
returns the state of the MIDIInputChanMap for the current track, as set in the Input-MIDI->Map Input to Channel menu. 0 for channel 1, 2 for channel 2, etc. Nil, if not existing.
</description>
<retvals>
integer MidiInputChanMap_state  - 0 for channel 1, 2 for channel 2, etc; nil, if not existing.
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, midi, input, chanmap, channelmap, channel, mapping
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetTrackMidiCTL
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer LinkedToMidiChannel, integer unknown = ultraschall.GetTrackMidiCTL(integer tracknumber)
</functionname>
<description>
returns linked to Midi channel and an unknown value. Nil if not existing.
</description>
<retvals>
integer LinkedToMidiChannel - linked to midichannel
integer unknown  - unknown
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
</parameters>
<semanticcontext>
Track Management
Get Track States
</semanticcontext>
<tags>
trackmanagement, state, get, midi, channel, linked
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackName
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackName(integer tracknumber, string name)
</functionname>
<description>
Set the name of a track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
string name - new name of the track
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, name, set, state, track
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackPeakColorState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackPeakColorState(integer tracknumber, integer colorvalue)
</functionname>
<description>
Set the color of the track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer colorvalue - the color for the track
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, color, state, set, track
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackBeatState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackBeatState(integer tracknumber, integer beatstate)
</functionname>
<description>
Set the timebase for a track.
</description>
<retvals>
boolean retval - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer beatstate - tracktimebase for this track; -1 - Project time base, 0 - Time, 1 - Beats position, length, rate, 2 - Beats position only
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, beat, state, set, track
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackAutoRecArmState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackAutoRecArmState(integer tracknumber, integer autorecarmstate)
</functionname>
<description>
Set the AutoRecArmState for a track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer autorecarmstate - autorecarmstate - 1 - autorecarm on, <> than 1 - off
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, autorecarm, rec, arm, track, set, state
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackMuteSoloState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackMuteSoloState(integer tracknumber, integer Mute, integer Solo, integer SoloDefeat)
</functionname>
<description>
Set the AutoRecArmState for a track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer Mute - 0 - Mute off, &lt;&gt; than 0 - on
integer Solo - 0 - off, &lt;&gt; than 0 - on
integer Solo Defeat - 0 - off, &lt;&gt; than 0 - on
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, mute, solo, solo defeat
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackIPhaseState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackIPhaseState(integer tracknumber, integer iphasestate)
</functionname>
<description>
Sets IPhase, the Phase-Buttonstate of the Track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer iphasestate - 0-off, &lt;&gt; than 0-on
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, set, track, state, iphase, phase
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackIsBusState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackIsBusState(integer tracknumber, integer busstate1, integer busstate2)
</functionname>
<description>
Sets ISBUS-state of the Track; if it's a folder track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer busstate1=0, integer busstate2=0 - track is no folder
integer busstate1=1, integer busstate2=1 - track is a folder
integer busstate1=1, integer busstate2=2 - track is a folder but view of all subtracks not compactible
integer busstate1=2, integer busstate2=-1 - track is last track in folder(no tracks of subfolders follow)
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, busstate, folder, subfolder, compactible
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackBusCompState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackBusCompState(integer tracknumber, integer buscompstate1, integer buscompstate2)
</functionname>
<description>
Sets BUSCOMP-state of the Track; if tracks in a folder are compacted or not.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer - buscompstate1 - 0 - no compacting, 1 - compacted tracks, 2 - minimized tracks
integer - buscompstate2 - 0 - unknown, 1 - unknown
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, compacting, busstate, folder, minimize
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackShowInMixState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackShowInMixState(integer tracknumber, integer MCPvisible, number MCP_FX_visible, number MCP_TrackSendsVisible, integer TCPvisible, number ShowInMix5, integer ShowInMix6, integer ShowInMix7, integer ShowInMix8)
</functionname>
<description>
Sets SHOWINMIX, that sets visibility of track in MCP and TCP.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer MCPvisible - 0 invisible, 1 visible
number MCP_FX_visible - 0 visible, 1 FX-Parameters visible, 2 invisible
number MCPTrackSendsVisible - 0 & 1.1 and higher TrackSends in MCP visible, every other number makes them invisible
integer TCPvisible - 0 track is invisible in TCP, 1 track is visible in TCP
number ShowInMix5 - unknown
integer ShowInMix6 - unknown
integer ShowInMix7 - unknown
integer ShowInMix8 - unknown
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, state, set, show in mix, mcp, fx, tcp
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackFreeModeState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackFreeModeState(integer tracknumber, integer freemodestate)
</functionname>
<description>
Sets FREEMODE-state; enables Track-Free Item Positioning.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer freemodestate - 0 - off, 1 - on
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, trackfree, item, positioning
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackRecState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackRecState(integer tracknumber, integer ArmState, integer InputChannel, integer MonitorInput, integer RecInput, integer MonitorWhileRec, integer presPDCdelay, integer RecordingPath)
</functionname>
<description>
Sets REC, that sets the Recording-state of the track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer ArmState - returns 1(armed) or 0(unarmed)

integer InputChannel - the InputChannel
--1 - No Input
-1-16(more?) - Mono Input Channel
-1024 - Stereo Channel 1 and 2
-1026 - Stereo Channel 3 and 4
-1028 - Stereo Channel 5 and 6
-...
-5056 - Virtual MIDI Keyboard all Channels
-5057 - Virtual MIDI Keyboard Channel 1
-...
-5072 - Virtual MIDI Keyboard Channel 16
-5088 - All MIDI Inputs - All Channels
-5089 - All MIDI Inputs - Channel 1
-...
-5104 - All MIDI Inputs - Channel 16

integer Monitor Input - 0 monitor off, 1 monitor on, 2 monitor on tape audio style

integer RecInput - the rec-input type
-0 input(Audio or Midi)
-1 Record Output Stereo
-2 Disabled, Input Monitoring Only
-3 Record Output Stereo, Latency Compensated
-4 Record Output MIDI
-5 Record Output Mono
-6 Record Output Mono, Latency Compensated
-7 MIDI overdub
-8 MIDI replace
-9 MIDI touch replace
-10 Record Output Multichannel
-11 Record Output Multichannel, Latency Compensated 
-12 Record Input Force Mono
-13 Record Input Force Stereo
-14 Record Input Force Multichannel
-15 Record Input Force MIDI
-16 MIDI latch replace

integer MonitorWhileRec - Monitor Trackmedie when recording, 0 is off, 1 is on

integer presPDCdelay - preserve PDC delayed monitoring in media items

integer RecordingPath - 0 Primary Recording-Path only, 1 Secondary Recording-Path only, 2 Primary Recording Path and Secondary Recording Path(for invisible backup)
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, armstate, inputchannel, monitorinput, recinput, monitorwhilerec, pdc, recordingpath, midi
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackVUState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackVUState(integer tracknumber, integer VUState)
</functionname>
<description>
Sets VU-state; the way metering shows.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer VUState -  0 if MultiChannelMetering is off, 2 if MultichannelMetering is on, 3 Metering is off
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, armstate, vu, metering, multichannel
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackHeightState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackHeightState(integer tracknumber, integer height, integer heightstate2)
</functionname>
<description>
Sets TRACKHEIGHT-state; the height and compacted state of the track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer height -  24 up to 443 pixels
integer heightstate2 - 0 - use height-parameter, 1 - compact the track and ignore the height-parameter
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, trackheight, height, compact
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackINQState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackINQState(integer tracknumber, integer INQ1, integer INQ2, integer INQ3, number INQ4, integer INQ5, integer INQ6, integer INQ7, integer INQ8)
</functionname>
<description>
Sets INQ-state; the purpose of this setting is unknown.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
tracknumber - number of the track, beginning with 0
integer INQ1 -  unknown
integer INQ2 -  unknown
integer INQ3 -  unknown
number INQ4 -  unknown
integer INQ5 -  unknown
integer INQ6 -  unknown
integer INQ7 -  unknown
integer INQ8 -  unknown
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, inq
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackNChansState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackNChansState(integer tracknumber, integer NChans)
</functionname>
<description>
Sets NCHAN-state; the number of channels in this track, as set in the routing.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer NChans - 2 to 64, counted every second channel (2,4,6,8,etc) with stereo-tracks. Unknown, if Multichannel and Mono-tracks count differently.
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, channels, number
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackBypFXState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackBypFXState(integer tracknumber, integer FXBypassState)
</functionname>
<description>
Sets FX, FX-Bypass-state of the track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer FXBypassState  - 0 bypass, 1 activate fx; has only effect, if FX or instruments are added to this track
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, state, track, set, fx, bypass
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackPerfState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackPerfState(integer tracknumber, integer Perf)
</functionname>
<description>
Sets PERF, the TrackPerformance-State.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer Perf  - performance-state
- 0 - allow anticipative FX + allow media buffering
- 1 - allow anticipative FX + prevent media buffering
- 2 - prevent anticipative FX + allow media buffering
- 3 - prevent anticipative FX + prevent media buffering
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, state, set, fx, performance
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackMIDIOutState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackMIDIOutState(integer tracknumber, integer MIDIOutState)
</functionname>
<description>
Sets MIDIOUT, the state of MIDI out for this track.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer MIDIOutState - 
- %-1 no output
- 416 %- microsoft GS wavetable synth-send to original channels
- 417-432 %- microsoft GS wavetable synth-send to channel state minus 416
- -31 %- no Output, send to original channel 1
- -16 %- no Output, send to original channel 16
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, state, set, midi, midiout
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackMainSendState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackMainSendState(integer tracknumber, integer MainSendOn, integer ParentChannels)
</functionname>
<description>
Sets MAINSEND, as set in the routing-settings.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer MainSendOn - on(1) or off(0)
integer ParentChannels  - the ParentChannels(0-64), interpreted as beginning with ParentChannels to ParentChannels+NCHAN
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, state, set, mainsend, parent channels, parent
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackLockState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackLockState(integer tracknumber, integer LockedState)
</functionname>
<description>
Sets LOCK-State, as set by the menu entry Lock Track Controls.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer LockedState  - 1 - locked, 0 - unlocked
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, lock, state, set, track
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackLayoutNames
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackLayoutNames(integer tracknumber, string TCP_Layoutname, string MCP_Layoutname)
</functionname>
<description>
Sets LAYOUTS, the MCP and TCP-layout by name of the layout as defined in the theme.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
string TCP_Layoutname  - name of the TrackControlPanel-Layout from the theme to use
string MCP_Layoutname  - name of the MixerControlPanel-Layout from the theme to use
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, state, set, mcp, tcp, layout, mixer, trackcontrol
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackAutomodeState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackAutomodeState(integer tracknumber, integer automodestate)
</functionname>
<description>
Sets AUTOMODE-State, as set by the menu entry Set Track Automation Mode
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer automodestate - 0 - trim/read, 1 - read, 2 - touch, 3 - write, 4 - latch
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, automode
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackIcon_Filename
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackIcon_Filename(integer tracknumber, string Iconfilename_with_path)
</functionname>
<description>
Sets TRACKIMGFN, the trackicon-filename with path.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
string Iconfilename_with_path - filename+path of the imagefile to use as the trackicon
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, state, track, set, trackicon, image
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackMidiInputChanMap
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackMidiInputChanMap(integer tracknumber, integer InputChanMap)
</functionname>
<description>
Sets MIDI_INPUT_CHANMAP, as set in the Input-MIDI->Map Input to Channel menu.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer InputChanMap - 0 for channel 1, 2 for channel 2, etc. -1 if not existing.
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, input, chanmap, channelmap, midi
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetTrackMidiCTL
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetTrackMidiCTL(integer tracknumber, integer LinkedToMidiChannel, integer unknown)
</functionname>
<description>
sets MIDICTL-state, the linkage to Midi-Channels.
</description>
<retvals>
boolean retval  - true, if successful, false if unsuccessful
</retvals>
<parameters>
integer tracknumber - number of the track, beginning with 0
integer LinkedToMidiChannel - unknown
integer unknown - unknown
</parameters>
<semanticcontext>
Track Management
Set Track States
</semanticcontext>
<tags>
trackmanagement, track, set, state, linked, midi, midichannel
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetID3TagsForCurrentProject
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.SetID3TagsForCurrentProject(string title, string artist, string album, string track, string year, string genre, string comment, string date, string involved_people, string language, string coverfilename_and_path, string coverfilename_and_path2, string coverfilename_and_path3)
</functionname>
<description>
sets project-states with the ID3-Tags. Use nil, if you don't want to change an already set ID3-Tag.

Sets the following tags:

Title, Artist, Album, Track, Years, Genre, Comment, Date, Involved_People, Language, Coverfilename_And_Path, Cover2filename_And_Path, Cover3filename_And_Path
</description>
<parameters>
string title - the file's title
string artist - the file's artist  
string album - the file's album
string track - the file's track
string year - the file's years
string genre - the file's genre
string comment - the file's comment
string date - the file's date
string involved_people - the file's involved people
string language - the file's language
string coverfilename_and_path - the file's cover 1
string coverfilename_and_path2 - the file's cover 2
string coverfilename_and_path3 - the file's cover 3
</parameters>
<semanticcontext>
Meta Data Management
ID3-Tags
</semanticcontext>
<tags>
tagmanagement, id3, title, artist, album, track, year, genre, comment, date, involved people, language, cover
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetID3TagsForCurrentProject_PodcastTags
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.SetID3TagsForCurrentProject_PodcastTags(string podcast, string podcast_category, string podcast_description, string podcast_id, string podcast_keywords, string podcast_url)
</functionname>
<description>
sets project-states with the ID3-Tags specifically for Podcasts. Use nil, if you don't want to change an already set ID3-Tag.

Sets the following tags:

Podcasttags for Podcast, Category, Description, ID, Keywords, URL
</description>
<parameters>
string podcast - podcast name
string podcast_category - podcast category
string podcast_description - podcast description
string podcast_id - podcast id
string podcast_keywords - podcast keywords
string podcast_url - podcast url
</parameters>
<semanticcontext>
Meta Data Management
ID3-Tags
</semanticcontext>
<tags>
tagmanagement, podcast, name, category, description, id, keywords, url
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetID3TagsFromCurrentProject
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string title, string artist, string album, string track, string year, string genre, string comment, string date, string involved_people, string language, string coverfilename_and_path, string coverfilename_and_path2, string coverfilename_and_path3 = ultraschall.GetID3TagsFromCurrentProject()
</functionname>
<description>
returns project-states with the ID3-Tags for:

Title, Artist, Album, Track, Years, Genre, Comment, Date, Involved_People, Language, Coverfilename_And_Path, Cover2filename_And_Path, Cover3filename_And_Path
</description>
<retvals>
string title - the file's title
string artist - the file's artist  
string album - the file's album
string track - the file's track
string year - the file's years
string genre - the file's genre
string comment - the file's comment
string date - the file's date
string involved_people - the file's involved people
string language - the file's language
string coverfilename_and_path - the file's cover 1
string coverfilename_and_path2 - the file's cover 2
string coverfilename_and_path3 - the file's cover 3
</retvals>
<semanticcontext>
Meta Data Management
ID3-Tags
</semanticcontext>
<tags>
tagmanagement, id3, title, artist, album, track, year, genre, comment, date, involved people, language, cover
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetID3TagsFromCurrentProject_PodcastTags
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string podcast, string podcast_category, string podcast_description, string podcast_id, string podcast_keywords, string podcast_url = ultraschall.GetID3TagsFromCurrentProject_PodcastTags()
</functionname>
<description>
returns project-states with the ID3-tags specifically for podcasts for 

Podcast, Category, Description, ID, Keywords, URL
</description>
<retvals>
string podcast - podcast name
string podcast_category - podcast category
string podcast_description - podcast description
string podcast_id - podcast id
string podcast_keywords - podcast keywords
string podcast_url - podcast url
</retvals>
<semanticcontext>
Meta Data Management
ID3-Tags
</semanticcontext>
<tags>
tagmanagement, podcast, name, category, description, id, keywords, url
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ToggleScrollingDuringPlayback
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.ToggleScrollingDuringPlayback(scrolling_switch, move_editcursor)
</functionname>
<description>
Toggles scrolling during playback and recording. Let's you choose to put the edit-marker at the playposition, where you toggled scrolling.

It changes, if necessary, the state of the actions 41817 and 40036 to scroll or not to scroll; keep that in mind, if you use these actions otherwise as well!
</description>
<parameters>
integer scrolling_switch - 1-on, 0-off
integer move_editcursor - when scrolling stops, shall the editcursor be moved to current position of the playcursor(1) or not(0)
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, scrolling, toggle, edit cursor
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetPlayCursor_WhenPlaying
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.SetPlayCursor_WhenPlaying(number position)
</functionname>
<description>
Changes position of the play-cursor, when playing. Changes view to new playposition. Has no effect during recording, when paused or stop and returns -1 in these cases!
</description>
<parameters>
number position - in seconds
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, play cursor, set
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetPlayAndEditCursor_WhenPlaying
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.SetPlayAndEditCursor_WhenPlaying(number position)
</functionname>
<description>
Changes position of the play and edit-cursor, when playing. Changes view to new playposition. Has no effect during recording, when paused or stop and returns -1 in these cases!
</description>
<parameters>
number position - in seconds
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, set, play cursor, edit cursor
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
JumpForwardBy
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.JumpForwardBy(number position)
</functionname>
<description>
Jumps forward by <i>position</i> seconds. Returns -1 if parameter is negative. During Recording: only the playcursor will be moved, the current recording-position is still at it's "old" position! If you want to move the current recording position as well, use <a href="#JumpForwardBy_Recording">ultraschall.JumpForwardBy_Recording</a> instead.
</description>
<parameters>
number position - in seconds
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, set, forward, jump
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
JumpBackwardBy
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.JumpBackwardBy(number position)
</functionname>
<description>
Jumps backward by <i>position</i> seconds. Returns -1 if parameter is negative. During Recording: only the playcursor will be moved, the current recording-position is still at it's "old" position! If you want to move the current recording position as well, use <a href="#JumpBackwardBy_Recording">ultraschall.JumpBackwardBy_Recording</a> instead.
</description>
<parameters>
number position - in seconds
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, set, backward, jump
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
JumpForwardBy_Recording
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.JumpForwardBy_Recording(number position)
</functionname>
<description>
Stops recording, jumps forward by <i>position</i> seconds and restarts recording. Will keep paused-recording, if recording was paused. Has no effect during play,play/pause and stop.
</description>
<parameters>
number position - in seconds
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, set, forward, recording
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
JumpBackwardBy_Recording
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.JumpBackwardBy_Recording(number position)
</functionname>
<description>
Stops recording, jumps backward by <i>position</i> seconds and restarts recording. Will keep paused-recording, if recording was paused. Has no effect during play,play/pause and stop.
</description>
<parameters>
number position - in seconds
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, jump, forward, recording
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetNextClosestItemEdge
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number position = ultraschall.GetNextClosestItemEdge(string tracksstring, integer cursor_type, optional number time_position)
</functionname>
<description>
returns the position of the next closest item in seconds. It will return the position of the beginning or the end of that item, depending on what is closer.
</description>
<retvals>
number position  - the position of the next closest item-edge in tracks in trackstring
</retvals>
<parameters>
string tracksstring - a string with the numbers of tracks to check for closest items, separated by a comma (e.g. "0,1,6")
integer cursor_type - next closest item related to the current position of 0 - Edit Cursor, 1 - Play Cursor, 2 - Mouse Cursor, 3 - Timeposition
optional number time_position - only, when cursor_type=3, a time position in seconds, from where to check for the next closest item. When omitted, it will take the current play(during play and rec) or edit-cursor-position.
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, next item, position, edge
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetPreviousClosestItemEdge
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number position = ultraschall.GetPreviousClosestItemEdge(string tracks, integer cursor_type, optional number time_position)
</functionname>
<description>
returns the position of the previous closest item-edge in seconds. It will return the position of the beginning or the end of that item, depending on what is closer.
</description>
<retvals>
number position  - the position of the previous closest item edge in tracks in trackstring
</retvals>
<parameters>
string tracks - a string with the numbers of tracks to check for closest items, separated by a comma (e.g. "0,1,6")
integer cursor_type - previous closest item related to the current position of 0 - Edit Cursor, 1 - Play Cursor, 2 - Mouse Cursor, 3 - Timeposition
optional time_position - only, when cursor_type=3, a time position in seconds, from where to check for the previous closest item. When omitted, it will take the current play(during play and rec) or edit-cursor-position.
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, previous item, position, edge
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetClosestNextMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number markerindex, number position, string markername = ultraschall.GetClosestNextMarker(integer cursor_type, optional number time_position)
</functionname>
<description>
returns the markerindex(counted from all markers), the position and the name of the next closest marker in seconds.
</description>
<retvals>
number markerindex - the next closest markerindex (of all(!) markers)
number position - the position of the next closest marker
string markername - the name of the next closest marker
</retvals>
<parameters>
integer cursor_type - previous closest marker related to the current position of 0 - Edit Cursor, 1 - Play Cursor, 2 - Mouse Cursor, 3 - Timeposition
optional number time_position - only, when cursor_type=3, a time position in seconds, from where to check for the next closest marker. When omitted, it will take the current play(during play and rec) or edit-cursor-position.
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, next marker, position, marker 
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetClosestPreviousMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number markerindex, number position, string markername = ultraschall.GetClosestPreviousMarker(integer cursor_type, optional number time_position)
</functionname>
<description>
returns the markerindex(counted from all markers), the position and the name of the previous closest marker in seconds.
</description>
<retvals>
number markerindex - the previous closest markerindex (of all(!) markers)
number position - the position of the previous closest marker
string markername - the name of the previous closest marker
</retvals>
<parameters>
integer cursor_type - previous closest marker related to the current position of 0 - Edit Cursor, 1 - Play Cursor, 2 - Mouse Cursor, 3 - Timeposition
optional number time_position - only, when cursor_type=3, a time position in seconds, from where to check for the previous closest marker. When omitted, it will take the current play(during play and rec) or edit-cursor-position.
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, previous marker, position, marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetClosestNextRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number markerindex, number position, string markername = ultraschall.GetClosestNextRegion(integer cursor_type, optional number time_position)
</functionname>
<description>
returns the regionindex(counted from all markers and regions), the position and the name of the next closest regionstart/end(depending on which is closer to time_position) in seconds.
</description>
<retvals>
number markerindex - the next closest markerindex (of all(!) markers)
number position - the position of the next closest region
string markername - the name of the next closest region
</retvals>
<parameters>
integer cursor_type - previous closest regionstart/end related to the current position of 0 - Edit Cursor, 1 - Play Cursor, 2 - Mouse Cursor, 3 - Timeposition
only number time_position - only, when cursor_type=3, a time position in seconds, from where to check for the next closest regionstart/end. When omitted, it will take the current play(during play and rec) or edit-cursor-position.
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, next region, region, position
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetClosestPreviousRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number markerindex, number position, string markername = ultraschall.GetClosestPreviousRegion(integer cursor_type, optional number time_position)
</functionname>
<description>
returns the regionindex(counted from all markers and regions), the position and the name of the previous closest regionstart/end(depending on which is closer to time_position) in seconds.
</description>
<retvals>
number markerindex - the previous closest markerindex (of all(!) markers)
number position - the position of the previous closest marker
string markername - the name of the previous closest marker
</retvals>
<parameters>
integer cursor_type - previous closest regionstart/end related to the current position of 0 - Edit Cursor, 1 - Play Cursor, 2 - Mouse Cursor, 3 - Timeposition
optional number time_position - only, when cursor_type=3, a time position in seconds, from where to check for the previous closest regionstart/end. When omitted, it will take the current play(during play and rec) or edit-cursor-position.
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, previous region, region, position
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetClosestGoToPoints
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number elementposition_prev, string elementtype_prev, integer number_prev, number elementposition_next, string elementtype_next, integer number_next = ultraschall.GetClosestGoToPoints(string tracksstring, number time_position)
</functionname>
<description>
returns, what are the closest markers/regions/item starts/itemends to position and within the chosen tracks.
</description>
<retvals>
number elementposition_prev - previous closest markers/regions/item starts/itemends
string elementtype_prev - type of the previous closest markers/regions/item starts/itemends
integer number_prev - number of previous closest markers/regions/item starts/itemends
number elementposition_next - previous closest markers/regions/item starts/itemends
string elementtype_next - type of the previous closest markers/regions/item starts/itemends
integer number_next  - number of previous closest markers/regions/item starts/itemends
</retvals>
<parameters>
string tracksstring - tracknumbers, separated by a comma.
number time_position - a time position in seconds, from where to check for the next/previous closest items/markers/regions.
</parameters>
<semanticcontext>
Navigation
</semanticcontext>
<tags>
navigation, previous, next, marker, region, item, edge
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ToggleMute
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.ToggleMute(integer track, number position, integer state)
</functionname>
<description>
Sets mute within the mute-envelope-lane, by inserting the fitting envelope-points. Can be used to program coughbuttons. Returns -1, if it fails.
</description>
<retvals>
integer retval  - toggling was 0 - success, -1 - fail
</retvals>
<parameters>
integer track - the track-number, for where you want to set the mute-envelope-lane.
number position - position in seconds
integer state - 0 for mute the track on this position, 1 for unmuting the track on this position
</parameters>
<semanticcontext>
Cough-Button
Muting tracks within envelope-lanes
</semanticcontext>
<tags>
cough button, mute, cough, position
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ToggleMute_TrackObject
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.ToggleMute_TrackObject(Mediatrack trackobject, number position, integer state)
</functionname>
<description>
Sets mute within the mute-envelope-lane, by inserting the fitting envelope-points. Can be used to program coughbuttons. Returns -1, if it fails.

Works like <a href="#ToggleMute">ultraschall.ToggleMute</a> but uses a trackobject instead of the tracknumber as parameter.
</description>
<retvals>
integer retval  - toggling was 0 - success, -1 - fail
</retvals>
<parameters>
Mediatrack trackobject - the track-object for the track, where you want to set the mute-envelope-lane. Refer <a href="Reaper_API_Lua.html#reaper.GetTrack">GetTrack()</a> for more details.
number position - position in seconds
integer state - 0 for mute the track on this position, 1 for unmuting the track on this position
</parameters>
<semanticcontext>
Cough-Button
Muting tracks within envelope-lanes
</semanticcontext>
<tags>
cough button, mute, cough, position, trackobject, mediatrack
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetNextMuteState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer envIDX, number envVal, number envPosition = ultraschall.GetNextMuteState(integer track, number position)
</functionname>
<description>
Returns the next mute-envelope-point-ID, it's value(0 or 1) and it's time. Envelope-Points numbering starts with 0! Returns -1 if not existing.
</description>
<retvals>
integer envIDX - number of the muteenvelope-point
 number envVal - value of the muteenvelope-point (0 or 1)
 number envPosition  - position of the muteenvelope-point in seconds
</retvals>
<parameters>
integer track - the track-number, for where you want to set the mute-envelope-lane.
number position - position in seconds, from where to look for the next mute-envelope-point
</parameters>
<semanticcontext>
Cough-Button
Muting tracks within envelope-lanes
</semanticcontext>
<tags>
cough button, mute, position, envelope, state, value
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetPreviousMuteState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer envIDX, number envVal, number envPosition = ultraschall.GetPreviousMuteState(integer track, number position)
</functionname>
<description>
Returns the previous mute-envelope-point-ID, it's value(0 or 1) and it's time. Envelope-Points numbering starts with 0! Returns -1 if not existing.
</description>
<retvals>
integer envIDX - number of the muteenvelope-point
 number envVal - value of the muteenvelope-point (0 or 1)
 number envPosition  - position of the muteenvelope-point in seconds
</retvals>
<parameters>
integer track - the track-number, for where you want to set the mute-envelope-lane.
number position - position in seconds, from where to look for the previous mute-envelope-point
</parameters>
<semanticcontext>
Cough-Button
Muting tracks within envelope-lanes
</semanticcontext>
<tags>
cough button, mute, position, envelope, state, value
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetNextMuteState_TrackObject
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer envIDX, number envVal, number envPosition = ultraschall.GetNextMuteState_TrackObject(MediaTrack track, number position)
</functionname>
<description>
Returns the next mute-envelope-point-ID, it's value(0 or 1) and it's time. Envelope-Points numbering starts with 0! Returns -1 if not existing.
</description>
<retvals>
integer envIDX - number of the muteenvelope-point
 number envVal - value of the muteenvelope-point (0 or 1)
 number envPosition  - position of the muteenvelope-point in seconds
</retvals>
<parameters>
MediaTrack track - the MediaTrack-object, for the track, where you want to set the mute-envelope-lane.
number position - position in seconds, from where to look for the next mute-envelope-point
</parameters>
<semanticcontext>
Cough-Button
Muting tracks within envelope-lanes
</semanticcontext>
<tags>
cough button, mute, position, envelope, state, value
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetPreviousMuteState_TrackObject
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer envIDX, number envVal, number envPosition = ultraschall.GetPreviousMuteState_TrackObject(MediaTrack track, number position)
</functionname>
<description>
Returns the previous mute-envelope-point-ID, it's value(0 or 1) and it's time. Envelope-Points numbering starts with 0! Returns -1 if not existing.
</description>
<retvals>
integer envIDX - number of the muteenvelope-point
 number envVal - value of the muteenvelope-point (0 or 1)
 number envPosition  - position of the muteenvelope-point in seconds
</retvals>
<parameters>
MediaTrack track - the MediaTrack-object, for the track, where you want to set the mute-envelope-lane.
number position - position in seconds, from where to look for the previous mute-envelope-point
</parameters>
<semanticcontext>
Cough-Button
Muting tracks within envelope-lanes
</semanticcontext>
<tags>
cough button, mute, position, envelope, state, value
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CountMuteEnvelopePoints
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.CountMuteEnvelopePoints(integer track)
</functionname>
<description>
Returns the number of the envelope-points in the Mute-lane of track "track". Returns -1, if it fails.
</description>
<retvals>
integer retval  - number of mute-envelope-points
</retvals>
<parameters>
integer track - the track-number, for which you want to count the mute-envelope-points.
</parameters>
<semanticcontext>
Cough-Button
Muting tracks within envelope-lanes
</semanticcontext>
<tags>
cough button, mute, envelope, state
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
AddNormalMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer marker_number = ultraschall.AddNormalMarker(number position, integer shown_number, string markertitle)
</functionname>
<description>
Adds a normal marker. Returns the index of the marker as marker_number. 
</description>
<retvals>
 integer marker_number  - the overall-marker-index, can be used for reaper's own marker-management functions
</retvals>
<parameters>
number position - position in seconds.
integer shown_number - the number, that will be shown within Reaper. Can be multiple times.
string markertitle - the title of the marker.
</parameters>
<semanticcontext>
Markers
Adding Markers
</semanticcontext>
<tags>
markermanagement, add, normal marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
AddPodRangeRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer marker_number = ultraschall.AddPodRangeRegion(number startposition, number endposition)
</functionname>
<description>
Adds a region, which shows the time-range from the beginning to the end of the podcast.
</description>
<retvals>
integer marker_number  - the overall-marker-index, can be used for reaper's own marker-management functions
</retvals>
<parameters>
number startposition - begin of the podcast in seconds
number endposition - end of the podcast in seconds
</parameters>
<semanticcontext>
Markers
Adding Markers
</semanticcontext>
<tags>
markermanagement, add, podrange, region
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
AddChapterMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer marker_number = ultraschall.AddChapterMarker(number position, integer shown_number, string chaptertitle)
</functionname>
<description>
Adds a Chapter marker. Returns the index of the marker as marker_number. 
</description>
<retvals>
 integer marker_number  - the overall-marker-index, can be used for reaper's own marker-management functions
</retvals>
<parameters>
number position - position in seconds.
integer shown_number - the number, that will be shown within Reaper. Can be multiple times.
string chaptertitle - the title of the chaptermarker; will be shown as _Chapter:chaptertitle
</parameters>
<semanticcontext>
Markers
Adding Markers
</semanticcontext>
<tags>
markermanagement, add, chapter, marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
AddEditMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer marker_number = ultraschall.AddEditMarker(number position, integer shown_number, string edittitle)
</functionname>
<description>
Adds an Edit marker. Returns the index of the marker as marker_number. 
</description>
<retvals>
 integer marker_number  - the overall-marker-index, can be used for reaper's own marker-management functions
</retvals>
<parameters>
number position - position in seconds.
integer shown_number - the number, that will be shown within Reaper. Can be multiple times.
string edittitle - the title of the chaptermarker; will be shown as _Edit:edittitle
</parameters>
<semanticcontext>
Markers
Adding Markers
</semanticcontext>
<tags>
markermanagement, add, edit, marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
AddDummyMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer marker_number = ultraschall.AddDummyMarker(number position, integer shown_number, string dummytitle)
</functionname>
<description>
Adds a Dummy marker. Returns the index of the marker as marker_number. 
</description>
<retvals>
 integer marker_number  - the overall-marker-index, can be used for reaper's own marker-management functions
</retvals>
<parameters>
number position - position in seconds.
integer shown_number - the number, that will be shown within Reaper. Can be multiple times.
string dummytitle - the title of the chaptermarker; will be shown as _Dummy:dummytitle
</parameters>
<semanticcontext>
Markers
Adding Markers
</semanticcontext>
<tags>
markermanagement, add, dummy, marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CountNormalMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer number_of_markers = ultraschall.CountNormalMarkers()
</functionname>
<description>
Counts all normal markers, not(!) _shownote/_edit/_chapter/_dummy-markers.
</description>
<retvals>
 integer number_of_markers  - number of normal markers
</retvals>
<semanticcontext>
Markers
Counting Markers
</semanticcontext>
<tags>
markermanagement, normal marker, marker, count
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CountChapterMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer number of chapter_markers = ultraschall.CountChapterMarkers()
</functionname>
<description>
Counts all chapter-markers.
</description>
<retvals>
 integer number of chapter_markers  - number of chapter markers
</retvals>
<semanticcontext>
Markers
Counting Markers
</semanticcontext>
<tags>
markermanagement, marker, count, chapter markers, chapter
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CountEditMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer number_of_edit_markers = ultraschall.CountEditMarkers()
</functionname>
<description>
Counts all edit-markers.
</description>
<retvals>
 integer number_of_edit_markers  - number of edit markers
</retvals>
<semanticcontext>
Markers
Counting Markers
</semanticcontext>
<tags>
markermanagement, marker, count, edit markers, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
CountDummyMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer number_of_dummy_markers = ultraschall.CountDummyMarkers()
</functionname>
<description>
Counts all dummy-markers.
</description>
<retvals>
 integer number_of_dummy_markers  - count dummy markers
</retvals>
<semanticcontext>
Markers
Counting Markers
</semanticcontext>
<tags>
markermanagement, marker, count, dummy markers, dummy
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetPodRangeRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 number start_position, number end_position = ultraschall.GetPodRangeRegion()
</functionname>
<description>
Gets the start_position and the end_position of the PodRangeRegion.
</description>
<retvals>
 number start_position - beginning of the podrangeregion, that marks the beginning of the podcast
 number end_position  - end of the podrangeregion, that marks the end of the podcast
</retvals>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, enumerate, podrange region, podrange, region
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EnumerateNormalMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retnumber, integer retidxnum, number position, string markername = ultraschall.EnumerateNormalMarkers(integer number)
</functionname>
<description>
Get the data of a normal marker.
</description>
<retvals>
 integer retnumber - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
- markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
- the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer retidxnum - indexnumber of the marker
 number position - the position of the marker
 string markername  - the name of the marker
</retvals>
<parameters>
integer number - number of the marker(normal markers only). Refer <a href="#CountNormalMarkers">ultraschall.CountNormalMarkers</a> for getting the number of normal markers.
</parameters>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, normal, normal marker, enumerate
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EnumerateChapterMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retnumber, integer retidxnum, number position, string chaptername = ultraschall.EnumerateChapterMarkers(integer number)
</functionname>
<description>
Get the data of a chapter marker.
</description>
<retvals>
  integer retnumber - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
- markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
- the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer retidxnum - indexnumber of the marker
 number position - the position of the marker
 string chaptername  - the name of the marker
</retvals>
<parameters>
integer number - number of the chapter-marker. Refer <a href="#CountChapterMarkers">ultraschall.CountChapterMarkers</a> for getting the number of chapter-markers.
</parameters>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, enumerate, chapter, chapter marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EnumerateDummyMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retnumber, integer retidxnum, number position, string dummyname = ultraschall.EnumerateDummyMarkers(integer number)
</functionname>
<description>
Get the data of a dummy marker.
</description>
<retvals>
 integer retnumber - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
- markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
- the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer retidxnum - indexnumber of the marker
 number position - the position of the marker
 string dummyname  - the name of the marker
</retvals>
<parameters>
integer number - number of the dummy-marker. Refer <a href="#CountDummyMarkers">ultraschall.CountDummyMarkers</a> for getting the number of dummy-markers.
</parameters>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, enumerate, dummy, dummy marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EnumerateEditMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retnumber, integer retidxnum, number position, string editname = ultraschall.EnumerateEditMarkers(integer number)
</functionname>
<description>
Get the data of an edit marker.
</description>
<retvals>
 integer retnumber - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
- markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
- the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer retidxnum - indexnumber of the marker
 number position - the position of the marker
 string dummyname  - the name of the marker
</retvals>
<parameters>
number - number of the edit-marker. Refer <a href="#CountEditMarkers">ultraschall.CountEditMarkers</a> for getting the number of edit-markers.
</parameters>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, enumerate, edit, edit marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetAllChapterMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer number_of_chapters, array chaptermarkersarray = ultraschall.GetAllChapterMarkers()
</functionname>
<description>
returns the number of chapters and an array with each chaptermarker in the format:
</description>
<retvals>
 integer number_of_chapters - the number of chapters returned
 array chaptermarkersarray  - an array, where array[0] holds the position and array[1] the name
</retvals>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, get, get all, chapter, chapter marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetAllEditMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer number_of_editmarkers, array editmarkersarray = ultraschall.GetAllEditMarkers()
</functionname>
<description>
returns the number of editmarkers and an array with each editmarker in the format:
</description>
<retvals>
integer number_of_editmarkers - the number of editmarkers returned
 array editmarkersarray  - an array, where array[0] holds the position and array[1] the name
</retvals>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, get, get all, edit, edit marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetAllNormalMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 index number_of_normalmarkers, array normalmarkersarray = ultraschall.GetAllNormalMarkers()
</functionname>
<description>
returns the number of normalmarkers and an array with each normalmarker in the format:
</description>
<retvals>
integer number_of_normalmarkers - the number of normalmarkers returned
array normalmarkersarray  - an array, where array[0] holds the position and array[1] the name
</retvals>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, get, get all, normal, normal marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
GetAllMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer number_of_all_markers, array allmarkersarray = ultraschall.GetAllMarkers()
</functionname>
<description>
To get all Markers in the project(normal, edit, chapter), regardless of their category.

returns the number of markers and an array with each marker in the format:
</description>
<retvals>
integer number_of_allmarkers - the number of normalmarkers returned
array allmarkersarray  - an array, where array[0] holds the position and array[1] the name
</retvals>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, marker, get, get all
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetNormalMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 boolean retval = ultraschall.SetNormalMarker(integer number, number position, integer shown_number, string markertitle)
</functionname>
<description>
 Sets values of a normal Marker(no _Chapter:, _Shownote:, etc). Returns true if successful and false if not(i.e. marker doesn't exist)
</description>
<parameters>
integer number - the number of the normal marker
number position - position of the marker in seconds
integer shown_number - the number of the marker
string markertitle - title of the marker
</parameters>
<retvals>
 boolean retval  - true if successful and false if not(i.e. marker doesn't exist)
</retvals>
<semanticcontext>
Markers
Setting Markers
</semanticcontext>
<tags>
markermanagement, marker, set, set normal, normal marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetEditMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 boolean retval = ultraschall.SetEditMarker(integer number, number position, integer shown_number, string edittitle)
</functionname>
<description>
Sets values of an Edit Marker. Returns true if successful and false if not(i.e. marker doesn't exist)
</description>
<parameters>
integer number - the number of the edit marker
number position - position of the marker in seconds
integer shown_number - the number of the marker
string markertitle - title of the marker
</parameters>
<retvals>
 boolean retval  - true if successful and false if not(i.e. marker doesn't exist)
</retvals>
<semanticcontext>
Markers
Setting Markers
</semanticcontext>
<tags>
markermanagement, marker, set, set edit, edit marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetChapterMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 boolean retval = ultraschall.SetChapterMarker(integer number, number position, integer shown_number, string chaptertitle)
</functionname>
<description>
Sets values of a Chapter Marker. Returns true if successful and false if not(i.e. marker doesn't exist)
</description>
<parameters>
integer number - the number of the chapter marker
number position - position of the marker in seconds
integer shown_number - the number of the marker
string markertitle - title of the marker
</parameters>
<retvals>
 boolean retval  - true if successful and false if not(i.e. marker doesn't exist)
</retvals>
<semanticcontext>
Markers
Setting Markers
</semanticcontext>
<tags>
markermanagement, marker, set, set chapter, chapter marker
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
SetPodRangeRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retval = ultraschall.SetPodRangeRegion(number startposition, number endposition)
</functionname>
<description>
Sets "_PodRange:"-Region, returns -1 if it fails.
</description>
<parameters>
number startposition - begin of the podcast in seconds
number endposition - end of the podcast in seconds
</parameters>
<retvals>
 integer retval  - number of the region, -1 if it fails
</retvals>
<semanticcontext>
Markers
Setting Markers
</semanticcontext>
<tags>
markermanagement, marker, set, set podrange, podrange region, region
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
DeletePodRangeRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retval = ultraschall.DeletePodRangeRegion()
</functionname>
<description>
deletes the PodRange-Region. Returns 1, if it worked, -1 if it failed.
</description>
<retvals>
 integer retval  - 1 in case of success, -1, if it failed
</retvals>
<semanticcontext>
Markers
Deleting Markers
</semanticcontext>
<tags>
markermanagement, marker, delete, delete podrange, podrange region, region
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
DeleteNormalMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 boolean retval = ultraschall.DeleteNormalMarker(integer number)
</functionname>
<description>
Deletes a Normal-Marker. Returns true if successful and false if not(i.e. marker doesn't exist) Use <a href="#EnumerateNormalMarkers">ultraschall.EnumerateNormalMarkers</a> to get the correct number.
</description>
<parameters>
integer number - number of a normal marker
</parameters>
<retvals>
 boolean retval  - true, if successful, false if not
</retvals>
<semanticcontext>
Markers
Deleting Markers
</semanticcontext>
<tags>
markermanagement, marker, delete, normal marker, normal
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
DeleteChapterMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 boolean retval = ultraschall.DeleteChapterMarker(integer number)
</functionname>
<description>
Deletes a _Chapter:-Marker. Returns true if successful and false if not(i.e. marker doesn't exist) Use <a href="#EnumerateChapterMarkers">ultraschall.EnumerateChapterMarkers</a> to get the correct number.
</description>
<parameters>
integer number - number of a chapter marker
</parameters>
<retvals>
 boolean retval  - true, if successful, false if not
</retvals>
<semanticcontext>
Markers
Deleting Markers
</semanticcontext>
<tags>
markermanagement, marker, delete, normal marker, normal
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
DeleteEditMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 boolean retval = ultraschall.DeleteEditMarker(integer number)
</functionname>
<description>
Deletes a _Edit:-Marker. Returns true if successful and false if not(i.e. marker doesn't exist) Use <a href="#EnumerateEditMarkers">ultraschall.EnumerateEditMarkers</a> to get the correct number.
</description>
<parameters>
integer number - number of a chapter marker
</parameters>
<retvals>
 boolean retval  - true, if successful, false if not
</retvals>
<semanticcontext>
Markers
Deleting Markers
</semanticcontext>
<tags>
markermanagement, marker, delete, edit marker, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
DeleteDummyMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 boolean retval = ultraschall.DeleteDummyMarker(integer number)
</functionname>
<description>
Deletes a _Dummy:-Marker. Returns true if successful and false if not(i.e. marker doesn't exist) Use <a href="#EnumerateDummyMarkers">ultraschall.EnumerateDummyMarkers</a> to get the correct number.
</description>
<parameters>
integer number - number of a dummy marker
</parameters>
<retvals>
 boolean retval  - true, if successful, false if not
</retvals>
<semanticcontext>
Markers
Deleting Markers
</semanticcontext>
<tags>
markermanagement, marker, delete, dummy marker, dummy
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ExportChapterMarkersToFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retval = ultraschall.ExportChapterMarkersToFile(string filename_with_path,number PodRangeStart, number PodRangeEnd)
</functionname>
<description>
Export Chapter-Markers to filename_with_path. Returns -1 in case of error.

PodRangeStart influences the time, with which the markers will be exported to file: chaptermarkerposition minus PodRangeStart. That way, you can skip the Podcaststart-offset, when a podcast doesn't start at 00:00, but later, which could otherwise lead to misplaced chapter-markers.
</description>
<retvals>
 integer retval  - 1 in case of success, -1 if it failed
</retvals>
<parameters>
string filename_with_path - the name of the export-file
 number PodRangeStart - beginning of the podcast in seconds
 number PodRangeEnd - end of the podcast in seconds
</parameters>
<semanticcontext>
Markers
Export Markers
</semanticcontext>
<tags>
markermanagement, marker, export, file, chapters
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ExportEditMarkersToFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retval = ultraschall.ExportEditMarkersToFile(string filename_with_path, number PodRangeStart, number PodRangeEnd)
</functionname>
<description>
Export Edit-Markers to filename_with_path. Returns -1 in case of error.
</description>
<retvals>
 integer retval  - 1 in case of success, -1 if it failed
</retvals>
<parameters>
string filename_with_path - the name of the export-file
 number PodRangeStart - beginning of the podcast in seconds
 number PodRangeEnd - end of the podcast in seconds
</parameters>
<semanticcontext>
Markers
Export Markers
</semanticcontext>
<tags>
markermanagement, marker, export, file, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ExportNormalMarkersToFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer retval = ultraschall.ExportNormalMarkersToFile(string filename_with_path, number PodRangeStart, number PodRangeEnd)
</functionname>
<description>
Export Normal-Markers to filename_with_path. Returns -1 in case of error.
</description>
<retvals>
 integer retval  - 1 in case of success, -1 if it failed
</retvals>
<parameters>
string filename_with_path - the name of the export-file
 number PodRangeStart - beginning of the podcast in seconds
 number PodRangeEnd - end of the podcast in seconds
</parameters>
<semanticcontext>
Markers
Export Markers
</semanticcontext>
<tags>
markermanagement, marker, export, file, normal
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ImportChaptersFromFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 array chapters = ultraschall.ImportChaptersFromFile(string filename_with_path, number PodRangeStart)
</functionname>
<description>
Imports chapterentries from a file and returns an array of the imported values.

returns -1 in case of error
</description>
<parameters>
string filename_with_path - markerfile to be imported
number PodRangeStart - podcast-start-offset
</parameters>
<retvals>
 array chapters  - array[0] is position of marker+PodRangeStart, array[1] is name of the marker
</retvals>
<semanticcontext>
Markers
Import Markers
</semanticcontext>
<tags>
markermanagement, marker, import, file, chapter
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ImportChaptersFromFile_Filerequester
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 array chapters = ultraschall.ImportChaptersFromFile_Filerequester(PodRangeStart)
</functionname>
<description>
Opens a filerequester to select the importfile. Imports chapterentries from the selected file and returns an array of the imported values.

returns -1 in case of error
</description>
<parameters>
number PodRangeStart - podcast-start-offset
</parameters>
<retvals>
 array chapters  - array[0] is position of marker+PodRangeStart, array[1] is name of the marker
</retvals>
<semanticcontext>
Markers
Import Markers
</semanticcontext>
<tags>
markermanagement, marker, import, file, chapter, requester
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ImportEditFromFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 array editmarkers = ultraschall.ImportEditFromFile(string filename_with_path, PodRangestart)
</functionname>
<description>
Imports editentries from a file and returns an array of the imported values.

returns -1 in case of error
</description>
<parameters>
string filename_with_path - markerfile to be imported
number PodRangeStart - podcast-start-offset
</parameters>
<retvals>
 array chapters  - array[0] is position of marker+PodRangeStart, array[1] is name of the marker
</retvals>
<semanticcontext>
Markers
Import Markers
</semanticcontext>
<tags>
markermanagement, marker, import, file, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ImportEditFromFile_Filerequester
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 array editmarkers = ultraschall.ImportEditFromFile_Filerequester(PodRangeStart)
</functionname>
<description>
Opens a filerequester to select the importfile. Imports editentries from the selected file and returns an array of the imported values.

returns -1 in case of error
</description>
<parameters>
number PodRangeStart - podcast-start-offset
</parameters>
<retvals>
 array chapters  - array[0] is position of marker+PodRangeStart, array[1] is name of the marker
</retvals>
<semanticcontext>
Markers
Import Markers
</semanticcontext>
<tags>
markermanagement, marker, import, file, edit, filerequester
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ImportMarkersFromFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 array markers = ultraschall.ImportMarkersFromFile(string filename_with_path, PodrangeStart)
</functionname>
<description>
Imports markerentries from a file and returns an array of the imported values.

returns -1 in case of error
</description>
<parameters>
string filename_with_path - markerfile to be imported
number PodRangeStart - podcast-start-offset
</parameters>
<retvals>
 array chapters  - array[0] is position of marker+PodRangeStart, array[1] is name of the marker
</retvals>
<semanticcontext>
Markers
Import Markers
</semanticcontext>
<tags>
markermanagement, marker, import, file
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ImportMarkersFromFile_Filerequester
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 array markers = ultraschall.ImportMarkersFromFile_Filerequester(PodRangeStart)
</functionname>
<description>
Opens a filerequester to select the importfile. Imports markerentries from the selected file and returns an array of the imported values.

returns -1 in case of error
</description>
<parameters>
number PodRangeStart - podcast-start-offset
</parameters>
<retvals>
 array chapters  - array[0] is position of marker+PodRangeStart, array[1] is name of the marker
</retvals>
<semanticcontext>
Markers
Import Markers
</semanticcontext>
<tags>
markermanagement, marker, import, file, filerequester
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
MarkerToEditMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.MarkerToEditMarker(integer number)
</functionname>
<description>
Converts a normal-marker to an edit-marker.
</description>
<retvals>
 integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the chapter-marker. Refer <a href="#CountNormalMarkers">ultraschall.CountNormalMarkers</a> for getting the number of normal-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, edit, normal
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
MarkerToChapterMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.MarkerToChapterMarker(integer number)
</functionname>
<description>
Converts a normal-marker to a chapter marker.
</description>
<retvals>
 integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the chapter-marker. Refer <a href="#CountNormalMarkers">ultraschall.CountNormalMarkers</a> for getting the number of normal-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, chapter, normal
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
MarkerToDummyMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.MarkerToDummyMarker(integer number)
</functionname>
<description>
Converts a normal-marker to a dummy marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the chapter-marker. Refer <a href="#CountNormalMarkers">ultraschall.CountNormalMarkers</a> for getting the number of normal-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, dummy, normal
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ChapterToEditMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.ChapterToEditMarker(integer number)
</functionname>
<description>
Converts a chapter-marker to an edit marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the chapter-marker. Refer <a href="#CountChapterMarkers">ultraschall.CountChapterMarkers</a> for getting the number of chapter-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, chapter, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ChapterToDummyMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.ChapterToDummyMarker(integer number)
</functionname>
<description>
Converts a chapter-marker to a dummy marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
number - number of the chapter-marker. Refer <a href="#CountChapterMarkers">ultraschall.CountChapterMarkers</a> for getting the number of chapter-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, chapter, dummy
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
ChapterToMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.ChapterToMarker(integer number)
</functionname>
<description>
Converts a chapter-marker to a normal marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the chapter-marker. Refer <a href="#CountChapterMarkers">ultraschall.CountChapterMarkers</a> for getting the number of chapter-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, chapter, normal
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EditToChapterMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.EditToChapterMarker(integer number)
</functionname>
<description>
Converts a edit-marker to a chapter marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the edit-marker. Refer <a href="#CountEditMarkers">ultraschall.CountEditMarkers</a> for getting the number of edit-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, chapter, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EditToDummyMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.EditToDummyMarker(integer number)
</functionname>
<description>
Converts an edit-marker to a dummy marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the edit-marker. Refer <a href="#CountEditMarkers">ultraschall.CountEditMarkers</a> for getting the number of edit-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, dummy, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
EditToMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.EditToMarker(integer number)
</functionname>
<description>
Converts an edit-marker to a normal marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the edit-marker. Refer <a href="#CountEditMarkers">ultraschall.CountEditMarkers</a> for getting the number of edit-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, normal, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
DummyToChapterMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.DummyToChapterMarker(integer number)
</functionname>
<description>
Converts a dummy-marker to a chapter marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the dummy-marker. Refer <a href="#CountDummyMarkers">ultraschall.CountDummyMarkers</a> for getting the number of dummy-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, dummy, chapter
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
DummyToEditMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.DummyToEditMarker(integer number)
</functionname>
<description>
Converts a dummy-marker to an edit marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the dummy-marker. Refer <a href="#CountDummyMarkers">ultraschall.CountDummyMarkers</a> for getting the number of dummy-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, dummy, edit
</tags>
</ApiDocBlocFunc>

--[[
<ApiDocBlocFunc>
<slug>
DummyToMarker
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
 integer idx, integer shown_number, number position, string markername = ultraschall.DummyToMarker(integer number)
</functionname>
<description>
Converts a dummy-marker to a normal marker.
</description>
<retvals>
integer idx - overallmarker/regionnumber of marker beginning with 1 for the first marker; ignore the order of first,second,etc creation of
-markers but counts from position 00:00:00 to end of project. So if you created a marker at position 00:00:00 and move the first created marker to
-the end of the timeline, it will be the last one, NOT the first one in the retval! For use with reaper's own marker-functions.
 integer shown_number - the shown number of the marker
 number position - the position of the marker in seconds
 string markername  - the markername
</retvals>
<parameters>
integer number - number of the dummy-marker. Refer <a href="#CountDummyMarkers">ultraschall.CountDummyMarkers</a> for getting the number of dummy-markers.
</parameters>
<semanticcontext>
Markers
Convert Markers
</semanticcontext>
<tags>
markermanagement, marker, convert, dummy, normal
</tags>
</ApiDocBlocFunc>




--]]
































--------------------------------------------------
------ ULTRASCHALL FRAMEWORK 4.00 BETA 2 ---------
--------------------------------------------------


-----------------------------
---- Ultraschall Helpers ----
-----------------------------

function ultraschall.GetApiVersion()
--[[
<ApiDocBlocFunc>
<slug>
GetPath
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string version, string date, string beta = ultraschall.GetApiVersion()
</functionname>
<description>
returns the version, release-date and if it's a beta-version
</description>
<retvals>
string version - the current Api-version
string date - the release date of this api-version
string beta - if it's a beta version, this is the beta-version-number
</retvals>
<semanticcontext>
API-Helper functions
</semanticcontext>
<tags>
version,versionmanagement
</tags>
</ApiDocBlocFunc>
--]]
  return "4.0 \"Ich und der Rock\"","(30th of August 2017)", "beta 2.1"
end

function ultraschall.CreateTrackNumbersString_SelectedTracks()
-- returns a string with the all numbers from selected tracks, separated by a ,
-- e.g. firstnumber=4, lastnumber=8 -> 4,5,6,7,8

--[[
<ApiDocBlocFunc>
<slug>
CreateTrackNumbersString_SelectedTracks
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string trackstring = ultraschall.CreateTrackNumbersString_SelectedTracks()
</functionname>
<description>
Creates a string with all numbers from selected tracks, separated by a ,
</description>
<retvals>
string trackstring - a string with the tracknumbers, separated by a string
</retvals>
<semanticcontext>
Track Management
Assistance functions
</semanticcontext>
<tags>
trackmanagement, datastructure
</tags>
</ApiDocBlocFunc>
]]
  
  local trackstring=""
  for i=1, reaper.CountTracks(0) do
  MediaTrack=reaper.GetTrack(0,i-1)
--  reaper.MB(tostring(MediaTrack),"",0)
  if reaper.IsTrackSelected(MediaTrack)==true then
    trackstring=trackstring..i..","
  end  
  end
  return trackstring:sub(1,-2)
end

--A=ultraschall.CreateTrackNumbersString_SelectedTracks()


-------------------------
---- File Management ----
-------------------------

function ultraschall.ReadValueFromFile(filename_with_path, value)
  -- Returns 
  -- a string with the contents of the file "filename_with_path" as well as
  -- a string, that contains the linenumbers returned as a , separated csv-string and
  -- an integer the number of lines returned
  --
  -- If "value" is given, it will return all lines, containing the value in the 
  -- file "filename_with_path". The second line-numbers return-value is very valuable 
  -- when giving a "value". "Value" is not case-sensitive.
  -- Keep in mind, that you need to escape \ by writing \\, or it will not work

--[[
<ApiDocBlocFunc>
<slug>
ReadValueFromFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string contents, string linenumbers, integer numberoflines = ultraschall.ReadValueFromFile(string filename_with_path, string value)
</functionname>
<description>
Return contents of filename_with_path. 

If "value" is given, it will return all lines, containing the value in the file "filename_with_path". 
The second line-numbers return-value is very valuable when giving a "value". "Value" is not case-sensitive.
The value can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!

Keep in mind, that on Windows, you need to escape \ by writing \\ in filenames, or it will not work.

</description>
<retvals>
string contents - the contents of the file, or the lines that contain parameter value in it, separated by a newline
string linenumbers - a string, that contains the linenumbers returned as a , separated csv-string and
integer numberoflines - the number of lines read
</retvals>
<parameters>
string filename_with_path - filename of the file to be read
string value - the value to look in the file for. Not case-sensitive.
</parameters>
<semanticcontext>
File Management
Read Files
</semanticcontext>
<tags>
filemanagement, read file, value, pattern
</tags>
</ApiDocBlocFunc>
]]
  if filename_with_path == nil then return nil end
  if value==nil then value="" end
  local file=io.open(filename_with_path,"r")
  if file==nil then return nil end
  file:close()

  local a=""
  local b=0
  local c=""
  local d=0
  if value=="" then 
    for line in io.lines(filename_with_path) do 
      a=a..line.."\n"
      b=b+1
      c=c..tostring(b)..","
      d=b
    end
  else
    for line in io.lines(filename_with_path) do
         local temp=line:lower()
         local valtemp=value:lower()
         b=b+1
         if temp:match(valtemp) then 
            a=a..line.."\n"          
            c=c..tostring(b)..","
            d=d+1
         end
    end
  end
  return a,c:sub(1,-2),d
end


--A,B,C=ultraschall.ReadValueFromFile("c:\\testhelp.html", "")



function ultraschall.ReadLinerangeFromFile(filename_with_path, firstlinenumber, lastlinenumber)
  -- Returns a string with the contents of the file "filename_with_path" from line
  -- firstlinenumber to lastlinenumber as well as a
  -- boolean false if fewer lines are returned than requested, true if as many lines returned as requested
  --
  -- every line is separated with a newline from each other
  -- Keep in mind, that you need to escape \ by writing \\, or it will not work
  -- returns nil in case of error like non existing file or invalid linenumbers
  -- returns "", if nothing was found
  --
  -- counting of linenumbers starts with 1 for the first line

--[[
<ApiDocBlocFunc>
<slug>
ReadLinerangeFromFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string contents, boolean correctnumberoflines = ultraschall.ReadLinerangeFromFile(stirng filename_with_path, integer firstlinenumber, integer lastlinenumber)
</functionname>
<description>
Return contents of filename_with_path, from firstlinenumber to lastlinenumber. Counting of linenumbers starts with 1 for the first line.
The returned string contains all requested lines, separated by a newline.

Returns nil, if the linenumbers are invalid.
</description>
<retvals>
string contents - the contents the lines of the file, that you requested
boolean correctnumberoflines - true, if the number of lines are returned, as requested; false if fewer lines are returned
</retvals>
<parameters>
string filename_with_path - filename of the file to be read
integer firstlinenumber - the first linenumber to be returned. First line in the file begins with 1!
integer lastlinenumber - the last linenumber to be returned.
</parameters>
<semanticcontext>
File Management
Read Files
</semanticcontext>
<tags>
filemanagement, read file, range
</tags>
</ApiDocBlocFunc>
]]
  
  if tonumber(firstlinenumber)==nil then return nil end
  if tonumber(lastlinenumber)==nil then return nil end
  firstlinenumber=tonumber(firstlinenumber)
  lastlinenumber=tonumber(lastlinenumber)
  if filename_with_path == nil then return nil end
  local file=io.open(filename_with_path,"r")
  if file==nil then return nil end
  file:close()

  local a=""
  local b=0

  for line in io.lines(filename_with_path) do 
     b=b+1
     if b>=firstlinenumber and b<=lastlinenumber then
       a=a..line.."\n"
     end
     if b>lastlinenumber then return a, true end
  end
  if b<lastlinenumber then return a, false end
  
  return a, true
end


--A,B=ultraschall.ReadLinerangeFromFile("c:\\Reaper\\tips.txt","-8","9")

function ultraschall.MakeCopyOfFile(input_filename_with_path, output_filename_with_path)
--makes a copy of a textfile

--[[
<ApiDocBlocFunc>
<slug>
MakeCopyOfFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.MakeCopyOfFile(string input_filename_with_path, string output_filename_with_path)
</functionname>
<description>
Copies input_filename_with_path to output_filename_with_path. 
Only textfiles! For binary-files use MakeCopyOfFile_Binary() instead!

Returns true, if it worked, false if it didn't.
</description>
<retvals>
boolean retval - true, if copy worked, false if it didn't.
</retvals>
<parameters>
string input_filename_with_path - filename of the file to copy
string output_filename_with_path - filename of the copied file to be created.
</parameters>
<semanticcontext>
File Management
Manipulate Files
</semanticcontext>
<tags>
read file, value
</tags>
<tags>
filemanagement, copy, file management
</tags>
</ApiDocBlocFunc>
]]
  if input_filename_with_path==nil or output_filename_with_path==nil then return false end
  if reaper.file_exists(input_filename_with_path)==true then
     local file=io.open(output_filename_with_path,"w")
     if file==nil then return false end
    for line in io.lines(input_filename_with_path) do
     file:write(line.."\n")
    end
    file:close()
  else return false
  end
  return true
end

--A=ultraschall.MakeCopyOfFile("c:\\tt.rpp","c:\\huibh.txt")

function ultraschall.MakeCopyOfFile_Binary(input_filename_with_path, output_filename_with_path)
--makes a copy of a binary-file

--[[
<ApiDocBlocFunc>
<slug>
MakeCopyOfFile_Binary
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.MakeCopyOfFile_Binary(string input_filename_with_path, string output_filename_with_path)
</functionname>
<description>
Copies input_filename_with_path to output_filename_with_path as binary-file.
</description>
<retvals>
boolean retval - returns true, if copy worked; false if it didn't
</retvals>
<parameters>
string input_filename_with_path - filename of the file to copy
string output_filename_with_path - filename of the copied file, that shall be created
</parameters>
<semanticcontext>
File Management
Manipulate Files
</semanticcontext>
<tags>
filemanagement, read file, binary
</tags>
</ApiDocBlocFunc>
]]

  local temp=""
  if input_filename_with_path==nil or output_filename_with_path==nil then return false end
  if reaper.file_exists(input_filename_with_path)==true then
    local fileread=io.open(input_filename_with_path,"rb")
    local file=io.open(output_filename_with_path,"wb")
    if file==nil then return false end
      temp=fileread:read("*a")
      file:write(temp)
    fileread:close()
    file:close()
  else return false
  end
  return true
end

--A=ultraschall.MakeCopyOfFile_Binary("c:\\testcopy.webm","c:\\testcopy2.webm")
--ultraschall.MakeCopyOfFile_Binary("c:\\reaper.exe","c:\\reaper.testrl")

function ultraschall.ReadBinaryFile(input_filename_with_path)
--reads a binary file

--[[
<ApiDocBlocFunc>
<slug>
ReadBinaryFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer length, string content = ultraschall.ReadBinaryFile(string input_filename_with_path)
</functionname>
<description>
Returns the contents of a binary file.

Returns false, if file can not be opened.
</description>
<retvals>
integer length - the length of the returned file
string content - the content of the file, that has been read
</retvals>
<parameters>
string input_filename_with_path - filename of the file to be read
</parameters>
<semanticcontext>
File Management
Read Files
</semanticcontext>
<tags>
filemanagement, read file, binary
</tags>
</ApiDocBlocFunc>
]]

  local temp=""
  local length
  local temp2
  if input_filename_with_path==nil then return false end
  if reaper.file_exists(input_filename_with_path)==true then
    local fileread=io.open(input_filename_with_path,"rb")
      temp=fileread:read("*a")
    fileread:close()
  else
    return false
  end
  return temp:len(), temp
end

--A,AA=ultraschall.ReadBinaryFile("c:\\reaper.exe")

function ultraschall.ReadBinaryFileUntilPattern(input_filename_with_path, pattern)
--reads a binary file until the first occurence of pattern
--pattern - case sensitive

--[[
<ApiDocBlocFunc>
<slug>
ReadBinaryFileUntilPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer length, string content = ultraschall.ReadBinaryFileUntilPattern(string input_filename_with_path, string pattern)
</functionname>
<description>
Returns a binary file, up until a pattern. The pattern is not case-sensitive.

Pattern can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!

</description>
<retvals>
integer length - the length of the returned data
string content - the content of the file, that has been read until pattern
</retvals>
<parameters>
string filename_with_path - filename of the file to be read
string pattern - a pattern to search for. Case-sensitive.
</parameters>
<semanticcontext>
File Management
Read Files
</semanticcontext>
<tags>
filemanagement, read file, pattern, binary
</tags>
</ApiDocBlocFunc>
]]

  local temp=""
  local length
  local temp2
  if input_filename_with_path==nil or pattern==nil then return false end
  if reaper.file_exists(input_filename_with_path)==true then
    local fileread=io.open(input_filename_with_path,"rb")
      temp=fileread:read("*a")
      temp2=temp:match(pattern)
      if temp2==nil then fileread:close() return false end
      temp2=temp:match("(.-"..pattern..")")
      if temp2==nil then fileread:close() return false end
      length=temp2:len()
    fileread:close()
--reaper.ShowConsoleMsg(temp2)
  else
    return false
  end
  return length, temp2
end

--A,AA=ultraschall.ReadBinaryFileUntilPattern("c:\\test.txt","ultraschall")

function ultraschall.ReadBinaryFileFromPattern(input_filename_with_path, pattern)
--reads a binary file from a first occurence of pattern to it's end. Doesn't show in ReaperConsole completely!
--pattern - case sensitive

--[[
<ApiDocBlocFunc>
<slug>
ReadBinaryFileFromPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer length, string content = ultraschall.ReadBinaryFileFromPattern(string input_filename_with_path, string pattern)
</functionname>
<description>
Returns a binary file, from pattern onwards. The pattern is not case-sensitive.

The pattern can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!
</description>
<retvals>
integer length - the length of the returned data
string content - the content of the file, that has been read until pattern
</retvals>
<parameters>
string filename_with_path - filename of the file to be read
string pattern - a pattern to search for. Case-sensitive.
</parameters>
<semanticcontext>
File Management
Read Files
</semanticcontext>
<tags>
filemanagement, read file, pattern, binary
</tags>
</ApiDocBlocFunc>
]]
  local temp=""
  local length
  local temp2
  if input_filename_with_path==nil or pattern==nil then return false end
  if reaper.file_exists(input_filename_with_path)==true then
    local fileread=io.open(input_filename_with_path,"rb")
      temp=fileread:read("*a")
      temp2=temp:match(pattern)
      if temp2==nil then fileread:close() return false end
      temp2=temp:match("("..pattern..".*)")
      if temp2==nil then fileread:close() return false end
      length=temp:len()-temp2:len()+1
    fileread:close()
--reaper.ShowConsoleMsg(temp2)
  else 
    return false
  end
  return length, temp2
end

--A,AA=ReadBinaryFileUntilPattern("c:\\reaper.exe","c:\\reaper.test","REAPER")
--A,AA=ReadBinaryFileUntilPattern("c:\\test.txt","c:\\test.temp","Ultraschall")
--A,BB=ultraschall.ReadBinaryFileFromPattern("c:\\test.txt","las")

--CC=AA..BB--:sub(9,-1)
--laeng=CC:len()
--laengA=AA:len()
--laengB=BB:len()

--ultraschall.WriteValueToFile("c:\\test2.txt",CC)
--A

function ultraschall.CountLinesInFile(filename_with_path)
  -- counts the number of lines in a file "filename_with_path" and returns it as integer
  -- Keep in mind, that you need to escape \ by writing \\, or it will not work
--[[
<ApiDocBlocFunc>
<slug>
CountLinesInFile
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer linesinfile = ultraschall.CountLinesInFile(string filename_with_path)
</functionname>
<description>
Counts lines in a textfile. In binary files, the number of line may be weird and unexpected!
Returns -1, if no such file exists.
</description>
<retvals>
integer linesinfile - number of lines in a textfile; -1 in case of error
</retvals>
<parameters>
string filename_with_path - filename of the file to be read
</parameters>
<semanticcontext>
File Management
File Analysis
</semanticcontext>
<tags>
filemanagement, count
</tags>
</ApiDocBlocFunc>
]]
  
  if filename_with_path == nil then return nil end
  local file=io.open(filename_with_path,"r")
  if file==nil then return -1 end
  file:close()

  local b=0
  for line in io.lines(filename_with_path) do 
      b=b+1
  end
  
  return b
end

--A=ultraschall.CountLinesInFile("c:\\Reaper\\reaper.exe")

--------------------------
---- Ini-Config-Files ----
--------------------------
---- must be:  ----
---- [section] ----
---- key=value ----
----  style -------
-------------------
function ultraschall.SetIniFileExternalState(section, key, value, ini_filename_with_path)
-- stores value into ini_filename_with_path
-- returns true if successful, false if unsuccessful

--[[
<ApiDocBlocFunc>
<slug>
SetIniFileExternalState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetIniFileExternalState(string section, string key, string value, string ini_filename_with_path)
</functionname>
<description>
Sets an external state into ini_filename_with_path. Returns false, if it doesn't work.
</description>
<retvals>
boolean retval - true, if setting the state was successful; false, if setting was unsuccessful
</retvals>
<parameters>
string section - section of the external state. No = allowed!
string key - key of the external state. No = allowed!
string value - value for the key
string filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, set, external state, value, ini-files
</tags>
</ApiDocBlocFunc>
]]

  if section==nil then return false end
  if key==nil then return false end
  if value==nil then return false end
  if ini_filename_with_path==nil then return false end
  if section:match(".*%=.*") then return false end
  if key:match(".*%=.*") then return false end

  return reaper.BR_Win32_WritePrivateProfileString(section, key, value, ini_filename_with_path)
end

--A=ultraschall.SetIniFileExternalState("hulasu","bulaabama","Mamula","c:\\huhududu.ini")

function ultraschall.GetIniFileExternalState(section, key, ini_filename_with_path)
-- gets a value from ini_filename_with_path
-- returns length of entry(integer) and the entry itself(string)
--[[
<ApiDocBlocFunc>
<slug>
GetIniFileExternalState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string value = ultraschall.GetIniFileExternalState(string section, string key, string ini_filename_with_path)
</functionname>
<description>
Gets an external state from ini_filename_with_path. Returns -1, if the file does not exist or parameters are invalid.
</description>
<retvals>
integer entrylength - the length of the returned value
string value - the value stored in a section->key in a configuration-file
</retvals>
<parameters>
string section - section of the external state
string key - key of the external state. No = allowed!
string filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, get, external state, value, ini-files
</tags>
</ApiDocBlocFunc>
]]

  if section==nil then return -1 end
  if key==nil then return -1 end
  if ini_filename_with_path==nil then return -1 end
  if reaper.file_exists(ini_filename_with_path)==false then return -1 end
    
  local L,LL=reaper.BR_Win32_GetPrivateProfileString(section, key, nil, ini_filename_with_path)
  if L==nil then return -1
  else
  return L,LL
  end
end

--A,AA=ultraschall.GetIniFileExternalState("REAPER","defsplitxfadelen","c:\\Ultraschall4\\reaper.ini")

function ultraschall.CountIniFileExternalState_sec(ini_filename_with_path)
--count number of sections in the ini_filename_with_path
--[[
<ApiDocBlocFunc>
<slug>
CountIniFileExternalState_sec
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer sectioncount = ultraschall.CountIniFileExternalState_sec(string ini_filename_with_path)
</functionname>
<description>
Count external-state-[sections] from an ini-configurationsfile.

Returns -1, if the file does not exist.
</description>
<retvals>
integer sectioncount - number of sections within an ini-configuration-file
</retvals>
<parameters>
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, count, sections, ini-files
</tags>
</ApiDocBlocFunc>
]]
  if ini_filename_with_path==nil then return -1 end
  if reaper.file_exists(ini_filename_with_path)==false then return -1 end
  local count=0
  
  for line in io.lines(ini_filename_with_path) do
    local check=line:match(".*=.*")
    if check~=nil then check="" count=count+1 end
  end
  return count
end

--AA=ultraschall.CountIniFileExternalState_sec("c:\\test.ini")

function ultraschall.CountIniFileExternalState_key(section, ini_filename_with_path)
--count number of keys in the section in ini_filename_with_path
--[[
<ApiDocBlocFunc>
<slug>
CountIniFileExternalState_key
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer keyscount = ultraschall.CountIniFileExternalState_key(string section, string ini_filename_with_path)
</functionname>
<description>
Count external-state-keys within a specific section, in a ini_filename_with_path.

Returns -1, if file does not exist.
</description>
<retvals>
integer keyscount - number of keys with section within an ini-configuration-file
</retvals>
<parameters>
string section - the section within the ini-filename
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, count, keys, ini-files
</tags>
</ApiDocBlocFunc>
]]
  local count=0
  local startcount=0
  if ini_filename_with_path==nil then return -1 end
  if reaper.file_exists(ini_filename_with_path)==false then return -1 end
  
  for line in io.lines(ini_filename_with_path) do
   local check=line:match("%[.*.%]")
    if startcount==1 and line:match(".*=.*") then
      count=count+1
    else
      startcount=0
    if "["..section.."]" == check then startcount=1 end
    if check==nil then check="" end
    end

  end
  return count
end

--A=ultraschall.CountIniFileExternalState_key("hula","c:\\test.ini")

function ultraschall.EnumerateIniFileExternalState_sec(number, ini_filename_with_path)
-- returns name of the numberth section in ini_filename_with_path or nil, if invalid
--[[
<ApiDocBlocFunc>
<slug>
EnumerateIniFileExternalState_sec
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string sectionname = ultraschall.EnumerateIniFileExternalState_sec(integer number_of_section, string ini_filename_with_path)
</functionname>
<description>
Returns the numberth section in an ini_filename_with_path.

Returns nil, in case of an error.
</description>
<retvals>
string sectionname - the name of the numberth section in the ini-file
</retvals>
<parameters>
integer number_of_section - the section within the ini-filename
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, get, section, enumerate, ini-files
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(number)==nil then return nil end
  local number=tonumber(number)
  if ini_filename_with_path==nil then return nil end
  if reaper.file_exists(ini_filename_with_path)==false then return nil end
  
  if number<=0 then return nil end
  if number>ultraschall.CountIniFileExternalState_sec(ini_filename_with_path) then return nil end
  
  local count=0
    for line in io.lines(ini_filename_with_path) do
      local check=line:match(".*=.*")
      if check==nil then count=count+1 end
      if count==number then return line:sub(2,-2) end
    end
end

--A=ultraschall.EnumerateIniFileExternalState_sec(1,"c:\\test.ini")

function ultraschall.EnumerateIniFileExternalState_key(section, number, ini_filename_with_path)
-- returns name of a numberth key within a section in ini_filename_with_path or nil if invalid or not existing
--[[
<ApiDocBlocFunc>
<slug>
EnumerateIniFileExternalState_key
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string keyname = ultraschall.EnumerateIniFileExternalState_key(string section, integer number, string ini_filename_with_path)
</functionname>
<description>
Returns the numberth key within a section in an ini_filename_with_path.

Returns nil, in case of an error.
</description>
<retvals>
string keyname - the name of the numberth key within section in the ini-file
</retvals>
<parameters>
string section - the name of the section
integer number - the number of the key within a section within the ini-filename
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, get, key, enumerate, ini-files
</tags>
</ApiDocBlocFunc>
]]

  if section==nil then return nil end
  if tonumber(number)==nil then return nil end
  number=tonumber(number)
  if ini_filename_with_path==nil then return nil end
  if reaper.file_exists(ini_filename_with_path)==false then return nil end

  local count=0
  local startcount=0
  
    for line in io.lines(ini_filename_with_path) do
     local check=line:match("%[.*.%]")
        if startcount==1 and line:match(".*=.*") then
        count=count+1
        if count==number then local temp=line:match(".*=") return temp:sub(1,-2) end
     else
        startcount=0
        if "["..section.."]" == check then startcount=1 end
        if check==nil then check="" end
    end

  end
  return nil
end


--A=ultraschall.EnumerateIniFileExternalState_key("hula","1","c:\\test.ini")

function ultraschall.CountSectionsByPattern(pattern, ini_filename_with_path)
--uses "pattern"-string to determine, how often a section with a certain pattern exists. Good for sections, that have a number in them, like
--[section1], [section2], [section3]
--returns the number of sections, that include that pattern as well as
--a string, that includes the names of all such sections, separated by a comma
--refer pattern-matching for lua for more details
--pattern - the pattern to look for. Is case-sensitive!

--[[
<ApiDocBlocFunc>
<slug>
CountSectionsByPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_of_sections, string sectionnames = ultraschall.CountSectionsByPattern(string pattern, string ini_filename_with_path)
</functionname>
<description>
Counts the number of sections within an ini-file, that fit a specific pattern.

Uses "pattern"-string to determine, how often a section with a certain pattern exists. Good for sections, that have a number in them, like [section1], [section2], [section3].
Returns the number of sections, that include that pattern as well as a string, that includes the names of all such sections, separated by a comma.

Pattern can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!

Returns -1, in case of an error.
</description>
<retvals>
integer number_of_sections - the number of sections, that fit the pattern
string sectionnames - a string, like: [section1],[section8],[section99]
</retvals>
<parameters>
string pattern - the pattern itself. Case sensitive.
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, count, sections, pattern, get, ini-files
</tags>
</ApiDocBlocFunc>
]]

  if pattern==nil then return -1 end
  if ini_filename_with_path==nil then return -1 end
  if reaper.file_exists(ini_filename_with_path)==false then return -1 end
  
  local count=0
  local sections=""
  for line in io.lines(ini_filename_with_path) do
    if line:match("%[.*"..pattern..".*%]") then count=count+1 sections=sections..line:match("(%[.*"..pattern..".*%])").."," end
  end
  return count, sections:sub(1,-2)
end

--A,AA=ultraschall.CountSectionsByPattern("","c:\\test.ini")

function ultraschall.CountKeysByPattern(pattern, ini_filename_with_path)
--uses "pattern"-string to determine, how often a key with a certain pattern exists. Good for keys, that have a number in them, like
--key1, key2, key3
--returns the number of sections, that include keys with that pattern as well as
--a string with all [sections] that contain keys= with a pattern, separated by a , i.e. [section1],key1=,key2=,key3=,[section2],key1,key4
--refer pattern-matching for lua for more details
--pattern - the pattern to look for

--[[
<ApiDocBlocFunc>
<slug>
CountKeysByPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_of_keys, string sections_and_keys = ultraschall.CountKeysByPattern(string pattern, string ini_filename_with_path)
</functionname>
<description>
Counts the number of keys within an ini-file, that fit a specific pattern.

Uses "pattern"-string to determine, how often a key with a certain pattern exists. Good for keys, that have a number in them, like key1, key2, key3.
Returns the number of keys, that include the pattern, as well as a string with all [sections] that contain keys= with a pattern, separated by a , i.e. [section1],key1=,key2=,key3=,[section2],key1=,key4=

Pattern can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!

Returns -1, in case of an error.
</description>
<retvals>
integer number_of_keys - the number of keys, that fit the pattern
string sections_and_keys - a string, like: [section1],Key1=,Key2=,Key3=[section2],Key7=
</retvals>
<parameters>
string pattern - the pattern itself. Case sensitive.
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, count, keys, pattern, get, ini-files
</tags>
</ApiDocBlocFunc>
]]

  if pattern==nil then return -1 end
  if ini_filename_with_path==nil then return -1 end
  if reaper.file_exists(ini_filename_with_path)==false then return -1 end
  
  local retpattern=""
  local count=0
  local tiff=0
  local temppattern=nil
  for line in io.lines(ini_filename_with_path) do
    if line:match("%[.*%]") then temppattern=line tiff=1 end--:match("%[(.*)%]") tiff=1 end-- reaper.MB(temppattern,"",0) end
    if line:match("%[.*%]")==nil and line:match(pattern..".*=") then count=count+1 
        if tiff==1 then retpattern=retpattern..temppattern.."," end 
        retpattern=retpattern..line:match(".*"..pattern..".*=")..","
        tiff=0 
    end
  end
  return count, retpattern:sub(1,-2)
end

--A,AA=ultraschall.CountKeysByPattern("","c:\\test.ini")


function ultraschall.CountValuesByPattern(pattern, ini_filename_with_path)
--uses "pattern"-string to determine, how often a value with a certain pattern exists. Good for values, that have a number in them, like
--value1, value2, value3
--returns the number of sections, that include that pattern as well as 
--a string, that contains the [sections] and the keys= that contain values that fit the pattern, separated by a comma
-- e.g. [section1], key1=, value, key4=, value, [section4], key2=, value
--refer pattern-matching for lua for more details
--pattern - the pattern to look for

--[[
<ApiDocBlocFunc>
<slug>
CountValuesByPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_of_keys, string sections_and_keys = ultraschall.CountValuesByPattern(string pattern, string ini_filename_with_path)
</functionname>
<description>
Counts the number of values within an ini-file, that fit a specific pattern.

Uses "pattern"-string to determine, how often a value with a certain pattern exists. Good for values, that have a number in them, like value1, value2, value3
Returns the number of values, that include that pattern as well as a string, that contains the [sections] and the keys= and values , the latter that contain the pattern, separated by a comma
 e.g. [section1], key1=, value, key4=, value, [section4], key2=, value

Pattern can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!

Returns -1, in case of an error.
</description>
<retvals>
integer number_of_values - the number of values, that fit the pattern
string sections_keys_values - a string, like: [section1],key1=,value,key4=,value,[section4],key2=,value
</retvals>
<parameters>
string pattern - the pattern itself. Case sensitive.
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, count, values, pattern, get, ini-files
</tags>
</ApiDocBlocFunc>
]]
  if pattern==nil then return -1 end
  if ini_filename_with_path==nil then return -1 end
  if reaper.file_exists(ini_filename_with_path)==false then return -1 end
  
  local retpattern=""
  local count=0
  local tiff=0
  local temppattern=nil
  for line in io.lines(ini_filename_with_path) do
    if line:match("%[.*%]") then temppattern=line tiff=1 end--:match("%[(.*)%]") tiff=1 end-- reaper.MB(temppattern,"",0) end
    if line:match("%[.*%]")==nil and line:match(".*=("..pattern..")") then count=count+1 
        if tiff==1 then retpattern=retpattern..temppattern.."," end 
        retpattern=retpattern..line:match(".*=")..","
        retpattern=retpattern..line:match(".*=("..pattern..")")..","
        tiff=0 
    end
  end
  return count, retpattern:sub(1,-2)
end

--A,AA=ultraschall.CountValuesByPattern("Mamula","c:\\test.ini")


function ultraschall.EnumerateSectionsByPattern(pattern, id, ini_filename_with_path)
--uses "pattern"-string to determine a section with a certain pattern. Good for sections, that have a number in them, like
--[section1], [section2], [section3]
--returns the full section-name of the "id"-th section, that fits the pattern description
--refer pattern-matching for lua for more details
--pattern - the pattern to look for
--id - the number of the section, that fits that pattern scheme

--[[
<ApiDocBlocFunc>
<slug>
EnumerateSectionsByPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string sectionname = ultraschall.EnumerateSectionsByPattern(string pattern, integer id, string ini_filename_with_path)
</functionname>
<description>
Returns the numberth section within an ini-file, that fits the pattern.

Uses "pattern"-string to determine if a section contains a certain pattern. Good for sections, that have a number in them, like section1, section2, section3
Returns the section that includes that pattern as a string, numbered by id.

Pattern can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!

Returns nil, in case of an error.
</description>
<retvals>
string sectionname - a string, that contains the sectionname
</retvals>
<parameters>
string pattern - the pattern itself. Case sensitive.
integer id - the number of section, that contains pattern
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, enumerate, section, pattern, get, ini-files
</tags>
</ApiDocBlocFunc>
]]
  if pattern==nil then return nil end
  if ini_filename_with_path==nil then return nil end
  if tonumber(id)==nil then return nil end
  id=tonumber(id)
  if reaper.file_exists(ini_filename_with_path)==false then return nil end
  
  local count=0
  for line in io.lines(ini_filename_with_path) do
    if line:match("%[.*"..pattern..".*%]") then count=count+1 end
    if count==id then return line:match("%[(.*"..pattern..".*)%]") end
  end
  return nil--count, sections:sub(1,-2)

end

--A,AA=ultraschall.EnumerateSectionsByPattern("hu",2,"c:\\test.ini")

function ultraschall.EnumerateKeysByPattern(pattern, section, id, ini_filename_with_path)
--uses "pattern"-string to determine, how often a key with a certain pattern exists. Good for keys, that have a number in them, like
--key1, key2, key3
--returns the full key-name of the "id"-th key, that fits the pattern description
--refer pattern-matching for lua for more details
--pattern - the pattern to look for
--section - the section, to where look for the key
--id - the number of the key, that fits that pattern scheme

--[[
<ApiDocBlocFunc>
<slug>
EnumerateKeysByPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string keyname = ultraschall.EnumerateKeysByPattern(string pattern, string section, integer id, string ini_filename_with_path)
</functionname>
<description>
Returns the numberth key within a section in an ini-file, that fits the pattern.

Uses "pattern"-string to determine if a key contains a certain pattern. Good for keys, that have a number in them, like key1=, key2=, key3=
Returns the key that includes that pattern as a string, numbered by id.

Pattern can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!

Returns nil, in case of an error.
</description>
<retvals>
string keyname - a string, that contains the keyname
</retvals>
<parameters>
string pattern - the pattern itself. Case sensitive.
string section - the section, in which to look for the key
integer id - the number of key, that contains pattern
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, ini-files, enumerate, section, key, pattern, get
</tags>
</ApiDocBlocFunc>
]]

  if pattern==nil then return nil end
  if section==nil then return nil end
  if ini_filename_with_path==nil then return nil end
  if tonumber(id)==nil then return nil end
  id=tonumber(id)
  if reaper.file_exists(ini_filename_with_path)==false then return nil end
  
  local count=0
  local tiff=0
  local temppattern=nil
  for line in io.lines(ini_filename_with_path) do
    if tiff==1 and line:match("%[.*%]")~=nil then return nil end
    if line:match(section) then temppattern=line tiff=1 end
    if tiff==1 and line:match(pattern..".*=") then count=count+1 
        if count==id then return line:match("(.*"..pattern..".*)=") end
    end
  end
end

--A=ultraschall.EnumerateKeysByPattern("l","hula",3,"c:\\test.ini")

function ultraschall.EnumerateValuesByPattern(pattern, section, id, ini_filename_with_path)
--uses "pattern"-string to determine, how often a value with a certain pattern exists. Good for values, that have a number in them, like
--values1, value2, value3
--returns the full value of the "id"-th value, that fits the pattern description
--refer pattern-matching for lua for more details
--pattern - the pattern to look for
--id - the number of the value, that fits that pattern scheme

--[[
<ApiDocBlocFunc>
<slug>
EnumerateValuesByPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string value, string keyname = ultraschall.EnumerateValuesByPattern(pattern, section, id, ini_filename_with_path)
</functionname>
<description>
Returns the numberth value(and it's accompanying key) within a section in an ini-file, that fits the pattern.

Uses "pattern"-string to determine if a value contains a certain pattern. Good for values, that have a number in them, like value1, value2, value3
Returns the value that includes that pattern as a string, numbered by id, as well as it's accompanying key.

Pattern can also contain patterns for pattern matching. Refer the LUA-docs for pattern matching.
i.e. characters like ^$()%.[]*+-? must be escaped with a %, means: %[%]%(%) etc
If you don't escape these characters and write a "malformed pattern" that way, it will show an error in the function!

Returns nil, in case of an error.
</description>
<retvals>
string value - the value that contains the pattern
string keyname - a string, that contains the keyname
</retvals>
<parameters>
string pattern - the pattern itself. Case sensitive.
string section - the section, in which to look for the key
integer id - the number of key, that contains pattern
string ini_filename_with_path - filename of the ini-file
</parameters>
<semanticcontext>
Configuration-Files Management
Ini-Files
</semanticcontext>
<tags>
configurationmanagement, ini-files, enumerate, section, key, value, pattern, get
</tags>
</ApiDocBlocFunc>
]]
  if pattern==nil then return nil end
  if section==nil then return nil end
  if tonumber(id)==nil then return nil end
  id=tonumber(id)
  if ini_filename_with_path==nil then return nil end
  if reaper.file_exists(ini_filename_with_path)==false then return nil end
  
  local count=0
  local tiff=0
  local temppattern=nil
  for line in io.lines(ini_filename_with_path) do
    if tiff==1 and line:match("%[.*%]")~=nil then return nil end
    if line:match(section) then temppattern=line tiff=1 end
    if tiff==1 and line:match("=.*"..pattern..".*") then count=count+1 
        if count==id then return line:match("=(.*"..pattern..".*)"), line:match("(.*)=.*"..pattern..".*") end
    end
  end

end

--A,AA=ultraschall.EnumerateValuesByPattern("l","l",1,"c:\\test.ini")


-------------------------------
---- Reaper.ini Management ----
-------------------------------

function ultraschall.GetSplitCrossFadeState_ReaperIni()
-- returns SplitCrossFadeStates, currently set in Reaper
-- see: Preferences->Media Item Defaults
--
-- returns
-- splitautoxfade -   0 - checkbox on:create automatic fadein/fadeout nor new items, length, Rest off
--                    1 - checkbox on: Overlap and crossfade items when splitting, length:
--                    2 - checkbox on: Enable automatic fadein/fadeout and autocrossfade for MIDI note velocity
--                    4 - (Editing Behavior->) Crossfades stay together during fade edits when trim content behind mediaitems is enabled
--                    8 - checkbox off: create automatic fadein/fadeout nor new items, length, Rest Off
--                   16 - checkbox on: Rightclick on crossfade sets fade shaper for only one side of the crossfade(shift toggles)
-- defsplitxfadelen - length of crossfade in seconds. If you split items, the left-hand item will be splittime+defsplitxfadelen
-- defxfadeshape - shape of the crossfade: 0 - 6
--[[
<ApiDocBlocFunc>
<slug>
GetSplitCrossFadeState_ReaperIni
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer splitautoxfade, integer defsplitxfadelen, integer defxfadeshape = ultraschall.GetSplitCrossFadeState_ReaperIni()
</functionname>
<description>
returns the states of splitautocrossfade, the length and the fadeshape, as set up in Preferences->Media Item Defaults and stored in the reaper.ini.
</description>
<retvals>
integer splitautoxfade - crossfade-state, bitmask
-0 - checkbox on:create automatic fadein/fadeout nor new items, length, Rest off
-1 - checkbox on: Overlap and crossfade items when splitting, length:
-2 - checkbox on: Enable automatic fadein/fadeout and autocrossfade for MIDI note velocity
-4 - (Editing Behavior->) Crossfades stay together during fade edits when trim content behind mediaitems is enabled
-8 - checkbox off: create automatic fadein/fadeout nor new items, length, Rest Off
-16 - checkbox on: Rightclick on crossfade sets fade shaper for only one side of the crossfade(shift toggles)

integer defsplitxfadelen - length of crossfade in seconds. If you split items, the left-hand item will be splittime+defsplitxfadelen
integer defxfadeshape - shape of the crossfade: 0 - 6
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper.Ini
</semanticcontext>
<tags>
Configurationmanagement, Reaper.ini, crossfade, state, get
</tags>
</ApiDocBlocFunc>
--]]
   __,a=ultraschall.GetIniFileExternalState("REAPER", "splitautoxfade", reaper.get_ini_file())
   __,b=ultraschall.GetIniFileExternalState("REAPER", "defsplitxfadelen", reaper.get_ini_file())
   __,c=ultraschall.GetIniFileExternalState("REAPER", "defxfadeshape", reaper.get_ini_file())
   return a,b,c
end

--A1,A2,A3=ultraschall.GetSplitCrossFadeState_ReaperIni()

---------------------------
---- Marker Management ----
---------------------------

function ultraschall.GetMarkerByScreenCoordinates(xmouseposition, retina)
--returns a string with the marker(s) in the timeline at given 
--screen-x-position. No Regions!
--string will be "Markeridx\npos\nName\nMarkeridx2\npos2\nName2"

--xmouseposition - x mouseposition
--retina - if it's retina/hiDPI, set it true, else, set it false

--[[
<ApiDocBlocFunc>
<slug>
GetMarkerByScreenCoordinates
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string marker = ultraschall.GetMarkerByScreenCoordinates(integer xmouseposition, boolean retina)
</functionname>
<description>
returns the markers at a given absolute-x-pixel-position. It sees markers according their graphical representation in the arrange-view, not just their position! Returned string will be "Markeridx\npos\nName\nMarkeridx2\npos2\nName2\n...".
Returns only markers, no time markers or regions!
</description>
<retvals>
string marker - a string with all markernumbers, markerpositions and markernames, separated by a newline. 
-Can contain numerous markers, if there are more markers in one position.
</retvals>
<parameters>
integer xmouseposition - the absolute x-screen-position, like current mouse-position
boolean retina - if the screen-resolution is retina or hidpi, turn this true, else false
</parameters>
<semanticcontext>
Markers
Assistance functions
</semanticcontext>
<tags>
markermanagement, navigation, get marker, position, marker
</tags>
</ApiDocBlocFunc>
]]

local one,two,three,four,five,six,seven,eight,nine,ten
if retina==false then
  ten=84
  nine=76
  eight=68
  seven=60
  six=52
  five=44
  four=36
  three=28
  two=20
  one=12
else
  ten=84*2
  nine=76*2
  eight=68*2
  seven=60*2
  six=52*2
  five=44*2
  four=36*2
  three=28*2
  two=20*2
  one=12*2
end
  local retstring=""
  local temp
  
  local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
  for i=0, retval do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, i)
    if isrgn==false then
      if markrgnindexnumber>999999999 then temp=ten
      elseif markrgnindexnumber>99999999 and markrgnindexnumber<1000000000  then temp=nine
      elseif markrgnindexnumber>9999999 and markrgnindexnumber<100000000 then temp=eight
      elseif markrgnindexnumber>999999 and markrgnindexnumber<10000000 then temp=seven
      elseif markrgnindexnumber>99999 and markrgnindexnumber<1000000 then temp=six
      elseif markrgnindexnumber>9999 and markrgnindexnumber<100000 then temp=five
      elseif markrgnindexnumber>999 and markrgnindexnumber<10000 then temp=four
      elseif markrgnindexnumber>99 and markrgnindexnumber<1000 then temp=three
      elseif markrgnindexnumber>9 and markrgnindexnumber<100 then temp=two
      elseif markrgnindexnumber>-1 and markrgnindexnumber<10 then temp=one
      end
    local Ax,AAx= reaper.GetSet_ArrangeView2(0, false, xmouseposition-temp,xmouseposition) 
local ALABAMA=xmouseposition
    if pos>=Ax and pos<=AAx then retstring=retstring..markrgnindexnumber.."\n"..pos.."\n"..name.."\n" end
    end
  end
  return retstring--:match("(.-)%c.-%c")), tonumber(retstring:match(".-%c(.-)%c")), retstring:match(".-%c.-%c(.*)")
end

--B=ultraschall.GetMarkerByScreenCoordinates(reaper.GetMousePosition(), false)

function ultraschall.GetMarkerByTime(position, retina)
--returns a string with the marker(s) at given timeline-position. No Regions!
--string will be "Markeridx\npos\nName\nMarkeridx2\npos2\nName2"

--position - position in time
--retina - if it's retina/hiDPI, set it true, else, set it false

--[[
<ApiDocBlocFunc>
<slug>
GetMarkerByTime
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string markers = ultraschall.GetMarkerByTime(number position, boolean retina)
</functionname>
<description>
returns the markers at a given absolute-x-pixel-position. It sees markers according their graphical representation in the arrange-view, not just their position! Returned string will be "Markeridx\npos\nName\nMarkeridx2\npos2\nName2\n...".
Returns only markers, no time markers or regions!
</description>
<retvals>
string marker - a string with all markernumbers, markerpositions and markernames, separated by a newline. 
-Can contain numerous markers, if there are more markers in one position.
</retvals>
<parameters>
number position - the time-position in seconds
boolean retina - if the screen-resolution is retina or hidpi, turn this true, else false
</parameters>
<semanticcontext>
Markers
Assistance functions
</semanticcontext>
<tags>
markermanagement, navigation, get marker, position, marker
</tags>
</ApiDocBlocFunc>
]]
local one,two,three,four,five,six,seven,eight,nine,ten
if retina==false then
  ten=84
  nine=76
  eight=68
  seven=60
  six=52
  five=44
  four=36
  three=28
  two=20
  one=12
else
  ten=84*2
  nine=76*2
  eight=68*2
  seven=60*2
  six=52*2
  five=44*2
  four=36*2
  three=28*2
  two=20*2
  one=12*2
end
  local retstring=""
  local temp
  
  local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
  for i=0, retval do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, i)
    if isrgn==false then
      if markrgnindexnumber>999999999 then temp=ten
      elseif markrgnindexnumber>99999999 and markrgnindexnumber<1000000000  then temp=nine
      elseif markrgnindexnumber>9999999 and markrgnindexnumber<100000000 then temp=eight
      elseif markrgnindexnumber>999999 and markrgnindexnumber<10000000 then temp=seven
      elseif markrgnindexnumber>99999 and markrgnindexnumber<1000000 then temp=six
      elseif markrgnindexnumber>9999 and markrgnindexnumber<100000 then temp=five
      elseif markrgnindexnumber>999 and markrgnindexnumber<10000 then temp=four
      elseif markrgnindexnumber>99 and markrgnindexnumber<1000 then temp=three
      elseif markrgnindexnumber>9 and markrgnindexnumber<100 then temp=two
      elseif markrgnindexnumber>-1 and markrgnindexnumber<10 then temp=one
      end
    local Aretval,ARetval2=reaper.BR_Win32_GetPrivateProfileString("REAPER", "leftpanewid", "", reaper.GetResourcePath()..ultraschall.Separator.."reaper.ini")
    local Ax,AAx= reaper.GetSet_ArrangeView2(0, false, ARetval2+57-temp,ARetval2+57) 
    local Bx=AAx-Ax
    if Bx+pos>=position and pos<=position then retstring=retstring..markrgnindexnumber.."\n"..pos.."\n"..name.."\n" end
    end
  end
  return retstring
end

--B=ultraschall.GetMarkerByTime(reaper.GetPlayPosition(), false)
--AAAA=GetMarkerByScreenCoordinates(reaper.GetMousePosition(), false)
--Aretval,ARetval2=reaper.BR_Win32_GetPrivateProfileString("REAPER", "leftpanewid", "", reaper.GetResourcePath().."\\reaper.ini")
--Ax,AAx= reaper.GetSet_ArrangeView2(0, false, ARetval2+57,ARetval2+57+84) 

--AAA=GetMarkerByTime(6475,false) --6476 in 6495
--Astart_time, Aend_time = reaper.GetSet_ArrangeView2(0, false, 0, 0)

function ultraschall.main()
Dx,Dy = reaper.GetMousePosition()
Gx,Gy=gfx.clienttoscreen(Dx,Dy)  
Hx,Ix= reaper.GetSet_ArrangeView2(0, false, Dx-84,Dx+84) --Das kann ich in Pixel umrechnen, da ich Mouse-und Time von Startposition habe und Bereich von Startarrange bis timposition DX
  
gfx.update()
--a,b,c,d,e,f,g,h,i=gfx.dock(-1,0,0,0,0)
--gfx.screentoclient(x,y)
reaper.defer(main)
end
--AA=reaper.GetResourcePath().."\\reaper.ini"
--HWND=reaper.GetMainHwnd()
--main()
--Aretval=reaper.BR_Win32_WritePrivateProfileString("REAPER", "wnd_w", "100", reaper.GetResourcePath().."\\reaper.ini")

function ultraschall.GetRegionByScreenCoordinates(xmouseposition, retina)
--returns a string with the marker(s) at given screen-x-position in the timeline. No Regions!
--string will be "Markeridx\npos\nName\nMarkeridx2\npos2\nName2"

--xmouseposition - x mouseposition
--retina - if it's retina/hiDPI, set it true, else, set it false

--[[
<ApiDocBlocFunc>
<slug>
GetRegionByScreenCoordinates
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string markers = ultraschall.GetRegionByScreenCoordinates(integer xmouseposition, boolean retina)
</functionname>
<description>
returns the regions at a given absolute-x-pixel-position. It sees regions according their graphical representation in the arrange-view, not just their position! Returned string will be "Regionidx\npos\nName\nRegionidx2\npos2\nName2\n...".
Returns only regions, no time markers or other markers!
</description>
<retvals>
string marker - a string with all regionnumbers, regionpositions and regionnames, separated by a newline. 
-Can contain numerous regions, if there are more regions in one position.
</retvals>
<parameters>
integer xmouseposition - the absolute x-screen-position, like current mouse-position
boolean retina - if the screen-resolution is retina or hidpi, turn this true, else false
</parameters>
<semanticcontext>
Markers
Assistance functions
</semanticcontext>
<tags>
markermanagement, navigation, get region, position, region
</tags>
</ApiDocBlocFunc>
]]

local one,two,three,four,five,six,seven,eight,nine,ten
if retina==false then
  ten=84
  nine=76
  eight=68
  seven=60
  six=52
  five=44
  four=36
  three=28
  two=20
  one=12
else
  ten=84*2
  nine=76*2
  eight=68*2
  seven=60*2
  six=52*2
  five=44*2
  four=36*2
  three=28*2
  two=20*2
  one=12*2
end
  local retstring=""
  local temp
  local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
  for i=0, retval do
local ALABAMA=xmouseposition
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, i)
    if isrgn==true then
      if markrgnindexnumber>999999999 then temp=ten
      elseif markrgnindexnumber>99999999 and markrgnindexnumber<1000000000  then temp=nine
      elseif markrgnindexnumber>9999999 and markrgnindexnumber<100000000 then temp=eight
      elseif markrgnindexnumber>999999 and markrgnindexnumber<10000000 then temp=seven
      elseif markrgnindexnumber>99999 and markrgnindexnumber<1000000 then temp=six
      elseif markrgnindexnumber>9999 and markrgnindexnumber<100000 then temp=five
      elseif markrgnindexnumber>999 and markrgnindexnumber<10000 then temp=four
      elseif markrgnindexnumber>99 and markrgnindexnumber<1000 then temp=three
      elseif markrgnindexnumber>9 and markrgnindexnumber<100 then temp=two
      elseif markrgnindexnumber>-1 and markrgnindexnumber<10 then temp=one
      end
    local Ax,AAx= reaper.GetSet_ArrangeView2(0, false, xmouseposition-temp,xmouseposition) 
    if pos>=Ax and pos<=AAx then retstring=retstring..markrgnindexnumber.."\n"..pos.."\n"..name.."\n" 
    elseif Ax>=pos and Ax<=rgnend then retstring=retstring..markrgnindexnumber.."\n"..pos.."\n"..name.."\n" 
    end
    end
  end
  return retstring
end

--A=ultraschall.GetRegionByScreenCoordinates(reaper.GetMousePosition(),false)

function ultraschall.GetRegionByTime(position, retina)
--returns a string with the marker(s) at given timeline-position. No Regions!
--string will be "Markeridx\npos\nName\nMarkeridx2\npos2\nName2"

--position - position in time
--retina - if it's retina/hiDPI, set it true, else, set it false

--[[
<ApiDocBlocFunc>
<slug>
GetRegionByTime
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string markers = ultraschall.GetRegionByTime(number position, boolean retina)
</functionname>
<description>
returns the regions at a given absolute-x-pixel-position. It sees regions according their graphical representation in the arrange-view, not just their position! Returned string will be "Regionidx\npos\nName\nRegionidx2\npos2\nName2\n...".
Returns only regions, no time markers or other markers!
</description>
<retvals>
string marker - a string with all regionnumbers, regionpositions and regionnames, separated by a newline. 
-Can contain numerous regions, if there are more regions in one position.
</retvals>
<parameters>
number position - position in seconds
boolean retina - if the screen-resolution is retina or hidpi, turn this true, else false
</parameters>
<semanticcontext>
Markers
Assistance functions
</semanticcontext>
<tags>
markermanagement, navigation, get region, position, region
</tags>
</ApiDocBlocFunc>
]]

local one,two,three,four,five,six,seven,eight,nine,ten
if retina==false then
  ten=84
  nine=76
  eight=68
  seven=60
  six=52
  five=44
  four=36
  three=28
  two=20
  one=12
else
  ten=84*2
  nine=76*2
  eight=68*2
  seven=60*2
  six=52*2
  five=44*2
  four=36*2
  three=28*2
  two=20*2
  one=12*2
end
  local retstring=""
  local temp
  local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
  for i=0, retval do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, i)
    if isrgn==true then
      if markrgnindexnumber>999999999 then temp=ten
      elseif markrgnindexnumber>99999999 and markrgnindexnumber<1000000000  then temp=nine
      elseif markrgnindexnumber>9999999 and markrgnindexnumber<100000000 then temp=eight
      elseif markrgnindexnumber>999999 and markrgnindexnumber<10000000 then temp=seven
      elseif markrgnindexnumber>99999 and markrgnindexnumber<1000000 then temp=six
      elseif markrgnindexnumber>9999 and markrgnindexnumber<100000 then temp=five
      elseif markrgnindexnumber>999 and markrgnindexnumber<10000 then temp=four
      elseif markrgnindexnumber>99 and markrgnindexnumber<1000 then temp=three
      elseif markrgnindexnumber>9 and markrgnindexnumber<100 then temp=two
      elseif markrgnindexnumber>-1 and markrgnindexnumber<10 then temp=one
      end
    local Aretval,ARetval2=reaper.BR_Win32_GetPrivateProfileString("REAPER", "leftpanewid", "", reaper.GetResourcePath()..ultraschall.Separator.."reaper.ini")
    local Ax,AAx= reaper.GetSet_ArrangeView2(0, false, ARetval2+57-temp,ARetval2+57) 
    local Bx=AAx-Ax
      if Bx+pos>=position and pos<=position then retstring=retstring..markrgnindexnumber.."\n"..pos.."\n"..name.."\n"
      elseif pos<=position and rgnend>=position then retstring=retstring..markrgnindexnumber.."\n"..pos.."\n"..name.."\n" 
      end
    end
  end
  return retstring
end
--mespotine
--A=ultraschall.GetRegionByTime(reaper.GetPlayPosition(), false)

function ultraschall.GetTimesignaturesByScreenCoordinates(xmouseposition, retina)
--returns a string with the marker(s) at given screen-x-position. No Regions!
--string will be "Markeridx\npos\nMarkeridx2\npos2\n"

--xmouseposition - x mouseposition
--retina - if it's retina/hiDPI, set it true, else, set it false

--[[
<ApiDocBlocFunc>
<slug>
GetTimesignaturesByScreenCoordinates
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string markers = ultraschall.GetTimesignaturesByScreenCoordinates(integer xmouseposition, boolean retina)
</functionname>
<description>
returns the time-signature/tempo-marker at a given absolute-x-pixel-position. It sees time-signature/tempo-markers according their graphical representation in the arrange-view, not just their position! Returned string will be "tempomarkeridx\npos\ntempomarkeridx2\npos2\n...".
Returns only time-signature-markers, no regions or other markers!
</description>
<retvals>
string marker - a string with all markernumbers and markerpositions, separated by a newline. 
-Can contain numerous markers, if there are more markers in one position.
</retvals>
<parameters>
integer xmouseposition - the absolute x-screen-position, like current mouse-position
boolean retina - if the screen-resolution is retina or hidpi, turn this true, else false
</parameters>
<semanticcontext>
Markers
Assistance functions
</semanticcontext>
<tags>
markermanagement, navigation, get region, position, time signature, tempo, marker, tempo marker
</tags>
</ApiDocBlocFunc>
]]

local one,two,three,four,five,six,seven,eight,nine,ten
if retina==false then
  ten=84
  nine=76
  eight=68
  seven=60
  six=52
  five=44
  four=36
  three=28
  two=20
  one=12
else
  ten=84*2
  nine=76*2
  eight=68*2
  seven=60*2
  six=52*2
  five=44*2
  four=36*2
  three=28*2
  two=20*2
  one=12*2
end
  local retstring=""
  local temp
  
  local timeretval = reaper.CountTempoTimeSigMarkers(0)
  for i=0, timeretval-1 do
    local retval, timepos, measurepos, beatpos, bpm, timesig_num, timesig_denom, lineartempo = reaper.GetTempoTimeSigMarker(0, i)
    temp=one
    
    local Ax,AAx= reaper.GetSet_ArrangeView2(0, false, xmouseposition-temp,xmouseposition) 
local ALABAMA=xmouseposition
    if timepos>=Ax and timepos<=AAx then retstring=retstring..i.."\n"..timepos.."\n" end
  end
  return retstring
end

--A=ultraschall.GetTimesignaturesByScreenCoordinates(reaper.GetMousePosition(),false)

function ultraschall.GetTimeSignaturesByTime(position, retina)
--returns a string with the marker(s) at given position. No Regions!
--string will be "Markeridx\npos\nName\nMarkeridx2\npos2\nName2"

--position - position in time
--retina - if it's retina/hiDPI, set it true, else, set it false

--[[
<ApiDocBlocFunc>
<slug>
GetTimeSignaturesByTime
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string markers = ultraschall.GetTimeSignaturesByTime(number position, boolean retina)
</functionname>
<description>
returns the time-signature/tempo-marker at a given absolute-x-pixel-position. It sees time-signature/tempo-markers according their graphical representation in the arrange-view, not just their position! Returned string will be "tempomarkeridx\npos\ntempomarkeridx2\npos2\n...".
Returns only time-signature-markers, no other markers or regions!
</description>
<retvals>
string marker - a string with all markernumbers and markerpositions, separated by a newline. 
-Can contain numerous markers, if there are more markers in one position.
</retvals>
<parameters>
number position - position in seconds
boolean retina - if the screen-resolution is retina or hidpi, turn this true, else false
</parameters>
<semanticcontext>
Markers
Assistance functions
</semanticcontext>
<tags>
markermanagement, navigation, get region, position, time signature, tempo, marker, tempo marker
</tags>
</ApiDocBlocFunc>
]]
local one,two,three,four,five,six,seven,eight,nine,ten
if retina==false then
  ten=84
  nine=76
  eight=68
  seven=60
  six=52
  five=44
  four=36
  three=28
  two=20
  one=12
else
  ten=84*2
  nine=76*2
  eight=68*2
  seven=60*2
  six=52*2
  five=44*2
  four=36*2
  three=28*2
  two=20*2
  one=12*2
end
  local retstring=""
  local temp
  
  local timeretval = reaper.CountTempoTimeSigMarkers(0)
  for i=0, timeretval-1 do
    local retval, timepos, measurepos, beatpos, bpm, timesig_num, timesig_denom, lineartempo = reaper.GetTempoTimeSigMarker(0, i)
    temp=one    
    local Aretval,ARetval2=reaper.BR_Win32_GetPrivateProfileString("REAPER", "leftpanewid", "", reaper.GetResourcePath()..ultraschall.Separator.."reaper.ini")
    local Ax,AAx= reaper.GetSet_ArrangeView2(0, false, ARetval2+57-temp,ARetval2+57) 
    local Bx=AAx-Ax
    if Bx+timepos>=position and timepos<=position then retstring=retstring..i.."\n"..timepos.."\n" end
  end
  return retstring
end

--A=ultraschall.GetTimeSignaturesByTime(reaper.GetPlayPosition(),false)
--A,AA=GetRegionByTime(16.269,false)


function ultraschall.IsMarkerShownote(markerid)
--checks, if a marker is an _Shownote:-Marker
--returns true or false
--returns nil, if markerid isn't valid
  if tonumber(markerid)==nil then return nil end
  markerid=tonumber(markerid)
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, markerid)
    if retval>0 then
      if isrgn==false then
        if name:sub(1, 10)=="_Shownote:" then return true      
        else return false
        end
      end
    end
    return false
end

--A=ultraschall.IsMarkerShownote(99)

function ultraschall.IsMarkerEdit(markerid)
--checks, if a marker is an _Edit:-Marker
--returns true or false
--returns nil, if markerid isn't valid

--[[
<ApiDocBlocFunc>
<slug>
IsMarkerEdit
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.IsMarkerEdit(integer markerid)
</functionname>
<description>
returns true, if the marker is an edit-marker, false if not. Returns nil, if markerid is invalid.
Markerid is the marker-number for all markers, as used by marker-functions from Reaper.
</description>
<retvals>
boolean retval - true, if it's an edit-marker, false if not
</retvals>
<parameters>
integer markerid - the markerid of all markers in the project, beginning with 0 for the first marker
</parameters>
<semanticcontext>
Markers
Checking Markers
</semanticcontext>
<tags>
markermanagement, navigation, check, edit marker, edit
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(markerid)==nil then return nil end
  markerid=tonumber(markerid)
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, markerid)
    if retval>0 then
      if isrgn==false then
        if name:sub(1, 6)=="_Edit:" then return true      
        else return false
        end
      end
    end
    return false
end

--A=ultraschall.IsMarkerEdit(1)

function ultraschall.IsMarkerChapter(markerid)
--checks, if a marker is a _Chapter:-Marker
--returns true or false
--returns nil, if markerid isn't valid
--[[
<ApiDocBlocFunc>
<slug>
IsMarkerChapter
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.IsMarkerChapter(integer markerid)
</functionname>
<description>
returns true, if the marker is a chapter-marker, false if not. Returns nil, if markerid is invalid.
Markerid is the marker-number for all markers, as used by marker-functions from Reaper.
</description>
<retvals>
boolean retval - true, if it's an chapter-marker, false if not
</retvals>
<parameters>
integer markerid - the markerid of all markers in the project, beginning with 0 for the first marker
</parameters>
<semanticcontext>
Markers
Checking Markers
</semanticcontext>
<tags>
markermanagement, navigation, check, chapter marker, chapter
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(markerid)==nil then return nil end
  markerid=tonumber(markerid)
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, markerid)
    if retval>0 then
      if isrgn==false then
        if name:sub(1, 9)=="_Chapter:" then return true      
        else return false
        end
      end
    end
    return false
end

--A=ultraschall.IsMarkerChapter(0)

function ultraschall.IsMarkerDummy(markerid)
--checks, if a marker is a _Dummy:-Marker
--returns true or false
--returns nil, if markerid isn't valid
--[[
<ApiDocBlocFunc>
<slug>
IsMarkerDummy
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.IsMarkerDummy(integer markerid)
</functionname>
<description>
returns true, if the marker is a dummy-marker, false if not. Returns nil, if markerid is invalid.
Markerid is the marker-number for all markers, as used by marker-functions from Reaper.
</description>
<retvals>
boolean retval - true, if it's a dummy-marker, false if not
</retvals>
<parameters>
integer markerid - the markerid of all markers in the project, beginning with 0 for the first marker
</parameters>
<semanticcontext>
Markers
Checking Markers
</semanticcontext>
<tags>
markermanagement, navigation, check, dummy marker, dummy
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(markerid)==nil then return nil end
  markerid=tonumber(markerid)
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, markerid)
    if retval>0 then
      if isrgn==false then
       if name:sub(1, 7)=="_Dummy:" then return true      
        else return false
        end
      end
    end
    return false
end

--A=ultraschall.IsMarkerDummy(0)

function ultraschall.IsMarkerNormal(markerid)
--checks, if a marker is a Normal-Marker
--returns true or false
--returns nil, if markerid isn't valid
--[[
<ApiDocBlocFunc>
<slug>
IsMarkerNormal
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.IsMarkerNormal(integer markerid)
</functionname>
<description>
returns true, if the marker is a normal-marker, false if not. Returns nil, if markerid is invalid.
Markerid is the marker-number for all markers, as used by marker-functions from Reaper.
</description>
<retvals>
boolean retval - true, if it's an normal-marker, false if not
</retvals>
<parameters>
integer markerid - the markerid of all markers in the project, beginning with 0 for the first marker
</parameters>
<semanticcontext>
Markers
Checking Markers
</semanticcontext>
<tags>
markermanagement, navigation, check, normal marker, normal
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(markerid)==nil then return nil end
  markerid=tonumber(markerid)
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, markerid)
    if retval>0 then
      if isrgn==false then
        if name:sub(1, 7)~="_Dummy:" and name:sub(1, 9)~="_Chapter:" and name:sub(1,10)~="_Shownote:" and name:sub(1,6)~="_Edit:" and name:sub(1,10)~="_LiveEdit:" then return true      
        else return false
        end
      end
    end
    return false
end

--A=ultraschall.IsMarkerNormal(0)

function ultraschall.IsRegionPodrange(markerid)
--checks, if a marker is a _PodRange:-Region
--returns true or false
--returns nil, if markerid isn't valid
--[[
<ApiDocBlocFunc>
<slug>
IsRegionPodrange
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.IsRegionPodrange(integer markerid)
</functionname>
<description>
returns true, if the marker is a Podrange-region, false if not. Returns nil, if markerid is invalid.
Markerid is the marker-number for all markers, as used by marker-functions from Reaper.
</description>
<retvals>
boolean retval - true, if it's a PodRange-Region, false if not
</retvals>
<parameters>
integer markerid - the markerid of all markers in the project, beginning with 0 for the first marker
</parameters>
<semanticcontext>
Markers
Checking Markers
</semanticcontext>
<tags>
markermanagement, navigation, check, podrangeregion, podrange, region
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(markerid)==nil then return nil end
  markerid=tonumber(markerid)
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, markerid)
    if retval>0 then
      if isrgn==true then
       if name:sub(1, 10)=="_PodRange:" then return true      
        else return false
        end
      end
    end
    return false
end

--A=ultraschall.IsRegionPodrange(1)

function ultraschall.IsRegionEditRegion(markerid)
--checks, if a marker is an _Edit:-Region
--returns true or false
--returns nil, if markerid isn't valid
--[[
<ApiDocBlocFunc>
<slug>
IsRegionEditRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.IsRegionEditRegion(integer markerid)
</functionname>
<description>
returns true, if the marker is an Edit-region, false if not. Returns nil, if markerid is invalid.
Markerid is the marker-number for all markers, as used by marker-functions from Reaper.
</description>
<retvals>
boolean retval - true, if it's an Edit-Region, false if not
</retvals>
<parameters>
integer markerid - the markerid of all markers in the project, beginning with 0 for the first marker
</parameters>
<semanticcontext>
Markers
Checking Markers
</semanticcontext>
<tags>
markermanagement, navigation, check, edit region, edit, region
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(markerid)==nil then return nil end
  markerid=tonumber(markerid)
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, markerid)
    if retval>0 then
      if isrgn==true then
       if name:sub(1, 6)=="_Edit:" then return true      
        else return false
        end
      end
    end
    return false
end

--A=ultraschall.IsRegionEditRegion(6)

----------------------
---- Edit Regions ----
----------------------

function ultraschall.AddEditRegion(startposition, endposition, text)
--[[
<ApiDocBlocFunc>
<slug>
AddEditRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer markernr = ultraschall.AddEditRegion(number startposition, number endposition, string text)
</functionname>
<description>
Adds a new edit-region and returns index of the newly created edit-marker-region.

</description>
<retvals>
integer markernr - the number of the newly created region
</retvals>
<parameters>
number startposition - startposition in seconds
number endposition - endposition in seconds
string text - the title of the marker
</parameters>
<semanticcontext>
Markers
Adding Markers
</semanticcontext>
<tags>
markermanagement, navigation, add, edit region, edit, region
</tags>
</ApiDocBlocFunc>
]]
  local color=0
  local retval=0
  local isrgn=true
  local pos=0
  local rgnend=0
  local name=""
  local markrgnindexnumber=""
  local noteID=0
  
   os = reaper.GetOS()
   if string.match(os, "OSX") then 
     color = 0xFF0000|0x1000000
   else
     color = 0x0000FF|0x1000000
   end
  
    local a,nummarkers,numregions=reaper.CountProjectMarkers(0)
    local count=0
    startposition=tonumber(startposition)
    endposition=tonumber(endposition)
    if startposition==nil then return -1 end
    if endposition==nil then return -1 end
    if startposition<0 then return -1 end
    if endposition<startposition then return -1 end
    
    noteID=reaper.AddProjectMarker2(0, 1, startposition, endposition, "_Edit:"..text, 0, color)
  
  return noteID
end

--A=ultraschall.AddEditRegion(23,26,"testofon2")

function ultraschall.SetEditRegion(number, position, endposition, edittitle)
--[[
<ApiDocBlocFunc>
<slug>
SetEditRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.SetEditRegion(integer number, number position, number endposition, string edittitle)
</functionname>
<description>
Sets the values of an already existing edit-region. To retain an already set position, endposition and/or edittitle, use nil.
Returns true in case of success, false if not.
Note: if you set the new beginning of the region before another region, the indexnumber of the edit-region changes. So if you want to set an edit-region repeatedly, you should get the indexnumber using <a href="#EnumerateEditRegion">ultraschall.EnumerateEditRegion</a>, or you might accidently change another region!
</description>
<retvals>
boolean retval - true, in case of success, false if not
</retvals>
<parameters>
integer number - the number of the edit-region, beginning with 1 for the first edit-region
number startposition - startposition in seconds, nil to retain the old value
number endposition - endposition in seconds, nil to retain the old value
string text - the title of the marker, nil to retain the old value
</parameters>
<semanticcontext>
Markers
Setting Markers
</semanticcontext>
<tags>
markermanagement, navigation, set, edit region, edit, region
</tags>
</ApiDocBlocFunc>
]]
local color=0
  os = reaper.GetOS()
    if string.match(os, "OSX") then 
      color = 0xFF0000|0x1000000
    else
      color = 0x0000FF|0x1000000
    end
  
  local shown_number=-1 
  if tonumber(position)==nil then position=-1 end
  if tonumber(position)<0 then position=-1 end
  if tonumber(endposition)==nil then endposition=-1 end
  if tonumber(endposition)<0 then endposition=-1 end
  if tonumber(number)==nil then return false end
  
  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)-1
  local wentfine=0
  local count=-1
  local retnumber=0
  for i=0, c-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if isrgn==true then
      if name:sub(1,6)=="_Edit:" then count=count+1 end 
      if number>=0 and wentfine==0 and count==number then 
          if tonumber(position)==-1 or position==nil then position=pos end
          if tonumber(endposition)==-1 or position==nil then endposition=rgnend end
          if tonumber(shown_number)<=-1 or shown_number==nil then shown_number=markrgnindexnumber end
          if edittitle==nil then edittitle=name:match("(_Edit:.*)") edittitle=edittitle:sub(7,-1) end
          retnumber=i
          wentfine=1
      end
      end
  end
  
  if edittitle==nil then edittitle="" end
  
  if wentfine==1 then return reaper.SetProjectMarkerByIndex(0, retnumber, true, position, endposition, shown_number, "_Edit:" .. edittitle, color)
  else return false
  end
end

--A=ultraschall.SetEditRegion(2,1,nil,"hula")

function ultraschall.DeleteEditRegion(number)
--[[
<ApiDocBlocFunc>
<slug>
DeleteEditRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.DeleteEditRegion(integer number)
</functionname>
<description>
Deletes an already existing edit-region.
Returns true in case of success, false if not.
</description>
<retvals>
boolean retval - true, in case of success, false if not
</retvals>
<parameters>
integer number - the number of the edit-region, beginning with 1 for the first edit-region
</parameters>
<semanticcontext>
Markers
Deleting Markers
</semanticcontext>
<tags>
markermanagement, navigation, delete, edit region, edit, region
</tags>
</ApiDocBlocFunc>
]]   
  if tonumber(number)==nil then return false end
  
  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  local number=tonumber(number)-1
  local wentfine=0
  local count=-1
  local retnumber=-1
  for i=0, c-1 do
     local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if isrgn==true then
      if name:sub(1,6)=="_Edit:" then count=count+1 
        if count==number then retnumber=i end
      end 
      end
  end
  
  return reaper.DeleteProjectMarkerByIndex(0, retnumber)
  
end

--A=ultraschall.DeleteEditRegion(1)

function ultraschall.EnumerateEditRegion(number)
--[[
<ApiDocBlocFunc>
<slug>
EnumerateEditRegion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval, number position, number endposition, string title, integer rgnindexnumber = ultraschall.EnumerateEditRegion(integer number)
</functionname>
<description>
Returns the values of an edit-region.
</description>
<retvals>
integer retval - the overall marker-index-number of all markers in the project, -1 in case of error
number position - position in seconds
number endposition - endposition in seconds
string title - the title of the region
integer rgnindexnumber - the overall region index number, as used by other of Reaper's own marker-functions
</retvals>
<parameters>
integer number - the number of the edit-region, beginning with 1 for the first edit-region
</parameters>
<semanticcontext>
Markers
Enumerating and Getting Markerdata
</semanticcontext>
<tags>
markermanagement, navigation, get, enumerate, edit region, edit, region
</tags>
</ApiDocBlocFunc>
]]   
  if tonumber(number)==nil then return false end
  
  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  number=tonumber(number)-1
  local wentfine=-1
  local count=-1
  local retnumber=0
  for i=0, c-1 do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if isrgn==true then
      if name:sub(1,6)=="_Edit:" then count=count+1  
        if count==number then wentfine=i end
      end
      end
  end
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber=reaper.EnumProjectMarkers(wentfine)
    if wentfine~=-1 then return retval, pos, rgnend, name, markrgnindexnumber
    else return -1
    end
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.EnumerateEditRegion(1)


function ultraschall.CountEditRegions()
--[[
<ApiDocBlocFunc>
<slug>
CountEditRegions
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.CountEditRegions()
</functionname>
<description>
returns the number of edit-regions in the project.
</description>
<retvals>
integer retval - the number of edit-regions in the project
</retvals>
<semanticcontext>
Markers
Counting Markers
</semanticcontext>
<tags>
markermanagement, navigation, count, edit region, edit, region
</tags>
</ApiDocBlocFunc>
]]  
  local c,nummarkers,b=reaper.CountProjectMarkers(0)
  local count=0
  for i=0, c do
    local retval, isrgn, pos, rgnend, name, markrgnindexnumber = reaper.EnumProjectMarkers(i)
    if isrgn==true then
      if name:sub(1,6)=="_Edit:" then count=count+1 end 
      end
  end
  return count
end


--AA=ultraschall.CountEditRegions()

---------------------------
---- kb-ini management ----
---------------------------

--[[ Eventuell kannste das Aktualisieren der reaper-kb.ini hiermit erzwingen?
integer reaper.AddRemoveReaScript(boolean add, integer sectionID, string scriptfn, boolean commit)

Add a ReaScript (return the new command ID, or 0 if failed) or remove a ReaScript (return >0 on success). 
Use commit==true when adding/removing a single script. When bulk adding/removing n scripts, you can optimize 
the n-1 first calls with commit==false and commit==true for the last call.

Leider nein, nur das hinzufügen der neu reingebauten Scripts :(
--]]

--integer=reaper.AddRemoveReaScript(true, 0, reaper.GetResourcePath().."\\Scripts\\hula.lua", true)

function ultraschall.GetKBIniFilepath()
  -- returns file with path to the reaper-kb.ini-file

--[[
<ApiDocBlocFunc>
<slug>
GetKBIniFilepath
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string kb_ini_path = ultraschall.GetKBIniFilepath()
</functionname>
<description>
Returns the path and filename of the Reaper-kb.ini-file.
</description>
<retvals>
string kb_ini_path - path and filename of the reaper-kb.ini
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, get
</tags>
</ApiDocBlocFunc>
]]  
  return reaper.GetResourcePath()..ultraschall.Separator.."reaper-kb.ini"
end

--AA=ultraschall.GetKBIniFilepath()

function ultraschall.CountKBIniActions(filename_with_path)

--[[
<ApiDocBlocFunc>
<slug>
CountKBIniActions
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer actions = ultraschall.CountKBIniActions(string filename_with_path)
</functionname>
<description>
Count the number of "ACT"-Actions of the Reaper-kb.ini-file.
Returns -1, if no such file exists.
</description>
<parameter>
string filename_with_path - path and filename of the reaper-kb.ini
</parameter>
<retvals>
integer actions - number of actions in the reaper-kb.ini
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, count, actions, action
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path==nil then return -1 end
  if reaper.file_exists(filename_with_path)==false then return -1 end
  local count=0
    for line in io.lines(filename_with_path) do 
      if line:sub(1,3)=="ACT" then 
      count=count+1
      end
    end
  if count>0 then return count
  else return -1
  end
end

--AAAAA=ultraschall.CountKBIniActions("c:\\test.txt")

function ultraschall.CountKBIniScripts(filename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
CountKBIniScripts
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer scripts = ultraschall.CountKBIniScripts(string filename_with_path)
</functionname>
<description>
Count the number of "SCR"-Scripts of the Reaper-kb.ini-file.
Returns -1, if no such file exists.
</description>
<parameter>
string filename_with_path - path and filename of the reaper-kb.ini
</parameter>
<retvals>
integer scripts - number of scripts in the reaper-kb.ini
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, count, scripts, script
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path==nil then return -1 end
  if reaper.file_exists(filename_with_path)==false then return -1 end
  local count=0
    for line in io.lines(filename_with_path) do 
      if line:sub(1,3)=="SCR" then 
      count=count+1
      end
    end
  if count>0 then return count
  else return -1
  end
end

--AAAAA=ultraschall.CountKBIniScripts("c:\\test.txt")

function ultraschall.CountKBIniKeys(filename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
CountKBIniKeys
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer keys = ultraschall.CountKBIniKeys(string filename_with_path)
</functionname>
<description>
Count the number of "KEY"-Keybindings of the Reaper-kb.ini-file.
Returns -1, if no such file exists.
</description>
<parameter>
string filename_with_path - path and filename of the reaper-kb.ini
</parameter>
<retvals>
integer keys - number of keys in the reaper-kb.ini
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, count, keys, key
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path==nil then return -1 end
  if reaper.file_exists(filename_with_path)==false then return -1 end
  local count=0
    for line in io.lines(filename_with_path) do 
      if line:sub(1,3)=="KEY" then 
      count=count+1
      end
    end
  if count>0 then return count
  else return -1
  end
end

--AAAAA=ultraschall.CountKBIniKeys("c:\\test.txt")


function ultraschall.GetKBIniActions(filename_with_path, idx)
-- returns integer consolidate, integer section, string ActionCommandID, string Description, string ActionsToBeExecuted
-- returns -1 if no such Action exist or filename/idx is invalid

--[[
<ApiDocBlocFunc>
<slug>
GetKBIniActions
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer consolidate, integer section, string ActionCommandID, string description, string ActionsToBeExecuted = ultraschall.GetKBIniActions(string filename_with_path, integer idx)
</functionname>
<description>
Get the states of "ACT"-Action number idx. Returns consolidate, section, ActionCommandID, description, ActionsToBeExecuted.
Returns -1, if no such entry or file exists.
</description>
<parameters>
string filename_with_path - path and filename of the reaper-kb.ini
integer idx - the number of the action to get, beginning with 1 for the first one
</parameters>
<retvals>
integer consolidate - consolidate-state
-1 consolidate undo points, 
-2 show in Actions-Menu, 
-3 consolidate undo points AND show in Actions Menu; 
-maybe 4 and higher?

integer section - the section, in which this action is executed
-0 - Main
-1 - action stays invisible but is kept, if Reaper rewrites the reaper-kb.ini. Menu-buttons with this action associated appear but don't work.
-100 - Main (alt recording)
-32060 - MIDI Editor
-32061 - MIDI Event List Editor
-32062 - MIDI Inline Editor
-32063 - Media Explorer

string ActionCommandID - the ActionCommandID given to this Action
string description - the description of this action
string ActionsToBeExecuted - the actions that are run, the ActionCommandIDs beginning with _, multiple ActionCommandIDs are separated by whitespaces
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, get, actions, action
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path == nil then return -1 end
  if reaper.file_exists(filename_with_path)==false then return -1 end
  if tonumber(idx)==nil then return -1 end
  idx=tonumber(idx)
  if reaper.file_exists(filename_with_path)==false then return -1 end
  local count=0
  for line in io.lines(filename_with_path) do 
    if line:sub(1,3)=="ACT" then count=count+1 
      if count==idx then 
      return tonumber(line:match("%s(.-)%s")), -- consolidate
         tonumber(line:match("%s.-%s(.-)%s")), -- section
         line:match("%s.-%s.-%s(.-)%s"), -- ActionCommandID
         line:match("%s.-%s.-%s.-%s\"(.-)\"%s"), -- Description
         line:match("%s.-%s.-%s.-%s\".-\"%s(.*)") -- Actions
      end
    end
  end
  return -1
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.GetKBIniActions("c:\\test.txt",35)

function ultraschall.GetKBIniScripts(filename_with_path, idx)
-- returns integer terminateinstance, integer section, string ActionCommandID, string Description, string Scriptfile
-- returns -1 if no such Script exist or filename/idx is invalid

--[[
<ApiDocBlocFunc>
<slug>
GetKBIniScripts
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer terminateinstance, integer section, string ActionCommandID, string description, string scriptfile = ultraschall.GetKBIniScripts(string filename_with_path, integer idx)
</functionname>
<description>
Get the states of "SCR"-Scripts number idx. Returns terminateinstance, section, ActionCommandID, description, scriptfile.
Returns -1, if no such entry or file exists.
</description>
<parameters>
string filename_with_path - path and filename of the reaper-kb.ini
integer idx - the number of the action to get, beginning with 1 for the first one
</parameters>
<retvals>
integer terminateinstance - the state of terminating instances
-4 - Dialogwindow appears(Terminate, New Instance, Abort), if another instance of a given script is started, that's already running
-260 - always Terminate Instances, when an instance of the script is already running
-516 - always start a New Instance of the script already running

integer section - the section, in which this action is executed
-0 - Main
-1 - action stays invisible but is kept, if Reaper rewrites the reaper-kb.ini. Menu-buttons with this action associated appear but don't work.
-100 - Main (alt recording)
-32060 - MIDI Editor
-32061 - MIDI Event List Editor
-32062 - MIDI Inline Editor
-32063 - Media Explorer

string ActionCommandID - the ActionCommandID given to this Action
string description - the description of this action
string scriptfile - the filename of the script that shall be run
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, get, scripts, script
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path == nil then return -1 end
  if reaper.file_exists(filename_with_path)==false then return -1 end
  if tonumber(idx)==nil then return -1 end
  idx=tonumber(idx)
  if reaper.file_exists(filename_with_path)==false then return -1 end
  local count=0
  for line in io.lines(filename_with_path) do 
    if line:sub(1,3)=="SCR" then count=count+1 
      if count==idx then 
      return tonumber(line:match("%s(.-)%s")), 
             tonumber(line:match("%s.-%s(.-)%s")),
             line:match("%s.-%s.-%s(.-)%s"), -- ActionCommandID
             line:match("%s.-%s.-%s.-%s\"(.-)\"%s"),
             line:match("%s.-%s.-%s.-%s\".-\"%s(.*)")
      end
    end
  end
  return -1
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.GetKBIniScripts(ultraschall.GetKBIniFilepath(),165)

function ultraschall.GetKBIniKeys(filename_with_path, idx)
-- returns integer Keytype/Modifier/MidiChannel, integer Key/MidiNote, string ActionCommandID, integer section
-- returns -1 if no such Script exist or filename/idx is invalid

--[[
<ApiDocBlocFunc>
<slug>
GetKBIniKeys
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer keytype_modifier_midichan, integer key_midinote, string ActionCommandID, integer section = ultraschall.GetKBIniKeys(string filename_with_path, integer idx)
</functionname>
<description>
Get the states of "KEY"-Keybinding-number idx, for MIDI/Key-bindings. Returns keytype_modifier_midichan, key_midinote, ActionCommandID, section.
Returns -1, if no such entry or file exists.
Doesn't return OSC-bindings!
</description>
<parameters>
string filename_with_path - path and filename of the reaper-kb.ini
integer idx - the number of the action to get, beginning with 1 for the first one
</parameters>
<retvals>
integer keytype_modifier_midichan - Type of Keytype, modifier or midichannel
-Shortcut Type (0-255, will repeat-> 256=0, 257=1, 260=5(Shift), 264=9(Ctrl or CMD)
-0 - Single Key(i.e . + or F18), makes Letters to Shift+Letter
-1 - Single Key(i.e Q)
-4 - Shift (allows no Shift+Space, why? Other differences to 5?)
-5 - Shift -> mostly used by Reaper (allows Shift+Space, why?)
-...
-9 - Ctrl or CMD
-13 - Ctrl+Shift  or CMD+Shift
-17 - Alt
-21 - Alt+Shift
-25 - Ctrl+Alt or CMD+Alt
-...
-143 - MIDI 8f 01 00
-144 - Midi Channel 1
-145 - Midi Channel 2
-176 - Midi Channel 1 CC 1
-191 - Midi Channel 16 CC1
-192 - Midi Channel 1 PC 1
-207 - Midi Channel 16 PC 1
-208 - MIDI d0 01 00
-209 - MIDI d1 01 00
-...
-254 - Midi fe 7b 01
-255 - Control+Alt+Mouswheel

integer key_midinote - the key(like ASCII-Codes) or midinote. Both will be repeating after 256 (Space=32, as well as 288(256+32).
-8 - Backspace
-13 - Enter
-...
-32 - Space (Shortcut Type 1, if single key)
-43 - + (Shortcut Type 0, if single key)
-46 - . (Shortcut Type 0, if single key)
-...
-65 - A
-77 - M (Shortcut Type 1, if single key)
-87 - W (Shortcut Type 1, if single key)
-90 - Z
-91 - cursor down (Shortcut Type 0, if single key)
-...

-Midi Notes: 
-       beginning with 0 (for note 0) going up to 127. 128 will be Note 0 again, up until 255, 256 will be note 0 again, etc etc.

string ActionCommandID - the ActionCommandID associated with this shortcut.
integer section - the section, in which this shortcut is used
-0 - Main
-100 - Main (alt recording)
-32060 - MIDI Editor
-32061 - MIDI Event List Editor
-32062 - MIDI Inline Editor
-32063 - Media Explorer
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, get, keys, key
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path == nil then return -1 end
  if reaper.file_exists(filename_with_path)==false then return -1 end
  if tonumber(idx)==nil then return -1 end
  idx=tonumber(idx)
  if reaper.file_exists(filename_with_path)==false then return -1 end
  local count=0
  for line in io.lines(filename_with_path) do 
    if line:sub(1,3)=="KEY" then count=count+1 
      if count==idx then 
      return tonumber(line:match("%s(.-)%s")), 
             tonumber(line:match("%s.-%s(.-)%s")),
             line:match("%s.-%s.-%s(.-)%s"),
             tonumber(line:match("%s.-%s.-%s.-%s(.*)"))
      end
    end
  end
  return -1
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.GetKBIniKeys(ultraschall.GetKBIniFilepath(),103)

function ultraschall.GetKBIniActionsID_ByActionCommandID(filename_with_path, ActionCommandID)
-- returns the idx(s) of an Action with a given ActionCommandID 
-- return false, if not existing
--[[
<ApiDocBlocFunc>
<slug>
GetKBIniActionsID_ByActionCommandID
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string retval = ultraschall.GetKBIniActionsID_ByActionCommandID(filename_with_path, ActionCommandID)
</functionname>
<description>
Returns the indexnumber(s) of actions by ActionCommandIDs within a reaper-kb.ini.
Returns -1, if no such entry or file exists.
</description>
<parameters>
string filename_with_path - path and filename of the reaper-kb.ini
string ActionCommandID - the ActionCommandID
</parameters>
<retvals>
string retval - the ids of actions with ActionCommandID, separated by a ,
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, get, actions, action
</tags>
</ApiDocBlocFunc>
]]  
  if reaper.file_exists(filename_with_path)==false then return nil end
local idx_string=""
local consolidate, section, AID, Description, ActionsToBeExecuted
  for i=1, ultraschall.CountKBIniActions(filename_with_path)-1 do
    consolidate, section, AID, Description, ActionsToBeExecuted=ultraschall.GetKBIniActions(filename_with_path,i)
    if AID:sub(1,1)=="\"" then AID=AID:sub(2,-1) end
    if AID:sub(-1,-1)=="\"" then AID=AID:sub(1,-2) end
    if ActionCommandID==AID then idx_string=idx_string..i.."," end
  end
  return idx_string:sub(1,-2)
end

--A=ultraschall.GetKBIniActions_ByActionCommandID("c:\\test.txt","Ultraschall_ZoomToSelection",0)

function ultraschall.GetKBIniScripts_ByActionCommandID(filename_with_path, ActionCommandID)
-- returns the idx(s) of a script with a given ActionCommandID
-- return false, if not existing
--[[
<ApiDocBlocFunc>
<slug>
GetKBIniScripts_ByActionCommandID
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string retval = ultraschall.GetKBIniScripts_ByActionCommandID(filename_with_path, ActionCommandID)
</functionname>
<description>
Returns the indexnumber(s) of scripts by ActionCommandIDs within a reaper-kb.ini.
Returns -1, if no such entry or file exists.
</description>
<parameters>
string filename_with_path - path and filename of the reaper-kb.ini
string ActionCommandID - the ActionCommandID
</parameters>
<retvals>
string retval - the ids of scripts with ActionCommandID, separated by a ,
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, get, scripts, script
</tags>
</ApiDocBlocFunc>
]]  
  if reaper.file_exists(filename_with_path)==false then return nil end
local idx_string=""
local consolidate, section, AID, Description, ScriptFile
  for i=1, ultraschall.CountKBIniScripts(filename_with_path)-1 do
    consolidate, section, AID, Description, ScriptFile=ultraschall.GetKBIniScripts(filename_with_path,i)
    if AID:sub(1,1)=="\"" then AID=AID:sub(2,-1) end
    if AID:sub(-1,-1)=="\"" then AID=AID:sub(1,-2) end
    if ActionCommandID==AID then idx_string=idx_string..i.."," end
  end
  return idx_string:sub(1,-2)
end

--A=ultraschall.GetKBIniScripts_ByActionCommandID("c:\\test.txt", "Haselnuss") --

function ultraschall.GetKBIniKeys_ByActionCommandID(filename_with_path, ActionCommandID)
-- returns the idx(s) of a key with a given ActionCommandID
-- return false, if not existing
--[[
<ApiDocBlocFunc>
<slug>
GetKBIniKeys_ByActionCommandID
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string retval = ultraschall.GetKBIniKeys_ByActionCommandID(filename_with_path, ActionCommandID)
</functionname>
<description>
Returns the indexnumber(s) of keys by ActionCommandIDs within a reaper-kb.ini.
Returns -1, if no such entry or file exists.
</description>
<parameters>
string filename_with_path - path and filename of the reaper-kb.ini
string ActionCommandID - the ActionCommandID
</parameters>
<retvals>
string retval - the ids of keys with ActionCommandID, separated by a ,
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, get, keys, key
</tags>
</ApiDocBlocFunc>
]]  
  if reaper.file_exists(filename_with_path)==false then return nil end
local idx_string=""
local Keytype, KeyNote, AID, section
  for i=1, ultraschall.CountKBIniKeys(filename_with_path)-1 do
    Keytype, KeyNote, AID, section=ultraschall.GetKBIniKeys(filename_with_path,i)
    if AID:sub(1,1)=="\"" then AID=AID:sub(2,-1) end
    if AID:sub(-1,-1)=="\"" then AID=AID:sub(1,-2) end
    if ActionCommandID==AID then idx_string=idx_string..i.."," end
  end
  return idx_string:sub(1,-2)
end

--A=ultraschall.GetKBIniKeys_ByActionCommandID("c:\\test.txt","40626")

function ultraschall.SetKBIniActions(filename_with_path, consolidate, section, ActionCommandID, Description, ActionCommandIDs, replace)
-- adds/sets existing Actions
-- integer consolidate - 
-- integer section - 
-- string ActionCommandID - the ActionCommandID for this Action
-- string Description - the description as shown in the "Show Actions List"-window
-- string ActionCommandIDs - the Action-CommandIDs that shall be executed, when calling this action. Each ActioncommandID separated by a space.
-- boolean replace - true - replace an "old" Action with this new one, false - keep the "old" Action

--returns false if file does not exist, invalid parameters or the first "ActionCommandID"-parameter starts with an _

--[[
<ApiDocBlocFunc>
<slug>
SetKBIniActions
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval, integer actionnumber = ultraschall.SetKBIniActions(string filename_with_path, integer consolidate, integer section, string ActionCommandID, string Description, string ActionCommandIDs, boolean replace)
</functionname>
<description>
Adds or sets(if it already exists) an "ACT"-action of a reaper-kb.ini.
Returns true/false when adding or setting worked/didn't work, as well as the action-number within the reaper-kb.ini

Needs a restart of Reaper for this change to take effect!
</description>
<parameters>
string filename_with_path - filename with path for the reaper-kb.ini
integer consolidate - consolidation state of this action
-1 consolidate undo points, 
-2 show in Actions-Menu, 
-3 consolidate undo points AND show in Actions Menu; 
-maybe 4 and higher?

integer section - section, in which this action is started
-0 - Main
-1 - action stays invisible but is kept, if Reaper rewrites the reaper-kb.ini. Menu-buttons with this action associated appear but don't work.
-100 - Main (alt recording)
-32060 - MIDI Editor
-32061 - MIDI Event List Editor
-32062 - MIDI Inline Editor
-32063 - Media Explorer

string ActionCommandID - the ActionCommandID of this action
string Description - a description for this action
string ActionCommandIDs - the ActionCommandIDs for the actions, that are triggered by this action; unlike CommandID-numbers, every ActionCommandID must begin with _
boolean replace - true if an already existing entry shall be replaced, false if not
</parameters>
<retvals>
boolean retval - true, if adding/setting worked, false if it didn't
integer actionnumber - the entrynumber within the reaper-kb.ini of this action
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, add, set, replace, action, actions
</tags>
</ApiDocBlocFunc>
]]  

  if filename_with_path == nil then return false end
  if reaper.file_exists(filename_with_path)==false then return false end
  if tonumber(consolidate)==nil then return false end 
  consolidate=tonumber(consolidate)
  if tonumber(section)==nil then return false end 
  section=tonumber(section)
  if ActionCommandID==nil or ActionCommandID:sub(1,1)=="_" then return false end
  if Description==nil then return false end
  if ActionCommandIDs==nil then return false end
  local FirstKBFilePath=nil
  local LastKBFilePath=nil
  local newfile=nil
  local count=0
  local finalcountdown=-1
  local checkstring1="ACT "..consolidate.." "..section.." \""..ActionCommandID.."\" \""..Description.."\" "..ActionCommandIDs
  local checkstring2="ACT %d- "..section.." \""..ActionCommandID
  local A,B,C=ultraschall.ReadValueFromFile(filename_with_path, checkstring2)
  if A~="" and replace==true then 
  if tonumber(B:match("(%d*)"))==nil then return false end
    FirstKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, 1, tonumber(B:match("(%d*)")-1))
    LastKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, tonumber(B:match("(%d*)")+1), ultraschall.CountLinesInFile(filename_with_path))
    newfile=FirstKBFilePath..checkstring1.."\n"..LastKBFilePath
    ultraschall.WriteValueToFile(filename_with_path,newfile)
  for line in io.lines(filename_with_path) do 
    if line:sub(1,3)=="ACT" then 
    count=count+1
    if line:match(checkstring1) then finalcountdown=count end
    end
  end
    return true, finalcountdown
  elseif A=="" then
    local A2,B,C2=ultraschall.ReadValueFromFile(filename_with_path, "KEY %d- %d-.*")
    if tonumber(B:match("(%d*)"))==nil then return false end
    FirstKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, 1, tonumber(B:match("(%d*)")-1))
    LastKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, tonumber(B:match("(%d*)")), ultraschall.CountLinesInFile(filename_with_path))
    newfile=FirstKBFilePath..checkstring1.."\n"..LastKBFilePath    
    ultraschall.WriteValueToFile(filename_with_path,newfile)
    for line in io.lines(filename_with_path) do 
      if line:sub(1,3)=="ACT" then 
      count=count+1
      if line:match(checkstring1) then finalcountdown=count end
      end
    end
    return true, finalcountdown
  end
  return false
end
--ACT 0 0 "9859d0c7f8dd418bb56a41f242ea92c1"
--AA,BB=ultraschall.SetKBIniActions("c:\\test.txt",3,2,"ATest","Atest2: hullebull","_one _tw", true)
--AA,BB=ultraschall.SetKBIniActions("c:\\test.txt",1,2,"ATest","Description","_one", true)

function ultraschall.SetKBIniScripts(filename_with_path, terminate, section, ActionCommandID, Description, Scriptname, replace)
--adds/sets existing Scripts
--[[
<ApiDocBlocFunc>
<slug>
SetKBIniScripts
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval, integer scriptnumber = ultraschall.SetKBIniScripts(string filename_with_path, integer terminate, integer section, string ActionCommandID, string Description, string Scriptname, boolean replace)
</functionname>
<description>
Adds or sets(if it already exists) an "SCR"-script of a reaper-kb.ini.
Returns true/false when adding or setting worked/didn't work, as well as the script-number within the reaper-kb.ini

Needs a restart of Reaper for this change to take effect!
</description>
<parameters>
string filename_with_path - filename with path for the reaper-kb.ini
integer terminate_state - state of handling mulitple running scripts
-4 - Dialogwindow appears(Terminate, New Instance, Abort), if another instance of a given script is started, that's already running
-260 - always Terminate Instances, when an instance of the script is already running
-516 - always start a New Instance of the script already running

integer section - section, in which this script is started
-0 - Main
-1 - action stays invisible but is kept, if Reaper rewrites the reaper-kb.ini. Menu-buttons with this action associated appear but don't work.
-100 - Main (alt recording)
-32060 - MIDI Editor
-32061 - MIDI Event List Editor
-32062 - MIDI Inline Editor
-32063 - Media Explorer

string ActionCommandID - the ActionCommandID of this action
string Description - a description for this script
string Scriptname - the name of the ReaScript, like .lua or .eel or .py
boolean replace - true if an already existing entry shall be replaced, false if not
</parameters>
<retvals>
boolean retval - true, if adding/setting worked, false if it didn't
integer scriptnumber - the entrynumber within the reaper-kb.ini of this script
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, add, set, script, scripts, replace
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path == nil then return false end
  if reaper.file_exists(filename_with_path)==false then return false end
  if tonumber(terminate)==nil then return false end 
  terminate=tonumber(terminate)
  if tonumber(section)==nil then return false end 
  section=tonumber(section)
  if ActionCommandID==nil or ActionCommandID:sub(1,1)=="_" then return false end
  if Description==nil then return false end
  if Scriptname==nil then return false end
  local FirstKBFilePath=nil
  local LastKBFilePath=nil
  local newfile=nil
  local count=0
  local finalcountdown=-1
  local checkstring1="SCR "..terminate.." "..section.." \""..ActionCommandID.."\" \""..Description.."\" "..Scriptname
  local checkstring2="SCR %d- "..section.." \""..ActionCommandID
  local A,B,C=ultraschall.ReadValueFromFile(filename_with_path, checkstring2)
  if A~="" and replace==true then 
  if tonumber(B:match("(%d*)"))==nil then return false end
    FirstKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, 1, tonumber(B:match("(%d*)")-1))
    LastKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, tonumber(B:match("(%d*)")+1), ultraschall.CountLinesInFile(filename_with_path))
    newfile=FirstKBFilePath..checkstring1.."\n"..LastKBFilePath
    ultraschall.WriteValueToFile(filename_with_path,newfile)
  for line in io.lines(filename_with_path) do 
    if line:sub(1,3)=="SCR" then 
    count=count+1
    if line:match(checkstring1) then finalcountdown=count end
    end
  end
    return true, finalcountdown
  elseif A=="" then
    local A2,B,C2=ultraschall.ReadValueFromFile(filename_with_path, "KEY %d- %d-.*")
    if tonumber(B:match("(%d*)"))==nil then return false end
    FirstKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, 1, tonumber(B:match("(%d*)")-1))
    LastKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, tonumber(B:match("(%d*)")), ultraschall.CountLinesInFile(filename_with_path))
    newfile=FirstKBFilePath..checkstring1.."\n"..LastKBFilePath    
    ultraschall.WriteValueToFile(filename_with_path,newfile)
    for line in io.lines(filename_with_path) do 
      if line:sub(1,3)=="SCR" then 
      count=count+1
      if line:match(checkstring1) then finalcountdown=count end
      end
    end
    return true, finalcountdown
  end
  return false
end

--AA,BB=ultraschall.SetKBIniScripts("c:\\test.txt", 42, 1207, "Haselnussa", "musmusmus", "Hula.luaa", false)
--

function ultraschall.SetKBIniKeys(filename_with_path, KeyType, KeyNote, ActionCommandID, section, replace)
--adds/sets existing Keybinds
--returns false, if it doesn't work or you forgot the _ at the beginning of the ActionCommandID
--
-- string filename_with_path - filename to the kb.ini-file
-- integer KeyType - Keytype/Modifier/Midichannel
-- integer KeyNote - Key(in ASCII) or MidiNote
-- string ActionCommand - the _ActionCommandID, with which the key shall be bound. Must have a _ at the beginning!
-- integer section - section, in where this keybind shall work
--[[
<ApiDocBlocFunc>
<slug>
SetKBIniKeys
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval, integer keynumber = ultraschall.SetKBIniKeys(string filename_with_path, integer keytype_modifier_midichan, integer key_midinote, string ActionCommandID, integer section, boolean replace)
</functionname>
<description>
Adds or sets(if it already exists) a "KEY"-key of a reaper-kb.ini.
Returns true/false when adding or setting worked/didn't work, as well as the keybinding-number within the reaper-kb.ini.
Additional keybindings cannot share the same keytype_modifier_midichan, key_midinote and section at the same time, as every such keybind must be unique.

Does not support OSC-keybinds!

Needs a restart of Reaper for this change to take effect!
</description>
<parameters>
string filename_with_path - filename with path for the reaper-kb.ini
integer keytype_modifier_midichan - Type of Keytype, modifier or midichannel
-Shortcut Type (0-255, will repeat-> 256=0, 257=1, 260=5(Shift), 264=9(Ctrl or CMD)
-0 - Single Key(i.e . + or F18), makes Letters to Shift+Letter
-1 - Single Key(i.e Q)
-4 - Shift (allows no Shift+Space, why? Other differences to 5?)
-5 - Shift -> mostly used by Reaper (allows Shift+Space, why?)
-...
-9 - Ctrl or CMD
-13 - Ctrl+Shift  or CMD+Shift
-17 - Alt
-21 - Alt+Shift
-25 - Ctrl+Alt or CMD+Alt
-...
-143 - MIDI 8f 01 00
-144 - Midi Channel 1
-145 - Midi Channel 2
-176 - Midi Channel 1 CC 1
-191 - Midi Channel 16 CC1
-192 - Midi Channel 1 PC 1
-207 - Midi Channel 16 PC 1
-208 - MIDI d0 01 00
-209 - MIDI d1 01 00
-...
-254 - Midi fe 7b 01
-255 - Control+Alt+Mouswheel

integer key_midinote - the key(like ASCII-Codes) or midinote. Both will be repeating after 256 (Space=32, as well as 288(256+32).
-8 - Backspace
-13 - Enter
-...
-32 - Space (Shortcut Type 1, if single key)
-43 - + (Shortcut Type 0, if single key)
-46 - . (Shortcut Type 0, if single key)
-...
-65 - A
-77 - M (Shortcut Type 1, if single key)
-87 - W (Shortcut Type 1, if single key)
-90 - Z
-91 - cursor down (Shortcut Type 0, if single key)
-...

-Midi Notes: 
-       beginning with 0 (for note 0) going up to 127. 128 will be Note 0 again, up until 255, 256 will be note 0 again, etc etc.

string ActionCommandID - the ActionCommandID associated with this shortcut.
integer section - the section, in which this shortcut is used
-0 - Main
-100 - Main (alt recording)
-32060 - MIDI Editor
-32061 - MIDI Event List Editor
-32062 - MIDI Inline Editor
-32063 - Media Explorer

boolean replace - true if an already existing entry shall be replaced, false if not
</parameters>
<retvals>
boolean retval - true, if adding/setting worked, false if it didn't
integer scriptnumber - the entrynumber within the reaper-kb.ini of this script
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, add, set, key, keys, replace
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path == nil then return false end
  if reaper.file_exists(filename_with_path)==false then return false end
  if tonumber(KeyType)==nil then return false end 
  KeyType=tonumber(KeyType)
  if tonumber(KeyNote)==nil then return false end 
  KeyNote=tonumber(KeyNote)
  if ActionCommandID==nil or ActionCommandID:sub(1,1)~="_" then return false end
  if tonumber(section)==nil then return false end 
  section=tonumber(section)
--  local replace=true

  local FirstKBFilePath=nil
  local LastKBFilePath=nil
  local newfile=nil
  local count=0
  local finalcountdown=-1
  local checkstring1="KEY "..KeyType.." "..KeyNote.." \""..ActionCommandID.."\" "..section
  local checkstringA="KEY "..KeyType.." "..KeyNote
  local A,B,C=ultraschall.ReadValueFromFile(filename_with_path, checkstringA..".-"..section)
  --HULA=A:match(checkstringA..".-"..section)
--  if HULA~=nil and replace==false then return false end
  if A~="" and replace==true then 
  if tonumber(B:match("(%d*)"))==nil then return false end
    FirstKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, 1, tonumber(B:match("(%d*)")-1))
    LastKBFilePath=ultraschall.ReadLinerangeFromFile(filename_with_path, tonumber(B:match("(%d*)")+1), ultraschall.CountLinesInFile(filename_with_path))
    newfile=FirstKBFilePath..checkstring1.."\n"..LastKBFilePath
    ultraschall.WriteValueToFile(filename_with_path,newfile)
  for line in io.lines(filename_with_path) do 
    if line:sub(1,3)=="KEY" then 
    count=count+1
    if line:match(checkstring1) then finalcountdown=count end
    end
  end
    return true, finalcountdown
  elseif A=="" then
    FirstKBFilePath=ultraschall.ReadValueFromFile(filename_with_path, nil)
    newfile=FirstKBFilePath..checkstring1.."\n"
    ultraschall.WriteValueToFile(filename_with_path,newfile)
    for line in io.lines(filename_with_path) do
      if line:sub(1,3)=="KEY" then 
      count=count+1
      if line:match(checkstring1) then finalcountdown=count end
      end
    end
    return true, finalcountdown
  end
  --]]
  return false
end

--AAA,BB=ultraschall.SetKBIniKeys("c:\\test.txt",110,110,"_Hulababula",101, true)
--AAA,BB=ultraschall.SetKBIniKeys("c:\\test.txt",110,110,"_Hulababula",101, true)

function ultraschall.DeleteKBIniActions(filename_with_path, idx)
--deletes the idx'th ACT-Action in the kb.ini-file
--returns false, if something went wrong, true in case of success
--string filename_with_path - the kb.ini-file with path
--integer idx - the ACT-Action entry-number, you'd like to delete
--[[
<ApiDocBlocFunc>
<slug>
DeleteKBIniActions
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.DeleteKBIniActions(string filename_with_path, integer idx)
</functionname>
<description>
Deletes an "ACT"-action of a reaper-kb.ini.
Returns true/false when deleting worked/didn't work.

Needs a restart of Reaper for this change to take effect!
</description>
<parameters>
string filename_with_path - filename with path for the reaper-kb.ini
integer idx - indexnumber of the action within the reaper-kb.ini
</parameters>
<retvals>
boolean retval - true, if deleting worked, false if it didn't
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, delete, action, actions
</tags>
</ApiDocBlocFunc>
]]  
  if filename_with_path==nil then return false end
  if tonumber(idx)==nil then return false end
  idx=tonumber(idx)
  local count=0
  local linecount=0
  local finallinecount=-1
  if reaper.file_exists(filename_with_path)==false then return false end
    for line in io.lines(filename_with_path) do 
    linecount=linecount+1
      if line:sub(1,3)=="ACT" then 
      count=count+1
        if count==idx then finallinecount=linecount end
      end
    end
  if finallinecount>-1 then 
    local FirstPart=ultraschall.ReadLinerangeFromFile(filename_with_path, 1, finallinecount-1)
    local LastPart=ultraschall.ReadLinerangeFromFile(filename_with_path, finallinecount+1,  ultraschall.CountLinesInFile(filename_with_path))
    ultraschall.WriteValueToFile(filename_with_path,FirstPart..LastPart)
    return true
  else 
    return false
  end
end

--A=ultraschall.DeleteKBIniActions(nil,"1")

function ultraschall.DeleteKBIniScripts(filename_with_path, idx)
--deletes the idx'th SCR-Script in the kb.ini-file
--returns false, if something went wrong, true in case of success
--string filename_with_path - the kb.ini-file with path
--integer idx - the SCR-Script entry-number, you'd like to delete
--[[
<ApiDocBlocFunc>
<slug>
DeleteKBIniScripts
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.DeleteKBIniScripts(string filename_with_path, integer idx)
</functionname>
<description>
Deletes an "SCR"-script of a reaper-kb.ini.
Returns true/false when deleting worked/didn't work.

Needs a restart of Reaper for this change to take effect!
</description>
<parameters>
string filename_with_path - filename with path for the reaper-kb.ini
integer idx - indexnumber of the script within the reaper-kb.ini
</parameters>
<retvals>
boolean retval - true, if deleting worked, false if it didn't
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, delete, script, scripts
</tags>
</ApiDocBlocFunc>
]]
  if filename_with_path==nil then return false end
  if tonumber(idx)==nil then return false end
  idx=tonumber(idx)
  local count=0
  local linecount=0
  local finallinecount=-1
  if reaper.file_exists(filename_with_path)==false then return false end
    for line in io.lines(filename_with_path) do 
    linecount=linecount+1
      if line:sub(1,3)=="SCR" then 
      count=count+1
        if count==idx then finallinecount=linecount end
      end
    end
  if finallinecount>-1 then 
    local FirstPart=ultraschall.ReadLinerangeFromFile(filename_with_path, 1, finallinecount-1)
    local LastPart=ultraschall.ReadLinerangeFromFile(filename_with_path, finallinecount+1,  ultraschall.CountLinesInFile(filename_with_path))
    ultraschall.WriteValueToFile(filename_with_path,FirstPart..LastPart)
    return true
  else 
    return false
  end
end

--A=ultraschall.DeleteKBIniScripts("c:\\test.txt",1)

function ultraschall.DeleteKBIniKeys(filename_with_path, idx)
--deletes the idx'th KEY-bind in the kb.ini-file
--returns false, if something went wrong, true in case of success
--string filename_with_path - the kb.ini-file with path
--integer idx - the KEY-bind entry-number, you'd like to delete
--[[
<ApiDocBlocFunc>
<slug>
DeleteKBIniKeys
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.DeleteKBIniKeys(string filename_with_path, integer idx)
</functionname>
<description>
Deletes a "KEY"-keybinding of a reaper-kb.ini.
Returns true/false when deleting worked/didn't work.

Needs a restart of Reaper for this change to take effect!
</description>
<parameters>
string filename_with_path - filename with path for the reaper-kb.ini
integer idx - indexnumber of the keybinding within the reaper-kb.ini
</parameters>
<retvals>
boolean retval - true, if deleting worked, false if it didn't
</retvals>
<semanticcontext>
Configuration-Files Management
Reaper-KB.ini
</semanticcontext>
<tags>
configurationmanagement, reaper-kb.ini, kb.ini, keybindings, delete, key, keys, keybind
</tags>
</ApiDocBlocFunc>
]]
  if filename_with_path==nil then return false end
  if tonumber(idx)==nil then return false end
  idx=tonumber(idx)
  local count=0
  local linecount=0
  local finallinecount=-1
  if reaper.file_exists(filename_with_path)==false then return false end
    for line in io.lines(filename_with_path) do 
    linecount=linecount+1
      if line:sub(1,3)=="KEY" then 
      count=count+1
        if count==idx then finallinecount=linecount end
      end
    end
  if finallinecount>-1 then 
    local FirstPart=ultraschall.ReadLinerangeFromFile(filename_with_path, 1, finallinecount-1)
    local LastPart=ultraschall.ReadLinerangeFromFile(filename_with_path, finallinecount+1,  ultraschall.CountLinesInFile(filename_with_path))
    ultraschall.WriteValueToFile(filename_with_path,FirstPart..LastPart)
    return true
  else 
    return false
  end
end

--A=ultraschall.DeleteKBIniKeys("c:\\test.txt",1)

----------------------------------------
---- copy n paste from to clipboard ----
----------------------------------------

-- Clipboard management for Windows and Mac
-- it uses Command-Line functions to get/put values from/to the clipboard
--
-- thanks to Udo Sauer for providing the information-links to the Mac-Side of things


function ultraschall.PutStringToClipboard(Value)
--[[
<ApiDocBlocFunc>
<slug>
PutStringToClipboard
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.PutStringToClipboard(string value)
</functionname>
<description>
Put the string value to the system's-clipboard. Supports UTF-8. Works on Mac and Windows.
</description>
<parameters>
string value - an UTF-8 encoded string, you want to put to the clipboard. Can contain \n.
</parameters>
<semanticcontext>
Clipboard Functions
</semanticcontext>
<tags>
copy and paste, clipboard
</tags>
</ApiDocBlocFunc>
]]


 -- Paste Value to the Clipboard

  --The Windows Side of things
  if reaper.GetOS()=="Win64" or reaper.GetOS()=="Win32" then
    local info = debug.getinfo(1,'S');
    local Path = info.source:match[[^@?(.*[\/])[^\/]-$]]
    local A=ultraschall.WriteValueToFile(Path.."\\temp.temp", Value)
    local AA=ultraschall.WriteValueToFile(Path.."\\Toclip.bat", "%SystemRoot%\\syswow64\\chcp.com 65001\ntype "..Path.."\\temp.temp | clip", false)
    --Atest=reaper.BR_Win32_ShellExecute("", "Toclip.bat", "", Path, 1000) 
    local BA=reaper.ExecProcess(Path.."\\Toclip.bat",1000)
    os.remove(Path.."\\temp.temp")
    os.remove(Path.."\\Toclip.bat")
  end 

  -- The Mac Side of things (experimental)
  if reaper.GetOS()=="OSX64" or reaper.GetOS()=="OSX32" then
    AA=reaper.ExecProcess("/bin/sh -c \"echo -n '"..Value.."' | pbcopy\"",1000)
  end

end


function ultraschall.GetStringFromClipboard()
--[[
<ApiDocBlocFunc>
<slug>
GetStringFromClipboard
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string value = ultraschall.GetStringFromClipboard()
</functionname>
<description>
Get the content from the clipboard and put it into the string value. Supports UTF-8. Works on Mac and Windows.
</description>
<retvals>
string value - an UTF-8 encoded string, you got from the clipboard. Can contain \n.
</retvals>
<semanticcontext>
Clipboard Functions
</semanticcontext>
<tags>
copy and paste, clipboard
</tags>
</ApiDocBlocFunc>
]]
 -- Get Value From the Clipboard

  --The Windows Side of things
  local clipboard=nil
  if reaper.GetOS()=="Win64" or reaper.GetOS()=="Win32" then
--  reaper.MB(content,"",0)
    local info = debug.getinfo(1,'S');
    local Path = info.source:match[[^@?(.*[\/])[^\/]-$]]
    local content="@echo off\n%SystemRoot%\\syswow64\\chcp.com 65001>temp.temp\n"..Path.."\\paste.exe"
    ultraschall.WriteValueToFile(Path.."\\FromClip.bat", content, false)
    local AA=reaper.ExecProcess(Path.."FromClip.bat",1000)
    clipboard=AA:match(".-%c(.*)")               -- getting rid of the first return-value, returned by the ExecProcess-Function
    os.remove(Path.."\\temp.temp")
    os.remove(Path.."\\Fromclip.bat")
  end 

 -- The Mac Side of things (experimental)
  if reaper.GetOS()=="OSX64" or reaper.GetOS()=="OSX32" then
    AA=reaper.ExecProcess("/bin/csh -c \"/usr/bin/env LC_CTYPE=UTF-8 /usr/bin/pbpaste\"",1000)
    clipboard=AA:match(".-%c(.*)") -- getting rid of the first return-value, returned by the ExecProcess-Function
  end
  return clipboard
end


--Rin ins Clipboard
--PasteValue="ActionIfWeGonnaMakeItLikeATrueSurvivor"
--ultraschall.PutToClipboard(PasteValue)

--Raus ausm Clipboard
--GetValue2=ultraschall.GetFromClipboard()
--ultraschall.PutToClipboard(GetValue2)



---------------------------------------
---- Reaper RPP-Project-management ----
---------------------------------------

--- Get ---
function ultraschall.GetProject_ReaperVersion(projectfilename_with_path)
-- return Reaper-Version and TimeStamp
--[[
<ApiDocBlocFunc>
<slug>
GetProject_ReaperVersion
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string reaperversion, string timestamp = ultraschall.GetProject_ReaperVersion(string projectfilename_with_path)
</functionname>
<description>
Returns the reaperversion and the timestamp from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path for the reaper-kb.ini
</parameters>
<retvals>
string reaperversion - the version of Reaper, with which this project had been saved
string timestamp - a timestamp for this project
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, reaperversion, timestamp
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local projectnr=file:match("REAPER_PROJECT%s.-%s\"(.-)\"")
  local projectid=file:match("REAPER_PROJECT.-\"%s(.-)%c")
  return projectnr, projectid
end

--A,AA=ultraschall.GetProject_ReaperVersion("c:\\tt.rpp")

function ultraschall.GetProject_RippleState(projectfilename_with_path)
-- Set RippleState in a projectfilename_with_path
--  0 - no Ripple, 1 - Ripple One Track, 2 - Ripple All
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RippleState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer ripplestate = ultraschall.GetProject_RippleState(string projectfilename_with_path)
</functionname>
<description>
Returns the ripple-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer ripplestate - 0 - no Ripple, 1 - Ripple One Track, 2 - Ripple All
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, ripple
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RIPPLE%s(.-)%c.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_RippleState("c:\\tt.rpp")
--reaper.ShowConsoleMsg(A)

function ultraschall.GetProject_GroupOverride(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_GroupOverride
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer group_override1, integer group_override2, integer group_override3 = ultraschall.GetProject_GroupOverride(string projectfilename_with_path)
</functionname>
<description>
Returns the group-override-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer group_override1 - the group-override state
integer group_override2 - the group-override state
integer group_override3 - the group-override state
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, group, override
</tags>
</ApiDocBlocFunc>
]]
 if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-GROUPOVERRIDE%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GROUPOVERRIDE%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GROUPOVERRIDE%s.-%s.-%s(.-)%s.-<RECORD_CFG"))
end

--A,AA,AAA=ultraschall.GetProject_GroupOverride("c:\\tt.rpp")

function ultraschall.GetProject_AutoCrossFade(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_AutoCrossFade
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer autocrossfade_state = ultraschall.GetProject_AutoCrossFade(string projectfilename_with_path)
</functionname>
<description>
Returns the autocrossfade-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer autocrossfade_state - the autocrossfade-state
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, crossfade, state, auto
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-AUTOXFADE%s(.-)%c.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_AutoCrossFade("c:\\tt.rpp")
--reaper.ShowConsoleMsg(A)

function ultraschall.GetProject_EnvAttach(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_EnvAttach
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer env_attach = ultraschall.GetProject_EnvAttach(string projectfilename_with_path)
</functionname>
<description>
Returns the EnvAttach-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer env_attach - the env-attach state
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, envattach
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-ENVATTACH%s(.-)%c.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_EnvAttach("c:\\tt.rpp")

function ultraschall.GetProject_MixerUIFlags(projectfilename_with_path)
--state1 - 0 - Show tracks in folders, Auto arrange tracks in mixer
--         1 - Show normal top level tracks
--         2 - Show Folders
--         4 - Group folders to left
--         8 - Show tracks that have receives
--         16 - Group tracks that have receives to left
--         32 - don't show tracks that are in folder
--         64 - No Autoarrange tracks in mixer
--         128 - ?
--         256 - ?

--state2 - 0 - Master track in mixer
--         1 - Don't show multiple rows of tracks, when size permits
--         2 - Show maximum rows even when tracks would fit in less rows
--         4 - Master Show on right side of mixer
--         8 - ?
--         16 - Show FX inserts when size permits
--         32 - Show sends when size permits
--         64 - Show tracks in mixer
--         128 - Show FX parameters, when size permits
--         256 - Don't show Master track in mixer

--[[
<ApiDocBlocFunc>
<slug>
GetProject_MixerUIFlags
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer state1, integer state2 = ultraschall.GetProject_MixerUIFlags(string projectfilename_with_path)
</functionname>
<description>
Returns the MixerUI-state-flags from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer state1 - folders, receives, etc 
-0 - Show tracks in folders, Auto arrange tracks in mixer
-1 - Show normal top level tracks
-2 - Show Folders
-4 - Group folders to left
-8 - Show tracks that have receives
-16 - Group tracks that have receives to left
-32 - don't show tracks that are in folder
-64 - No Autoarrange tracks in mixer
-128 - ?
-256 - ?

integer state2 - master-track, FX, Mixer
-0 - Master track in mixer
-1 - Don't show multiple rows of tracks, when size permits
-2 - Show maximum rows even when tracks would fit in less rows
-4 - Master Show on right side of mixer
-8 - ?
-16 - Show FX inserts when size permits
-32 - Show sends when size permits
-64 - Show tracks in mixer
-128 - Show FX parameters, when size permits
-256 - Don't show Master track in mixer
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, mixer, ui, flags
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-MIXERUIFLAGS%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-MIXERUIFLAGS%s.-%s(.-)%c.-<RECORD_CFG"))
end

--A,AA=ultraschall.GetProject_MixerUIFlags("c:\\tt.rpp")

function ultraschall.GetProject_PeakGain(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_PeakGain
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number peakgain_state = ultraschall.GetProject_PeakGain(string projectfilename_with_path)
</functionname>
<description>
Returns the GetProject_PeakGain-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
number peakgain_state - peakgain-state
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, mixer, peakgain, peak, gain
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-PEAKGAIN%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_PeakGain("c:\\tt.rpp")

function ultraschall.GetProject_Feedback(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_Feedback
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer feedback_state = ultraschall.GetProject_Feedback(string projectfilename_with_path)
</functionname>
<description>
Returns the GetProject_Feedback-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer feedback_state - feedback-state
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, mixer, feedback
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-FEEDBACK%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_Feedback("c:\\tt.rpp")

function ultraschall.GetProject_PanLaw(projectfilename_with_path)
--returns
-- number state - as set in the project-settings->Advanced->Pan law/mode->Pan:law(db)
--                0.5(-6.02 db) to 1(default +0.0 db)

--[[
<ApiDocBlocFunc>
<slug>
GetProject_PanLaw
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number panlaw_state = ultraschall.GetProject_PanLaw(string projectfilename_with_path)
</functionname>
<description>
Returns the GetProject_PanLaw-state from an RPP-Projectfile, as set in the project-settings->Advanced->Pan law/mode->Pan:law(db).
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
number panlaw_state - state of the panlaw, as set in the project-settings->Advanced->Pan law/mode->Pan:law(db). 0.5(-6.02 db) to 1(default +0.0 db)
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, mixer, panlaw, pan
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-PANLAW%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_PanLaw("c:\\tt.rpp")

function ultraschall.GetProject_ProjOffsets(projectfilename_with_path)
--returns Projectoffset (ProjectSettings->ProjectSettings->Project Start Time/Measure)
-- Project Start Time - in seconds
-- Project Start Measure - starting with 0, unlike the Settingswindow, where the 0 becomes 1 as measure
--[[
<ApiDocBlocFunc>
<slug>
GetProject_ProjOffsets
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number start_time, integer start_measure = ultraschall.GetProject_ProjOffsets(string projectfilename_with_path)
</functionname>
<description>
Returns the Project Offset-state from an RPP-Projectfile, start time as well as start measure.
as set in ProjectSettings->ProjectSettings->Project Start Time/Measure.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
number start_time - the project-start-time in seconds
integer start_measure - starting with 0, unlike the Settingswindow, where the 0 becomes 1 as measure
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, project, offset, start, starttime
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-PROJOFFS%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-PROJOFFS%s.-%s(.-)%s.-<RECORD_CFG"))
end

--A,AA=ultraschall.GetProject_ProjOffsets("c:\\tt.rpp")

function ultraschall.GetProject_MaxProjectLength(projectfilename_with_path)
-- returns ProjectSettings->Advanced->
-- checkbox "Limit project length, stop playback/recording at:" - 0 off, 1 on
-- Projectlengthlimit - in seconds

--[[
<ApiDocBlocFunc>
<slug>
GetProject_MaxProjectLength
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer limit_project_length, number projectlength_limit = ultraschall.GetProject_MaxProjectLength(string projectfilename_with_path)
</functionname>
<description>
Returns the maximum-project-length from an RPP-Projectfile, as set in ProjectSettings->Advanced->
as set in ProjectSettings->ProjectSettings->Project Start Time/Measure.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer limit_project_length - checkbox "Limit project length, stop playback/recording at:" - 0 off, 1 on
number projectlength_limit - projectlength-limit in seconds
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, project, end, length, limit
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-MAXPROJLEN%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-MAXPROJLEN%s.-%s(.-)%s.-<RECORD_CFG"))
end

--A,AA=ultraschall.GetProject_MaxProjectLength("c:\\tt.rpp")

function ultraschall.GetProject_Grid(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_Grid
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer gridstate1, integer gridstate2, number gridstate3, integer gridstate4, number gridstate5, integer gridstate6, integer gridstate7, number gridstate8 = ultraschall.GetProject_Grid(string projectfilename_with_path)
</functionname>
<description>
Returns the grid-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer gridstate1 - gridstate1
integer gridstate2 - gridstate2
number gridstate3 - gridstate3
integer gridstate4 - gridstate4
number gridstate5 - gridstate5
integer gridstate6 - gridstate6
integer gridstate7 - gridstate7
number gridstate8 - gridstate8
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, grid
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-GRID%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GRID%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GRID%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GRID%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GRID%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GRID%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GRID%s.-%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-GRID%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG"))
end

--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA=ultraschall.GetProject_Grid("c:\\tt.rpp")

function ultraschall.GetProject_Timemode(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_Timemode
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer timemode1, integer timemode2, integer showntime, integer timemode4, integer timemode5 = ultraschall.GetProject_Timemode(string projectfilename_with_path)
</functionname>
<description>
Returns the timemode-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer timemode1 - timemode-state
integer timemode2 - timemode-state
integer showntime - Transport shown time
-      -1 - use ruler time unit
-       0 - minutes:seconds
-       1 - measures:beats/minutes:seconds
-       2 - measures:beats
-       3 - seconds
-       4 - samples
-       5 - hours:minutes:seconds:frames
-       8 - absolute frames
integer timemode4 - timemode-state
integer timemode5 - timemode-state
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, timemode
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-TIMEMODE%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-TIMEMODE%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-TIMEMODE%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-TIMEMODE%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-TIMEMODE%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG"))
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.GetProject_Timemode("c:\\tt.rpp")

function ultraschall.GetProject_VideoConfig(projectfilename_with_path)
-- returns:
-- integer preferredVidSizeX - preferred video size, x pixels
-- integer preferredVidSizeY - preferred video size, y pixels
-- integer settingsBitfield3 - settings
--              0 - turned on/selected: use high quality filtering, 
--                      preserve aspect ratio(letterbox) when resizing, Items in higher numbered tracks replace lower,
--                      as well as Video colorspace set to Auto
--              1 - Video colorspace: I420/YV12
--              2 - Video colorspace: YUV2
--              3 - RGB
--              256 - Items in lower numbered tracks replace higher
--              512 - Always resize video sources to preferred video size
--              1024 - Always resize output to preferred video size
--              2048 - turn off "Use high quality filtering when resizing"
--              4096 - turn off "preserve aspect ratio (letterbox) when resizing"
-- returns nil, in case of error

--[[
<ApiDocBlocFunc>
<slug>
GetProject_VideoConfig
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer preferredVidSizeX, integer preferredVidSizeY, integer settingsflags = ultraschall.GetProject_VideoConfig(string projectfilename_with_path)
</functionname>
<description>
Returns the videoconfig-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer preferredVidSizeX - preferred video size, x pixels
integer preferredVidSizeY - preferred video size, y pixels
integer settingsflags - settings
-0 - turned on/selected: use high quality filtering, preserve aspect ratio(letterbox) when resizing, 
- Items in higher numbered tracks replace lower, as well as Video colorspace set to Auto
-1 - Video colorspace: I420/YV12
-2 - Video colorspace: YUV2
-3 - RGB
-256 - Items in lower numbered tracks replace higher
-512 - Always resize video sources to preferred video size
-1024 - Always resize output to preferred video size
-2048 - turn off "Use high quality filtering when resizing"
-4096 - turn off "preserve aspect ratio (letterbox) when resizing"
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, video, videoconfig
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-VIDEO_CONFIG%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-VIDEO_CONFIG%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-VIDEO_CONFIG%s.-%s.-%s(.-)%s.-<RECORD_CFG"))
end

--A,AA,AAA=ultraschall.GetProject_VideoConfig("c:\\tt.rpp")

function ultraschall.GetProject_PanMode(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_PanMode
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer panmode_state = ultraschall.GetProject_PanMode(string projectfilename_with_path)
</functionname>
<description>
Returns the panmode-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer panmode_state - panmode-state
-0 reaper 3.x balance (deprecated)
-3 Stereo balance / mono pan (default)
-5 Stereo pan
-6 Dual Pan
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, panmode
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-PANMODE%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_PanMode("c:\\tt.rpp")

function ultraschall.GetProject_CursorPos(projectfilename_with_path)
-- returns cursorposition in seconds
--[[
<ApiDocBlocFunc>
<slug>
GetProject_CursorPos
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number cursorpos = ultraschall.GetProject_CursorPos(string projectfilename_with_path)
</functionname>
<description>
Returns the cursorposition-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
number cursorpos - editcursorposition in seconds
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, cursor, position, cursorposition, editcursor, edit
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-CURSOR%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_CursorPos("c:\\tt.rpp")

function ultraschall.GetProject_HorizontalZoom(projectfilename_with_path)
-- returns:
-- number HorizontalZoom - 0.007 to 1000000, zoomfactor
-- integer horizontalscrollbarpos - 0 - 4294967296
-- integer scrollbarfactor - 0 to 500837, counts up, when maximum horizontalscrollbarpos overflows
--[[
<ApiDocBlocFunc>
<slug>
GetProject_Zoom
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
number hzoom, integer hzoomscrollpos, integer scrollbarfactor = ultraschall.GetProject_Zoom(string projectfilename_with_path)
</functionname>
<description>
Returns the horizontal-zoom-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
number hzoom - HorizontalZoomfactor, 0.007 to 1000000
integer hzoomscrollpos - horizontalscrollbarposition - 0 - 4294967296
integer scrollbarfactor - 0 to 500837, counts up, when maximum hzoomscrollpos overflows
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, zoom, horizontal, scrollbar, factor
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-ZOOM%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-ZOOM%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-ZOOM%s.-%s.-%s(.-)%s.-<RECORD_CFG"))
end

--A1,AA,AAA=ultraschall.GetProject_HorizontalZoom("c:\\tt.rpp")

function ultraschall.GetProject_VerticalZoom(projectfilename_with_path)
-- returns vertical zoomfactor(0-40)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_VerticalZoom
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer vzoom = ultraschall.GetProject_VerticalZoom(string projectfilename_with_path)
</functionname>
<description>
Returns the verticalzoom from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer vzoom - vertical zoomfactor(0-40)
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, zoom, vertical, scrollbar, factor
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-VZOOMEX%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_VerticalZoom("c:\\tt.rpp")

function ultraschall.GetProject_UseRecConfig(projectfilename_with_path)
-- ProjectSettings->Media->Format for Apply FX, Glue, Freeze, etc
-- 0 - Automatic .wav (recommended)
-- 1 - Custom (use ultraschall.GetProject_ApplyFXCFG to get recording_cfg_string)
-- 2 - Recording Format

--[[
<ApiDocBlocFunc>
<slug>
GetProject_UseRecConfig
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer rec_cfg = ultraschall.GetProject_UseRecConfig(string projectfilename_with_path)
</functionname>
<description>
Returns the rec-cfg-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer rec_cfg - recording-cfg-state
- 0 - Automatic .wav (recommended)
- 1 - Custom (use ultraschall.GetProject_ApplyFXCFG to get recording_cfg_string)
- 2 - Recording Format
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, recording, rec, config
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-USE_REC_CFG%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_UseRecConfig("c:\\tt.rpp")

function ultraschall.GetProject_RecMode(projectfilename_with_path)
--returns Recording Mode
-- 0 - Autopunch/Selected Items
-- 1 - normal
-- 2 - Time Selection/Auto Punch

--[[
<ApiDocBlocFunc>
<slug>
GetProject_RecMode
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer rec_mode = ultraschall.GetProject_RecMode(string projectfilename_with_path)
</functionname>
<description>
Returns the rec-mode-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer rec_mode - recording-mode-state
- 0 - Autopunch/Selected Items
- 1 - normal
- 2 - Time Selection/Auto Punch
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, recording, rec, mode
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RECMODE%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_RecMode("c:\\tt.rpp")

function ultraschall.GetProject_SMPTESync(projectfilename_with_path)
-- ProjectSettings->Advanced->External Timecode Synchronization
--[[
<ApiDocBlocFunc>
<slug>
GetProject_SMPTESync
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer smptesync_state1, number smptesync_fps, integer smptesync_resyncdrift, integer smptesync_skipdropframes, integer smptesync_syncseek, integer smptesync_freewheel, integer smptesync_userinput, number smptesync_offsettimecode, integer smptesync_stop_rec_drift, integer smptesync_state10, integer smptesync_stop_rec_lacktime  = ultraschall.GetProject_SMPTESync(string projectfilename_with_path)
</functionname>
<description>
Returns the smpte-sync-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer smptesync_state1 - flag 
-0 - external timecode synchronization disabled
-1 - external timecode synchronization enabled
-4 - Start playback on valid timecode when stopped
-8 - turned off: display flashing notification window when waiting for sync for recording
-16 - playback off
-32 - recording off
-256 - MTC - 24/30fps MTC is 23.976/29.97ND works only with smptesync_userinput set to 4159
-512 - MTC - 24/30fps MTC is 24/30ND

number smptesync_fps - framerate in fps
integer smptesync_resyncdrift - "Re-synchronize if drift exceeds" in ms (0 = never)
integer smptesync_skipdropframes - "skip/drop frames if drift exceeds" in ms(0 - never)
integer smptesync_syncseek - "Synchronize by seeking ahead" in ms (default = 1000)
integer smptesync_freewheel - "Freewheel on missing time code for up to" in ms(0 = forever)
integer smptesync_userinput - User Input-flag
-0 - LTC: Input 1
-1 - LTC: Input 2
-4159 - MTC - All inputs - 24/30 fps MTC 23.976ND/29.97ND if project is ND
-4223 - SPP: All Inputs
-8192 - ASIO Positioning Protocol

number smptesync_offsettimecode - Offset incoming timecode by in seconds
integer smptesync_stop_rec_drift - "Stop recording if drift exceeds" in ms(0 = never)
integer smptesync_state10 - smptesync-state
integer smptesync_stop_rec_lacktime - "stop recording on lack of timecode after" in ms(0 = never)
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, smpte, sync
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),         
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s.-%s(.-)%s.-<RECORD_CFG"))
end

--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA,AAAAAAAAA,AL,AM=ultraschall.GetProject_SMPTESync("c:\\tt.rpp")

function ultraschall.GetProjectReWireSlave(projectfilename_with_path)
--To Do
-- ProjectSettings->Advanced->Rewire Slave Settings
end

function ultraschall.GetProject_Loop(projectfilename_with_path)
-- Loopbutton-state
-- 0 - off
-- 1 - on

--[[
<ApiDocBlocFunc>
<slug>
GetProject_Loop
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer loopbutton_state = ultraschall.GetProject_Loop(string projectfilename_with_path)
</functionname>
<description>
Returns the loop-button-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer loop_mode - loopbutton-state, 0 - off, 1 - on
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, loop, button
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-LOOP%s(.-)%s.-<RECORD_CFG"))
end

--A=ultraschall.GetProject_Loop("c:\\tt.rpp")

function ultraschall.GetProject_LoopGran(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_LoopGran
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer loopgran_state1, number loopgran_state2 = ultraschall.GetProject_LoopGran(string projectfilename_with_path)
</functionname>
<description>
Returns the loop_gran-state from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer loopgran_state1 - loopgran_state1
number loopgran_state2 - loopgran_state2
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, loop, gran
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-LOOPGRAN%s(.-)%s.-<RECORD_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-LOOPGRAN%s.-%s(.-)%c.-<RECORD_CFG"))
end

--A,AA=ultraschall.GetProject_LoopGran("c:\\tt.rpp")

function ultraschall.GetProject_RecPath(projectfilename_with_path)
--returns first and secondary recording paths
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RecPath
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string prim_recpath, string sec_recpath = ultraschall.GetProject_RecPath(string projectfilename_with_path)
</functionname>
<description>
Returns the primary and secondary recording-path from an RPP-Projectfile.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
string prim_recpath - the primary recording path
string sec_recpath - the secondary recording path
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, recording, path, recording path, primary, secondary
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
    return file:match("<REAPER_PROJECT.-RECORD_PATH%s\"(.-)\"%s.-<RECORD_CFG"),
         file:match("<REAPER_PROJECT.-RECORD_PATH%s.-%s\"(.-)\"%c.-<RECORD_CFG")
end

--A,AA=ultraschall.GetProject_RecPath("c:\\tt.rpp")


function ultraschall.GetProject_RecordCFG(projectfilename_with_path)
--To Do: Research
-- ProjectSettings->Media->Recording
-- recording-cfg-string

--[[
<ApiDocBlocFunc>
<slug>
GetProject_RecordCFG
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string recording_cfg_string = ultraschall.GetProject_RecordCFG(string projectfilename_with_path)
</functionname>
<description>
Returns the recording-configuration as encoded string from an RPP-Projectfile, as set in ProjectSettings->Media->Recording.

Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
recording_cfg_string - the record-configuration as encoded string
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, recording, configuration
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
    return file:match("<REAPER_PROJECT.-RECORD_CFG%c%s*(.-)%c.-RENDER_FILE")
end

--A=ultraschall.GetProject_RecordCFG("c:\\tt.rpp")

function ultraschall.GetProject_ApplyFXCFG(projectfilename_with_path)
--To Do: Research
-- ProjectSettings->Media->Format for Apply FX, Glue, Freeze, etc
-- recording_cfg-string
--[[
<ApiDocBlocFunc>
<slug>
GetProject_ApplyFXCFG
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string applyfx_cfg_string = ultraschall.GetProject_ApplyFXCFG(string projectfilename_with_path)
</functionname>
<description>
Returns the audioformat-configuration, for fx-appliance-operation, as an encoded string from an RPP-Projectfile, as set in ProjectSettings->Media->Format for Apply FX, Glue, Freeze, etc

Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
string applyfx_cfg_string - the file-format-configuration for fx-appliance as encoded string
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, fx, configuration
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
    return file:match("<REAPER_PROJECT.-APPLYFX_CFG%c%s*(.-)%c.-RENDER_FILE")
end

--A=ultraschall.GetProject_ApplyFXCFG("c:\\tt.rpp")

function ultraschall.GetProject_RenderFilename(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RenderFilename
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string render_filename = ultraschall.GetProject_RenderFilename(string projectfilename_with_path)
</functionname>
<description>
Returns the render-filename from an RPP-Projectfile. If it contains only a path or nothing, you should check the Render_Pattern using <a href="#GetProject_RenderPattern">GetProject_RenderPattern</a>, as a render-pattern influences the rendering-filename as well.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
string render_filename - the filename for rendering, check also <a href="#GetProject_RenderPattern">GetProject_RenderPattern</a>
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, recording, path, render filename, filename, render
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  temp=file:match("<REAPER_PROJECT.-RENDER_FILE%s(.-)%c.-<RENDER_CFG")
  if temp:sub(1,1)=="\"" then temp=temp:sub(2,-1) end
  if temp:sub(-1,-1)=="\"" then temp=temp:sub(1,-2) end
  return temp
end

--A=ultraschall.GetProject_RenderFilename("c:\\16.flac.rpp")

function ultraschall.GetProject_RenderPattern(projectfilename_with_path)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RenderPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string render_pattern = ultraschall.GetProject_RenderPattern(string projectfilename_with_path)
</functionname>
<description>
Returns the render-pattern, that tells Reaper, how to automatically name the render-file, from an RPP-Projectfile. If it contains nothing, you should check the Render_Pattern using <a href="#GetProject_RenderFilename">GetProject_RenderFilename</a>, as a render-pattern influences the rendering-filename as well.

Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
string render_pattern - the pattern, with which the rendering-filename will be automatically created. Check also <a href="#GetProject_RenderFilename">GetProject_RenderFilename</a>
-Capitalizing the first character of the wildcard will capitalize the first letter of the substitution. 
-Capitalizing the first two characters of the wildcard will capitalize all letters.
-
-Directories will be created if necessary. For example if the render target is "$project/track", the directory "$project" will be created.
-
-$item    media item take name, if the input is a media item
-$itemnumber  1 for the first media item on a track, 2 for the second...
-$track    track name
-$tracknumber  1 for the first track, 2 for the second...
-$parenttrack  parent track name
-$region    region name
-$regionnumber  1 for the first region, 2 for the second...
-$namecount  1 for the first item or region of the same name, 2 for the second...
-$start    start time of the media item, render region, or time selection
-$end    end time of the media item, render region, or time selection
-$startbeats  start time in beats of the media item, render region, or time selection
-$endbeats  end time in beats of the media item, render region, or time selection
-$timelineorder  1 for the first item or region on the timeline, 2 for the second...
-$project    project name
-$tempo    project tempo at the start of the render region
-$timesignature  project time signature at the start of the render region, formatted as 4-4
-$filenumber  blank (optionally 1) for the first file rendered, 1 (optionally 2) for the second...
-$filenumber[N]  N for the first file rendered, N+1 for the second...
-$note    C0 for the first file rendered,C#0 for the second...
-$note[X]    X (example: B2) for the first file rendered, X+1 (example: C3) for the second...
-$natural    C0 for the first file rendered, D0 for the second...
-$natural[X]  X (example: F2) for the first file rendered, X+1 (example: G2) for the second...
-$format    render format (example: wav)
-$samplerate  sample rate (example: 44100)
-$sampleratek  sample rate (example: 44.1)
-$year    year
-$year2    last 2 digits of the year
-$month    month number
-$monthname  month name
-$day    day of the month
-$hour    hour of the day in 24-hour format
-$hour12    hour of the day in 12-hour format
-$ampm    am if before noon,pm if after noon
-$minute    minute of the hour
-$second    second of the minute
-$user    user name
-$computer  computer name
-
-(this description has been taken from the Render Wildcard Help within the Render-Dialog of Reaper)
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, recording, render pattern, filename, render
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  temp=file:match("<REAPER_PROJECT.-RENDER_PATTERN%s(.-)%c.-<RENDER_CFG")
  if temp:sub(1,1)=="\"" then temp=temp:sub(2,-1) end
  if temp:sub(-1,-1)=="\"" then temp=temp:sub(1,-2) end
  return temp
end

--A=ultraschall.GetProject_RenderPattern("c:\\tt.rpp")
--A=ultraschall.GetProject_RenderPattern("c:\\tt.rpp")

function ultraschall.GetProject_RenderFreqNChans(projectfilename_with_path)
-- returns an unknown number, Number_Channels(0-default) and RenderFrequency(0-default)
-- Number_Channels 0-seems default-project-settings(?), 1-Mono, 2-Stereo, ... up to 64 channels
-- RenderFrequency -2147483647 to 2147483647, except 0, which seems to be default-project-settings-frequency
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RenderFreqNChans
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer unknown, integer rendernum_chans, integer render_frequency = ultraschall.GetProject_RenderFreqNChans(string projectfilename_with_path)
</functionname>
<description>
Returns an unknown number, the render-frequency and rendernumber of channels from an RPP-Projectfile. 
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer unknown - unknown number
integer rendernum_chans - Number_Channels 0-seems default-project-settings(?), 1-Mono, 2-Stereo, ... up to 64 channels
integer render_frequency - RenderFrequency -2147483647 to 2147483647, except 0, which seems to be default-project-settings-frequency
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, render, frequency, num channels, channels
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RENDER_FMT%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-RENDER_FMT%s.-%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-RENDER_FMT%s.-%s.-%s(.-)%s.-<RENDER_CFG"))
end

--A,AA,AAA=ultraschall.GetProject_RenderFreqNChans("c:\\tt.rpp")

function ultraschall.GetProject_RenderSpeed(projectfilename_with_path)
--    Rendering_Speed 0-Fullspeed Offline, 1-1x Offline, 
--                    2-Online Render, 3-Offline Render (Idle), 
--                    4-1x Offline Render (Idle)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RenderSpeed
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer render_speed = ultraschall.GetProject_RenderSpeed(string projectfilename_with_path)
</functionname>
<description>
Returns the rendering-speed from an RPP-Projectfile. 
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer render_speed - render_speed 
-0-Fullspeed Offline
-1-1x Offline
-2-Online Render
-3-Offline Render (Idle)
-4-1x Offline Render (Idle)
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, render, speed
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RENDER_1X%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_RenderSpeed("c:\\tt.rpp")

function ultraschall.GetProject_RenderRange(projectfilename_with_path)
-- returns RenderRange
-- Bounds: 0 Custom Time Range, 1 Entire Project, 2 Time Selection, 
--          3 Project Regions, 4 Selected Media Items(in combination with RENDER_STEMS 32)
-- TimeStart in milliseconds -2147483647 to 2147483647
-- TimeEnd in milliseconds 2147483647 to 2147483647
-- Tail: 
--0 Custom Time Range
--1 Entire Project
--2 Time Selection, 
--3 Project Regions
--4 Selected Media Items(in combination with RENDER_STEMS 32); to get RENDER_STEMS to 32, refer <a href="#GetProject_RenderStems">GetProject_RenderStems</a>
-- TailLength in milliseconds, valuerange 0 - 2147483647  
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RenderRange
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer bounds, number time_start, number time_end, integer tail, integer tail_length = ultraschall.GetProject_RenderRange(string projectfilename_with_path)
</functionname>
<description>
Returns the render-range, render-timestart, render-timeend, render-tail and render-taillength from an RPP-Projectfile. To get RENDER_STEMS, refer <a href="#GetProject_RenderStems">GetProject_RenderStems</a>
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer bounds - the bounds of the project to be rendered
-0 Custom Time Range
-1 Entire Project
-2 Time Selection, 
-3 Project Regions
-4 Selected Media Items(in combination with RENDER_STEMS 32); to get RENDER_STEMS, refer <a href="#GetProject_RenderStems">GetProject_RenderStems</a>

number time_start - TimeStart in milliseconds -2147483647 to 2147483647
number time_end - TimeEnd in milliseconds 2147483647 to 2147483647
integer tail - Tail on/off-flags for individual bounds
-0 - tail off for all bounds
-1 - custom time range - tail on
-2 - entire project - tail on
-4 - time selection - tail on
-8 - project regions - tail on

integer tail_length - TailLength in milliseconds, valuerange 0 - 2147483647
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, render, timestart, timeend, range, tail, bounds
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RENDER_RANGE%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-RENDER_RANGE%s.-%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-RENDER_RANGE%s.-%s.-%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-RENDER_RANGE%s.-%s.-%s.-%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-RENDER_RANGE%s.-%s.-%s.-%s.-%s(.-)%s.-<RENDER_CFG"))
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.GetProject_RenderRange("c:\\tt.rpp")

function ultraschall.GetProject_RenderResample(projectfilename_with_path)
-- returns Resamplemode for a)Rendering and b)Playback as well as c)if both are combined
--- Resample_Mode - 0-medium (64pt Sinc), 1-Low (Linear Interpolation), 
--                2-Lowest (Point Sampling), 3-Good(192pt Sinc), 
--                4-Better(384pt Sinc), 5-Fast (IIR + Linear Interpolation), 
--                6-Fast (IIRx2 + Linear Interpolation), 7-Fast (16pt sinc) - Default, 
--                8-HQ (512pt Sinc), 9-Extreme HQ (768pt HQ Sinc)
-- Playback_Resample_Mode (as set in the Project-Settings)
--                0-medium (64pt Sinc), 1-Low (Linear Interpolation), 
--                2-Lowest (Point Sampling), 3-Good(192pt Sinc), 
--                4-Better(384pt Sinc), 5-Fast (IIR + Linear Interpolation), 
--                6-Fast (IIRx2 + Linear Interpolation), 7-Fast (16pt sinc) - Default, 
--                8-HQ (512pt Sinc), 9-Extreme HQ (768pt HQ Sinc)
-- Use_Project_Sample_Rate_for_Mixing_and_FX/Synth_Processing - 1 - yes, 0-no

--[[
<ApiDocBlocFunc>
<slug>
GetProject_RenderResample
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer resample_mode, integer playback_resample_mode, integer project_smplrate4mix_and_fx = ultraschall.GetProject_RenderResample(string projectfilename_with_path)
</functionname>
<description>
Returns Resamplemode for a)Rendering and b)Playback as well as c)if both are combined from an RPP-Projectfile. 
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer resample_mode - Resample_Mode 
-0-medium (64pt Sinc), 
-1-Low (Linear Interpolation), 
-2-Lowest (Point Sampling), 
-3-Good(192pt Sinc), 
-4-Better(384pt Sinc), 
-5-Fast (IIR + Linear Interpolation), 
-6-Fast (IIRx2 + Linear Interpolation), 
-7-Fast (16pt sinc) - Default, 
-8-HQ (512pt Sinc), 
-9-Extreme HQ (768pt HQ Sinc)

integer playback_resample_mode - Playback Resample Mode (as set in the Project-Settings)
-0-medium (64pt Sinc), 
-1-Low (Linear Interpolation), 
-2-Lowest (Point Sampling), 
-3-Good(192pt Sinc), 
-4-Better(384pt Sinc), 
-5-Fast (IIR + Linear Interpolation), 
-6-Fast (IIRx2 + Linear Interpolation), 
-7-Fast (16pt sinc) - Default, 
-8-HQ (512pt Sinc), 
-9-Extreme HQ (768pt HQ Sinc)

integer project_smplrate4mix_and_fx - Use_Project_Sample_Rate_for_Mixing_and_FX/Synth_Processing 1 - yes, 0-no
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, render, resample, playback, mixing, fx, synth
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RENDER_RESAMPLE%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-RENDER_RESAMPLE%s.-%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-RENDER_RESAMPLE%s.-%s.-%s(.-)%s.-<RENDER_CFG"))
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.GetProject_RenderResample("c:\\tt.rpp")

function ultraschall.GetProject_AddMediaToProjectAfterRender(projectfilename_with_path)
-- returns the state, if rendered media shall be added to the project afterwards
-- 0 - don't add, 1 - add to project
--[[
<ApiDocBlocFunc>
<slug>
GetProject_AddMediaToProjectAfterRender
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer addmedia_after_render_state = ultraschall.GetProject_AddMediaToProjectAfterRender(string projectfilename_with_path)
</functionname>
<description>
Returns, if rendered media shall be added to the project afterwards, from an RPP-Projectfile. 
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer addmedia_after_render_state - 1 - rendered media shall be added to the project afterwards, 0 - don't add
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, render, add, media, after, project
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RENDER_ADDTOPROJ%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_AddMediaToProjectAfterRender("c:\\tt.rpp")

function ultraschall.GetProject_RenderStems(projectfilename_with_path)
-- returns the state of Render Stems
-- 0 - Source Master Mix, 1 - Source Master mix + stems, 3 - Source Stems, selected tracks, 
-- 4 - Multichannel Tracks to Multichannel Files, 8 - Source Region Render Matrix, 
-- 16 - Tracks with only Mono-Media to Mono Files,  
-- 32 Selected Media Items(in combination with RENDER_RANGE->Bounds->4)  
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RenderStems
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer render_stems = ultraschall.GetProject_RenderStems(string projectfilename_with_path)
</functionname>
<description>
Returns the render-stems-state from an rpp-project-file.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer render_stems - the state of Render Stems
- 0 - Source Master Mix, 
- 1 - Source Master mix + stems, 
- 3 - Source Stems, selected tracks, 
- 4 - Multichannel Tracks to Multichannel Files, 
- 8 - Source Region Render Matrix, 
- 16 - Tracks with only Mono-Media to Mono Files,  
- 32 Selected Media Items(in combination with RENDER_RANGE->Bounds->4, refer to <a href="#GetProject_RenderRange">GetProject_RenderRange</a> to get RENDER_RANGE)
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, render, stems, multichannel
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RENDER_STEMS%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_RenderStems("c:\\tt.rpp")

function ultraschall.GetProject_RenderDitherState(projectfilename_with_path)
-- returns the state of dithering of rendering
-- 0 - Dither Master Mix, 1 - Don't Dither Master Mix, 2 - Noise-shaping On Master Mix, 
-- 3 - Dither And Noiseshape Master Mix
--[[
<ApiDocBlocFunc>
<slug>
GetProject_RenderDitherState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer renderdither_state = ultraschall.GetProject_RenderDitherState(string projectfilename_with_path)
</functionname>
<description>
Returns the render-dither-state from an rpp-project-file.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer renderdither_state - the state of render dithering
-0 - Dither Master Mix, 
-1 - Don't Dither Master Mix, 
-2 - Noise-shaping On Master Mix, 
-3 - Dither And Noiseshape Master Mix
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, render, dither, state, master, noise shaping
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-RENDER_DITHER%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_RenderDitherState("c:\\tt.rpp")


function ultraschall.GetProject_TimeBase(projectfilename_with_path)
-- returns Time Base for items/envelopes/markers as set in the project settings
-- 0 - Time, 1 - Beats (position, length, rate), 2 - Beats (position only)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_TimeBase
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer timebase = ultraschall.GetProject_TimeBase(string projectfilename_with_path)
</functionname>
<description>
Returns the timebase-state from an rpp-project-file.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer timebase - the timebase for items/envelopes/markers as set in the project settings
-0 - Time, 
-1 - Beats (position, length, rate), 
-2 - Beats (position only)
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, timebase, time, beats, items, envelopes, markers
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-TIMELOCKMODE%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_TimeBase("c:\\tt.rpp")

function ultraschall.GetProject_TempoTimeSignature(projectfilename_with_path)
-- returns Time Base for tempo/time-signature as set in the project settings
-- 0 - Time, 1 - Beats
--[[
<ApiDocBlocFunc>
<slug>
GetProject_TempoTimeSignature
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer tempotimesignature = ultraschall.GetProject_TempoTimeSignature(string projectfilename_with_path)
</functionname>
<description>
Returns the timebase for tempo/time-signature as set in the project-settings, from an rpp-project-file.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer tempotimesignature - the timebase for tempo/time-signature as set in the project settings
-0 - Time 
-1 - Beats
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, timebase, time, beats, tempo, signature
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-TEMPOENVLOCKMODE%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_TempoTimeSignature("c:\\tt.rpp")

function ultraschall.GetProject_ItemMixBehavior(projectfilename_with_path)
-- returns Project Settings Item Mix Behavior
-- 0 - Enclosed items replace enclosing items 
-- 1 - Items always mix
-- 2 - Items always replace earlier items

--[[
<ApiDocBlocFunc>
<slug>
GetProject_ItemMixBehavior
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer item_mix_behav_state = ultraschall.GetProject_ItemMixBehavior(string projectfilename_with_path)
</functionname>
<description>
Returns the item mix behavior, as set in the project-settings, from an rpp-project-file.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer item_mix_behav_state - item mix behavior
- 0 - Enclosed items replace enclosing items 
- 1 - Items always mix
- 2 - Items always replace earlier items
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, item, mix
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-ITEMMIX%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_ItemMixBehavior("c:\\tt.rpp")

function ultraschall.GetProject_DefPitchMode(projectfilename_with_path)
-- returns Default Pitch Mode for project
--      0 - Soundtouch(Default)
--      1 - Soundtouch(High Quality)
--      2 - Soundtouch(Fast)
--      131072 - Simple Windowed(fast) (50ms window, 25ms fade)
--      131073 - Simple Windowed(fast) (50ms window, 16ms fade)
--      131074 - Simple Windowed(fast) (50ms window, 10ms fade)
--      131075 - Simple Windowed(fast) (50ms window, 7ms fade)
--      131076 - Simple Windowed(fast) (75ms window, 37ms fade)
--      131077 - Simple Windowed(fast) (75ms window, 25ms fade)
--      131078 - Simple Windowed(fast) (75ms window, 15ms fade)
--      131079 - Simple Windowed(fast) (75ms window, 10ms fade)
--      131080 - Simple Windowed(fast) (100ms window, 50ms fade)
--      131081 - Simple Windowed(fast) (100ms window, 33ms fade)
--      131082 - Simple Windowed(fast) (100ms window, 20ms fade)
--      131083 - Simple Windowed(fast) (100ms window, 14ms fade)
--      131084 - Simple Windowed(fast) (150ms window, 75ms fade)
--      131085 - Simple Windowed(fast) (150ms window, 50ms fade)
--      131086 - Simple Windowed(fast) (150ms window, 30ms fade)
--      131087 - Simple Windowed(fast) (150ms window, 21ms fade)
--      131088 - Simple Windowed(fast) (225ms window, 112ms fade)
--      131089 - Simple Windowed(fast) (225ms window, 75ms fade)
--      131090 - Simple Windowed(fast) (225ms window, 45ms fade)
--      131091 - Simple Windowed(fast) (225ms window, 32ms fade)
--      131092 - Simple Windowed(fast) (300ms window, 150ms fade)
--      131093 - Simple Windowed(fast) (300ms window, 100ms fade)
--      131094 - Simple Windowed(fast) (300ms window, 60ms fade)
--      131095 - Simple Windowed(fast) (300ms window, 42ms fade)
--      131096 - Simple Windowed(fast) (40ms window, 20ms fade)
--      131097 - Simple Windowed(fast) (40ms window, 13ms fade)
--      131098 - Simple Windowed(fast) (40ms window, 8ms fade)
--      131099 - Simple Windowed(fast) (40ms window, 5ms fade)
--      131100 - Simple Windowed(fast) (30ms window, 15ms fade)
--      131101 - Simple Windowed(fast) (30ms window, 10ms fade)
--      131102 - Simple Windowed(fast) (30ms window, 6s fade)
--      131103 - Simple Windowed(fast) (30ms window, 4ms fade)
--      131104 - Simple Windowed(fast) (20ms window, 10ms fade)
--      131105 - Simple Windowed(fast) (20ms window, 6ms fade)
--      131106 - Simple Windowed(fast) (20ms window, 4ms fade)
--      131107 - Simple Windowed(fast) (20ms window, 2ms fade)
--      131108 - Simple Windowed(fast) (10ms window, 5ms fade)
--      131109 - Simple Windowed(fast) (10ms window, 3ms fade)
--      131110 - Simple Windowed(fast) (10ms window, 2ms fade)
--      131111 - Simple Windowed(fast) (10ms window, 1ms fade)
--      131112 - Simple Windowed(fast) (5ms window, 2ms fade)
--      131113 - Simple Windowed(fast) (5ms window, 1ms fade)
--      131114 - Simple Windowed(fast) (5ms window, 1ms fade)
--      131115 - Simple Windowed(fast) (5ms window, 1ms fade)
--      131116 - Simple Windowed(fast) (3ms window, 1ms fade)
--      131117 - Simple Windowed(fast) (3ms window, 1ms fade)
--      131118 - Simple Windowed(fast) (3ms window, 1ms fade)
--      131119 - Simple Windowed(fast) (3ms window, 1ms fade)
--      393216 - elastique 2.28 Pro Normal
--      393217 - elastique 2.28 Pro Preserve Formants(Lowest Pitches)
--      393218 - elastique 2.28 Pro Preserve Formants(Lower Pitches)
--      393219 - elastique 2.28 Pro Preserve Formants(Low Pitches)
--      393220 - elastique 2.28 Pro Preserve Formants(Most Pitches)
--      393221 - elastique 2.28 Pro Preserve Formants(High Pitches)
--      393222 - elastique 2.28 Pro Preserve Formants(Higher Pitches)
--      393223 - elastique 2.28 Pro Preserve Formants(Highest Pitches)
--      393224 - elastique 2.28 Pro Mid/Side
--      393225 - elastique 2.28 Pro Mid/Side, Preserve Formants(Lowest Pitches)
--      393226 - elastique 2.28 Pro Mid/Side, Preserve Formants(Lower Pitches)
--      393227 - elastique 2.28 Pro Mid/Side, Preserve Formants(Low Pitches)
--      393228 - elastique 2.28 Pro Mid/Side, Preserve Formants(Most Pitches)
--      393229 - elastique 2.28 Pro Mid/Side, Preserve Formants(High Pitches)
--      393230 - elastique 2.28 Pro Mid/Side, Preserve Formants(Higher Pitches)
--      393231 - elastique 2.28 Pro Mid/Side, Preserve Formants(Highest Pitches)
--      393232 - elastique 2.28 Pro Synchronized: Normal
--      393233 - elastique 2.28 Pro Synchronized: Preserve Formants(Lowest Pitches)
--      393234 - elastique 2.28 Pro Synchronized: Preserve Formants(Lower Pitches)
--      393235 - elastique 2.28 Pro Synchronized: Preserve Formants(Low Pitches)
--      393236 - elastique 2.28 Pro Synchronized: Preserve Formants(Most Pitches)
--      393237 - elastique 2.28 Pro Synchronized: Preserve Formants(High Pitches)
--      393238 - elastique 2.28 Pro Synchronized: Preserve Formants(Higher Pitches)
--      393239 - elastique 2.28 Pro Synchronized: Preserve Formants(Highest Pitches)
--      393240 - elastique 2.28 Pro Synchronized: Mid/Side 
--      393241 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Lowest Pitches)
--      393242 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Lower Pitches) 
--      393243 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Low Pitches)
--      393244 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Most Pitches)
--      393245 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(High Pitches)
--      393246 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Higher Pitches)
--      393247 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Highest Pitches)
--      458752 - elastique 2.28 Efficient Normal
--      458753 - elastique 2.28 Efficient Mid/Side
--      458754 - elastique 2.28 Efficient Synchronized: Normal
--      458755 - elastique 2.28 Efficient Synchronized: Mid/Side
--      524288 - elastique 2.28 Soloist Monophonic
--      524289 - elastique 2.28 Soloist Monophonic [Mid/Side]
--      524290 - elastique 2.28 Soloist Speech
--      524291 - elastique 2.28 Soloist Speech [Mid/Side]
--      589824 - elastique 3.1.4 Pro Normal
--      589825 - elastique 3.1.4 Pro Preserve Formants(Lowest Pitches)
--      589826 - elastique 3.1.4 Pro Preserve Formants(Lower Pitches)
--      589827 - elastique 3.1.4 Pro Preserve Formants(Low Pitches)
--      589828 - elastique 3.1.4 Pro Preserve Formants(Most Pitches)
--      589829 - elastique 3.1.4 Pro Preserve Formants(High Pitches)
--      589830 - elastique 3.1.4 Pro Preserve Formants(Higher Pitches)
--      589831 - elastique 3.1.4 Pro Preserve Formants(Highest Pitches)
--      589832 - elastique 3.1.4 Pro Mid/Side
--      589833 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Lowest Pitches)
--      589834 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Lower Pitches)
--      589835 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Low Pitches)
--      589836 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Most Pitches)
--      589837 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(High Pitches)
--      589838 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Higher Pitches)
--      589839 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Highest Pitches)
--      589840 - elastique 3.1.4 Pro Synchronized: Normal
--      589841 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Lowest Pitches)
--      589842 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Lower Pitches)
--      589843 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Low Pitches)
--      589844 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Most Pitches)
--      589845 - elastique 3.1.4 Pro Synchronized: Preserve Formants(High Pitches)
--      589846 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Higher Pitches)
--      589847 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Highest Pitches)
--      589848 - elastique 3.1.4 Pro Synchronized: Mid/Side 
--      589849 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Lowest Pitches)
--      589850 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Lower Pitches) 
--      589851 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Low Pitches)
--      589852 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Most Pitches)
--      589853 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(High Pitches)
--      589853 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Higher Pitches)
--      589855 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Highest Pitches)
--      655360 - elastique 3.1.4 Efficient Normal
--      655361 - elastique 3.1.4 Efficient Mid/Side
--      655362 - elastique 3.1.4 Efficient Synchronized: Normal
--      655363 - elastique 3.1.4 Efficient Synchronized: Mid/Side
--      720896 - elastique 3.1.4 Soloist (Monophonic)
--      720897 - elastique 3.1.4 Soloist (Monophonic Mid Side)
--[[
<ApiDocBlocFunc>
<slug>
GetProject_DefPitchMode
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer def_pitch_mode_state = ultraschall.GetProject_DefPitchMode(string projectfilename_with_path)
</functionname>
<description>
Returns the default-pitch-mode, as set in the project-settings, from an rpp-project-file.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer def_pitch_mode_state - the default pitch mode
-      0 - Soundtouch(Default)
-      1 - Soundtouch(High Quality)
-      2 - Soundtouch(Fast)
-      131072 - Simple Windowed(fast) (50ms window, 25ms fade)
-      131073 - Simple Windowed(fast) (50ms window, 16ms fade)
-      131074 - Simple Windowed(fast) (50ms window, 10ms fade)
-      131075 - Simple Windowed(fast) (50ms window, 7ms fade)
-      131076 - Simple Windowed(fast) (75ms window, 37ms fade)
-      131077 - Simple Windowed(fast) (75ms window, 25ms fade)
-      131078 - Simple Windowed(fast) (75ms window, 15ms fade)
-      131079 - Simple Windowed(fast) (75ms window, 10ms fade)
-      131080 - Simple Windowed(fast) (100ms window, 50ms fade)
-      131081 - Simple Windowed(fast) (100ms window, 33ms fade)
-      131082 - Simple Windowed(fast) (100ms window, 20ms fade)
-      131083 - Simple Windowed(fast) (100ms window, 14ms fade)
-      131084 - Simple Windowed(fast) (150ms window, 75ms fade)
-      131085 - Simple Windowed(fast) (150ms window, 50ms fade)
-      131086 - Simple Windowed(fast) (150ms window, 30ms fade)
-      131087 - Simple Windowed(fast) (150ms window, 21ms fade)
-      131088 - Simple Windowed(fast) (225ms window, 112ms fade)
-      131089 - Simple Windowed(fast) (225ms window, 75ms fade)
-      131090 - Simple Windowed(fast) (225ms window, 45ms fade)
-      131091 - Simple Windowed(fast) (225ms window, 32ms fade)
-      131092 - Simple Windowed(fast) (300ms window, 150ms fade)
-      131093 - Simple Windowed(fast) (300ms window, 100ms fade)
-      131094 - Simple Windowed(fast) (300ms window, 60ms fade)
-      131095 - Simple Windowed(fast) (300ms window, 42ms fade)
-      131096 - Simple Windowed(fast) (40ms window, 20ms fade)
-      131097 - Simple Windowed(fast) (40ms window, 13ms fade)
-      131098 - Simple Windowed(fast) (40ms window, 8ms fade)
-      131099 - Simple Windowed(fast) (40ms window, 5ms fade)
-      131100 - Simple Windowed(fast) (30ms window, 15ms fade)
-      131101 - Simple Windowed(fast) (30ms window, 10ms fade)
-      131102 - Simple Windowed(fast) (30ms window, 6s fade)
-      131103 - Simple Windowed(fast) (30ms window, 4ms fade)
-      131104 - Simple Windowed(fast) (20ms window, 10ms fade)
-      131105 - Simple Windowed(fast) (20ms window, 6ms fade)
-      131106 - Simple Windowed(fast) (20ms window, 4ms fade)
-      131107 - Simple Windowed(fast) (20ms window, 2ms fade)
-      131108 - Simple Windowed(fast) (10ms window, 5ms fade)
-      131109 - Simple Windowed(fast) (10ms window, 3ms fade)
-      131110 - Simple Windowed(fast) (10ms window, 2ms fade)
-      131111 - Simple Windowed(fast) (10ms window, 1ms fade)
-      131112 - Simple Windowed(fast) (5ms window, 2ms fade)
-      131113 - Simple Windowed(fast) (5ms window, 1ms fade)
-      131114 - Simple Windowed(fast) (5ms window, 1ms fade)
-      131115 - Simple Windowed(fast) (5ms window, 1ms fade)
-      131116 - Simple Windowed(fast) (3ms window, 1ms fade)
-      131117 - Simple Windowed(fast) (3ms window, 1ms fade)
-      131118 - Simple Windowed(fast) (3ms window, 1ms fade)
-      131119 - Simple Windowed(fast) (3ms window, 1ms fade)
-      393216 - elastique 2.28 Pro Normal
-      393217 - elastique 2.28 Pro Preserve Formants(Lowest Pitches)
-      393218 - elastique 2.28 Pro Preserve Formants(Lower Pitches)
-      393219 - elastique 2.28 Pro Preserve Formants(Low Pitches)
-      393220 - elastique 2.28 Pro Preserve Formants(Most Pitches)
-      393221 - elastique 2.28 Pro Preserve Formants(High Pitches)
-      393222 - elastique 2.28 Pro Preserve Formants(Higher Pitches)
-      393223 - elastique 2.28 Pro Preserve Formants(Highest Pitches)
-      393224 - elastique 2.28 Pro Mid/Side
-      393225 - elastique 2.28 Pro Mid/Side, Preserve Formants(Lowest Pitches)
-      393226 - elastique 2.28 Pro Mid/Side, Preserve Formants(Lower Pitches)
-      393227 - elastique 2.28 Pro Mid/Side, Preserve Formants(Low Pitches)
-      393228 - elastique 2.28 Pro Mid/Side, Preserve Formants(Most Pitches)
-      393229 - elastique 2.28 Pro Mid/Side, Preserve Formants(High Pitches)
-      393230 - elastique 2.28 Pro Mid/Side, Preserve Formants(Higher Pitches)
-      393231 - elastique 2.28 Pro Mid/Side, Preserve Formants(Highest Pitches)
-      393232 - elastique 2.28 Pro Synchronized: Normal
-      393233 - elastique 2.28 Pro Synchronized: Preserve Formants(Lowest Pitches)
-      393234 - elastique 2.28 Pro Synchronized: Preserve Formants(Lower Pitches)
-      393235 - elastique 2.28 Pro Synchronized: Preserve Formants(Low Pitches)
-      393236 - elastique 2.28 Pro Synchronized: Preserve Formants(Most Pitches)
-      393237 - elastique 2.28 Pro Synchronized: Preserve Formants(High Pitches)
-      393238 - elastique 2.28 Pro Synchronized: Preserve Formants(Higher Pitches)
-      393239 - elastique 2.28 Pro Synchronized: Preserve Formants(Highest Pitches)
-      393240 - elastique 2.28 Pro Synchronized: Mid/Side 
-      393241 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Lowest Pitches)
-      393242 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Lower Pitches) 
-      393243 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Low Pitches)
-      393244 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Most Pitches)
-      393245 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(High Pitches)
-      393246 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Higher Pitches)
-      393247 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Highest Pitches)
-      458752 - elastique 2.28 Efficient Normal
-      458753 - elastique 2.28 Efficient Mid/Side
-      458754 - elastique 2.28 Efficient Synchronized: Normal
-      458755 - elastique 2.28 Efficient Synchronized: Mid/Side
-      524288 - elastique 2.28 Soloist Monophonic
-      524289 - elastique 2.28 Soloist Monophonic [Mid/Side]
-      524290 - elastique 2.28 Soloist Speech
-      524291 - elastique 2.28 Soloist Speech [Mid/Side]
-      589824 - elastique 3.1.4 Pro Normal
-      589825 - elastique 3.1.4 Pro Preserve Formants(Lowest Pitches)
-      589826 - elastique 3.1.4 Pro Preserve Formants(Lower Pitches)
-      589827 - elastique 3.1.4 Pro Preserve Formants(Low Pitches)
-      589828 - elastique 3.1.4 Pro Preserve Formants(Most Pitches)
-      589829 - elastique 3.1.4 Pro Preserve Formants(High Pitches)
-      589830 - elastique 3.1.4 Pro Preserve Formants(Higher Pitches)
-      589831 - elastique 3.1.4 Pro Preserve Formants(Highest Pitches)
-      589832 - elastique 3.1.4 Pro Mid/Side
-      589833 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Lowest Pitches)
-      589834 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Lower Pitches)
-      589835 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Low Pitches)
-      589836 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Most Pitches)
-      589837 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(High Pitches)
-      589838 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Higher Pitches)
-      589839 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Highest Pitches)
-      589840 - elastique 3.1.4 Pro Synchronized: Normal
-      589841 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Lowest Pitches)
-      589842 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Lower Pitches)
-      589843 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Low Pitches)
-      589844 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Most Pitches)
-      589845 - elastique 3.1.4 Pro Synchronized: Preserve Formants(High Pitches)
-      589846 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Higher Pitches)
-      589847 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Highest Pitches)
-      589848 - elastique 3.1.4 Pro Synchronized: Mid/Side 
-      589849 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Lowest Pitches)
-      589850 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Lower Pitches) 
-      589851 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Low Pitches)
-      589852 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Most Pitches)
-      589853 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(High Pitches)
-      589853 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Higher Pitches)
-      589855 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Highest Pitches)
-      655360 - elastique 3.1.4 Efficient Normal
-      655361 - elastique 3.1.4 Efficient Mid/Side
-      655362 - elastique 3.1.4 Efficient Synchronized: Normal
-      655363 - elastique 3.1.4 Efficient Synchronized: Mid/Side
-      720896 - elastique 3.1.4 Soloist (Monophonic)
-      720897 - elastique 3.1.4 Soloist (Monophonic Mid Side)
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, default, pitch mode, pitch
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-DEFPITCHMODE%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_DefPitchMode("c:\\tt.rpp")

function ultraschall.GetProject_TakeLane(projectfilename_with_path)
-- returns TakeLane state
--[[
<ApiDocBlocFunc>
<slug>
GetProject_TakeLane
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer take_lane_state = ultraschall.GetProject_TakeLane(string projectfilename_with_path)
</functionname>
<description>
Returns the take-lane-state from an rpp-project-file.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer take_lane_state - take-lane-state
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, take, lane
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-TAKELANE%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_TakeLane("c:\\tt.rpp")

function ultraschall.GetProject_SampleRate(projectfilename_with_path)
-- returns Project Settings Samplerate
--        a - Project Sample Rate
--        b - Checkbox: Project Sample Rate
--        c - Checkbox: Force Project Tempo/Time Signature changes to occur on whole samples 
--[[
<ApiDocBlocFunc>
<slug>
GetProject_SampleRate
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer sample_rate, integer project_sample_rate, integer force_tempo_time_sig = ultraschall.GetProject_SampleRate(string projectfilename_with_path)
</functionname>
<description>
Returns the take-lane-state, as set in the project-settings, from an rpp-project-file.
Returns nil in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer sample_rate - Project Sample Rate in Hz
integer project_sample_rate - Checkbox: Project Sample Rate
integer force_tempo_time_sig - Checkbox: Force Project Tempo/Time Signature changes to occur on whole samples 
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, sample, rate, samplerate, tempo, time, signature
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return nil end
  if reaper.file_exists(projectfilename_with_path)==false then return nil end
   file=ultraschall.ReadValueFromFile(projectfilename_with_path)
   if file==nil then return "hui" end
  return tonumber(file:match("<REAPER_PROJECT.-SAMPLERATE%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SAMPLERATE%s.-%s(.-)%s.-<RENDER_CFG")),
         tonumber(file:match("<REAPER_PROJECT.-SAMPLERATE%s.-%s.-%s(.-)%s.-<RENDER_CFG"))
end

--A,AA,AAA=ultraschall.GetProject_SampleRate("c:\\tt.rpp")

function ultraschall.GetProject_TrackMixingDepth(projectfilename_with_path)
-- returns TrackMixingDepth
--          1 - 32 bit float
--          2 - 39 bit integer
--          3 - 24 bit integer
--          4 - 16 bit integer
--          5 - 12 bit integer
--          6 - 8 bit integer
--[[
<ApiDocBlocFunc>
<slug>
GetProject_TrackMixingDepth
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer track_mixing_depth = ultraschall.GetProject_TrackMixingDepth(string projectfilename_with_path)
</functionname>
<description>
Returns the track-mixing-state, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error, nil if it's set to 64bit(default)!
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer track_mixing_depth - track mixing depth
-nil - 64bit float (default)
-1 - 32 bit float
-2 - 39 bit integer
-3 - 24 bit integer
-4 - 16 bit integer
-5 - 12 bit integer
-6 - 8 bit integer
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, track, mixing, depth
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  return tonumber(file:match("<REAPER_PROJECT.-INTMIXMODE%s(.-)%s.-<RENDER_CFG"))
end

--A=ultraschall.GetProject_TrackMixingDepth("c:\\tt.rpp")

function ultraschall.GetProject_TrackStateChunk(projectfilename_with_path,idx,deletetrackid)
-- returns a trackstatechunk from an rpp-projectfile
-- projectfilename_with_path - the projectfile
-- idx - the tracknumber you want to have
-- deletetrackid - deletes trackID, to avoid possible conflicts within a project, where it shall be imported to

--[[
<ApiDocBlocFunc>
<slug>
GetProject_TrackStateChunk
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
string trackstatechunk = ultraschall.GetProject_TrackStateChunk(string projectfilename_with_path, intger idx, boolean deletetrackid)
</functionname>
<description>
Returns an RPPXML-trackstatechunk from an rpp-project-file from tracknumber idx. IDX is 1 for the first track in the project-file, 2 for the second, etc
Returns -1 in case of error.

Use <a href="#GetProject_NumberOfTracks">GetProject_NumberOfTracks</a> to get the number of tracks within an rpp-file.

The returned trackstatechunk can be inserted into the current project with <a href="#InsertTrack_TrackStateChunk">InsertTrack_TrackStateChunk</a>.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer idx - the tracknumber you want to have
boolean deletetrackid - deletes the trackID in the trackstate-chunk, to avoid possible conflicts within a project, where it shall be imported to
</parameters>
<retvals>
string trackstatechunk - an RPP-XML-Trackstate-chunk, that can be used by functions like reaper.SetTrackStateChunk()
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, track, chunk, rppxml, trackstate, trackstatechunk
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local trackstate
  for i=1,idx do
    trackstate=file:match("<TRACK.-%c%s%s>%c")
    if trackstate==nil then break end
    file=file:match("<TRACK.-%c%s%s%s%s>%c(.*)")
  end
  if deletetrackid==true and trackstate~=nil then trackstate="<TRACK\n"..trackstate:match("%c(.*)")
    if trackstate:match("TRACKID")~=nil then trackstate=trackstate:match("(.-%c)%s-TRACKID")..trackstate:match("TRACKID.-%c(.*)") end
  end
--  reaper.MB(trackstate:match("TRACKID"),"",0)
--  trackstate=file:match("<ITEM.-%c%s%s%s%s>%c")
--  reaper.ClearConsole()
--  reaper.ShowConsoleMsg(tostring(trackstate))
  if trackstate==nil then return -1 end
  return trackstate
end

--A=ultraschall.GetProject_TrackStateChunk("c:\\tt.rpp",2,true)

function ultraschall.GetProject_NumberOfTracks(projectfilename_with_path)
--returns the number of tracks within an rpp-projectfile
--beware of files with thousands of items, as this can take ages or even leave Reaper hang!
--[[
<ApiDocBlocFunc>
<slug>
GetProject_NumberOfTracks
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_of_tracks = ultraschall.GetProject_NumberOfTracks(string projectfilename_with_path)
</functionname>
<description>
Returns the number of tracks within an rpp-project-file.
Returns -1 in case of error.

Note: Beware of files with thousands of items, as this can take ages or even leave Reaper to hang!
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
</parameters>
<retvals>
integer number_of_tracks - the number of tracks within an projectfile
</retvals>
<semanticcontext>
Project-Files
RPP-Files Get
</semanticcontext>
<tags>
projectfiles, rpp, state, get, track, count
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local count=0
  local trackstate=""
  while trackstate~=nil do
    trackstate=file:match("<TRACK.-%c%s%s>%c")
    if trackstate==nil then return count end
    count=count+1
--    reaper.ShowConsoleMsg(count.."\n")
    file=file:match("<TRACK.-%c%s%s%s%s>%c(.*)")
  end
  return count
end

--C=ultraschall.GetProject_NumberOfTracks("c:\\botz.RPP")

--MediaTrack=reaper.GetTrack(0,6)
--boolean=reaper.SetTrackStateChunk(MediaTrack, A, true)

--  reaper.ClearConsole()
--  reaper.ShowConsoleMsg(tostring(A))


function ultraschall.InsertTrack_TrackStateChunk(trackstatechunk)
--[[
<ApiDocBlocFunc>
<slug>
InsertTrack_TrackStateChunk
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval, MediaTrack MediaTrack = ultraschall.InsertTrack_TrackStateChunk(string trackstatechunk)
</functionname>
<description>
Creates a new track at the end of the project and sets it's trackstate, using the parameter trackstatechunk.
Returns, if it succeeded and the newly created MediaTrack.
</description>
<parameters>
string trackstatechunk - the rpp-xml-Trackstate-Chunk, as created by reaper.GetTrackStateChunk or <a href="#GetProject_TrackStateChunk">GetProject_TrackStateChunk</a>
</parameters>
<retvals>
boolean retval - if, if creation succeeded, false if not
MediaTrack MediaTrack - the newly created track, as MediaItem-trackobject
</retvals>
<semanticcontext>
Track Management
Assistance functions
</semanticcontext>
<tags>
trackstring, track, create, trackstate, trackstatechunk, chunk, state
</tags>
</ApiDocBlocFunc>
]]--
  if trackstatechunk==nil then return false end
  reaper.InsertTrackAtIndex(reaper.CountTracks(0), true)
  local MediaTrack=reaper.GetTrack(0,reaper.CountTracks(0)-1)
  local bool=reaper.SetTrackStateChunk(MediaTrack, trackstatechunk, true)
  if bool==false then reaper.DeleteTrack(MediaTrack) return false end
--reaper.UpdateArrange()
  return true, MediaTrack
end

--A=ultraschall.GetProject_TrackStateChunk("c:\\tt.rpp",3,true)
--B,B2=ultraschall.InsertTrack_TrackStateChunk(A)
--- Set ---

function ultraschall.SetProject_RippleState(projectfilename_with_path, state)
-- Set RippleState in a projectfilename_with_path
--  0 - no Ripple, 1 - Ripple One Track, 2 - Ripple All
--[[
<ApiDocBlocFunc>
<slug>
SetProject_RippleState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RippleState(string projectfilename_with_path, integer state)
</functionname>
<description>
Sets the ripple-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer state - 0 - no Ripple, 1 - Ripple One Track, 2 - Ripple All
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, ripple, all, one
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
--  if tonumber(state)<0 or tonumber(state)>2 then return -1 end
  if tonumber(state)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RIPPLE%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RIPPLE%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state).."\n"..FileEnd)
end

--ABB=ultraschall.SetProject_RippleState("c:\\tt.rpp",1)
--AB=ultraschall.GetProject_RippleState("c:\\tt.rpp")
--reaper.ShowConsoleMsg(A)

function ultraschall.SetProject_GroupOverride(projectfilename_with_path, state1, state2, state3)
-- Sets Group Override
-- integer state1 - 
-- integer state2 - 
-- integer state3 - 
--[[
<ApiDocBlocFunc>
<slug>
SetProject_GroupOverride
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_GroupOverride(string projectfilename_with_path, integer group_override1)
</functionname>
<description>
Sets the group-override-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer group_override1 - the group-override state
integer group_override2 - the group-override state
integer group_override3 - the group-override state
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, group, override
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(state1)==nil then return -1 end
  if tonumber(state2)==nil then return -1 end
  if tonumber(state3)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-GROUPOVERRIDE%s).-%s.-%s.-%s.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-GROUPOVERRIDE%s.-%s.-%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state1).." "..tonumber(state2).." "..tonumber(state3).."\n"..FileEnd)
end

--A,AA,AAA=ultraschall.SetProject_GroupOverride("c:\\tt.rpp","1","2","3")
--A,AA,AAA=ultraschall.GetProject_GroupOverride("c:\\tt.rpp")

function ultraschall.SetProject_AutoCrossFade(projectfilename_with_path, state)
-- sets AutoCrossFade in a projectfilename_with_path
-- integer state
--[[
<ApiDocBlocFunc>
<slug>
SetProject_AutoCrossFade
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_AutoCrossFade(string projectfilename_with_path, integer autocrossfade_state)
</functionname>
<description>
Sets the autocrossfade-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer autocrossfade_state - autocrossfade-state
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, autocrossfade, crossfade
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(state)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-AUTOXFADE%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-AUTOXFADE%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state).."\n"..FileEnd)
end

--A=ultraschall.SetProject_AutoCrossFade("c:\\tt.rpp","9")
--A=ultraschall.GetProject_AutoCrossFade("c:\\tt.rpp")
--reaper.ShowConsoleMsg(A)

function ultraschall.SetProject_EnvAttach(projectfilename_with_path, state)
-- sets Enc Attach
-- integer state - 
--[[
<ApiDocBlocFunc>
<slug>
SetProject_EnvAttach
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_EnvAttach(string projectfilename_with_path, integer env_attach)
</functionname>
<description>
Sets the env_attach-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer env_attach  - env_attach-state
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, env, attach, envattach
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(state)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-ENVATTACH%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-ENVATTACH%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state).."\n"..FileEnd)
end

--A=ultraschall.SetProject_EnvAttach("c:\\tt.rpp","2")
--A=ultraschall.GetProject_EnvAttach("c:\\tt.rpp")

function ultraschall.SetProject_MixerUIFlags(projectfilename_with_path, state_bitfield1, state_bitfield2)
--integer state_bitfield1 
--         0 - Show tracks in folders, Auto arrange tracks in mixer
--         1 - Show normal top level tracks
--         2 - Show Folders
--         4 - Group folders to left
--         8 - Show tracks that have receives
--         16 - Group tracks that have receives to left
--         32 - don't show tracks that are in folder
--         64 - No Autoarrange tracks in mixer
--         128 - ?
--         256 - ?

--integer state_bitfield2 
--         0 - Master track in mixer
--         1 - Don't show multiple rows of tracks, when size permits
--         2 - Show maximum rows even when tracks would fit in less rows
--         4 - Master Show on right side of mixer
--         8 - ?
--         16 - Show FX inserts when size permits
--         32 - Show sends when size permits
--         64 - Show tracks in mixer
--         128 - Show FX parameters, when size permits
--         256 - Don't show Master track in mixer

--[[
<ApiDocBlocFunc>
<slug>
SetProject_MixerUIFlags
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer state_bitfield1, integer state_bitfield2 = ultraschall.SetProject_MixerUIFlags(string projectfilename_with_path, integer state_bitfield1, integer state_bitfield2)
</functionname>
<description>
Sets the Mixer-UI-state-flags in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer state1 - folders, receives, etc 
-             0 - Show tracks in folders, Auto arrange tracks in mixer
-             1 - Show normal top level tracks
-             2 - Show Folders
-             4 - Group folders to left
-             8 - Show tracks that have receives
-             16 - Group tracks that have receives to left
-             32 - don't show tracks that are in folder
-             64 - No Autoarrange tracks in mixer
-             128 - ?
-             256 - ?

integer state2 - master-track, FX, Mixer
-             0 - Master track in mixer
-             1 - Don't show multiple rows of tracks, when size permits
-             2 - Show maximum rows even when tracks would fit in less rows
-             4 - Master Show on right side of mixer
-             8 - ?
-             16 - Show FX inserts when size permits
-             32 - Show sends when size permits
-             64 - Show tracks in mixer
-             128 - Show FX parameters, when size permits
-             256 - Don't show Master track in mixer
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, mixer, ui, flags, folders, tracks, master, fx, groups
</tags>
</ApiDocBlocFunc>
]]         
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  if tonumber(state_bitfield1)==nil then return -1 end
  if tonumber(state_bitfield2)==nil then return -1 end
  local FileStart=file:match("(<REAPER_PROJECT.-MIXERUIFLAGS%s).-%s.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-MIXERUIFLAGS%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state_bitfield1).." "..tonumber(state_bitfield2).."\n"..FileEnd)
end

--A,AA=ultraschall.SetProject_MixerUIFlags("c:\\tt.rpp", "2", "4")
--A,AA=ultraschall.GetProject_MixerUIFlags("c:\\tt.rpp")

function ultraschall.SetProject_PeakGain(projectfilename_with_path, state)
-- number state - 
--[[
<ApiDocBlocFunc>
<slug>
SetProject_PeakGain
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_PeakGain(string projectfilename_with_path, number peakgain_state)
</functionname>
<description>
Sets the peak-gain-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
number peakgain_state  - peak-gain-state
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, peak, gain, peakgain
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(state)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-PEAKGAIN%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-PEAKGAIN%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state).."\n"..FileEnd)
end

--A=ultraschall.SetProject_PeakGain("c:\\tt.rpp", "1.9")
--A=ultraschall.GetProject_PeakGain("c:\\tt.rpp")

function ultraschall.SetProject_Feedback(projectfilename_with_path, state)
-- integer state - 
--[[
<ApiDocBlocFunc>
<slug>
SetProject_Feedback
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_Feedback(string projectfilename_with_path, integer feedback_state)
</functionname>
<description>
Sets the feedback-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer feedback-state - feedback-state
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, feedback
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(state)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-FEEDBACK%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-FEEDBACK%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state).."\n"..FileEnd)
end

--A=ultraschall.SetProject_Feedback("c:\\tt.rpp", "2")
--A=ultraschall.GetProject_Feedback("c:\\tt.rpp", 0)

function ultraschall.SetProject_PanLaw(projectfilename_with_path, state)
-- number state - as set in the project-settings->Advanced->Pan law/mode->Pan:law(db)
--                0.5(-6.02 db) to 1(default +0.0 db)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_PanLaw
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_PanLaw(string projectfilename_with_path, number panlaw_state)
</functionname>
<description>
Sets the panlaw-state, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
number panlaw_state - state of the panlaw, as set in the project-settings->Advanced->Pan law/mode->Pan:law(db). 0.5(-6.02 db) to 1(default +0.0 db)
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, pan, law, pan law
</tags>
</ApiDocBlocFunc>
]]  
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(state)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-PANLAW%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-PANLAW%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state).."\n"..FileEnd)
end

--A=ultraschall.SetProject_PanLaw("c:\\tt.rpp","2")
--A=ultraschall.GetProject_PanLaw("c:\\tt.rpp")

function ultraschall.SetProject_ProjOffsets(projectfilename_with_path, state1, state2)
-- number state1
-- integer state2
--[[
<ApiDocBlocFunc>
<slug>
SetProject_ProjOffsets
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_ProjOffsets(string projectfilename_with_path, number start_time, integer start_measure)
</functionname>
<description>
Sets the project-offset-state, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
number start_time - the project-start-time in seconds
integer start_measure - starting with 0, unlike the Settingswindow, where the 0 becomes 1 as measure
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, project, offset, start, starttime, measure
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  if tonumber(state1)==nil then return -1 end
  if tonumber(state2)==nil then return -1 end
  local FileStart=file:match("(<REAPER_PROJECT.-PROJOFFS%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-PROJOFFS%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state1).." "..tonumber(state2).."\n"..FileEnd)         
end

--A,AA=ultraschall.SetProject_ProjOffsets("c:\\tt.rpp", 0,-1)
--A,AA=ultraschall.SetProject_ProjOffsets("c:\\tt.rpp", "8","4")
--A,AA=ultraschall.GetProject_ProjOffsets("c:\\tt.rpp")

--

function ultraschall.SetProject_MaxProjectLength(projectfilename_with_path, state1, state2)
-- integer state1 - 
-- number state 2 - 
--[[
<ApiDocBlocFunc>
<slug>
SetProject_MaxProjectLength
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_MaxProjectLength(string projectfilename_with_path, integer limit_project_length, number projectlength_limit)
</functionname>
<description>
Sets the max-project-length-state, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer limit_project_length - checkbox "Limit project length, stop playback/recording at:" - 0 off, 1 on
number projectlength_limit - projectlength-limit in seconds
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, project, end, length, limit
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(state1)==nil then return -1 end
  if tonumber(state2)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-MAXPROJLEN%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-MAXPROJLEN%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state1).." "..tonumber(state2).."\n"..FileEnd)         
end

--A,AA=ultraschall.SetProject_MaxProjectLength("c:\\tt.rpp","4","5")
--A,AA=ultraschall.GetProject_MaxProjectLength("c:\\tt.rpp",1,2)

function ultraschall.SetProject_Grid(projectfilename_with_path, state1, state2, state3, state4, state5, state6, state7, state8)
-- integer state1 - 
-- integer state2 - 
-- number state3 - 
-- integer state4 -
-- number state5 -
-- integer state6 -
-- integer state7 -
-- number state8 - 

--[[
<ApiDocBlocFunc>
<slug>
SetProject_Grid
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_Grid(string projectfilename_with_path, integer gridstate1, integer gridstate2, number gridstate3, integer gridstate4, number gridstate5, integer gridstate6, integer gridstate7, number gridstate8)
</functionname>
<description>
Sets the setproject-grid-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer gridstate1 - gridstate1
integer gridstate2 - gridstate2
number gridstate3 - gridstate3
integer gridstate4 - gridstate4
number gridstate5 - gridstate5
integer gridstate6 - gridstate6
integer gridstate7 - gridstate7
number gridstate8 - gridstate8
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, grid
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  if tonumber(state1)==nil then return -1 end
  if tonumber(state2)==nil then return -1 end
  if tonumber(state3)==nil then return -1 end
  if tonumber(state4)==nil then return -1 end
  if tonumber(state5)==nil then return -1 end
  if tonumber(state6)==nil then return -1 end
  if tonumber(state7)==nil then return -1 end
  if tonumber(state8)==nil then return -1 end
  local FileStart=file:match("(<REAPER_PROJECT.-GRID%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-GRID%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state1).." "..tonumber(state2).." "..tonumber(state3).." "..tonumber(state4).." "..tonumber(state5).." "..tonumber(state6).." "..tonumber(state7).." "..tonumber(state8).."\n"..FileEnd)
end

--A=ultraschall.SetProject_Grid("c:\\tt.rpp","2","3","4","5","6","7","2","3")
--A,A1,A2,A3,A4,A5,A6,A7,A8,A9=ultraschall.GetProject_Grid("c:\\tt.rpp")

function ultraschall.SetProject_Timemode(projectfilename_with_path, state1, state2, showntime, state4, state5)
-- integer state1
-- integer state2
-- integer showntime - Transport shown time
--      -1 - use ruler time unit
--       0 - minutes:seconds
--       1 - measures:beats/minutes:seconds
--       2 - measures:beats
--       3 - seconds
--       4 - samples
--       5 - hours:minutes:seconds:frames
--       8 - absolute frames
-- integer state4
-- integer state5

--[[
<ApiDocBlocFunc>
<slug>
SetProject_Timemode
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_Timemode(string projectfilename_with_path, integer timemode1, integer timemode2, integer showntime, integer timemode4, integer timemode5)
</functionname>
<description>
Sets the timemode-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - the filename of the projectfile
integer timemode1 - timemode-state
integer timemode2 - timemode-state
integer showntime - Transport shown time
-              -1 - use ruler time unit
-              0 - minutes:seconds
-              1 - measures:beats/minutes:seconds
-              2 - measures:beats
-              3 - seconds
-              4 - samples
-              5 - hours:minutes:seconds:frames
-              8 - absolute frames
integer timemode4 - timemode-state
integer timemode5 - timemode-state
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, timemode
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  if tonumber(state1)==nil then return -1 end
  if tonumber(state2)==nil then return -1 end
  if tonumber(showntime)==nil then return -1 end
  if tonumber(state4)==nil then return -1 end
  if tonumber(state5)==nil then return -1 end
  local FileStart=file:match("(<REAPER_PROJECT.-TIMEMODE%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-TIMEMODE%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state1).." "..tonumber(state2).." "..tonumber(showntime).." "..tonumber(state4).." "..tonumber(state5).."\n"..FileEnd)         
end

--A=ultraschall.SetProject_Timemode("c:\\tt.rpp")
--A,A2,A3,A4,A5=ultraschall.GetProject_Timemode("c:\\tt.rpp",1,2,3,4,5)
--A,A2,A3,A4,A5=ultraschall.SetProject_Timemode("c:\\tt.rpp","1","2","3","4","5")
--A,A2,A3,A4,A5=ultraschall.GetProject_Timemode("c:\\tt.rpp",1,2,3,4,5)

function ultraschall.SetProject_VideoConfig(projectfilename_with_path, preferredVidSizeX, preferredVidSizeY, settingsBitfield)
-- integer preferredVidSizeX - preferred video size, x pixels
-- integer preferredVidSizeY - preferred video size, y pixels
-- integer settingsBitfield3 - settings
--              0 - turned on/selected: use high quality filtering, 
--                      preserve aspect ratio(letterbox) when resizing, Items in higher numbered tracks replace lower,
--                      as well as Video colorspace set to Auto
--              1 - Video colorspace: I420/YV12
--              2 - Video colorspace: YUV2
--              3 - RGB
--              256 - Items in lower numbered tracks replace higher
--              512 - Always resize video sources to preferred video size
--              1024 - Always resize output to preferred video size
--              2048 - turn off "Use high quality filtering when resizing"
--              4096 - turn off "preserve aspect ratio (letterbox) when resizing"
--[[
<ApiDocBlocFunc>
<slug>
SetProject_VideoConfig
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_VideoConfig(string projectfilename_with_path, integer preferredVidSizeX, integer preferredVidSizeY, integer settingsflags)
</functionname>
<description>
Sets the video-config-settings, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer preferredVidSizeX - preferred video size, x pixels
integer preferredVidSizeY - preferred video size, y pixels
integer settingsflags - settings
-             0 - turned on/selected: use high quality filtering, preserve aspect ratio(letterbox) when resizing, 
- Items in higher numbered tracks replace lower, as well as Video colorspace set to Auto
-             1 - Video colorspace: I420/YV12
-             2 - Video colorspace: YUV2
-             3 - RGB
-             256 - Items in lower numbered tracks replace higher
-             512 - Always resize video sources to preferred video size
-             1024 - Always resize output to preferred video size
-             2048 - turn off "Use high quality filtering when resizing"
-             4096 - turn off "preserve aspect ratio (letterbox) when resizing"
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, video, videoconfig
</tags>
</ApiDocBlocFunc>
]]         
         if projectfilename_with_path==nil then return -1 end
         if reaper.file_exists(projectfilename_with_path)==false then return -1 end
         if tonumber(preferredVidSizeX)==nil then return -1 end
         if tonumber(preferredVidSizeY)==nil then return -1 end
         if tonumber(settingsBitfield)==nil then return -1 end         
         local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
         local FileStart=file:match("(<REAPER_PROJECT.-VIDEO_CONFIG%s).-%c.-<RECORD_CFG.*")
         local FileEnd=file:match("<REAPER_PROJECT.-VIDEO_CONFIG%s.-%c(.-<RECORD_CFG.*)")
         return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(preferredVidSizeX).." "..tonumber(preferredVidSizeY).." "..tonumber(settingsBitfield).."\n"..FileEnd)         
end

--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA,AAAAAAAAA=ultraschall.SetProject_VideoConfig("c:\\tt.rpp","5","6","7")
--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA,AAAAAAAAA=ultraschall.SetProject_VideoConfig("c:\\tt.rpp")
--A,AA,AAA=ultraschall.GetProject_VideoConfig("c:\\tt.rpp",1,2,3)

function ultraschall.SetProject_PanMode(projectfilename_with_path, state)
-- Panmode as set in ProjectSettings->Advanced->Pan law/mode->Pan mode
-- integer state - 3 Stereo balance / mono pan (default)
--                 5 Stereo pan
--                 6 Dual Pan
--                 0 reaper 3.x balance (deprecated)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_PanMode
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_PanMode(string projectfilename_with_path, integer panmode_state)
</functionname>
<description>
Sets the panmode-settings, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer panmode_state - panmode-state - ProjectSettings->Advanced->Pan law/mode->Pan mode
-             0 reaper 3.x balance (deprecated)
-             3 Stereo balance / mono pan (default)
-             5 Stereo pan
-             6 Dual Pan
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, panmode
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(state)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-PANMODE%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-PANMODE%s.-%c(.-<RECORD_CFG.*)")
  if FileStart==nil or FileEnd==nil then 
    FileStart=file:match("(<REAPER_PROJECT.-)CURSOR.-<RECORD_CFG.*")
    FileEnd="  "..file:match("<REAPER_PROJECT.-(CURSOR.-<RECORD_CFG.*)")
      state="PANMODE "..tostring(state)
  end
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state).."\n"..FileEnd)         
end

--A=ultraschall.SetProject_PanMode("c:\\tt.rpp", 0)
--A=ultraschall.SetProject_PanMode("c:\\tt.rpp", "99")
--A=ultraschall.GetProject_PanMode("c:\\tt.rpp", 0)

function ultraschall.SetProject_CursorPos(projectfilename_with_path, timeposition)
-- number timeposition - in seconds
--[[
<ApiDocBlocFunc>
<slug>
SetProject_CursorPos
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_CursorPos(string projectfilename_with_path, number cursorpos)
</functionname>
<description>
Sets the cursor-position in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
number cursorpos - editcursorposition in seconds
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, cursor, position, cursorposition, editcursor, edit
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if tonumber(timeposition)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-CURSOR%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-CURSOR%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(timeposition).."\n"..FileEnd)         
end

--A=ultraschall.SetProject_CursorPos("c:\\tt.rpp")
--A=ultraschall.SetProject_CursorPos("c:\\tt.rpp","9")
--A=ultraschall.GetProject_CursorPos("c:\\tt.rpp",1.954658736589369)

function ultraschall.SetProject_HorizontalZoom(projectfilename_with_path, HZoomfactor, HScrollbarPos, Scrollbarfactor)
-- number HZoomfactor - 0.007 to 1000000, horizontal zoom factor
-- integer HScrollbarPos - 0 - 4294967296; horizontal scrollbar position
-- integer Scrollbarfactor - 0 to 500837, counts up, when maximum HScrollbarPos overflows
--[[
<ApiDocBlocFunc>
<slug>
SetProject_HorizontalZoom
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_HorizontalZoom(string projectfilename_with_path, number hzoom, integer hzoomscrollpos, integer scrollbarfactor)
</functionname>
<description>
Sets the horizontal-zoom in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
number hzoom - HorizontalZoomfactor, 0.007 to 1000000
integer hzoomscrollpos - horizontalscrollbarposition - 0 - 4294967296
integer scrollbarfactor - 0 to 500837, counts up, when maximum hzoomscrollpos overflows
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, zoom, horizontal, scrollbar, factor
</tags>
</ApiDocBlocFunc>
]]         
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(HZoomfactor)==nil then return -1 end
  if tonumber(HScrollbarPos)==nil then return -1 end
  if tonumber(Scrollbarfactor)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-ZOOM%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-ZOOM%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(HZoomfactor).." "..tonumber(HScrollbarPos).." "..tonumber(Scrollbarfactor).."\n"..FileEnd)                  
end

--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA,AAAAAAAAA=ultraschall.SetProject_Zoom("c:\\tt.rpp")
--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA,AAAAAAAAA=ultraschall.SetProject_HorizontalZoom("c:\\tt.rpp","10","11","12")
--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA,AAAAAAAAA=ultraschall.GetProject_HorizontalZoom("c:\\tt.rpp",10,11,12)

function ultraschall.SetProject_VerticalZoom(projectfilename_with_path, verticalzoom)
--integer verticalzoom - 0-40; zoomfactor for vertical zoom
--[[
<ApiDocBlocFunc>
<slug>
SetProject_VerticalZoom
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_VerticalZoom(string projectfilename_with_path, integer vzoom)
</functionname>
<description>
Sets the vertical-zoom from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer vzoom - vertical zoomfactor(0-40)
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, zoom, vertical, scrollbar, factor
</tags>
</ApiDocBlocFunc>
]]         
  if projectfilename_with_path==nil then return -1 end
  if tonumber(verticalzoom)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-VZOOMEX%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-VZOOMEX%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(verticalzoom).."\n"..FileEnd)   
end

--A=ultraschall.SetProject_VerticalZoom("c:\\tt.rpp","17")
--A=ultraschall.SetProject_VerticalZoom("c:\\tt.rpp","a")
--A=ultraschall.GetProject_VerticalZoom("c:\\tt.rpp",10)

function ultraschall.SetProject_UseRecConfig(projectfilename_with_path, reccfgnr)
--
--[[
<ApiDocBlocFunc>
<slug>
SetProject_UseRecConfig
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_UseRecConfig(string projectfilename_with_path, integer rec_cfg)
</functionname>
<description>
Sets the UseRec-Config in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer rec_cfg - recording-cfg-state
-              0 - Automatic .wav (recommended)
-              1 - Custom (use ultraschall.GetProject_ApplyFXCFG to get recording_cfg_string)
-              2 - Recording Format
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, recording, rec, config
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if tonumber(reccfgnr)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-USE_REC_CFG%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-USE_REC_CFG%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(reccfgnr).."\n"..FileEnd)
end

--A=ultraschall.SetProject_UseRecConfig("c:\\tt.rpp", "10")
--A=ultraschall.GetProject_UseRecConfig("c:\\tt.rpp", 0)

function ultraschall.SetProject_RecMode(projectfilename_with_path, recmode)
--returns Recording Mode
-- 0 - Autopunch/Selected Items
-- 1 - normal
-- 2 - Time Selection/Auto Punch

--[[
<ApiDocBlocFunc>
<slug>
SetProject_RecMode
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RecMode(string projectfilename_with_path, integer rec_mode)
</functionname>
<description>
Sets the recording-mode-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer loop_mode - loopbutton-state, 0 - off, 1 - on
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, recording, rec, mode
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if tonumber(recmode)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RECMODE%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RECMODE%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(recmode).."\n"..FileEnd)
end

--A=ultraschall.SetProject_RecMode("c:\\tt.rpp","7")
--A=ultraschall.GetProject_RecMode("c:\\tt.rpp",1)

function ultraschall.SetProject_SMPTESync(projectfilename_with_path, state1, state2, state3, state4, state5, state6, state7, state8, state9, state10, state11)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_SMPTESync
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_SMPTESync(string projectfilename_with_path, integer smptesync_state1, number smptesync_fps, integer smptesync_resyncdrift, integer smptesync_skipdropframes, integer smptesync_syncseek, integer smptesync_freewheel, integer smptesync_userinput, number smptesync_offsettimecode, integer smptesync_stop_rec_drift, integer smptesync_state10, integer smptesync_stop_rec_lacktime)
</functionname>
<description>
Sets the TimeCodeSyncronization-SMPTE-Config in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer smptesync_state1 - flag 
-             0 - external timecode synchronization disabled
-             1 - external timecode synchronization enabled
-             4 - Start playback on valid timecode when stopped
-             8 - turned off: display flashing notification window when waiting for sync for recording
-             16 - playback off
-             32 - recording off
-             256 - MTC - 24/30fps MTC is 23.976/29.97ND works only with smptesync_userinput set to 4159
-             512 - MTC - 24/30fps MTC is 24/30ND

number smptesync_fps - framerate in fps
integer smptesync_resyncdrift - "Re-synchronize if drift exceeds" in ms (0 = never)
integer smptesync_skipdropframes - "skip/drop frames if drift exceeds" in ms(0 - never)
integer smptesync_syncseek - "Synchronize by seeking ahead" in ms (default = 1000)
integer smptesync_freewheel - "Freewheel on missing time code for up to" in ms(0 = forever)
integer smptesync_userinput - User Input-flag
-             0 - LTC: Input 1
-             1 - LTC: Input 2
-             4159 - MTC - All inputs - 24/30 fps MTC 23.976ND/29.97ND if project is ND
-             4223 - SPP: All Inputs
-             8192 - ASIO Positioning Protocol

number smptesync_offsettimecode - Offset incoming timecode by in seconds
integer smptesync_stop_rec_drift - "Stop recording if drift exceeds" in ms(0 = never)
integer smptesync_state10 - smptesync-state
integer smptesync_stop_rec_lacktime - "stop recording on lack of timecode after" in ms(0 = never)
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, smpte, sync
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if tonumber(state1)==nil then return -1 end
  if tonumber(state2)==nil then return -1 end
  if tonumber(state3)==nil then return -1 end
  if tonumber(state4)==nil then return -1 end
  if tonumber(state5)==nil then return -1 end
  if tonumber(state6)==nil then return -1 end
  if tonumber(state7)==nil then return -1 end
  if tonumber(state8)==nil then return -1 end
  if tonumber(state9)==nil then return -1 end
  if tonumber(state10)==nil then return -1 end
  if tonumber(state11)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-SMPTESYNC%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-SMPTESYNC%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..state1.." "..state2.." "..state3.." "..state4.." "..state5.." "..state6.." "..state7.." "..state8.." "..state9.." "..state10.." "..state11.."\n"..FileEnd)
end

--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA,AAAAAAAAA,AL,AM=ultraschall.SetProject_SMPTESync("c:\\tt.rpp","1","2","3","4","5","6","7","8","9","10","11")
--A,AA,AAA,AAAA,AAAAA,AAAAAA,AAAAAAA,AAAAAAAA,AAAAAAAAA,AL,AM=ultraschall.GetProject_SMPTESync("c:\\tt.rpp",1,2,3,4,5,6,7,8,9,10,11)

function ultraschall.SetProject_Loop(projectfilename_with_path, LoopMode)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_Loop
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_Loop(string projectfilename_with_path, integer loopbutton_state)
</functionname>
<description>
Sets the UseRec-Config in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer loop_mode - loopbutton-state, 0 - off, 1 - on
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, loop, button
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if tonumber(LoopMode)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-LOOP%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-LOOP%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(LoopMode).."\n"..FileEnd)
end

--A=ultraschall.SetProject_Loop("c:\\tt.rpp","10")
--A=ultraschall.GetProject_Loop("c:\\tt.rpp",1)

function ultraschall.SetProject_LoopGran(projectfilename_with_path, state1, state2)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_LoopGran
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_LoopGran(string projectfilename_with_path, integer loopgran_state1, number loopgran_state2)
</functionname>
<description>
Sets the Loop-Gran-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer loopgran_state1 - loopgran_state1
number loopgran_state2 - loopgran_state2
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, loop, gran
</tags>
</ApiDocBlocFunc>
]]         
  if projectfilename_with_path==nil then return -1 end
  if tonumber(state1)==nil then return -1 end
  if tonumber(state2)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-LOOPGRAN%s).-%c.-<RECORD_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-LOOPGRAN%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state1).." "..tonumber(state2).."\n"..FileEnd)
end

--A,AA=ultraschall.SetProject_LoopGran("c:\\tt.rpp","3","6")
--A,AA=ultraschall.GetProject_LoopGran("c:\\tt.rpp",1,2)

function ultraschall.SetProject_RecPath(projectfilename_with_path, recpath, recpath_secondary)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_RecPath
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RecPath(string projectfilename_with_path, string prim_recpath, string sec_recpath)
</functionname>
<description>
Sets the primary and secondary recording-paths in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string prim_recpath - primary recording path
string sec_recpath - secondary recording path
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, recording, path, primary, secondary
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if recpath==nil then return -1 end
  if recpath_secondary==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  FileStart=file:match("(<REAPER_PROJECT.-RECORD_PATH%s).-%c.-<RECORD_CFG.*")
  FileEnd=file:match("<REAPER_PROJECT.-RECORD_PATH%s.-%c(.-<RECORD_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart.."\""..recpath.."\" \""..recpath_secondary.."\"\n"..FileEnd)
end

--A,AA=ultraschall.SetProject_RecPath("c:\\tt.rpp","test","test2")


function ultraschall.SetProject_RecordCFG(projectfilename_with_path, state)
--To Do: Research
-- ProjectSettings->Media->Recording
-- recording-cfg-string

--[[
<ApiDocBlocFunc>
<slug>
SetProject_RecordCFG
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RecordCFG(string projectfilename_with_path, string recording_cfg_string)
</functionname>
<description>
Sets the recording-configuration as encoded string in an RPP-Projectfile, as set in ProjectSettings->Media->Recording.

Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
recording_cfg_string - the record-configuration as encoded string
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, recording, configuration
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if state==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RECORD_CFG%c%s*).-%c.-RENDER_FILE.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RECORD_CFG%c%s*.-(%c.-RENDER_FILE.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..state..FileEnd)

  --if projectfilename_with_path==nil then return nil end
  --if reaper.file_exists(projectfilename_with_path)==false then return nil end
 -- local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
--    return file:match("<REAPER_PROJECT.-RECORD_CFG%c%s*(.-)%c.-RENDER_FILE")
end

--A=ultraschall.SetProject_RecordCFG("c:\\tt.rpp", "Hubbelbubbel==")
--A=ultraschall.GetProject_RecordCFG("c:\\tt.rpp")

function ultraschall.SetProject_ApplyFXCFG(projectfilename_with_path, state)
--To Do: Research
-- ProjectSettings->Media->Format for Apply FX, Glue, Freeze, etc
-- recording_cfg-string
--[[
<ApiDocBlocFunc>
<slug>
SetProject_ApplyFXCFG
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_ApplyFXCFG(string projectfilename_with_path, string applyfx_cfg_string)
</functionname>
<description>
Sets the audioformat-configuration, for fx-appliance-operation, as an encoded string in an RPP-Projectfile, as set in ProjectSettings->Media->Format for Apply FX, Glue, Freeze, etc

Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string applyfx_cfg_string - the file-format-configuration for fx-appliance as encoded string
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, fx, configuration
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if state==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-APPLYFX_CFG%c%s*).-%c.-RENDER_FILE.*")
  local FileEnd=file:match("<REAPER_PROJECT.-APPLYFX_CFG%c%s*.-(%c.-RENDER_FILE.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..state..FileEnd)
  
--  if projectfilename_with_path==nil then return nil end
 -- if reaper.file_exists(projectfilename_with_path)==false then return nil end
  --local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
   -- return file:match("<REAPER_PROJECT.-APPLYFX_CFG%c%s*(.-)%c.-RENDER_FILE")
end

--A=ultraschall.SetProject_ApplyFXCFG("c:\\tt.rpp","nilfluss")
--A=ultraschall.GetProject_ApplyFXCFG("c:\\tt.rpp")

function ultraschall.SetProject_RenderFilename(projectfilename_with_path, renderfilename)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_RenderFilename
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RenderFilename(string projectfilename_with_path, string renderfilename)
</functionname>
<description>
Sets the render-filename in an rpp-projectfile. Set to "", if you want to set a render-pattern with <a href="#SetProject_RenderPattern">SetProject_RenderPattern</a>.

Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string render_filename - the filename for rendering, check also <a href="#GetProject_RenderPattern">GetProject_RenderPattern</a>
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, recording, path, render filename, filename, render
</tags>
</ApiDocBlocFunc>
]]  
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if renderfilename==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RENDER_FILE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RENDER_FILE%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart.."\""..renderfilename.."\" \n"..FileEnd)
end

--A=ultraschall.SetProject_RenderFilename("c:\\tt.rpp")
--A=ultraschall.SetProject_RenderFilename("c:\\tt.rpp", "c:\\testname.ext")
--A=ultraschall.GetProject_RenderFilename("c:\\tt.rpp", "c:\\testname.ext")


function ultraschall.SetProject_RenderPattern(projectfilename_with_path, renderpattern)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_RenderPattern
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RenderPattern(string projectfilename_with_path, string render_pattern)
</functionname>
<description>
Sets the render-filename in an rpp-projectfile. Set it to "", if you want to set the render-filename with <a href="#SetProject_RenderFilename">SetProject_RenderFilename</a>.

Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string render_pattern - the pattern, with which the rendering-filename will be automatically created. Check also <a href="#GetProject_RenderFilename">GetProject_RenderFilename</a>
-Capitalizing the first character of the wildcard will capitalize the first letter of the substitution. 
-Capitalizing the first two characters of the wildcard will capitalize all letters.
-
-Directories will be created if necessary. For example if the render target is "$project/track", the directory "$project" will be created.
-
-$item    media item take name, if the input is a media item
-$itemnumber  1 for the first media item on a track, 2 for the second...
-$track    track name
-$tracknumber  1 for the first track, 2 for the second...
-$parenttrack  parent track name
-$region    region name
-$regionnumber  1 for the first region, 2 for the second...
-$namecount  1 for the first item or region of the same name, 2 for the second...
-$start    start time of the media item, render region, or time selection
-$end    end time of the media item, render region, or time selection
-$startbeats  start time in beats of the media item, render region, or time selection
-$endbeats  end time in beats of the media item, render region, or time selection
-$timelineorder  1 for the first item or region on the timeline, 2 for the second...
-$project    project name
-$tempo    project tempo at the start of the render region
-$timesignature  project time signature at the start of the render region, formatted as 4-4
-$filenumber  blank (optionally 1) for the first file rendered, 1 (optionally 2) for the second...
-$filenumber[N]  N for the first file rendered, N+1 for the second...
-$note    C0 for the first file rendered,C#0 for the second...
-$note[X]    X (example: B2) for the first file rendered, X+1 (example: C3) for the second...
-$natural    C0 for the first file rendered, D0 for the second...
-$natural[X]  X (example: F2) for the first file rendered, X+1 (example: G2) for the second...
-$format    render format (example: wav)
-$samplerate  sample rate (example: 44100)
-$sampleratek  sample rate (example: 44.1)
-$year    year
-$year2    last 2 digits of the year
-$month    month number
-$monthname  month name
-$day    day of the month
-$hour    hour of the day in 24-hour format
-$hour12    hour of the day in 12-hour format
-$ampm    am if before noon,pm if after noon
-$minute    minute of the hour
-$second    second of the minute
-$user    user name
-$computer  computer name
-
-(this description has been taken from the Render Wildcard Help within the Render-Dialog of Reaper)
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, recording, render pattern, filename, render
</tags>
</ApiDocBlocFunc>
]]  
  if projectfilename_with_path==nil then return false end
  if reaper.file_exists(projectfilename_with_path)==false then return false end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  FileStart=file:match("(<REAPER_PROJECT.-RENDER_PATTERN%s).-%c.-<RENDER_CFG.*")
  FileEnd=file:match("<REAPER_PROJECT.-RENDER_PATTERN%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart.."\""..renderpattern.."\" \n"..FileEnd)
end

--A=ultraschall.SetProject_RenderPattern("c:\\tt.rpp", "testofon")
--A=ultraschall.GetProject_RenderPattern("c:\\tt.rpp")


function ultraschall.SetProject_RenderFreqNChans(projectfilename_with_path, state1, numchans, renderfreq)
-- returns an unknown number, Number_Channels(0-default) and RenderFrequency(0-default)
-- Number_Channels 0-seems default-project-settings(?), 1-Mono, 2-Stereo, ... up to 64 channels
-- RenderFrequency -2147483647 to 2147483647, except 0, which seems to be default-project-settings-frequency
--[[
<ApiDocBlocFunc>
<slug>
SetProject_RenderFreqNChans
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RenderFreqNChans(string projectfilename_with_path, integer unknown, integer rendernum_chans, integer render_frequency)
</functionname>
<description>
Returns an unknown number, the render-frequency and rendernumber of channels from an RPP-Projectfile. 

Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer unknown - unknown number
integer rendernum_chans - Number_Channels 0-seems default-project-settings(?), 1-Mono, 2-Stereo, ... up to 64 channels
integer render_frequency - RenderFrequency -2147483647 to 2147483647, except 0, which seems to be default-project-settings-frequency
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, render, frequency, num channels, channels
</tags>
</ApiDocBlocFunc>
]]           
  if projectfilename_with_path==nil then return -1 end
  if tonumber(state1)==nil then return -1 end
  if tonumber(numchans)==nil then return -1 end
  if tonumber(renderfreq)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RENDER_FMT%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RENDER_FMT%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(state1).." "..tonumber(numchans).." "..tonumber(renderfreq).." \n"..FileEnd)         
end

--A,AA,AAA=ultraschall.SetProject_RenderFreqNChans("c:\\tt.rpp","55","66","77")
--A,AA,AAA=ultraschall.GetProject_RenderFreqNChans("c:\\tt.rpp",1,4,3)

function ultraschall.SetProject_RenderSpeed(projectfilename_with_path, RenderingSpeed)
--    Rendering_Speed 0-Fullspeed Offline, 1-1x Offline, 
--                    2-Online Render, 3-Offline Render (Idle), 
--                    4-1x Offline Render (Idle)

--[[
<ApiDocBlocFunc>
<slug>
SetProject_RenderSpeed
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RenderSpeed(string projectfilename_with_path, integer render_speed)
</functionname>
<description>
Sets a rendering-speed in an RPP-Projectfile. 
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer render_speed - render_speed 
-             0-Fullspeed Offline
-             1-1x Offline
-             2-Online Render
-             3-Offline Render (Idle)
-            4-1x Offline Render (Idle)
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, render, speed
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if tonumber(RenderingSpeed)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RENDER_1X%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RENDER_1X%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(RenderingSpeed).." \n"..FileEnd)         
end

--A=ultraschall.SetProject_RenderSpeed("c:\\tt.rpp","199")
--A=ultraschall.GetProject_RenderSpeed("c:\\tt.rpp",0)

function ultraschall.SetProject_RenderRange(projectfilename_with_path, bounds, timestart, timeend, tail, taillength)
-- returns RenderRange
-- Bounds: 0 Custom Time Range, 1 Entire Project, 2 Time Selection, 
--          3 Project Regions, 4 Selected Media Items(in combination with RENDER_STEMS 32)
-- TimeStart in milliseconds -2147483647 to 2147483647
-- TimeEnd in milliseconds 2147483647 to 2147483647
--integer tail - Tail on/off-flags for individual bounds
--0 - tail off for all bounds
--1 - custom time range - tail on
--2 - entire project - tail on
--4 - time selection - tail on
--8 - project regions - tail on
-- TailLength in milliseconds, valuerange 0 - 2147483647  


--[[
<ApiDocBlocFunc>
<slug>
SetProject_RenderRange
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RenderRange(string projectfilename_with_path, integer bounds, number time_start, number time_end, integer tail, integer tail_length)
</functionname>
<description>
Sets the render-range, render-timestart, render-timeend, render-tail and render-taillength in an RPP-Projectfile. To get RENDER_STEMS, refer <a href="#GetProject_RenderStems">GetProject_RenderStems</a>
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer bounds - the bounds of the project to be rendered
-             0 Custom Time Range
-             1 Entire Project
-             2 Time Selection, 
-             3 Project Regions
-             4 Selected Media Items(in combination with RENDER_STEMS 32); to get RENDER_STEMS, refer GetProject_RenderStems

number time_start - TimeStart in milliseconds -2147483647 to 2147483647
number time_end - TimeEnd in milliseconds 2147483647 to 2147483647
integer tail - Tail on/off-flags for individual bounds
-             0 - tail off for all bounds
-             1 - custom time range - tail on
-             2 - entire project - tail on
-             4 - time selection - tail on
-             8 - project regions - tail on

integer tail_length - TailLength in milliseconds, valuerange 0 - 2147483647
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, render, timestart, timeend, range, tail, bounds
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(bounds)==nil then return -1 end
  if tonumber(timestart)==nil then return -1 end
  if tonumber(timeend)==nil then return -1 end
  if tonumber(tail)==nil then return -1 end
  if tonumber(taillength)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RENDER_RANGE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RENDER_RANGE%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(bounds).." "..tonumber(timestart).." "..tonumber(timeend).." "..tonumber(tail).." "..tonumber(taillength).." \n"..FileEnd)         
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.SetProject_RenderRange("c:\\tt.rpp","1","2","3","4","5")
--A,AA,AAA,AAAA,AAAAA=ultraschall.GetProject_RenderRange("c:\\tt.rpp",0,-0.062,11.937,0,0)

function ultraschall.SetProject_RenderResample(projectfilename_with_path, resamplemode, playbackresample, usesamplerate)
-- returns Resamplemode for a)Rendering and b)Playback as well as c)if both are combined
--- Resample_Mode - 0-medium (64pt Sinc), 1-Low (Linear Interpolation), 
--                2-Lowest (Point Sampling), 3-Good(192pt Sinc), 
--                4-Better(384pt Sinc), 5-Fast (IIR + Linear Interpolation), 
--                6-Fast (IIRx2 + Linear Interpolation), 7-Fast (16pt sinc) - Default, 
--                8-HQ (512pt Sinc), 9-Extreme HQ (768pt HQ Sinc)
-- Playback_Resample_Mode (as set in the Project-Settings)
--                0-medium (64pt Sinc), 1-Low (Linear Interpolation), 
--                2-Lowest (Point Sampling), 3-Good(192pt Sinc), 
--                4-Better(384pt Sinc), 5-Fast (IIR + Linear Interpolation), 
--                6-Fast (IIRx2 + Linear Interpolation), 7-Fast (16pt sinc) - Default, 
--                8-HQ (512pt Sinc), 9-Extreme HQ (768pt HQ Sinc)
-- Use_Project_Sample_Rate_for_Mixing_and_FX/Synth_Processing - 1 - yes, 0-no

--[[
<ApiDocBlocFunc>
<slug>
SetProject_RenderResample
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RenderResample(string projectfilename_with_path, integer resample_mode, integer playback_resample_mode, integer project_smplrate4mix_and_fx)
</functionname>
<description>
Resamplemode for a)Rendering and b)Playback as well as c)if both are combined from an RPP-Projectfile. 
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer resample_mode - Resample_Mode 
-             0-medium (64pt Sinc), 
-             1-Low (Linear Interpolation), 
-             2-Lowest (Point Sampling), 
-             3-Good(192pt Sinc), 
-             4-Better(384pt Sinc), 
-             5-Fast (IIR + Linear Interpolation), 
-             6-Fast (IIRx2 + Linear Interpolation), 
-             7-Fast (16pt sinc) - Default, 
-             8-HQ (512pt Sinc), 
-             9-Extreme HQ (768pt HQ Sinc)

integer playback_resample_mode - Playback Resample Mode (as set in the Project-Settings)
-             0-medium (64pt Sinc), 
-            1-Low (Linear Interpolation), 
-            2-Lowest (Point Sampling), 
-            3-Good(192pt Sinc), 
-            4-Better(384pt Sinc), 
-           5-Fast (IIR + Linear Interpolation), 
-           6-Fast (IIRx2 + Linear Interpolation), 
-           7-Fast (16pt sinc) - Default, 
-           8-HQ (512pt Sinc), 
-           9-Extreme HQ (768pt HQ Sinc)

integer project_smplrate4mix_and_fx - Use_Project_Sample_Rate_for_Mixing_and_FX/Synth_Processing 1 - yes, 0-no
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, render, resample, playback, mixing, fx, synth
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if tonumber(resamplemode)==nil then return -1 end
  if tonumber(playbackresample)==nil then return -1 end
  if tonumber(usesamplerate)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RENDER_RESAMPLE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RENDER_RESAMPLE%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(resamplemode).." "..tonumber(playbackresample).." "..tonumber(usesamplerate).." \n"..FileEnd)         
end

--A,AA,AAA,AAAA,AAAAA=ultraschall.SetProject_RenderResample("c:\\tt.rpp","1","2","3")
--A,AA,AAA,AAAA,AAAAA=ultraschall.GetProject_RenderResample("c:\\tt.rpp", 1, 2, 3)

function ultraschall.SetProject_AddMediaToProjectAfterRender(projectfilename_with_path, addstate)
-- returns the state, if rendered media shall be added to the project afterwards
-- 0 - don't add, 1 - add to project

--[[
<ApiDocBlocFunc>
<slug>
SetProject_AddMediaToProjectAfterRender
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_AddMediaToProjectAfterRender(string projectfilename_with_path, integer addmedia_after_render_state)
</functionname>
<description>
Returns, if rendered media shall be added to the project afterwards, from an RPP-Projectfile. 
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer addmedia_after_render_state - 1 - rendered media shall be added to the project afterwards, 0 - don't add
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, render, add, media, after, project
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if tonumber(addstate)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RENDER_ADDTOPROJ%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RENDER_ADDTOPROJ%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(addstate).." \n"..FileEnd)         
  end

--A=ultraschall.SetProject_AddMediaToProjectAfterRender("c:\\tt.rpp","9")
--A=ultraschall.GetProject_AddMediaToProjectAfterRender("c:\\tt.rpp",1)

function ultraschall.SetProject_RenderStems(projectfilename_with_path, stemsstate)
-- returns the state of Render Stems
-- 0 - Source Master Mix, 1 - Source Master mix + stems, 3 - Source Stems, selected tracks, 
-- 4 - Multichannel Tracks to Multichannel Files, 8 - Source Region Render Matrix, 
-- 16 - Tracks with only Mono-Media to Mono Files,  
-- 32 Selected Media Items(in combination with RENDER_RANGE->Bounds->4)  

--[[
<ApiDocBlocFunc>
<slug>
SetProject_RenderStems
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RenderStems(string projectfilename_with_path, integer render_stems)
</functionname>
<description>
Sets the render-stems-state from an RPP-Projectfile. 
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer render_stems - the state of Render Stems
- 0 - Source Master Mix, 
- 1 - Source Master mix + stems, 
- 3 - Source Stems, selected tracks, 
- 4 - Multichannel Tracks to Multichannel Files, 
- 8 - Source Region Render Matrix, 
- 16 - Tracks with only Mono-Media to Mono Files,  
- 32 Selected Media Items(in combination with RENDER_RANGE->Bounds->4, refer to <a href="#GetProject_RenderRange">GetProject_RenderRange</a> to get RENDER_RANGE)
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, render, stems, multichannel
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if tonumber(stemsstate)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RENDER_STEMS%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RENDER_STEMS%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(stemsstate).." \n"..FileEnd)         
end

--A=ultraschall.SetProject_RenderStems("c:\\tt.rpp","2")
--A=ultraschall.GetProject_RenderStems("c:\\tt.rpp", 2)

function ultraschall.SetProject_RenderDitherState(projectfilename_with_path, ditherstate)
-- returns the state of dithering of rendering
-- 0 - Dither Master Mix, 1 - Don't Dither Master Mix, 2 - Noise-shaping On Master Mix, 
-- 3 - Dither And Noiseshape Master Mix

--[[
<ApiDocBlocFunc>
<slug>
SetProject_RenderDitherState
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_RenderDitherState(string projectfilename_with_path, integer renderdither_state)
</functionname>
<description>
Sets the render-dither-state from an RPP-Projectfile. 
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer renderdither_state - the state of render dithering
-             0 - Dither Master Mix, 
-             1 - Don't Dither Master Mix, 
-             2 - Noise-shaping On Master Mix, 
-             3 - Dither And Noiseshape Master Mix
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, render, dither, state, master, noise shaping
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if tonumber(ditherstate)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-RENDER_DITHER%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-RENDER_DITHER%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..tonumber(ditherstate).." \n"..FileEnd)         
end

--A=ultraschall.SetProject_RenderDitherState("c:\\tt.rpp","99")
--A=ultraschall.GetProject_RenderDitherState("c:\\tt.rpp",1)


function ultraschall.SetProject_TimeBase(projectfilename_with_path, timebase)
-- returns Time Base for items/envelopes/markers as set in the project settings
-- 0 - Time, 1 - Beats (position, length, rate), 2 - Beats (position only)
--[[
<ApiDocBlocFunc>
<slug>
SetProject_TimeBase
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_TimeBase(string projectfilename_with_path, integer timebase)
</functionname>
<description>
Sets the timebase, as set in the project-settings, in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer timebase - the timebase for items/envelopes/markers as set in the project settings
-             0 - Time, 
-             1 - Beats (position, length, rate), 
-             2 - Beats (position only)
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, timebase, time, beats, items, envelopes, markers
</tags>
</ApiDocBlocFunc>
]]  
  if projectfilename_with_path==nil then return -1 end
  if tonumber(timebase)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-TIMELOCKMODE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-TIMELOCKMODE%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..timebase.." \n"..FileEnd)         
end

--A=ultraschall.SetProject_TimeBase("c:\\tt.rpp", "10")
--A=ultraschall.GetProject_TimeBase("c:\\tt.rpp")

function ultraschall.SetProject_TempoTimeSignature(projectfilename_with_path, timebase)
-- returns Time Base for tempo/time-signature as set in the project settings
-- 0 - Time, 1 - Beats
--[[
<ApiDocBlocFunc>
<slug>
SetProject_TempoTimeSignature
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_TempoTimeSignature(string projectfilename_with_path, integer tempotimesignature)
</functionname>
<description>
Sets the timebase, as set in the project-settings, in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer tempotimesignature - the timebase for tempo/time-signature as set in the project settings
-             0 - Time 
-             1 - Beats
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, timebase, time, beats, tempo, signature
</tags>
</ApiDocBlocFunc>
]]  
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(timebase)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-TEMPOENVLOCKMODE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-TEMPOENVLOCKMODE%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..timebase.." \n"..FileEnd)         
end

--A=ultraschall.SetProject_TempoTimeSignature("c:\\tt.rpp","10")
--A=ultraschall.GetProject_TempoTimeSignature("c:\\tt.rpp",1)
--Mespotine

function ultraschall.SetProject_ItemMixBehavior(projectfilename_with_path, itemmixbehavior)
-- returns Project Settings Item Mix Behavior
-- 0 - Enclosed items replace enclosing items 
-- 1 - Items always mix
-- 2 - Items always replace earlier items

--[[
<ApiDocBlocFunc>
<slug>
SetProject_ItemMixBehavior
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_ItemMixBehavior(string projectfilename_with_path, integer item_mix_behav_state)
</functionname>
<description>
Sets the item mix behavior, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer item_mix_behav_state - item mix behavior
-              0 - Enclosed items replace enclosing items 
-              1 - Items always mix
-              2 - Items always replace earlier items
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, item, mix
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if tonumber(itemmixbehavior)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-ITEMMIX%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-ITEMMIX%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..itemmixbehavior.." \n"..FileEnd)         
end

--A=ultraschall.SetProject_ItemMixBehavior("c:\\tt.rpp","100")
--A=ultraschall.GetProject_ItemMixBehavior("c:\\tt.rpp",0)

function ultraschall.SetProject_DefPitchMode(projectfilename_with_path, pitchmode)
-- returns Default Pitch Mode for project
--      0 - Soundtouch(Default)
--      1 - Soundtouch(High Quality)
--      2 - Soundtouch(Fast)
--      131072 - Simple Windowed(fast) (50ms window, 25ms fade)
--      131073 - Simple Windowed(fast) (50ms window, 16ms fade)
--      131074 - Simple Windowed(fast) (50ms window, 10ms fade)
--      131075 - Simple Windowed(fast) (50ms window, 7ms fade)
--      131076 - Simple Windowed(fast) (75ms window, 37ms fade)
--      131077 - Simple Windowed(fast) (75ms window, 25ms fade)
--      131078 - Simple Windowed(fast) (75ms window, 15ms fade)
--      131079 - Simple Windowed(fast) (75ms window, 10ms fade)
--      131080 - Simple Windowed(fast) (100ms window, 50ms fade)
--      131081 - Simple Windowed(fast) (100ms window, 33ms fade)
--      131082 - Simple Windowed(fast) (100ms window, 20ms fade)
--      131083 - Simple Windowed(fast) (100ms window, 14ms fade)
--      131084 - Simple Windowed(fast) (150ms window, 75ms fade)
--      131085 - Simple Windowed(fast) (150ms window, 50ms fade)
--      131086 - Simple Windowed(fast) (150ms window, 30ms fade)
--      131087 - Simple Windowed(fast) (150ms window, 21ms fade)
--      131088 - Simple Windowed(fast) (225ms window, 112ms fade)
--      131089 - Simple Windowed(fast) (225ms window, 75ms fade)
--      131090 - Simple Windowed(fast) (225ms window, 45ms fade)
--      131091 - Simple Windowed(fast) (225ms window, 32ms fade)
--      131092 - Simple Windowed(fast) (300ms window, 150ms fade)
--      131093 - Simple Windowed(fast) (300ms window, 100ms fade)
--      131094 - Simple Windowed(fast) (300ms window, 60ms fade)
--      131095 - Simple Windowed(fast) (300ms window, 42ms fade)
--      131096 - Simple Windowed(fast) (40ms window, 20ms fade)
--      131097 - Simple Windowed(fast) (40ms window, 13ms fade)
--      131098 - Simple Windowed(fast) (40ms window, 8ms fade)
--      131099 - Simple Windowed(fast) (40ms window, 5ms fade)
--      131100 - Simple Windowed(fast) (30ms window, 15ms fade)
--      131101 - Simple Windowed(fast) (30ms window, 10ms fade)
--      131102 - Simple Windowed(fast) (30ms window, 6s fade)
--      131103 - Simple Windowed(fast) (30ms window, 4ms fade)
--      131104 - Simple Windowed(fast) (20ms window, 10ms fade)
--      131105 - Simple Windowed(fast) (20ms window, 6ms fade)
--      131106 - Simple Windowed(fast) (20ms window, 4ms fade)
--      131107 - Simple Windowed(fast) (20ms window, 2ms fade)
--      131108 - Simple Windowed(fast) (10ms window, 5ms fade)
--      131109 - Simple Windowed(fast) (10ms window, 3ms fade)
--      131110 - Simple Windowed(fast) (10ms window, 2ms fade)
--      131111 - Simple Windowed(fast) (10ms window, 1ms fade)
--      131112 - Simple Windowed(fast) (5ms window, 2ms fade)
--      131113 - Simple Windowed(fast) (5ms window, 1ms fade)
--      131114 - Simple Windowed(fast) (5ms window, 1ms fade)
--      131115 - Simple Windowed(fast) (5ms window, 1ms fade)
--      131116 - Simple Windowed(fast) (3ms window, 1ms fade)
--      131117 - Simple Windowed(fast) (3ms window, 1ms fade)
--      131118 - Simple Windowed(fast) (3ms window, 1ms fade)
--      131119 - Simple Windowed(fast) (3ms window, 1ms fade)
--      393216 - élastique 2.28 Pro Normal
--      393217 - élastique 2.28 Pro Preserve Formants(Lowest Pitches)
--      393218 - élastique 2.28 Pro Preserve Formants(Lower Pitches)
--      393219 - élastique 2.28 Pro Preserve Formants(Low Pitches)
--      393220 - élastique 2.28 Pro Preserve Formants(Most Pitches)
--      393221 - élastique 2.28 Pro Preserve Formants(High Pitches)
--      393222 - élastique 2.28 Pro Preserve Formants(Higher Pitches)
--      393223 - élastique 2.28 Pro Preserve Formants(Highest Pitches)
--      393224 - élastique 2.28 Pro Mid/Side
--      393225 - élastique 2.28 Pro Mid/Side, Preserve Formants(Lowest Pitches)
--      393226 - élastique 2.28 Pro Mid/Side, Preserve Formants(Lower Pitches)
--      393227 - élastique 2.28 Pro Mid/Side, Preserve Formants(Low Pitches)
--      393228 - élastique 2.28 Pro Mid/Side, Preserve Formants(Most Pitches)
--      393229 - élastique 2.28 Pro Mid/Side, Preserve Formants(High Pitches)
--      393230 - élastique 2.28 Pro Mid/Side, Preserve Formants(Higher Pitches)
--      393231 - élastique 2.28 Pro Mid/Side, Preserve Formants(Highest Pitches)
--      393232 - élastique 2.28 Pro Synchronized: Normal
--      393233 - élastique 2.28 Pro Synchronized: Preserve Formants(Lowest Pitches)
--      393234 - élastique 2.28 Pro Synchronized: Preserve Formants(Lower Pitches)
--      393235 - élastique 2.28 Pro Synchronized: Preserve Formants(Low Pitches)
--      393236 - élastique 2.28 Pro Synchronized: Preserve Formants(Most Pitches)
--      393237 - élastique 2.28 Pro Synchronized: Preserve Formants(High Pitches)
--      393238 - élastique 2.28 Pro Synchronized: Preserve Formants(Higher Pitches)
--      393239 - élastique 2.28 Pro Synchronized: Preserve Formants(Highest Pitches)
--      393240 - élastique 2.28 Pro Synchronized: Mid/Side 
--      393241 - élastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Lowest Pitches)
--      393242 - élastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Lower Pitches) 
--      393243 - élastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Low Pitches)
--      393244 - élastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Most Pitches)
--      393245 - élastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(High Pitches)
--      393246 - élastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Higher Pitches)
--      393247 - élastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Highest Pitches)
--      458752 - élastique 2.28 Efficient Normal
--      458753 - élastique 2.28 Efficient Mid/Side
--      458754 - élastique 2.28 Efficient Synchronized: Normal
--      458755 - élastique 2.28 Efficient Synchronized: Mid/Side
--      524288 - élastique 2.28 Soloist Monophonic
--      524289 - élastique 2.28 Soloist Monophonic [Mid/Side]
--      524290 - élastique 2.28 Soloist Speech
--      524291 - élastique 2.28 Soloist Speech [Mid/Side]
--      589824 - élastique 3.1.4 Pro Normal
--      589825 - élastique 3.1.4 Pro Preserve Formants(Lowest Pitches)
--      589826 - élastique 3.1.4 Pro Preserve Formants(Lower Pitches)
--      589827 - élastique 3.1.4 Pro Preserve Formants(Low Pitches)
--      589828 - élastique 3.1.4 Pro Preserve Formants(Most Pitches)
--      589829 - élastique 3.1.4 Pro Preserve Formants(High Pitches)
--      589830 - élastique 3.1.4 Pro Preserve Formants(Higher Pitches)
--      589831 - élastique 3.1.4 Pro Preserve Formants(Highest Pitches)
--      589832 - élastique 3.1.4 Pro Mid/Side
--      589833 - élastique 3.1.4 Pro Mid/Side, Preserve Formants(Lowest Pitches)
--      589834 - élastique 3.1.4 Pro Mid/Side, Preserve Formants(Lower Pitches)
--      589835 - élastique 3.1.4 Pro Mid/Side, Preserve Formants(Low Pitches)
--      589836 - élastique 3.1.4 Pro Mid/Side, Preserve Formants(Most Pitches)
--      589837 - élastique 3.1.4 Pro Mid/Side, Preserve Formants(High Pitches)
--      589838 - élastique 3.1.4 Pro Mid/Side, Preserve Formants(Higher Pitches)
--      589839 - élastique 3.1.4 Pro Mid/Side, Preserve Formants(Highest Pitches)
--      589840 - élastique 3.1.4 Pro Synchronized: Normal
--      589841 - élastique 3.1.4 Pro Synchronized: Preserve Formants(Lowest Pitches)
--      589842 - élastique 3.1.4 Pro Synchronized: Preserve Formants(Lower Pitches)
--      589843 - élastique 3.1.4 Pro Synchronized: Preserve Formants(Low Pitches)
--      589844 - élastique 3.1.4 Pro Synchronized: Preserve Formants(Most Pitches)
--      589845 - élastique 3.1.4 Pro Synchronized: Preserve Formants(High Pitches)
--      589846 - élastique 3.1.4 Pro Synchronized: Preserve Formants(Higher Pitches)
--      589847 - élastique 3.1.4 Pro Synchronized: Preserve Formants(Highest Pitches)
--      589848 - élastique 3.1.4 Pro Synchronized: Mid/Side 
--      589849 - élastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Lowest Pitches)
--      589850 - élastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Lower Pitches) 
--      589851 - élastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Low Pitches)
--      589852 - élastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Most Pitches)
--      589853 - élastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(High Pitches)
--      589853 - élastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Higher Pitches)
--      589855 - élastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Highest Pitches)
--      655360 - élastique 3.1.4 Efficient Normal
--      655361 - élastique 3.1.4 Efficient Mid/Side
--      655362 - élastique 3.1.4 Efficient Synchronized: Normal
--      655363 - élastique 3.1.4 Efficient Synchronized: Mid/Side
--      720896 - élastique 3.1.4 Soloist (Monophonic)
--      720897 - élastique 3.1.4 Soloist (Monophonic Mid Side)
  
--[[
<ApiDocBlocFunc>
<slug>
SetProject_DefPitchMode
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_DefPitchMode(string projectfilename_with_path, integer def_pitch_mode_state)
</functionname>
<description>
Sets the default-pitch-mode, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer def_pitch_mode_state - the default pitch mode
-      0 - Soundtouch(Default)
-      1 - Soundtouch(High Quality)
-      2 - Soundtouch(Fast)
-      131072 - Simple Windowed(fast) (50ms window, 25ms fade)
-      131073 - Simple Windowed(fast) (50ms window, 16ms fade)
-      131074 - Simple Windowed(fast) (50ms window, 10ms fade)
-      131075 - Simple Windowed(fast) (50ms window, 7ms fade)
-      131076 - Simple Windowed(fast) (75ms window, 37ms fade)
-      131077 - Simple Windowed(fast) (75ms window, 25ms fade)
-      131078 - Simple Windowed(fast) (75ms window, 15ms fade)
-      131079 - Simple Windowed(fast) (75ms window, 10ms fade)
-      131080 - Simple Windowed(fast) (100ms window, 50ms fade)
-      131081 - Simple Windowed(fast) (100ms window, 33ms fade)
-      131082 - Simple Windowed(fast) (100ms window, 20ms fade)
-      131083 - Simple Windowed(fast) (100ms window, 14ms fade)
-      131084 - Simple Windowed(fast) (150ms window, 75ms fade)
-      131085 - Simple Windowed(fast) (150ms window, 50ms fade)
-      131086 - Simple Windowed(fast) (150ms window, 30ms fade)
-      131087 - Simple Windowed(fast) (150ms window, 21ms fade)
-      131088 - Simple Windowed(fast) (225ms window, 112ms fade)
-      131089 - Simple Windowed(fast) (225ms window, 75ms fade)
-      131090 - Simple Windowed(fast) (225ms window, 45ms fade)
-      131091 - Simple Windowed(fast) (225ms window, 32ms fade)
-      131092 - Simple Windowed(fast) (300ms window, 150ms fade)
-      131093 - Simple Windowed(fast) (300ms window, 100ms fade)
-      131094 - Simple Windowed(fast) (300ms window, 60ms fade)
-      131095 - Simple Windowed(fast) (300ms window, 42ms fade)
-      131096 - Simple Windowed(fast) (40ms window, 20ms fade)
-      131097 - Simple Windowed(fast) (40ms window, 13ms fade)
-      131098 - Simple Windowed(fast) (40ms window, 8ms fade)
-      131099 - Simple Windowed(fast) (40ms window, 5ms fade)
-      131100 - Simple Windowed(fast) (30ms window, 15ms fade)
-      131101 - Simple Windowed(fast) (30ms window, 10ms fade)
-      131102 - Simple Windowed(fast) (30ms window, 6s fade)
-      131103 - Simple Windowed(fast) (30ms window, 4ms fade)
-      131104 - Simple Windowed(fast) (20ms window, 10ms fade)
-      131105 - Simple Windowed(fast) (20ms window, 6ms fade)
-      131106 - Simple Windowed(fast) (20ms window, 4ms fade)
-      131107 - Simple Windowed(fast) (20ms window, 2ms fade)
-      131108 - Simple Windowed(fast) (10ms window, 5ms fade)
-      131109 - Simple Windowed(fast) (10ms window, 3ms fade)
-      131110 - Simple Windowed(fast) (10ms window, 2ms fade)
-      131111 - Simple Windowed(fast) (10ms window, 1ms fade)
-      131112 - Simple Windowed(fast) (5ms window, 2ms fade)
-      131113 - Simple Windowed(fast) (5ms window, 1ms fade)
-      131114 - Simple Windowed(fast) (5ms window, 1ms fade)
-      131115 - Simple Windowed(fast) (5ms window, 1ms fade)
-      131116 - Simple Windowed(fast) (3ms window, 1ms fade)
-      131117 - Simple Windowed(fast) (3ms window, 1ms fade)
-      131118 - Simple Windowed(fast) (3ms window, 1ms fade)
-      131119 - Simple Windowed(fast) (3ms window, 1ms fade)
-      393216 - elastique 2.28 Pro Normal
-      393217 - elastique 2.28 Pro Preserve Formants(Lowest Pitches)
-      393218 - elastique 2.28 Pro Preserve Formants(Lower Pitches)
-      393219 - elastique 2.28 Pro Preserve Formants(Low Pitches)
-      393220 - elastique 2.28 Pro Preserve Formants(Most Pitches)
-      393221 - elastique 2.28 Pro Preserve Formants(High Pitches)
-      393222 - elastique 2.28 Pro Preserve Formants(Higher Pitches)
-      393223 - elastique 2.28 Pro Preserve Formants(Highest Pitches)
-      393224 - elastique 2.28 Pro Mid/Side
-      393225 - elastique 2.28 Pro Mid/Side, Preserve Formants(Lowest Pitches)
-      393226 - elastique 2.28 Pro Mid/Side, Preserve Formants(Lower Pitches)
-      393227 - elastique 2.28 Pro Mid/Side, Preserve Formants(Low Pitches)
-      393228 - elastique 2.28 Pro Mid/Side, Preserve Formants(Most Pitches)
-      393229 - elastique 2.28 Pro Mid/Side, Preserve Formants(High Pitches)
-      393230 - elastique 2.28 Pro Mid/Side, Preserve Formants(Higher Pitches)
-      393231 - elastique 2.28 Pro Mid/Side, Preserve Formants(Highest Pitches)
-      393232 - elastique 2.28 Pro Synchronized: Normal
-      393233 - elastique 2.28 Pro Synchronized: Preserve Formants(Lowest Pitches)
-      393234 - elastique 2.28 Pro Synchronized: Preserve Formants(Lower Pitches)
-      393235 - elastique 2.28 Pro Synchronized: Preserve Formants(Low Pitches)
-      393236 - elastique 2.28 Pro Synchronized: Preserve Formants(Most Pitches)
-      393237 - elastique 2.28 Pro Synchronized: Preserve Formants(High Pitches)
-      393238 - elastique 2.28 Pro Synchronized: Preserve Formants(Higher Pitches)
-      393239 - elastique 2.28 Pro Synchronized: Preserve Formants(Highest Pitches)
-      393240 - elastique 2.28 Pro Synchronized: Mid/Side 
-      393241 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Lowest Pitches)
-      393242 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Lower Pitches) 
-      393243 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Low Pitches)
-      393244 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Most Pitches)
-      393245 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(High Pitches)
-      393246 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Higher Pitches)
-      393247 - elastique 2.28 Pro Synchronized: Mid/Side, Preserve Formants(Highest Pitches)
-      458752 - elastique 2.28 Efficient Normal
-      458753 - elastique 2.28 Efficient Mid/Side
-      458754 - elastique 2.28 Efficient Synchronized: Normal
-      458755 - elastique 2.28 Efficient Synchronized: Mid/Side
-      524288 - elastique 2.28 Soloist Monophonic
-      524289 - elastique 2.28 Soloist Monophonic [Mid/Side]
-      524290 - elastique 2.28 Soloist Speech
-      524291 - elastique 2.28 Soloist Speech [Mid/Side]
-      589824 - elastique 3.1.4 Pro Normal
-      589825 - elastique 3.1.4 Pro Preserve Formants(Lowest Pitches)
-      589826 - elastique 3.1.4 Pro Preserve Formants(Lower Pitches)
-      589827 - elastique 3.1.4 Pro Preserve Formants(Low Pitches)
-      589828 - elastique 3.1.4 Pro Preserve Formants(Most Pitches)
-      589829 - elastique 3.1.4 Pro Preserve Formants(High Pitches)
-      589830 - elastique 3.1.4 Pro Preserve Formants(Higher Pitches)
-      589831 - elastique 3.1.4 Pro Preserve Formants(Highest Pitches)
-      589832 - elastique 3.1.4 Pro Mid/Side
-      589833 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Lowest Pitches)
-      589834 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Lower Pitches)
-      589835 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Low Pitches)
-      589836 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Most Pitches)
-      589837 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(High Pitches)
-      589838 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Higher Pitches)
-      589839 - elastique 3.1.4 Pro Mid/Side, Preserve Formants(Highest Pitches)
-      589840 - elastique 3.1.4 Pro Synchronized: Normal
-      589841 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Lowest Pitches)
-      589842 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Lower Pitches)
-      589843 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Low Pitches)
-      589844 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Most Pitches)
-      589845 - elastique 3.1.4 Pro Synchronized: Preserve Formants(High Pitches)
-      589846 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Higher Pitches)
-      589847 - elastique 3.1.4 Pro Synchronized: Preserve Formants(Highest Pitches)
-      589848 - elastique 3.1.4 Pro Synchronized: Mid/Side 
-      589849 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Lowest Pitches)
-      589850 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Lower Pitches) 
-      589851 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Low Pitches)
-      589852 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Most Pitches)
-      589853 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(High Pitches)
-      589853 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Higher Pitches)
-      589855 - elastique 3.1.4 Pro Synchronized: Mid/Side, Preserve Formants(Highest Pitches)
-      655360 - elastique 3.1.4 Efficient Normal
-      655361 - elastique 3.1.4 Efficient Mid/Side
-      655362 - elastique 3.1.4 Efficient Synchronized: Normal
-      655363 - elastique 3.1.4 Efficient Synchronized: Mid/Side
-      720896 - elastique 3.1.4 Soloist (Monophonic)
-      720897 - elastique 3.1.4 Soloist (Monophonic Mid Side)
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, default, pitch mode, pitch
</tags>
</ApiDocBlocFunc>
]]
  
  if projectfilename_with_path==nil then return -1 end
  if tonumber(pitchmode)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-DEFPITCHMODE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-DEFPITCHMODE%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..pitchmode.." \n"..FileEnd)         
end

--A=ultraschall.SetProject_DefPitchMode("c:\\tt.rpp", "19879")
--A=ultraschall.GetProject_DefPitchMode("c:\\tt.rpp", 1987)

function ultraschall.SetProject_TakeLane(projectfilename_with_path, takelane)
-- returns TakeLane state
--[[
<ApiDocBlocFunc>
<slug>
SetProject_TakeLane
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_TakeLane(string projectfilename_with_path, integer take_lane_state)
</functionname>
<description>
Sets the take-lane-state in an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer take_lane_state - take-lane-state
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, take, lane
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  if tonumber(takelane)==nil then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-TAKELANE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-TAKELANE%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..takelane.." \n"..FileEnd)         
end

--A=ultraschall.SetProject_TakeLane("c:\\tt.rpp","99")
--A=ultraschall.GetProject_TakeLane("c:\\tt.rpp",1)

function ultraschall.SetProject_SampleRate(projectfilename_with_path, projectsamplerate, useprojectsamplerate, forcetempotimesignature)
-- returns Project Settings Samplerate
--        a - Project Sample Rate
--        b - Checkbox: Project Sample Rate
--        c - Checkbox: Force Project Tempo/Time Signature changes to occur on whole samples 

--[[
<ApiDocBlocFunc>
<slug>
SetProject_SampleRate
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_SampleRate(string projectfilename_with_path, integer sample_rate, integer project_sample_rate, integer force_tempo_time_sig)
</functionname>
<description>
Sets the project-samplerate-state, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer sample_rate - Project Sample Rate in Hz
integer project_sample_rate - Checkbox: Project Sample Rate
integer force_tempo_time_sig - Checkbox: Force Project Tempo/Time Signature changes to occur on whole samples 
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, sample, rate, samplerate, tempo, time, signature
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil then return -1 end
  if tonumber(projectsamplerate)==nil then return -1 end
  if tonumber(useprojectsamplerate)==nil then return -1 end  
  if tonumber(forcetempotimesignature)==nil then return -1 end  
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-SAMPLERATE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-SAMPLERATE%s.-%c(.-<RENDER_CFG.*)")
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..projectsamplerate.." "..useprojectsamplerate.." "..forcetempotimesignature.."\n"..FileEnd)         
end

--A,AA,AAA=ultraschall.SetProject_SampleRate("c:\\tt.rpp",8000,2,"0")
--A,AA,AAA=ultraschall.GetProject_SampleRate("c:\\tt.rpp",8000,2,0)

function ultraschall.SetProject_TrackMixingDepth(projectfilename_with_path, mixingdepth)
-- returns TrackMixingDepth
--          1 - 32 bit float
--          2 - 39 bit integer
--          3 - 24 bit integer
--          4 - 16 bit integer
--          5 - 12 bit integer
--          6 - 8 bit integer

--[[
<ApiDocBlocFunc>
<slug>
SetProject_TrackMixingDepth
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.SetProject_TrackMixingDepth(string projectfilename_with_path, integer sample_rate, integer project_sample_rate, integer force_tempo_time_sig)
</functionname>
<description>
Sets the project-samplerate-state, as set in the project-settings, from an rpp-project-file.
Returns -1 in case of error.
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
integer sample_rate - Project Sample Rate in Hz
integer project_sample_rate - Checkbox: Project Sample Rate
integer force_tempo_time_sig - Checkbox: Force Project Tempo/Time Signature changes to occur on whole samples 
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
</retvals>
<semanticcontext>
Project-Files
RPP-Files Set
</semanticcontext>
<tags>
projectfiles, rpp, state, set, sample, rate, samplerate, tempo, time, signature
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil then return -1 end
  if tonumber(mixingdepth)==nil then return -1 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  local file=ultraschall.ReadValueFromFile(projectfilename_with_path)
  local FileStart=file:match("(<REAPER_PROJECT.-INTMIXMODE%s).-%c.-<RENDER_CFG.*")
  local FileEnd=file:match("<REAPER_PROJECT.-INTMIXMODE%s.-%c(.-<RENDER_CFG.*)")

  if FileStart==nil or FileEnd==nil then 
    FileStart=file:match("(<REAPER_PROJECT.-)<RENDER_CFG.*")
      FileEnd="  "..file:match("<REAPER_PROJECT.-(<RENDER_CFG.*)")
      mixingdepth="INTMIXMODE "..tostring(mixingdepth)
  end
--  reaper.MB(FileStart,"",0)
  return ultraschall.WriteValueToFile(projectfilename_with_path, FileStart..mixingdepth.."\n"..FileEnd)         
end

--A=ultraschall.SetProject_TrackMixingDepth("c:\\tt.rpp",3)
--A=ultraschall.GetProject_TrackMixingDepth("c:\\tt.rpp",2)


--- Delete ---



-------------------------------
---- Reaper.ini Management ----
-------------------------------

--- Get ---

--- Set ---

--- Delete ---


----------------------
---- FX-Snapshots ----
----------------------


----------------------
---- RenderExport ----
----------------------


function ultraschall.RenderProjectToAIFF(projectfilename_with_path, AIFF_filename_with_path, bits)
-- Renders the projectfile "projectfilename_with_path" as AIFF
-- returns -1 in case of error
-- returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
-- returns -3, if the tempfile ultraschall-temp.rpp already exists
--
-- string projectfilename_with_path - the RPP-File to Render
-- string AIFF_filename - the AIFF-filename with path, that shall be created

--[[
<ApiDocBlocFunc>
<slug>
RenderProjectToAIFF
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RenderProjectToAIFF(string projectfilename_with_path, string AIFF_filename_with_path, integer bits)
</functionname>
<description>
Renders the projectfilename_with_path as AIFF to AIFF_filename_with_path.
returns -1 in case of error
returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
returns -3, if the tempfile ultraschall-temp.rpp already exists in the projectfolder of the projectfile
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string AIFF_filename_with_path - the name of the file, where the project will be rendered to
integer bit - bitrate of the renderfile, 8, 16, 24, 32
</parameters>
<retvals>
integer retval - returns, if rendering was successful
- 0 in case of success
- -1 in case of error
- -2, if the current projectfile hasn't been saved yet(it must be saved first!)
- -3, if the tempfile ultraschall-temp.rpp already exists
</retvals>
<semanticcontext>
Rendering of Project
Audio
</semanticcontext>
<tags>
rendering, project, export, audio, aiff
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil or AIFF_filename_with_path==nil or tonumber(bits)==nil then return -1 end
  bits=tonumber(bits)
  if reaper.IsProjectDirty(0)==1 then return -2 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  
  local AIF_Render_Setting=""
  if bits==8 then AIF_Render_Setting="ZmZpYQgAAA==" --8Bit PCM
  elseif bits==16 then AIF_Render_Setting="ZmZpYRAAAA==" --16Bit PCM
  elseif bits==24 then AIF_Render_Setting="ZmZpYRgAAA==" --24Bit PCM
  elseif bits==32 then AIF_Render_Setting="ZmZpYSAAAA==" --32Bit PCM
  else return -1
  end
  
  -- Read Projectfile
  local A,B=ultraschall.ReadValueFromFile(projectfilename_with_path, "RENDER_FILE")
  local D,E=ultraschall.ReadValueFromFile(projectfilename_with_path, "<RENDER_CFG")
  local Count=ultraschall.CountLinesInFile(projectfilename_with_path)
  
  --Read the File again into individual parts
  local AA,BB=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, 1, B-1)
    --RENDER_FILE "Filename"
    --RENDER_PATTERN 
  local CC,DD=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, B+2,E)
    --<RENDER_CFG
    -- crypticrender_cfg_pattern
    -->
  local EE,FF=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, E+2,Count)
  --Now, we can insert the render-filename(AIFF) 
  --as well as the AIFF-Render-Settings for High Quality
  local Newfile=AA.."\n  RENDER_FILE \""..AIFF_filename_with_path.."\"\n"..CC.."    "..AIF_Render_Setting.."\n"..EE
  
  --Let's save the modified project into a temp-file in the same directory as the
  --original projectfile
  --but only, if the file ultraschall-temp.rpp does not exist yet!
  local tempfile
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    tempfile=projectfilename_with_path:match("(.*)\\").."\\ultraschall-temp.rpp"
  else
    tempfile=projectfilename_with_path:match("(.*)/").."/ultraschall-temp.rpp"
  end
  if reaper.file_exists(tempfile)==true then return -3 end
  local file=io.open(tempfile,"w")
  file:write(Newfile)
  file:close()
  
  --Now we need to get the currently opened project
  local projectpath = reaper.GetProjectPath("pathtofile")
  projectpath = projectpath:sub(1,-11)
  local oldprojectname = projectpath..reaper.GetProjectName(0, 0)

  --Now the magic happens:
  reaper.Main_openProject(tempfile) --load the temporary projectfile
  reaper.Main_OnCommand(41824,0)    --render using it with the last rendersettings(those, we inserted included)
  reaper.Main_SaveProject(0, false) --save it(no use, but otherwise, Reaper would open a Save-Dialog, that we don't want and need)

  --Now reopen the old project again. If there wasn't one(an empty project), just close the tempproject
  if reaper.file_exists(oldprojectname)==true then reaper.Main_openProject(oldprojectname)
  else reaper.Main_OnCommand(40860,0)
  end
  --remove the temp-file and we are done.
  os.remove (tempfile)
  os.remove (tempfile.."-bak")
  return 0
end

--A=ultraschall.RenderProjectToAIFF("c:\\tt.rpp", "c:\\test.aiff", 8)

function ultraschall.RenderProjectToFLAC(projectfilename_with_path, FLAC_filename_with_path, bits, compression)
-- Renders the projectfile "projectfilename_with_path" as FLAC
-- returns -1 in case of error
-- returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
-- returns -3, if the tempfile ultraschall-temp.rpp already exists
--
-- string projectfilename_with_path - the RPP-File to Render
-- string FLAC_filename - the FLAC-filename with path, that shall be created

--[[
<ApiDocBlocFunc>
<slug>
RenderProjectToFLAC
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RenderProjectToFLAC(string projectfilename_with_path, string FLAC_filename_with_path, integer bits, integer compression)
</functionname>
<description>
Renders the projectfilename_with_path as FLAC to FLAC_filename_with_path.
returns -1 in case of error
returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
returns -3, if the tempfile ultraschall-temp.rpp already exists in the projectfolder of the projectfile
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string FLAC_filename_with_path - the name of the file, where the project will be rendered to
integer bit - bitrate of the renderfile, 16 to 24 bits
integer compression - compression-efficiency; 8(Slowest) to 0(Fastest); 5 is default
</parameters>
<retvals>
integer retval - returns, if rendering was successful
- 0 in case of success
- -1 in case of error
- -2, if the current projectfile hasn't been saved yet(it must be saved first!)
- -3, if the tempfile ultraschall-temp.rpp already exists
</retvals>
<semanticcontext>
Rendering of Project
Audio
</semanticcontext>
<tags>
rendering, project, export, audio, flac
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil or FLAC_filename_with_path==nil or tonumber(bits)==nil then return -1 end
  bits=tonumber(bits)
  if reaper.IsProjectDirty(0)==1 then return -2 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  
  local FLAC_Render_Setting=""
  local bitcode=""
  local compcode=""
  if bits==24 then bitcode="g" --24Bit PCM
  elseif bits==23 then bitcode="c" --23Bit PCM
  elseif bits==22 then bitcode="Y" --22Bit PCM
  elseif bits==21 then bitcode="U" --21Bit PCM
  elseif bits==20 then bitcode="Q" --20Bit PCM
  elseif bits==19 then bitcode="M" --19Bit PCM
  elseif bits==18 then bitcode="I" --18Bit PCM
  elseif bits==17 then bitcode="E" --17Bit PCM
  elseif bits==16 then bitcode="A" --16Bit PCM
  else return -1
  end
  
  if compression==8 then compcode="I" --compression 8 - slowest
  elseif compression==7 then compcode="H" --7
  elseif compression==6 then compcode="G" --6
  elseif compression==5 then compcode="F" --5 - default
  elseif compression==4 then compcode="E" --4
  elseif compression==3 then compcode="D" --3
  elseif compression==2 then compcode="C" --2
  elseif compression==1 then compcode="B" --1
  elseif compression==0 then compcode="A" --0 - fastest
  else return -1
  end
  
  FLAC_Render_Setting="Y2FsZh"..bitcode.."AAAA"..compcode.."AAAA"
  
  -- Read Projectfile
  local A,B=ultraschall.ReadValueFromFile(projectfilename_with_path, "RENDER_FILE")
  local D,E=ultraschall.ReadValueFromFile(projectfilename_with_path, "<RENDER_CFG")
  local Count=ultraschall.CountLinesInFile(projectfilename_with_path)
  
  --Read the File again into individual parts
  local AA,BB=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, 1, B-1)
    --RENDER_FILE "Filename"
    --RENDER_PATTERN 
  local CC,DD=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, B+2,E)
    --<RENDER_CFG
    -- crypticrender_cfg_pattern
    -->
  local EE,FF=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, E+2,Count)
  --Now, we can insert the render-filename(FLAC) 
  --as well as the FLAC-Render-Settings for High Quality
  local Newfile=AA.."\n  RENDER_FILE \""..FLAC_filename_with_path.."\"\n"..CC.."    "..FLAC_Render_Setting.."\n"..EE
  
  --Let's save the modified project into a temp-file in the same directory as the
  --original projectfile
  --but only, if the file ultraschall-temp.rpp does not exist yet!
  local tempfile
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    tempfile=projectfilename_with_path:match("(.*)\\").."\\ultraschall-temp.rpp"
  else
    tempfile=projectfilename_with_path:match("(.*)/").."/ultraschall-temp.rpp"
  end
  if reaper.file_exists(tempfile)==true then return -3 end
  local file=io.open(tempfile,"w")
  file:write(Newfile)
  file:close()
    
  --Now we need to get the currently opened project
  local projectpath = reaper.GetProjectPath("pathtofile")
  projectpath = projectpath:sub(1,-11)
  local oldprojectname = projectpath..reaper.GetProjectName(0, 0)

  --Now the magic happens:
  reaper.Main_openProject(tempfile) --load the temporary projectfile
  reaper.Main_OnCommand(41824,0)    --render using it with the last rendersettings(those, we inserted included)
  reaper.Main_SaveProject(0, false) --save it(no use, but otherwise, Reaper would open a Save-Dialog, that we don't want and need)

  --Now reopen the old project again. If there wasn't one(an empty project), just close the tempproject
  if reaper.file_exists(oldprojectname)==true then reaper.Main_openProject(oldprojectname)
  else reaper.Main_OnCommand(40860,0)
  end
  --remove the temp-file and we are done.
  os.remove (tempfile)
  os.remove (tempfile.."-bak")
  return 0
end

--A=ultraschall.RenderProjectToFLAC("c:\\tt.rpp", "c:\\test.flac", 16, 5)


function ultraschall.RenderProjectToWebMVideo(projectfilename_with_path, WebM_filename_with_path, videobitrate, audiobitrate, resolution, framerate)
-- Renders the projectfile "projectfilename_with_path" as FLAC
-- returns -1 in case of error
-- returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
-- returns -3, if the tempfile ultraschall-temp.rpp already exists
--
-- string projectfilename_with_path - the RPP-File to Render
-- string FLAC_filename - the FLAC-filename with path, that shall be created

--[[
<ApiDocBlocFunc>
<slug>
RenderProjectToWebMVideo
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RenderProjectToWebMVideo(string projectfilename_with_path, string WebM_filename_with_path, integer videobitrate, integer audiobitrate, string resolution, number framerate)
</functionname>
<description>
Renders the projectfilename_with_path as WebM-video to WebM_filename_with_path.
returns -1 in case of error
returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
returns -3, if the tempfile ultraschall-temp.rpp already exists in the projectfolder of the projectfile
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string WebM_filename_with_path - the name of the file, where the project will be rendered to
integer videobitrate - videobitrate
-256 kbps
-384 kbps
-512 kbps
-768 kbps
-1024 kbps
-1200 kbps
-1600 kbps
-2400 kbps
-5000 kbps
-10000 kbps
-16000 kbps
-24000 kbps

integer audiobitrate - audiobitrate
-48 kbps
-56 kbps
-64 kbps
-80 kbps
-96 kbps
-112 kbps
-128 kbps
-160 kbps
-192 kbps
-224 kbps
-256 kbps
-320 kbps
-512 kbps
-1024 kbps

string resolution - the resolution. The following are supported by this function:
- QVGA - 320x240 px
- VGA - 640x480
- SVGA - 800x600
- XGA - 1024x768
- HD - 1280x720
- FULLHD - 1980x1080
- 4K - 3840 x 2160
- 8K - 7680 x 4320

number framerate - the framerate of the project
-1200.00 fps
-580.00 fps
-240.00 fps
-120.00 fps
-60.00 fps
-48.00 fps
-30.00 fps
-29.97 fps
-25.00 fps
-24.00 fps
-23.98 fps
-20.00 fps
-18.00 fps
-15.00 fps
-12.00 fps
-08.00 fps

</parameters>
<retvals>
integer retval - returns, if rendering was successful
- 0 in case of success
- -1 in case of error
- -2, if the current projectfile hasn't been saved yet(it must be saved first!)
- -3, if the tempfile ultraschall-temp.rpp already exists
</retvals>
<semanticcontext>
Rendering of Project
Video
</semanticcontext>
<tags>
rendering, project, export, video, webm
</tags>
</ApiDocBlocFunc>
]]
  if projectfilename_with_path==nil or WebM_filename_with_path==nil or  tonumber(videobitrate)==nil or tonumber(audiobitrate)==nil or resolution==nil or tonumber(framerate)==nil then return -1 end
  videobitrate=tonumber(videobitrate)
  audiobitrate=tonumber(audiobitrate)
  framerate=tonumber(framerate)
    
  if reaper.IsProjectDirty(0)==1 then return -2 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  
  local videobitcode=""
  local audiobitcode=""
  local width, height, fps

  if videobitrate<=256 then videobitcode="AAE" --256kbps
  elseif videobitrate>256 and videobitrate<=384 then videobitcode="gAE" --384kbps
  elseif videobitrate>384 and videobitrate<=512 then videobitcode="AAI" --512kbps
  elseif videobitrate>512 and videobitrate<=768 then videobitcode="AAM" --768
  elseif videobitrate>768 and videobitrate<=1024 then videobitcode="AAQ" --1024
  elseif videobitrate>1024 and videobitrate<=1200 then videobitcode="sAQ" --1200
  elseif videobitrate>1200 and videobitrate<=1600 then videobitcode="QAY" --1600
  elseif videobitrate>1600 and videobitrate<=2400 then videobitcode="YAk" --2400
  elseif videobitrate>2400 and videobitrate<=5000 then videobitcode="iBM" --5000
  elseif videobitrate>5000 and videobitrate<=10000 then videobitcode="ECc" --10000
  elseif videobitrate>10000 and videobitrate<=16000 then videobitcode="gD4" --16000
  elseif videobitrate>16000 then videobitcode="wF0" --24000kbps
  else return -1
  end

  if audiobitrate<=48 then audiobitcode="AwAA" --48 kbps
  elseif audiobitrate>48 and audiobitrate<=56 then audiobitcode="A4AA" --56 kbps
  elseif audiobitrate>56 and audiobitrate<=64 then audiobitcode="BAAA" --64 kbps
  elseif audiobitrate>64 and audiobitrate<=80 then audiobitcode="BQAA" --80 kbps
  elseif audiobitrate>80 and audiobitrate<=96 then audiobitcode="BgAA" --96 kbps
  elseif audiobitrate>96 and audiobitrate<=112 then audiobitcode="BwAA" --112 kbps
  elseif audiobitrate>112 and audiobitrate<=128 then audiobitcode="CAAA" --128 kbps
  elseif audiobitrate>128 and audiobitrate<=160 then audiobitcode="CgAA" --160 kbps
  elseif audiobitrate>160 and audiobitrate<=192 then audiobitcode="DAAA" --192 kbps
  elseif audiobitrate>192 and audiobitrate<=224 then audiobitcode="DgAA" --224 kbps
  elseif audiobitrate>224 and audiobitrate<=256 then audiobitcode="AAAQ" --256 kbps
  elseif audiobitrate>256 and audiobitrate<=320 then audiobitcode="BAAQ" --320 kbps
  elseif audiobitrate>320 and audiobitrate<=512 then audiobitcode="AAAq" --512 kbps
  elseif audiobitrate>512 then audiobitcode="AABA" --1024 kbps
  else return -1
  end

  
  if resolution=="QVGA" then width="QAE" height="PAA" --320x240 px
  elseif resolution=="VGA" then width="gAI" height="OAB" --640x480
  elseif resolution=="SVGA" then width="IAM" height="FgC" --800x600
  elseif resolution=="XGA" then width="AAQ" height="AAD" --1024x768
  elseif resolution=="HD" then width="AAU" height="NAC" --1280x720
  elseif resolution=="FULLHD" then width="gAc" height="DgE" --1980x1080
  elseif resolution=="4K" then width="AA8" height="HAI" -- 3840 x 2160
  elseif resolution=="8K" then width="AB4" height="OAQ" -- 7680 x 4320
  else return -1
  end
  

  if framerate<=8 then fps="AAAABB"
  elseif framerate>8 and framerate<=12 then     fps="AAAEBB"
  elseif framerate>12 and framerate<=15 then    fps="AAAHBB"
  elseif framerate>15 and framerate<=18 then    fps="AAAJBB"
  elseif framerate>18 and framerate<=20 then    fps="AAAKBB"
  elseif framerate>20 and framerate<=23.98 then fps="DZzr9B"
  elseif framerate>23.98 and framerate<=24 then fps="AAAMBB"
  elseif framerate>24 and framerate<=25 then    fps="AAAMhB"
  elseif framerate>25 and framerate<=29.97 then fps="CPwu9B"
  elseif framerate>29.97 and framerate<=30 then fps="AAAPBB"
  elseif framerate>30 and framerate<=48 then    fps="AAAEBC"
  elseif framerate>48 and framerate<=60 then    fps="AAAHBC"
  elseif framerate>60 and framerate<=120 then   fps="AAAPBC"
  elseif framerate>120 and framerate<=240 then  fps="AAAHBD"
  elseif framerate>240 and framerate<=580 then  fps="AAABFE"
  elseif framerate>580 then                     fps="AAAJZE"
  else return -1
  end
  
  
  local WebM_Render_Setting="UE1GRgYAAAAAAAAA"..videobitcode.."AAAAAAA"..audiobitcode.."AA"..width.."AA"..height.."AA"..fps.."AQAAAF8AAAA="
--  reaper.ShowConsoleMsg(WebM_Render_Setting)
  
  -- Read Projectfile
  local A,B=ultraschall.ReadValueFromFile(projectfilename_with_path, "RENDER_FILE")
  local D,E=ultraschall.ReadValueFromFile(projectfilename_with_path, "<RENDER_CFG")
  local Count=ultraschall.CountLinesInFile(projectfilename_with_path)
  
  --Read the File again into individual parts
  local AA,BB=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, 1, B-1)
    --RENDER_FILE "Filename"
    --RENDER_PATTERN 
  local CC,DD=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, B+2,E)
    --<RENDER_CFG
    -- crypticrender_cfg_pattern
    -->
  local EE,FF=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, E+2,Count)
  --Now, we can insert the render-filename(WebM) 
  --as well as the WEBM-Render-Settings
  local Newfile=AA.."\n  RENDER_FILE \""..WebM_filename_with_path.."\"\n"..CC.."    "..WebM_Render_Setting.."\n"..EE
  
  --Let's save the modified project into a temp-file in the same directory as the
  --original projectfile
  --but only, if the file ultraschall-temp.rpp does not exist yet!
  local tempfile
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    tempfile=projectfilename_with_path:match("(.*)\\").."\\ultraschall-temp.rpp"
  else
    tempfile=projectfilename_with_path:match("(.*)/").."/ultraschall-temp.rpp"
  end
  if reaper.file_exists(tempfile)==true then return -3 end
  local file=io.open(tempfile,"w")
  file:write(Newfile)
  file:close()
    
  --Now we need to get the currently opened project
  local projectpath = reaper.GetProjectPath("pathtofile")
  projectpath = projectpath:sub(1,-11)
  local oldprojectname = projectpath..reaper.GetProjectName(0, 0)

  --Now the magic happens:
  reaper.Main_openProject(tempfile) --load the temporary projectfile
  reaper.Main_OnCommand(41824,0)    --render using it with the last rendersettings(those, we inserted included)
  reaper.Main_SaveProject(0, false) --save tempproject(no use, but otherwise, Reaper would open a Save-Dialog, that we don't want and need)

  --Now reopen the old project again. If there wasn't one(an empty project), just close the tempproject
  if reaper.file_exists(oldprojectname)==true then reaper.Main_openProject(oldprojectname)
  else reaper.Main_OnCommand(40860,0)
  end
  --remove the temp-file and we are done.
  os.remove (tempfile)
  os.remove (tempfile.."-bak")--]]
  return 0
end

--A=ultraschall.RenderProjectToWebMVideo("c:\\tt.rpp", "C:\\testograf.webm", 1, 1, "XGA", 8)
--A=ultraschall.RenderFLAC("c:\\tt.rpp", "c:\\test.flac", 16,5)

--ultraschall.RenderWebM(projectfilename_with_path, WebM_filename_with_path, videobitrate, audiobitrate, resolution, framerate)

function ultraschall.RenderProjectToMP3_MaxQuality(projectfilename_with_path, MP3_filename_with_path)
-- Renders the projectfile "projectfilename_with_path" as MP3
-- returns -1 in case of error
-- returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
--
-- string projectfilename_with_path - the RPP-File to Render
-- string MP3_filename - the MP3-filename with path, that shall be created

--[[
<ApiDocBlocFunc>
<slug>
RenderProjectToMP3_MaxQuality
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RenderProjectToMP3_MaxQuality(string projectfilename_with_path, string MP3_filename_with_path)
</functionname>
<description>
Renders the projectfilename_with_path as MP3 to MP3_filename_with_path.
returns -1 in case of error
returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
returns -3, if the tempfile ultraschall-temp.rpp already exists in the projectfolder of the projectfile
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string MP3_filename_with_path - the name of the file, where the project will be rendered to
</parameters>
<retvals>
integer retval - returns, if rendering was successful
- 0 in case of success
- -1 in case of error
- -2, if the current projectfile hasn't been saved yet(it must be saved first!)
- -3, if the tempfile ultraschall-temp.rpp already exists
</retvals>
<semanticcontext>
Rendering of Project
Audio
</semanticcontext>
<tags>
rendering, project, export, audio, mp3
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil or MP3_filename_with_path==nil then return -1 end
  if reaper.IsProjectDirty(0)==1 then return -2 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  
  local MP3_Render_Setting="bDNwbSAAAAABAAAACQAAAAAAAAAAAAAAQAEAAAAAAAA=" --highest quality setting
  
  -- Read Projectfile
  local A,B=ultraschall.ReadValueFromFile(projectfilename_with_path, "RENDER_FILE")
  local D,E=ultraschall.ReadValueFromFile(projectfilename_with_path, "<RENDER_CFG")
  local Count=ultraschall.CountLinesInFile(projectfilename_with_path)
  
  --Read the File again into individual parts
  local AA,BB=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, 1, B-1)
    --RENDER_FILE "Filename"
    --RENDER_PATTERN 
  local CC,DD=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, B+2,E)
    --<RENDER_CFG
    -- crypticrender_cfg_pattern
    -->
  local EE,FF=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, E+2,Count)
  --Now, we can insert the render-filename(MP3) 
  --as well as the MP3-Render-Settings for High Quality
  local Newfile=AA.."\n  RENDER_FILE \""..MP3_filename_with_path.."\"\n"..CC.."    "..MP3_Render_Setting.."\n"..EE
  
  --Let's save the modified project into a temp-file in the same directory as the
  --original projectfile
  --but only, if the file ultraschall-temp.rpp does not exist yet!
  local tempfile
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    tempfile=projectfilename_with_path:match("(.*)\\").."\\ultraschall-temp.rpp"
  else
    tempfile=projectfilename_with_path:match("(.*)/").."/ultraschall-temp.rpp"
  end
  if reaper.file_exists(tempfile)==true then return -3 end
  local file=io.open(tempfile,"w")
  file:write(Newfile)
  file:close()
    
  --Now we need to get the currently opened project
  local projectpath = reaper.GetProjectPath("pathtofile")
  projectpath = projectpath:sub(1,-11)
  local oldprojectname = projectpath..reaper.GetProjectName(0, 0)

  --Now the magic happens:
  reaper.Main_openProject(tempfile) --load the temporary projectfile
  reaper.Main_OnCommand(41824,0)    --render using it with the last rendersettings(those, we inserted included)
  reaper.Main_SaveProject(0, false) --save it(no use, but otherwise, Reaper would open a Save-Dialog, that we don't want and need)

  --Now reopen the old project again. If there wasn't one(an empty project), just close the tempproject
  if reaper.file_exists(oldprojectname)==true then reaper.Main_openProject(oldprojectname)
  else reaper.Main_OnCommand(40860,0)
  end
  --remove the temp-file and we are done.
  os.remove (tempfile)
  os.remove (tempfile.."-bak")
  return 0
end


--AAAAA=ultraschall.RenderProjectToMP3_MaxQuality("c:\\tt.rpp", "c:\\temp\\test mulle.mp3")


function ultraschall.RenderProjectToMP3_VBR(projectfilename_with_path, MP3_filename_with_path, quality, encode_speed)
-- Renders the projectfile "projectfilename_with_path" as MP3 with a variable bitrate
-- returns -1 in case of error
-- returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
-- returns -3, if the tempfile ultraschall-temp.rpp already exists
--
-- string projectfilename_with_path - the RPP-File to Render
-- string MP3_filename - the MP3-filename with path, that shall be created
-- integer quality - 1 - worst,2,3,4,5,6,7,8,9,10 - best
-- integer encode_speed - 1- fastest encode, 2 - Fast encode, 3 - Normal, 4 - Better, 5 - Maximum

--[[
<ApiDocBlocFunc>
<slug>
RenderProjectToMP3_VBR
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RenderProjectToMP3_VBR(string projectfilename_with_path, string MP3_filename_with_path, integer quality, integer encode_speed)
</functionname>
<description>
Renders the projectfilename_with_path as variable-bitrate-MP3 to MP3_filename_with_path.
returns -1 in case of error
returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
returns -3, if the tempfile ultraschall-temp.rpp already exists in the projectfolder of the projectfile
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string MP3_filename_with_path - the name of the file, where the project will be rendered to
integer quality - the quality of the MP3-file; 1(worst) to 10(best)
integer encode_speed - encoding-speed from 1(fastest encode) to 5(maximum slow); 3-normal(default encoding speed)
</parameters>
<retvals>
integer retval - returns, if rendering was successful
- 0 in case of success
- -1 in case of error
- -2, if the current projectfile hasn't been saved yet(it must be saved first!)
- -3, if the tempfile ultraschall-temp.rpp already exists
</retvals>
<semanticcontext>
Rendering of Project
Audio
</semanticcontext>
<tags>
rendering, project, export, audio, mp3, vbr
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil or MP3_filename_with_path==nil or tonumber(quality)==nil or tonumber(encode_speed)==nil then return -1 end
  quality=tonumber(quality)
  encode_speed=tonumber(encode_speed)
  if reaper.IsProjectDirty(0)==1 then return -2 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  
--  reaper.MB(encode_speed,"",0)
  
  local MP3_Render_Setting=""
  local qualitycode=""
  local speedcode=""
  
  if quality==1 then qualitycode="J" -- worst
  elseif quality==2 then qualitycode="I" --
  elseif quality==3 then qualitycode="H" --
  elseif quality==4 then qualitycode="G" --
  elseif quality==5 then qualitycode="F" --
  elseif quality==6 then qualitycode="E" --
  elseif quality==7 then qualitycode="D" --
  elseif quality==8 then qualitycode="C" --
  elseif quality==9 then qualitycode="B" --
  elseif quality==10 then qualitycode="A" -- best
  else return -1
  end
  
  if encode_speed==1 then speedcode="CQ" -- Fastest encode
  elseif encode_speed==2 then speedcode="Bw" -- Fast encode
  elseif encode_speed==3 then speedcode="BQ" -- Normal (recommended)
  elseif encode_speed==4 then speedcode="Ag" -- Better (slower)
  elseif encode_speed==5 then speedcode="AA" -- Maximum (slow)
  else return -1
  end

  MP3_Render_Setting="bDNwbSAAAAABAAAA"..speedcode.."AAAAAAAAA"..qualitycode.."AAAAQAEAAAAAAAA="
  
--  reaper.ShowConsoleMsg(MP3_Render_Setting)
  
  --
  -- Read Projectfile
  local A,B=ultraschall.ReadValueFromFile(projectfilename_with_path, "RENDER_FILE")
  local D,E=ultraschall.ReadValueFromFile(projectfilename_with_path, "<RENDER_CFG")
  local Count=ultraschall.CountLinesInFile(projectfilename_with_path)
  
  --Read the File again into individual parts
  local AA,BB=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, 1, B-1)
    --RENDER_FILE "Filename"
    --RENDER_PATTERN 
  local CC,DD=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, B+2,E)
    --<RENDER_CFG
    -- crypticrender_cfg_pattern
    -->
  local EE,FF=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, E+2,Count)
  --Now, we can insert the render-filename(FLAC) 
  --as well as the FLAC-Render-Settings for High Quality
  local Newfile=AA.."\n  RENDER_FILE \""..MP3_filename_with_path.."\"\n"..CC.."    "..MP3_Render_Setting.."\n"..EE
  
  --Let's save the modified project into a temp-file in the same directory as the
  --original projectfile
  --but only, if the file ultraschall-temp.rpp does not exist yet!
  local tempfile
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    tempfile=projectfilename_with_path:match("(.*)\\").."\\ultraschall-temp.rpp"
  else
    tempfile=projectfilename_with_path:match("(.*)/").."/ultraschall-temp.rpp"
  end
  if reaper.file_exists(tempfile)==true then return -3 end
  local file=io.open(tempfile,"w")
  file:write(Newfile)
  file:close()
    
  --Now we need to get the currently opened project
  local projectpath = reaper.GetProjectPath("pathtofile")
  projectpath = projectpath:sub(1,-11)
  local oldprojectname = projectpath..reaper.GetProjectName(0, 0)

  --Now the magic happens:
  reaper.Main_openProject(tempfile) --load the temporary projectfile
  reaper.Main_OnCommand(41824,0)    --render using it with the last rendersettings(those, we inserted included)
  reaper.Main_SaveProject(0, false) --save it(no use, but otherwise, Reaper would open a Save-Dialog, that we don't want and need)

  --Now reopen the old project again. If there wasn't one(an empty project), just close the tempproject
  if reaper.file_exists(oldprojectname)==true then reaper.Main_openProject(oldprojectname)
  else reaper.Main_OnCommand(40860,0)
  end
  --remove the temp-file and we are done.
  os.remove (tempfile)
  os.remove (tempfile.."-bak")--]]
  return 0
end

--A=ultraschall.RenderFLAC("c:\\tt.rpp", "c:\\test.flac", 16,5)

--A=ultraschall.RenderProjectToMP3_VBR("c:\\tt.rpp", "c:\\tt.mp3", 10, 5)


function ultraschall.RenderProjectToMP3_CBR(projectfilename_with_path, MP3_filename_with_path, audiobitrate, encode_speed)
-- Renders the projectfile "projectfilename_with_path" as MP3 with a constant bitrate
-- returns -1 in case of error
-- returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
-- returns -3, if the tempfile ultraschall-temp.rpp already exists
--
-- string projectfilename_with_path - the RPP-File to Render
-- string MP3_filename - the MP3-filename with path, that shall be created
-- integer audiobitrate - 8-320 kbps (allowed, 8,16,24,32,40,48,56,64,80,96,112,128,160,192,225,256,320)
-- integer encode_speed - 1- fastest encode, 2 - Fast encode, 3 - Normal, 4 - Better, 5 - Maximum


--[[
<ApiDocBlocFunc>
<slug>
RenderProjectToMP3_CBR
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RenderProjectToMP3_CBR(string projectfilename_with_path, string MP3_filename_with_path, integer audiobitrate, integer encode_speed)
</functionname>
<description>
Renders the projectfilename_with_path as constant-bitrate-MP3 to MP3_filename_with_path.
returns -1 in case of error
returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
returns -3, if the tempfile ultraschall-temp.rpp already exists in the projectfolder of the projectfile
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string MP3_filename_with_path - the name of the file, where the project will be rendered to
integer audiobitrate - the bitrate of the MP3
- 8 kbps
- 16 kbps
- 24 kbps
- 32 kbps
- 40 kbps
- 48 kbps
- 56 kbps
- 64 kbps
- 80 kbps
- 96 kbps
- 112 kbps
- 128 kbps
- 160 kbps
- 192 kbps
- 224 kbps
- 256 kbps
- 320 kbps

integer encode_speed - encoding-speed from 1(fastest encode) to 5(maximum slow); 3-normal(default encoding speed)
</parameters>
<retvals>
integer retval - returns, if rendering was successful
- 0 in case of success
- -1 in case of error
- -2, if the current projectfile hasn't been saved yet(it must be saved first!)
- -3, if the tempfile ultraschall-temp.rpp already exists
</retvals>
<semanticcontext>
Rendering of Project
Audio
</semanticcontext>
<tags>
rendering, project, export, audio, mp3, cbr
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil or MP3_filename_with_path==nil or tonumber(audiobitrate)==nil or tonumber(encode_speed)==nil then return -1 end
  audiobitrate=tonumber(audiobitrate)
  encode_speed=tonumber(encode_speed)
  if reaper.IsProjectDirty(0)==1 then return -2 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  
--  reaper.MB(encode_speed,"",0)
  
  local MP3_Render_Setting=""
  local audiobitcode=""
  local audiobitcode2=""
  local speedcode=""
  
  if audiobitrate<=8 then audiobitcode2="QgA" audiobitcode="CAA" --8 kbps
  elseif audiobitrate>8 and audiobitrate<=16 then audiobitcode2="RAA" audiobitcode="EAA" --16 kbps
  elseif audiobitrate>16 and audiobitrate<=24 then audiobitcode2="RgA" audiobitcode="GAA" --24 kbps
  elseif audiobitrate>24 and audiobitrate<=32 then audiobitcode2="SAA" audiobitcode="IAA" --32 kbps
  elseif audiobitrate>32 and audiobitrate<=40 then audiobitcode2="SgA" audiobitcode="KAA" --40 kbps
  elseif audiobitrate>40 and audiobitrate<=48 then audiobitcode2="TAA" audiobitcode="MAA" --48 kbps
  elseif audiobitrate>48 and audiobitrate<=56 then audiobitcode2="TgA" audiobitcode="OAA" --56 kbps
  elseif audiobitrate>56 and audiobitrate<=64 then audiobitcode2="UAA" audiobitcode="QAA" --64 kbps
  elseif audiobitrate>64 and audiobitrate<=80 then audiobitcode2="VAA" audiobitcode="UAA" --80 kbps
  elseif audiobitrate>80 and audiobitrate<=96 then audiobitcode2="WAA" audiobitcode="YAA" --96 kbps
  elseif audiobitrate>96 and audiobitrate<=112 then audiobitcode2="XAA" audiobitcode="cAA" --112 kbps
  elseif audiobitrate>112 and audiobitrate<=128 then audiobitcode2="YAA" audiobitcode="gAA" --128 kbps
  elseif audiobitrate>128 and audiobitrate<=160 then audiobitcode2="aAA" audiobitcode="oAA" --160 kbps
  elseif audiobitrate>160 and audiobitrate<=192 then audiobitcode2="cAA" audiobitcode="wAA" --192 kbps
  elseif audiobitrate>192 and audiobitrate<=224 then audiobitcode2="eAA" audiobitcode="4AA" --224 kbps
  elseif audiobitrate>224 and audiobitrate<=256 then audiobitcode2="QAB" audiobitcode="AAE" --256 kbps
  elseif audiobitrate>256 then audiobitcode2="UAB" audiobitcode="QAE" --320 kbps
  else return -1
  end
    
  if encode_speed==1 then speedcode="CQ" -- Fastest encode
  elseif encode_speed==2 then speedcode="Bw" -- Fast encode
  elseif encode_speed==3 then speedcode="BQ" -- Normal (recommended)
  elseif encode_speed==4 then speedcode="Ag" -- Better (slower)
  elseif encode_speed==5 then speedcode="AA" -- Maximum (slow)
  else return -1
  end

  MP3_Render_Setting="bDNwb"..audiobitcode2.."AAABAAAA"..speedcode.."AAAP////8EAAAA"..audiobitcode.."AAAAAAAA="
--  reaper.ShowConsoleMsg(MP3_Render_Setting)
  --
  -- Read Projectfile
  local A,B=ultraschall.ReadValueFromFile(projectfilename_with_path, "RENDER_FILE")
  local D,E=ultraschall.ReadValueFromFile(projectfilename_with_path, "<RENDER_CFG")
  local Count=ultraschall.CountLinesInFile(projectfilename_with_path)
  
  --Read the File again into individual parts
  local AA,BB=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, 1, B-1)
    --RENDER_FILE "Filename"
    --RENDER_PATTERN 
  local CC,DD=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, B+2,E)
    --<RENDER_CFG
    -- crypticrender_cfg_pattern
    -->
  local EE,FF=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, E+2,Count)
  --Now, we can insert the render-filename(FLAC) 
  --as well as the FLAC-Render-Settings for High Quality
  local Newfile=AA.."\n  RENDER_FILE \""..MP3_filename_with_path.."\"\n"..CC.."    "..MP3_Render_Setting.."\n"..EE
  
  --Let's save the modified project into a temp-file in the same directory as the
  --original projectfile
  --but only, if the file ultraschall-temp.rpp does not exist yet!
  local tempfile
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    tempfile=projectfilename_with_path:match("(.*)\\").."\\ultraschall-temp.rpp"
  else
    tempfile=projectfilename_with_path:match("(.*)/").."/ultraschall-temp.rpp"
  end
  if reaper.file_exists(tempfile)==true then return -3 end
  local file=io.open(tempfile,"w")
  file:write(Newfile)
  file:close()
    
  --Now we need to get the currently opened project
  local projectpath = reaper.GetProjectPath("pathtofile")
  projectpath = projectpath:sub(1,-11)
  local oldprojectname = projectpath..reaper.GetProjectName(0, 0)

  --Now the magic happens:
  reaper.Main_openProject(tempfile) --load the temporary projectfile
  reaper.Main_OnCommand(41824,0)    --render using it with the last rendersettings(those, we inserted included)
  reaper.Main_SaveProject(0, false) --save it(no use, but otherwise, Reaper would open a Save-Dialog, that we don't want and need)

  --Now reopen the old project again. If there wasn't one(an empty project), just close the tempproject
  if reaper.file_exists(oldprojectname)==true then reaper.Main_openProject(oldprojectname)
  else reaper.Main_OnCommand(40860,0)
  end
  --remove the temp-file and we are done.
  os.remove (tempfile)
  os.remove (tempfile.."-bak")--]]
  return 0
end

--A=ultraschall.RenderProjectToMP3_CBR("c:\\tt.rpp", "c:\\Att.mp3", -1, 5)

function ultraschall.RenderProjectToMP3_ABR(projectfilename_with_path, MP3_filename_with_path, audiobitrate, encode_speed)
-- Renders the projectfile "projectfilename_with_path" as MP3 with n average bit rate(ABR)
-- returns -1 in case of error
-- returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
-- returns -3, if the tempfile ultraschall-temp.rpp already exists
--
-- string projectfilename_with_path - the RPP-File to Render
-- string MP3_filename - the MP3-filename with path, that shall be created
-- integer audiobitrate - 8-320 kbps (allowed, 8,16,24,32,40,48,56,64,80,96,112,128,160,192,225,256,320)
-- integer encode_speed - 1- fastest encode, 2 - Fast encode, 3 - Normal, 4 - Better, 5 - Maximum


--[[
<ApiDocBlocFunc>
<slug>
RenderProjectToMP3_ABR
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RenderProjectToMP3_ABR(string projectfilename_with_path, string MP3_filename_with_path, integer audiobitrate, integer encode_speed)
</functionname>
<description>
Renders the projectfilename_with_path as average-bitrate-MP3 to MP3_filename_with_path.
returns -1 in case of error
returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
returns -3, if the tempfile ultraschall-temp.rpp already exists in the projectfolder of the projectfile
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string MP3_filename_with_path - the name of the file, where the project will be rendered to
integer audiobitrate - the bitrate of the MP3
- 8 kbps
- 16 kbps
- 24 kbps
- 32 kbps
- 40 kbps
- 48 kbps
- 56 kbps
- 64 kbps
- 80 kbps
- 96 kbps
- 112 kbps
- 128 kbps
- 160 kbps
- 192 kbps
- 224 kbps
- 256 kbps
- 320 kbps

integer encode_speed - 1 - fastest encode, 2 - Fast encode, 3 - Normal, 4 - Better, 5 - Maximum
</parameters>
<retvals>
integer retval - returns, if rendering was successful
- 0 in case of success
- -1 in case of error
- -2, if the current projectfile hasn't been saved yet(it must be saved first!)
- -3, if the tempfile ultraschall-temp.rpp already exists
</retvals>
<semanticcontext>
Rendering of Project
Audio
</semanticcontext>
<tags>
rendering, project, export, audio, mp3, abr
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil or MP3_filename_with_path==nil or tonumber(audiobitrate)==nil or tonumber(encode_speed)==nil then return -1 end
  audiobitrate=tonumber(audiobitrate)
  encode_speed=tonumber(encode_speed)
  if reaper.IsProjectDirty(0)==1 then return -2 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  
--  reaper.MB(encode_speed,"",0)
  
  local MP3_Render_Setting=""
  local targetbitratecode=""
  local speedcode=""
  
  if audiobitrate<=8 then targetbitratecode="AgA" --8 kbps
  elseif audiobitrate>8 and audiobitrate<=16 then targetbitratecode="BAA" --16 kbps
  elseif audiobitrate>16 and audiobitrate<=24 then targetbitratecode="BgA" --24 kbps
  elseif audiobitrate>24 and audiobitrate<=32 then targetbitratecode="CAA" --32 kbps
  elseif audiobitrate>32 and audiobitrate<=40 then targetbitratecode="CgA" --40 kbps
  elseif audiobitrate>40 and audiobitrate<=48 then targetbitratecode="DAA" --48 kbps
  elseif audiobitrate>48 and audiobitrate<=56 then targetbitratecode="DgA" --56 kbps
  elseif audiobitrate>56 and audiobitrate<=64 then targetbitratecode="EAA" --64 kbps
  elseif audiobitrate>64 and audiobitrate<=80 then targetbitratecode="FAA" --80 kbps
  elseif audiobitrate>80 and audiobitrate<=96 then targetbitratecode="GAA" --96 kbps
  elseif audiobitrate>96 and audiobitrate<=112 then targetbitratecode="HAA" --112 kbps
  elseif audiobitrate>112 and audiobitrate<=128 then targetbitratecode="IAA" --128 kbps
  elseif audiobitrate>128 and audiobitrate<=160 then targetbitratecode="KAA" --160 kbps
  elseif audiobitrate>160 and audiobitrate<=192 then targetbitratecode="MAA" --192 kbps
  elseif audiobitrate>192 and audiobitrate<=224 then targetbitratecode="OAA" --224 kbps
  elseif audiobitrate>224 and audiobitrate<=256 then targetbitratecode="AAB" --256 kbps
  elseif audiobitrate>256 then targetbitratecode="EAB" --320 kbps
  else return -1
  end
    
  if encode_speed==1 then speedcode="CQ" -- Fastest encode
  elseif encode_speed==2 then speedcode="Bw" -- Fast encode
  elseif encode_speed==3 then speedcode="BQ" -- Normal (recommended)
  elseif encode_speed==4 then speedcode="Ag" -- Better (slower)
  elseif encode_speed==5 then speedcode="AA" -- Maximum (slow)
  else return -1
  end

  MP3_Render_Setting="bDNwbSAAAAABAAAA"..speedcode.."AAAAQAAAAEAAAAQAEAA"..targetbitratecode.."AAA="
--  reaper.ShowConsoleMsg(MP3_Render_Setting)
  
  --
  -- Read Projectfile
  local A,B=ultraschall.ReadValueFromFile(projectfilename_with_path, "RENDER_FILE")
  local D,E=ultraschall.ReadValueFromFile(projectfilename_with_path, "<RENDER_CFG")
  local Count=ultraschall.CountLinesInFile(projectfilename_with_path)
  
  --Read the File again into individual parts
  local AA,BB=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, 1, B-1)
    --RENDER_FILE "Filename"
    --RENDER_PATTERN 
  local CC,DD=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, B+2,E)
    --<RENDER_CFG
    -- crypticrender_cfg_pattern
    -->
  local EE,FF=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, E+2,Count)
  --Now, we can insert the render-filename(FLAC) 
  --as well as the FLAC-Render-Settings for High Quality
  local Newfile=AA.."\n  RENDER_FILE \""..MP3_filename_with_path.."\"\n"..CC.."    "..MP3_Render_Setting.."\n"..EE
  
  --Let's save the modified project into a temp-file in the same directory as the
  --original projectfile
  --but only, if the file ultraschall-temp.rpp does not exist yet!
  local tempfile
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    tempfile=projectfilename_with_path:match("(.*)\\").."\\ultraschall-temp.rpp"
  else
    tempfile=projectfilename_with_path:match("(.*)/").."/ultraschall-temp.rpp"
  end
  if reaper.file_exists(tempfile)==true then return -3 end
  local file=io.open(tempfile,"w")
  file:write(Newfile)
  file:close()
    
  --Now we need to get the currently opened project
  local projectpath = reaper.GetProjectPath("pathtofile")
  projectpath = projectpath:sub(1,-11)
  local oldprojectname = projectpath..reaper.GetProjectName(0, 0)

  --Now the magic happens:
  reaper.Main_openProject(tempfile) --load the temporary projectfile
  reaper.Main_OnCommand(41824,0)    --render using it with the last rendersettings(those, we inserted included)
  reaper.Main_SaveProject(0, false) --save it(no use, but otherwise, Reaper would open a Save-Dialog, that we don't want and need)

  --Now reopen the old project again. If there wasn't one(an empty project), just close the tempproject
  if reaper.file_exists(oldprojectname)==true then reaper.Main_openProject(oldprojectname)
  else reaper.Main_OnCommand(40860,0)
  end
  --remove the temp-file and we are done.
  os.remove (tempfile)
  os.remove (tempfile.."-bak")--]]
  return 0
end

--A=ultraschall.RenderProjectToMP3_ABR("c:\\tt.rpp", "c:\\Att.mp3", 320, 5)

function ultraschall.RenderProjectToOPUS(projectfilename_with_path, OPUS_filename_with_path, audiobitrate, bitratemode, complexity)
-- Renders the projectfile "projectfilename_with_path" as MP3 with n average bit rate(ABR)
-- returns -1 in case of error
-- returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
-- returns -3, if the tempfile ultraschall-temp.rpp already exists
--
-- string projectfilename_with_path - the RPP-File to Render
-- string MP3_filename - the MP3-filename with path, that shall be created
-- integer audiobitrate - 8-320 kbps (allowed, 8,16,24,32,40,48,56,64,80,96,112,128,160,192,225,256,320)
-- integer encode_speed - 1- fastest encode, 2 - Fast encode, 3 - Normal, 4 - Better, 5 - Maximum

--[[
<ApiDocBlocFunc>
<slug>
RenderProjectToOPUS
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.RenderProjectToOPUS(string projectfilename_with_path, string OPUS_filename_with_path, integer audiobitrate, integer bitratemode, integer complexity)
</functionname>
<description>
Renders the projectfilename_with_path as Opus to OPUS_filename_with_path.
returns -1 in case of error
returns -2, if the current projectfile hasn't been saved yet(it must be saved first!)
returns -3, if the tempfile ultraschall-temp.rpp already exists in the projectfolder of the projectfile
</description>
<parameters>
string projectfilename_with_path - filename with path of the rpp-project-file
string OPUS_filename_with_path - the name of the file, where the project will be rendered to
integer audiobitrate - the bitrate of the MP3
- 8 kbps
- 16 kbps
- 24 kbps
- 32 kbps
- 40 kbps
- 48 kbps
- 56 kbps
- 64 kbps
- 80 kbps
- 96 kbps
- 112 kbps
- 128 kbps
- 160 kbps
- 192 kbps
- 224 kbps
- 256 kbps

integer bitratemode -  1 - VariableBitrate, 2 - ConstantVariableBitrate, 3 - HARD-ConstantBitrate
integer complexity - complexity of the encoding
- 0 - Fastest encode
- 1 - Fastest encode
- 2 - Fast encode
- 3 - Normal (recommended)
- 4 - Better (slower)
- 5 - Maximum (slow)
- 6 - Fast encode
- 7 - Normal (recommended)
- 8 - Better (slower)
- 9 - Maximum (slow)
- 10 - Maximum (slow)
</parameters>
<retvals>
integer retval - returns, if rendering was successful
- 0 in case of success
- -1 in case of error
- -2, if the current projectfile hasn't been saved yet(it must be saved first!)
- -3, if the tempfile ultraschall-temp.rpp already exists
</retvals>
<semanticcontext>
Rendering of Project
Audio
</semanticcontext>
<tags>
rendering, project, export, audio, opus, vbr, cvbr, cbr, hadrcbr
</tags>
</ApiDocBlocFunc>
]]

  if projectfilename_with_path==nil or OPUS_filename_with_path==nil or tonumber(audiobitrate)==nil or tonumber(bitratemode)==nil or tonumber(complexity)==nil then return -1 end
  audiobitrate=tonumber(audiobitrate)
  bitratemode=tonumber(bitratemode)
  complexity=tonumber(complexity)
  if reaper.IsProjectDirty(0)==1 then return -2 end
  if reaper.file_exists(projectfilename_with_path)==false then return -1 end
  
--  reaper.MB(encode_speed,"",0)
  
  local OPUS_Render_Setting=""
  local targetbitratecode=""
  local complcode=""
  local modecode=""
  
  if audiobitrate<=8 then targetbitratecode="AEE" --8 kbps
  elseif audiobitrate>8 and audiobitrate<=16 then targetbitratecode="gEE" --16 kbps
  elseif audiobitrate>16 and audiobitrate<=24 then targetbitratecode="wEE" --24 kbps
  elseif audiobitrate>24 and audiobitrate<=32 then targetbitratecode="AEI" --32 kbps
  elseif audiobitrate>32 and audiobitrate<=40 then targetbitratecode="IEI" --40 kbps
  elseif audiobitrate>40 and audiobitrate<=48 then targetbitratecode="QEI" --48 kbps
  elseif audiobitrate>48 and audiobitrate<=56 then targetbitratecode="YEI" --56 kbps
  elseif audiobitrate>56 and audiobitrate<=64 then targetbitratecode="gEI" --64 kbps
  elseif audiobitrate>64 and audiobitrate<=80 then targetbitratecode="oEI" --80 kbps
  elseif audiobitrate>80 and audiobitrate<=96 then targetbitratecode="wEI" --96 kbps
  elseif audiobitrate>96 and audiobitrate<=112 then targetbitratecode="4EI" --112 kbps
  elseif audiobitrate>112 and audiobitrate<=128 then targetbitratecode="AEM" --128 kbps
  elseif audiobitrate>128 and audiobitrate<=160 then targetbitratecode="IEM" --160 kbps
  elseif audiobitrate>160 and audiobitrate<=192 then targetbitratecode="QEM" --192 kbps
  elseif audiobitrate>192 and audiobitrate<=224 then targetbitratecode="YEM" --224 kbps
  elseif audiobitrate>224 then targetbitratecode="gEM" --256 kbps
  else return -1
  end

  if bitratemode==1 then modecode="A" -- VBR
  elseif bitratemode==2 then modecode="B" -- CVBR
  elseif bitratemode==3 then modecode="C" -- HARD-CBR
  else return -1
  end
    
  if complexity==0 then complcode="AA" -- Fastest encode
  elseif complexity==1 then complcode="AQ" -- Fastest encode
  elseif complexity==2 then complcode="Ag" -- Fast encode
  elseif complexity==3 then complcode="Aw" -- Normal (recommended)
  elseif complexity==4 then complcode="BA" -- Better (slower)
  elseif complexity==5 then complcode="BQ" -- Maximum (slow)
  elseif complexity==6 then complcode="Bg" -- Fast encode
  elseif complexity==7 then complcode="Bw" -- Normal (recommended)
  elseif complexity==8 then complcode="CA" -- Better (slower)
  elseif complexity==9 then complcode="CQ" -- Maximum (slow)
  elseif complexity==10 then complcode="Cg" -- Maximum (slow)
  else return -1
  end

  OPUS_Render_Setting="U2dnTwAA"..targetbitratecode..modecode..complcode.."AAAA=="
  --reaper.ShowConsoleMsg(OPUS_Render_Setting)
  
  --
  -- Read Projectfile
  local A,B=ultraschall.ReadValueFromFile(projectfilename_with_path, "RENDER_FILE")
  local D,E=ultraschall.ReadValueFromFile(projectfilename_with_path, "<RENDER_CFG")
  local Count=ultraschall.CountLinesInFile(projectfilename_with_path)
  
  --Read the File again into individual parts
  local AA,BB=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, 1, B-1)
    --RENDER_FILE "Filename"
    --RENDER_PATTERN 
  local CC,DD=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, B+2,E)
    --<RENDER_CFG
    -- crypticrender_cfg_pattern
    -->
  local EE,FF=ultraschall.ReadLinerangeFromFile(projectfilename_with_path, E+2,Count)
  --Now, we can insert the render-filename(FLAC) 
  --as well as the FLAC-Render-Settings for High Quality
  local Newfile=AA.."\n  RENDER_FILE \""..OPUS_filename_with_path.."\"\n"..CC.."    "..OPUS_Render_Setting.."\n"..EE
  
  --Let's save the modified project into a temp-file in the same directory as the
  --original projectfile
  --but only, if the file ultraschall-temp.rpp does not exist yet!
  local tempfile
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    tempfile=projectfilename_with_path:match("(.*)\\").."\\ultraschall-temp.rpp"
  else
    tempfile=projectfilename_with_path:match("(.*)/").."/ultraschall-temp.rpp"
  end
  if reaper.file_exists(tempfile)==true then return -3 end
  local file=io.open(tempfile,"w")
  file:write(Newfile)
  file:close()
    
  --Now we need to get the currently opened project
  local projectpath = reaper.GetProjectPath("pathtofile")
  projectpath = projectpath:sub(1,-11)
  local oldprojectname = projectpath..reaper.GetProjectName(0, 0)

  --Now the magic happens:
  reaper.Main_openProject(tempfile) --load the temporary projectfile
  reaper.Main_OnCommand(41824,0)    --render using it with the last rendersettings(those, we inserted included)
  reaper.Main_SaveProject(0, false) --save it(no use, but otherwise, Reaper would open a Save-Dialog, that we don't want and need)

  --Now reopen the old project again. If there wasn't one(an empty project), just close the tempproject
  if reaper.file_exists(oldprojectname)==true then reaper.Main_openProject(oldprojectname)
  else reaper.Main_OnCommand(40860,0)
  end
  --remove the temp-file and we are done.
  os.remove (tempfile)
  os.remove (tempfile.."-bak")--]]
  return 0
end

--A=ultraschall.RenderProjectToMP3_ABR("c:\\tt.rpp", "c:\\Att.mp3", 320, 5)

--A=ultraschall.RenderProjectToOPUS("c:\\tt.rpp", "c:\\tt2.opus", "127", "2", "10")


--reaper.MB(reaper.GetAppVersion(),"",0)

function ultraschall.MoveTrackEnvelopePointsBy(startposition, endposition, moveby, MediaTrack, cut_at_border)
--[[
<ApiDocBlocFunc>
<slug>
MoveTrackEnvelopePointsBy
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.MoveTrackEnvelopePointsBy(number startposition, number endposition, number moveby, MediaTrack MediaTrack, boolean cut_at_border)
</functionname>
<description>
Moves the envelopepoints between startposition and endposition by moveby in MediaTrack. 
It moves all trackenvelope-points for all track-envelopes available.

Does NOT move item-envelopepoints!

Returns -1 in case of failure.
</description>
<retvals>
integer retval - -1 in case of failure
</retvals>
<parameters>
number startposition - the startposition in seconds
number endposition - the endposition in seconds
number moveby - in seconds, negative values: move toward beginning of project, positive values: move toward the end of project
MediaTrack MediaTrack - the MediaTrack object of the track, where the EnvelopsPoints shall be moved
boolean cut_at_border - true, cut envelope-points, that would move outside section between startposition and endposition
</parameters>
<semanticcontext>
Envelope Management
Move
</semanticcontext>
<tags>
envelopemanagement, envelope, point, envelope point, move, moveby
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(startposition)==nil then return -1 end
  if tonumber(endposition)==nil then return -1 end
  if tonumber(startposition)>tonumber(endposition) then return -1 end
  if tonumber(moveby)==nil then return -1 end
  if reaper.ValidatePtr2(0, MediaTrack, "MediaTrack*")==false then return -1 end
  local EnvTrackCount=reaper.CountTrackEnvelopes(MediaTrack)

  for a=0, EnvTrackCount-1 do
    local TrackEnvelope=reaper.GetTrackEnvelope(MediaTrack, a)
    local EnvCount=reaper.CountEnvelopePoints(TrackEnvelope)
  
    for i=EnvCount, 0, -1 do
      local retval, time, value, shape, tension, selected = reaper.GetEnvelopePoint(TrackEnvelope, i)
      if time>=startposition and time<=endposition then
        if time+moveby>=tonumber(startposition) and time+moveby<=tonumber(endposition) then
          reaper.SetEnvelopePoint(TrackEnvelope, i, time+moveby,nil,nil,nil,nil,true)
        elseif cut_at_border==true and (time+moveby<tonumber(startposition) or time+moveby>tonumber(endposition)) then
--        reaper.MB("","",0)
          local boolean=reaper.DeleteEnvelopePointRange(TrackEnvelope, time, time+0.0000000000001)
        end
      end
    end
    reaper.Envelope_SortPoints(TrackEnvelope)
  end
  
end

--B=reaper.GetTrack(0,2)
--A=ultraschall.MoveTrackEnvelopePointsBy(3, 32, 1, B, true)
--reaper.UpdateArrange()
--Envelope_SortPoints


---------------------------
---- Marker Management ----
---------------------------

function ultraschall.MoveMarkers(startposition, endposition, moveby, cut_at_borders)
--[[
<ApiDocBlocFunc>
<slug>
MoveMarkers
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.MoveMarkers(number startposition, number endposition, number moveby, boolean cut_at_borders)
</functionname>
<description>
Moves the markers and regions between startposition and endposition by moveby.

Does NOT move time-signature-markers!

Returns -1 in case of failure.
</description>
<retvals>
integer retval - -1 in case of failure
</retvals>
<parameters>
number startposition - the startposition in seconds
number endposition - the endposition in seconds
number moveby - in seconds, negative values: move toward beginning of project, positive values: move toward the end of project
boolean cut_at_borders - shortens or cuts markers/regions, that leave (partially) the section between startposition and endposition
- Regions will only be affected, if they are completely within the section, otherwise, they will be just shortened.
</parameters>
<semanticcontext>
Markers
Move
</semanticcontext>
<tags>
markermanagement, move, moveby, region, marker
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(startposition)==nil then return -1 end
  if tonumber(endposition)==nil then return -1 end
  if tonumber(startposition)>tonumber(endposition) then return -1 end
  if tonumber(moveby)==nil then return -1 end
  
  local retval, num_markers, num_regions = reaper.CountProjectMarkers(0)
  
  for i=0, retval do
    local sretval, isrgn, pos, rgnend, name, markrgnindexnumber, color = reaper.EnumProjectMarkers3(0, i)
    if pos>=tonumber(startposition) and pos<=tonumber(endposition) then
--    reaper.ShowConsoleMsg("OHNEEE\n")
      if cut_at_borders==true then
        if isrgn==true and pos+moveby>=tonumber(startposition) and rgnend+moveby<=tonumber(endposition) then
          local boolean=reaper.SetProjectMarker(markrgnindexnumber, isrgn, pos+moveby, rgnend+moveby, name)
        elseif isrgn==true and pos+moveby<tonumber(startposition) and rgnend+moveby<=tonumber(startposition) then
          local boolean=reaper.DeleteProjectMarker(0, markrgnindexnumber, true)
        elseif isrgn==true and pos+moveby>=tonumber(endposition) and rgnend<=tonumber(endposition)+moveby then
          local boolean=reaper.DeleteProjectMarker(0, markrgnindexnumber, true)
        elseif isrgn==true and pos+moveby<tonumber(startposition) and rgnend+moveby<=tonumber(endposition) then
          local boolean=reaper.SetProjectMarker(markrgnindexnumber, isrgn, startposition, rgnend+moveby, name)
        elseif isrgn==true and pos+moveby>=tonumber(startposition) and rgnend+moveby>tonumber(endposition) and moveby<0 then
          local boolean=reaper.SetProjectMarker(markrgnindexnumber, isrgn, pos+moveby, rgnend, name)
        elseif isrgn==true and pos+moveby>=tonumber(startposition) and rgnend+moveby>tonumber(endposition) and moveby>=0 then
          local boolean=reaper.SetProjectMarker(markrgnindexnumber, isrgn, pos+moveby, rgnend, name)
          
        elseif isrgn==false and pos+moveby>=tonumber(startposition) and pos+moveby<=tonumber(endposition) then
          local boolean=reaper.SetProjectMarker(markrgnindexnumber, isrgn, pos+moveby, rgnend+moveby, name)
        elseif isrgn==false and pos+moveby<tonumber(startposition) or pos+moveby>tonumber(endposition) then
          local boolean=reaper.DeleteProjectMarker(0, markrgnindexnumber, false)          
        end
      else
        local boolean=reaper.SetProjectMarker(markrgnindexnumber, isrgn, pos+moveby, rgnend+moveby, name)
      end --if cutborders
    elseif isrgn==true and pos<=tonumber(startposition) and pos<=tonumber(endposition) then
--    reaper.ShowConsoleMsg("hula\n")
      if cut_at_borders==true then
        if rgnend+moveby<=tonumber(endposition) and rgnend+moveby>=tonumber(startposition)then
          local boolean=reaper.SetProjectMarker(markrgnindexnumber, isrgn, pos, rgnend+moveby, name)
        end
      end --if cutborders - only regions that start before startposition
    end --if
  end --for
end

--Aretval = ultraschall.MoveMarkers(23, 169, -1, true)

-------------------------------
---- Media Item Management ----
-------------------------------

function ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
--sorts entries in a trackstring and removes duplicate numbers.
--returns it as csv string(values separated by a ,), an array, with all the tracknumbers individually and the number of numbers in the trackstring
--[[
<ApiDocBlocFunc>
<slug>
RemoveDuplicateTracksInTrackstring
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval, string trackstring, array trackstringarray, integer number_of_entries = ultraschall.RemoveDuplicateTracksInTrackstring(string trackstring)
</functionname>
<description>
Sorts tracknumbers in trackstring and throws out duplicates. It also throws out entries, that are no numbers.
Returns the "cleared" trackstring as string and as array, as well as the number of entries. Returns -1 in case of failure.
</description>
<parameters>
string trackstring - the tracknumbers, separated by a comma
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
string trackstring - the cleared trackstring, -1 in case of error
array trackstringarray - the "cleared" trackstring as an array
integer number_of_entries - the number of entries in the trackstring
</retvals>
<semanticcontext>
Track Management
Assistance functions
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, selection
</tags>
</ApiDocBlocFunc>
]]

    local Trackstring_array=ultraschall.CSV2IndividualLinesAsArray(trackstring)
    if Trackstring_array==-1 then return -1 end
    table.sort(Trackstring_array)
    local count=2
    while Trackstring_array[count]~=nil do
      if Trackstring_array[count]==Trackstring_array[count-1] then table.remove(Trackstring_array,count) count=count-1 
      elseif tonumber(Trackstring_array[count])==nil then table.remove(Trackstring_array,count) count=count-1
      end
      count=count+1
    end
    count=1
    if tonumber(Trackstring_array[1])==nil then table.remove(Trackstring_array,1) end
    trackstring=""
    while Trackstring_array[count]~=nil do
      trackstring=trackstring..Trackstring_array[count]..","
      count=count+1
    end
    return 1, trackstring:sub(1,-2), Trackstring_array, count-1
end

--A,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring("o,1,2,99,l,8,4")

--C,CC=ultraschall.GetAllMediaItemsBetween(0,260,"1,2,3",false)
--P=ultraschall.OnlyMediaItemsOfTracksInTrackstring(CC, "2,3")


function ultraschall.GetMediaItemsAtPosition(position, trackstring)
-- returns the items at given position in your selected tracks
--
-- number position - time in seconds
-- string trackstring - the tracksnumbers, beginning with 1 for first track, separated by a ,
--[[
<ApiDocBlocFunc>
<slug>
GetMediaItemsAtPosition
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_of_items, array MediaItemArray = ultraschall.GetMediaItemsAtPosition(number position, string trackstring)
</functionname>
<description>
Getsa all Mediaitems at position, from the tracks given by trackstring.
Returns a MediaItemArray with the found MediaItems; returns -1 in case of error
</description>
<parameters>
number position - position in seconds
string trackstring - the tracknumbers, separated by a comma
</parameters>
<retvals>
integer number_of_items - the number of items at position
array MediaItemArray - an array, that contains all MediaItems at position from the tracks given by trackstring.
</retvals>
<semanticcontext>
MediaItem Management
Selection
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, selection
</tags>
</ApiDocBlocFunc>
]]

  if tonumber(position)==nil then return -1 end
  position=tonumber(position)
  if trackstring==nil then return -1 end
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring=="" then return -1 end
  
  local MediaItemArray={}
  local count=0
  local LineArray,Numbers=ultraschall.CSV2IndividualLinesAsArray(trackstring)
  local Anumber=reaper.CountMediaItems(0)
  for i=0,Anumber-1 do
    local MediaItem=reaper.GetMediaItem(0, i)
    local Astart=reaper.GetMediaItemInfo_Value(MediaItem, "D_POSITION")
    local Alength=reaper.GetMediaItemInfo_Value(MediaItem, "D_LENGTH")
    local MediaTrack=reaper.GetMediaItem_Track(MediaItem)
    local MediaTrackNumber=reaper.GetMediaTrackInfo_Value(MediaTrack, "IP_TRACKNUMBER")
    local Aend=Astart+Alength
    if position>=Astart and position<=Aend then
       for a=1, Numbers do
--       reaper.MB(MediaTrackNumber,LineArray[a],0)
        if tonumber(LineArray[a])==nil then return -1 end
        if MediaTrackNumber==tonumber(LineArray[a]) then
          count=count+1 
          MediaItemArray[count]=MediaItem
--          reaper.MB(MediaTrackNumber,LineArray[a],0)
        end
       end
    end
  end
  return count, MediaItemArray
end

--reaper.MB(tostring(AA[1],"",0),"",0)

--A,B=ultraschall.GetMediaItemsAtPosition(20, "ö")
--C=ultraschall.OnlyMediaItemsOfTracksInTrackstring(B, "o")

function ultraschall.OnlyMediaItemsOfTracksInTrackstring(MediaItemArray, trackstring)
--Throws out all items, that are not in the tracks, as given by trackstring
--[[
<ApiDocBlocFunc>
<slug>
OnlyMediaItemsOfTracksInTrackstring
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval, array MediaItemArray = ultraschall.OnlyMediaItemsOfTracksInTrackstring(array MediaItemArray, string trackstring)
</functionname>
<description>
Throws all MediaItems out of the MediaItemArray, that is not within the tracks, as given with trackstring.
Returns the "cleared" MediaItemArray; returns -1 in case of error
</description>
<parameters>
array MediaItemArray - an array with MediaItems; no nil-entries allowed, will be seen as the end of the array
string trackstring - the tracknumbers, separated by a comma
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
array MediaItemArray - the "cleared" array, that contains only Items in tracks, as given by trackstring, -1 in case of error
</retvals>
<semanticcontext>
MediaItem Management
Assistance functions
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, selection
</tags>
</ApiDocBlocFunc>
]]
  if type(MediaItemArray)~="table" then return -1 end
  if trackstring==nil then return -1 end
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring=="" then return -1 end
  
  local count=1
  local count2=1
  local i=1
  local trackstring_array= ultraschall.CSV2IndividualLinesAsArray(trackstring)
  local MediaItemArray2={}
  
  while MediaItemArray[count]~=nil do
    if MediaItemArray[count]==nil then break end
    i=1
    while trackstring_array[i]~=nil do
      if tonumber(trackstring_array[i])==nil then return -1 end
--      reaper.MB(tonumber(trackstring_array[i]),"",0)
        if reaper.GetTrack(0,trackstring_array[i]-1)==reaper.GetMediaItem_Track(MediaItemArray[count]) then
  --      reaper.MB(tostring(MediaItemArray2),"",0)
        MediaItemArray2[count2]=MediaItemArray[count]
        count2=count2+1
        end
--        end
        i=i+1
    end
    count=count+1
  end
  return 1, MediaItemArray2
end

--A,B=ultraschall.GetMediaItemsAtPosition(20, "1,2,3")
--CT=ultraschall.OnlyMediaItemsOfTracksInTrackstring(B, "o")


function ultraschall.SplitMediaItems_Position(position, trackstring, crossfade)
-- Deletes ItemObject
-- MediaItem MediaItemObject - the MediaItem to delete
--[[
<ApiDocBlocFunc>
<slug>
SplitMediaItems_Position
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval, array MediaItemArray = ultraschall.SplitMediaItems_Position(number position, string trackstring, boolean crossfade)
</functionname>
<description>
Splits items at position, in the tracks given by trackstring.
If auto-crossfade is set in the Reaper-preferences, crossfade turns it on(true) or off(false).

Returns false, in case of error.
</description>
<parameters>
number position - the position in seconds
string trackstring - the numbers for the tracks, where split shall be applied to; numbers separated by a comma
boolean crossfade - true - automatic crossfade(if enabled) will be applied; false - automatic crossfade is off
</parameters>
<retvals>
boolean retval - true - success, false - error
array MediaItemArray - an array with the items on the right side of the split
</retvals>
<semanticcontext>
MediaItem Management
Edit
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, split, edit, crossfade
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(position)==nil or trackstring==nil then return false end
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring=="" then return false end
  position=tonumber(position)
  local FadeOut, MediaItem, oldfade, oldlength
  local ReturnMediaItemArray={}
  local count=0
  local LineArray,Numbers=ultraschall.CSV2IndividualLinesAsArray(trackstring)
  local Anumber=reaper.CountMediaItems(0)
--  a,Crossfadetime,a=ultraschall.GetSplitCrossFadeState_ReaperIni()
if crossfade~=true and crossfade~=false then return false end
  for i=Anumber-1,0,-1 do
    MediaItem=reaper.GetMediaItem(0, i)
--    reaper.MB(tostring(MediaItem),"",0)
    local Astart=reaper.GetMediaItemInfo_Value(MediaItem, "D_POSITION")
    local Alength=reaper.GetMediaItemInfo_Value(MediaItem, "D_LENGTH")
    FadeOut=reaper.GetMediaItemInfo_Value(MediaItem, "D_FADEOUTLEN")
    local MediaTrack=reaper.GetMediaItem_Track(MediaItem)
    local MediaTrackNumber=reaper.GetMediaTrackInfo_Value(MediaTrack, "IP_TRACKNUMBER")
    local Aend=(Astart+Alength)
--    reaper.ShowConsoleMsg(FadeOut.." "..Aend.."\n")
    if position>=Astart and position<=Aend then
       for a=1, Numbers do
--       reaper.MB(MediaTrackNumber,LineArray[a],0)
        if tonumber(LineArray[a])==nil then return false end
        if MediaTrackNumber==tonumber(LineArray[a]) then
          count=count+1 
          ReturnMediaItemArray[count]=reaper.SplitMediaItem(MediaItem, position)
          if crossfade==false then 
              oldfade=reaper.GetMediaItemInfo_Value(MediaItem, "D_FADEOUTLEN_AUTO")
            oldlength=reaper.GetMediaItemInfo_Value(MediaItem, "D_LENGTH")
            reaper.SetMediaItemInfo_Value(MediaItem, "D_LENGTH", oldlength-oldfade)
          end
--          reaper.MB(MediaTrackNumber,LineArray[a],0)
--          reaper.MB(position-FadeOut,position,0)
        end
       end
    end
  end
  return true, ReturnMediaItemArray
end

--AA,B=ultraschall.SplitMediaItems_Position(12, "1", false)

--D_FADEOUTLEN
--Mespotine
--B=ultraschall.SplitMediaItems_Position(20,"1,2,3",false)
--boolean retval, string str = reaper.GetItemStateChunk(MediaItem item, string str, boolean isundo)

--retval, str = reaper.GetItemStateChunk(MediaItem item, "", true)

function ultraschall.SplitItemsAtPositionFromArray(position, MediaItemArray, crossfade)
-- Splits the MediaItems from MediaItemArray and returns it's right hand split as an array.
-- The MediaItemArray must not include nil-entries, as they'll be interpreted as end of array.
-- MediaItemArray must start with indexnumber 1 !

--[[
<ApiDocBlocFunc>
<slug>
SplitItemsAtPositionFromArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval, array MediaItemArray = ultraschall.SplitItemsAtPositionFromArray(number position, array MediaItemArray, boolean crossfade)
</functionname>
<description>
Splits items in MediaItemArray at position, in the tracks given by trackstring.
If auto-crossfade is set in the Reaper-preferences, crossfade turns it on(true) or off(false).

Returns false, in case of error.
</description>
<parameters>
number position - the position in seconds
array MediaItemArray - an array with the items, where split shall be applied to. No nil-entries allowed!
boolean crossfade - true - automatic crossfade(if enabled) will be applied; false - automatic crossfade is off
</parameters>
<retvals>
boolean retval - true - success, false - error
array MediaItemArray - an array with the items on the right side of the split
</retvals>
<semanticcontext>
MediaItem Management
Edit
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, split, edit, crossfade, mediaitemarray
</tags>
</ApiDocBlocFunc>
]]


if crossfade~=true and crossfade~=false then return false end
  if type(MediaItemArray)~="table" then return false end
--if tostring(MediaItemArray):sub(1,7)~="table: " then return -1 end
local ReturnMediaItemArray={}
local count=1
  while MediaItemArray[count]~=nil do
    ReturnMediaItemArray[count]=reaper.SplitMediaItem(MediaItemArray[count], position)
    if crossfade==false then 
        oldfade=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_FADEOUTLEN_AUTO")
      oldlength=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_LENGTH")
      reaper.SetMediaItemInfo_Value(MediaItemArray[count], "D_LENGTH", oldlength-oldfade)
    end
    count=count+1
  end
  return true, ReturnMediaItemArray
end

--reaper.MB(tostring(A2),"",0)
--A,AA=ultraschall.GetMediaItemsAtPosition(20, "1,3")
--B,BB=ultraschall.SplitItemsAtPositionFromArray(2,AA,false)

--reaper.UpdateArrange()

function ultraschall.DeleteMediaItem(MediaItemObject)
-- Deletes ItemObject
-- MediaItem MediaItemObject - the MediaItem to delete
--[[
<ApiDocBlocFunc>
<slug>
DeleteMediaItem
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.DeleteMediaItem(MediaItem MediaItem)
</functionname>
<description>
deletes a MediaItem. Returns true, in case of success, false in case of error.
</description>
<parameters>
MedaItem MediaItem - the MediaItem to be deleted
</parameters>
<retvals>
boolean retval - true, delete was successful; false was unsuccessful
</retvals>
<semanticcontext>
MediaItem Management
Delete
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, delete
</tags>
</ApiDocBlocFunc>
]]
    if reaper.ValidatePtr2(0, MediaItemObject, "MediaItem*")==false then return false end
    local MediaTrack=reaper.GetMediaItemTrack(MediaItemObject)
    return reaper.DeleteTrackMediaItem(MediaTrack, MediaItemObject)
end

-- MediaItem=reaper.GetMediaItem(0,0)
-- A=ultraschall.DeleteMediaItem(MediaItem)

function ultraschall.DeleteMediaItemsFromArray(MediaItemArray)
-- Deletes the MediaItems from MediaItemArray
-- The MediaItemArray must not include nil-entries, as they'll be interpreted as end of array.
-- MediaItemArray must start with indexnumber 1 !
--[[
<ApiDocBlocFunc>
<slug>
DeleteMediaItemsFromArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.DeleteMediaItemsFromArray(array MediaItemArray)
</functionname>
<description>
deletes the MediaItems from MediaItemArray. Returns true, in case of success, false in case of error.
</description>
<parameters>
array MediaItemArray - a array with MediaItem-objects to delete; no nil entries allowed
</parameters>
<retvals>
boolean retval - true, delete was successful; false was unsuccessful
</retvals>
<semanticcontext>
MediaItem Management
Delete
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, delete
</tags>
</ApiDocBlocFunc>
]]  
  if type(MediaItemArray)~="table" then return false end
--if tostring(MediaItemArray):sub(1,7)~="table: " then return -1 end
  local count=1
  while MediaItemArray[count]~=nil do
      local hula=ultraschall.DeleteMediaItem(MediaItemArray[count])
--      reaper.MB(tostring(MediaItemArray[count]),"",0)
    count=count+1
  end
  return true
end


--Aposition=24
--A1,A2=ultraschall.GetMediaItemsAtPosition(5, "1,2,3")
--AAAAAA=ultraschall.SplitItemsAtPosition(Aposition, A2)
--A3,A4=ultraschall.GetMediaItemsAtPosition(10, "1,2,3")
--AAAAAAA=ultraschall.SplitItemsAtPosition(Aposition+5, A4)
--K=ultraschall.DeleteMediaItemsFromArray(fuddel)



function ultraschall.DeleteMediaItems_Position(position, trackstring)
-- Deletes ItemObject
-- MediaItem MediaItemObject - the MediaItem to delete
--[[
<ApiDocBlocFunc>
<slug>
DeleteMediaItems_Position
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.DeleteMediaItems_Position(number position, string trackstring)
</functionname>
<description>
Delete the MediaItems at given position, from the tracks as given by trackstring.
Returns the "cleared" trackstring as string and as array, as well as the number of entries; returns false in case of error
</description>
<parameters>
number position - the position in seconds
string trackstring - the tracknumbers, separated by a comma
</parameters>
<retvals>
boolean retval - true, delete was successful; false was unsuccessful
</retvals>
<semanticcontext>
MediaItem Management
Delete
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, delete
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(position)==nil or trackstring==nil then return false end
  position=tonumber(position)
  local count=0
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return false end
  local LineArray,Numbers=ultraschall.CSV2IndividualLinesAsArray(trackstring)
  local Anumber=reaper.CountMediaItems(0)
  for i=Anumber-1,0,-1 do
    local MediaItem=reaper.GetMediaItem(0, i)
--    reaper.MB(tostring(MediaItem),"",0)
    local Astart=reaper.GetMediaItemInfo_Value(MediaItem, "D_POSITION")
    local Alength=reaper.GetMediaItemInfo_Value(MediaItem, "D_LENGTH")
    local MediaTrack=reaper.GetMediaItem_Track(MediaItem)
    local MediaTrackNumber=reaper.GetMediaTrackInfo_Value(MediaTrack, "IP_TRACKNUMBER")
    local Aend=Astart+Alength
    if position>=Astart and position<=Aend then
       for a=1, Numbers do
--       reaper.MB(MediaTrackNumber,LineArray[a],0)
        if tonumber(LineArray[a])==nil then return false end
        if MediaTrackNumber==tonumber(LineArray[a]) then
          count=count+1 
          ultraschall.DeleteMediaItem(MediaItem)
--          reaper.MB(MediaTrackNumber,LineArray[a],0)
        end
       end
    end
  end
  return true
end


--L=ultraschall.DeleteMediaItems_Position("18","o")
--

--A,AA=ultraschall.SplitMediaItems_Position(8,"ö")
--ALABAMAA=ultraschall.DeleteMediaItemsFromArray(AA)
--reaper.UpdateArrange()

function ultraschall.GetAllMediaItemsBetween(startposition,endposition,trackstring,inside)
--returns all MediaItems between startposition and endposition in the tracks given with trackstring
--
-- number startposition - time in seconds
-- number endposition - time in seconds
-- string trackstring - the tracksnumbers, beginning with 1 for first track, separated by a ,
-- boolean inside - true: only return items that are fully inside selection, 
--                  false: include items where at least start or end is inside selection

--[[
<ApiDocBlocFunc>
<slug>
GetAllMediaItemsBetween
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer count, array MediaItemArray, array MediaItemStateChunkArray = ultraschall.GetAllMediaItemsBetween(number startposition, number endposition, string trackstring, boolean inside)
</functionname>
<description>
Gets all MediaItems between startposition and endposition from the tracks as given by trackstring. 
Set inside to true to get only items, that are fully within the start and endposition, set it to false, if you also want items, that are just partially inside(end or just the beginning of the item).

Returns the number of items, an array with all the MediaItems and an array with all the MediaItemStateChunks of the items, as used by functions as <a href="#InsertMediaItem_MediaItemStateChunk">InsertMediaItem_MediaItemStateChunk</a>, reaper.GetItemStateChunk and reaper.SetItemStateChunk.
Returns -1 in case of failure.
</description>
<parameters>
number startposition - startposition in seconds
number endposition - endposition in seconds
string trackstring - the tracknumbers, separated by a comma
boolean inside - true, only items that are completely within selection; false, include items that are partially within selection
</parameters>
<retvals>
integer count - the number of selected items
array MediaItemArray - an array with all the found MediaItems
array MediaItemStateChunkArray - an array with the MediaItemStateChunks, that can be used to create new items with <a href="#InsertMediaItem_MediaItemStateChunk">InsertMediaItem_MediaItemStateChunk</a>
</retvals>
<semanticcontext>
MediaItem Management
Selection
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, selection, position, statechunk, rppxml
</tags>
</ApiDocBlocFunc>
]]

  if tonumber(startposition)==nil then return -1 end
  startposition=tonumber(startposition)
  if tonumber(endposition)==nil then return -1 end
  endposition=tonumber(endposition)
  if tonumber(endposition)<tonumber(startposition) then return -1 end
  if trackstring==nil then return -1 end
  if inside~=true and inside~=false then return -1 end
    
  local MediaItemArray={}
  local MediaItemStateChunkArray={}
  local count=0
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return -1 end
  local LineArray,Numbers=ultraschall.CSV2IndividualLinesAsArray(trackstring)
  local Anumber=reaper.CountMediaItems(0)
  local temp
  for i=0,Anumber-1 do
    local MediaItem=reaper.GetMediaItem(0, i)
    local Astart=reaper.GetMediaItemInfo_Value(MediaItem, "D_POSITION")
    local Alength=reaper.GetMediaItemInfo_Value(MediaItem, "D_LENGTH")
    local MediaTrack=reaper.GetMediaItem_Track(MediaItem)
    local MediaTrackNumber=reaper.GetMediaTrackInfo_Value(MediaTrack, "IP_TRACKNUMBER")
    local Aend=Astart+Alength
--    reaper.ShowConsoleMsg("nummer:"..i.."- "..Astart.." "..Aend.."\n")
    if inside==true and Astart>=startposition and 
        Astart<=endposition  and
        Aend>=startposition and
        Aend<=endposition then
        for a=1, Numbers do
--        reaper.ShowConsoleMsg(AStart.." "..Aend.." "..startposition.." "..endposition.."\n")
          if tonumber(LineArray[a])==nil then return -1 end
          if MediaTrackNumber==tonumber(LineArray[a]) then
            count=count+1 
            MediaItemArray[count]=MediaItem
            temp,MediaItemStateChunkArray[count]= reaper.GetItemStateChunk(MediaItem, "", true)
          end
       end
    elseif inside==false then
      if (Astart>=startposition and 
          Astart<=endposition) or
          (Aend>=startposition and
          Aend<=endposition) or
          (Astart<=startposition and
          Aend>=endposition) then
--          then
--        reaper.MB(tostring(inside),"",0)
        for a=1, Numbers do
          if tonumber(LineArray[a])==nil then return -1 end
          if MediaTrackNumber==tonumber(LineArray[a]) then
            count=count+1 
            MediaItemArray[count]=MediaItem
            temp,MediaItemStateChunkArray[count]= reaper.GetItemStateChunk(MediaItem, "", true)
          end
       end
      end 
    end
  end
  return count, MediaItemArray, MediaItemStateChunkArray

end

--A,MediaItem=ultraschall.GetAllMediaItemsBetween(2,22,"ö",false)

--A,AA=ultraschall.GetAllMediaItemsBetween(4,21,"1,2,3",true)
--A,AA,AAA=ultraschall.GetAllMediaItemsBetween(0,200,"1,2,3",true)


function ultraschall.MoveMediaItemsAfter_By(oldposition, changepositionby, trackstring)
--Moves all MediaItems, between oldposition and the end of the project, by changepositionby, in all tracks given by trackstring
--intended for things as RippleCut
--
-- number oldposition - old position in seconds
-- number changepositionby - the difference in seconds. negative means, move toward projectstart, positive toward projectend
-- string trackstring - the tracksnumbers, beginning with 1 for first track, separated by a ,

--[[
<ApiDocBlocFunc>
<slug>
MoveMediaItemsAfter_By
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.MoveMediaItemsAfter_By(number old_position, number change_position_by, string trackstring)
</functionname>
<description>
Moves all items after old_position by change_position_by-seconds. Affects only items, that begin after oldposition, so items that start before and end after old_position do not move.

Returns false in case of failure, true in case of success.
</description>
<parameters>
number oldposition - the position, from where the movement shall be applied to, in seconds
number change_position_by - the change of the position in seconds; positive - toward the end of the project, negative - toward the beginning.
string trackstring - the tracknumbers, separated by a comma
</parameters>
<retvals>
boolean retval - true in case of success; false in case of failure
</retvals>
<semanticcontext>
MediaItem Management
Manipulate
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, move, position
</tags>
</ApiDocBlocFunc>
]]
  
  if tonumber(oldposition)==nil then return false end
  if tonumber(changepositionby)==nil then return false end
  if trackstring==nil then return false end 
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return false end
  local A,MediaItem=ultraschall.GetAllMediaItemsBetween(oldposition,reaper.GetProjectLength(),trackstring,true)
  for i=1, A do
    local ItemStart=reaper.GetMediaItemInfo_Value(MediaItem[i], "D_POSITION")
    local ItemEnd=reaper.GetMediaItemInfo_Value(MediaItem[i], "D_LENGTH")
    local Takes=reaper.CountTakes(MediaItem[i])
    if ItemStart+changepositionby>=0 then reaper.SetMediaItemInfo_Value(MediaItem[i], "D_POSITION", ItemStart+changepositionby)
    elseif ItemStart+changepositionby<=0 then 
      if ItemEnd+changepositionby<0 then reaper.DeleteTrackMediaItem(reaper.GetMediaItem_Track(MediaItem[i]),MediaItem[i]) --reaper.MB("","",0)
      else 
        for k=0, Takes-1 do
          local Offset=reaper.GetMediaItemTakeInfo_Value(reaper.GetMediaItemTake(MediaItem[i], k), "D_STARTOFFS")
          reaper.SetMediaItemTakeInfo_Value(reaper.GetMediaItemTake(MediaItem[i], k), "D_STARTOFFS", Offset-changepositionby)
        end
      reaper.SetMediaItemInfo_Value(MediaItem[i], "D_LENGTH", ItemEnd+changepositionby)
      end
    end
  end
  return true
end

--A=ultraschall.MoveMediaItemsAfter_By(10,5.1,"ö,1")

function ultraschall.MoveMediaItemsBefore_By(oldposition, changepositionby, trackstring)
--Moves all MediaItems, between projectstart and oldposition, by changepositionby, in all tracks given by trackstring
--intended for things as RippleCut
--
-- number oldposition - old position in seconds
-- number changepositionby - the difference in seconds. negative means, move toward projectstart, positive toward projectend
-- string trackstring - the tracksnumbers, beginning with 1 for first track, separated by a ,

--[[
<ApiDocBlocFunc>
<slug>
MoveMediaItemsBefore_By
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.MoveMediaItemsBefore_By(number old_position, number change_position_by, string trackstring)
</functionname>
<description>
Moves all items before old_position by change_position_by-seconds. Affects only items, that end before oldposition, so items that start before and end after old_position do not move.

Returns false in case of failure, true in case of success.
</description>
<parameters>
number oldposition - the position, from where the movement shall be applied to, in seconds
number change_position_by - the change of the position in seconds; positive - toward the end of the project, negative - toward the beginning.
string trackstring - the tracknumbers, separated by a comma
</parameters>
<retvals>
boolean retval - true in case of success; false in case of failure
</retvals>
<semanticcontext>
MediaItem Management
Manipulate
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, move, position
</tags>
</ApiDocBlocFunc>
]]
  
  if tonumber(oldposition)==nil then return false end
  if tonumber(changepositionby)==nil then return false end
  if trackstring==nil then return false end 
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return false end
  local A,MediaItem=ultraschall.GetAllMediaItemsBetween(0,oldposition,trackstring,true)
  for i=1, A do
    local ItemStart=reaper.GetMediaItemInfo_Value(MediaItem[i], "D_POSITION")
    local ItemEnd=reaper.GetMediaItemInfo_Value(MediaItem[i], "D_LENGTH")
    local Takes=reaper.CountTakes(MediaItem[i])
    if ItemStart+changepositionby>=0 then reaper.SetMediaItemInfo_Value(MediaItem[i], "D_POSITION", ItemStart+changepositionby)
    elseif ItemStart+changepositionby<=0 then 
      if ItemEnd+changepositionby<0 then reaper.DeleteTrackMediaItem(reaper.GetMediaItem_Track(MediaItem[i]),MediaItem[i]) --reaper.MB("","",0)
      else 
        for k=0, Takes-1 do
          local Offset=reaper.GetMediaItemTakeInfo_Value(reaper.GetMediaItemTake(MediaItem[i], k), "D_STARTOFFS")
          reaper.SetMediaItemTakeInfo_Value(reaper.GetMediaItemTake(MediaItem[i], k), "D_STARTOFFS", Offset-changepositionby)
        end
      reaper.SetMediaItemInfo_Value(MediaItem[i], "D_LENGTH", ItemEnd+changepositionby)
      end
    end
  end
  return true
end

--A=ultraschall.MoveMediaItemsBefore_By(14,1,"ö,1")

function ultraschall.MoveMediaItemsSectionTo(sectionstart, sectionend, newposition, trackstring, inside)
--Moves all MediaItems within sectionstart and sectionend to newposition in all tracks given by trackstring.
-- Use inside to tell, if only the items that are completely within the section, shall be moved
--intended for things as RippleCut
--
-- number sectionstart - start of the section in seconds
-- number sectionend - end of the section in seconds
-- number newposition - the new position in seconds. The first MediaItem in the selection gets this 
--                        newposition, all others are moved in relation to this first MediaItem.
-- string trackstring - the tracksnumbers, beginning with 1 for first track, separated by a ,
-- boolean inside - true: only affects items that are fully inside selection, 
--                  false: include items where at least start or end is inside selection

--[[
<ApiDocBlocFunc>
<slug>
MoveMediaItemsSectionTo
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.MoveMediaItemsSectionTo(number sectionstart, number sectionend, number newposition, string trackstring, boolean inside)
</functionname>
<description>
Moves the items between sectionstart and sectionend to newposition, within the tracks given by trackstring.
If inside is set to true, only items completely within the section are moved; if set to false, also items are affected, that are just partially within the section.

Items, that start after sectionstart, and therefore have an offset, will be moved to newposition+their offset. Keep that in mind.

Returns false in case of failure, true in case of success.
</description>
<parameters>
number sectionstart - begin of the section in seconds
number sectionend - end of the section in seconds
number newposition - new position in seconds
string trackstring - the tracknumbers, separated by a ,
boolean inside - true, only items completely within the section; false, also items partially within the section
</parameters>
<retvals>
boolean retval - true in case of success; false in case of failure
</retvals>
<semanticcontext>
MediaItem Management
Manipulate
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, move, position
</tags>
</ApiDocBlocFunc>
]]

  if tonumber(sectionstart)==nil then return false end
  if tonumber(sectionend)==nil then return false end
  if tonumber(newposition)==nil then return false end
  if tonumber(sectionend)<tonumber(sectionstart) then return false end
  if trackstring==nil then return false end
  if inside~=true and inside~=false then return false end

  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return false end
  local A,MediaItem=ultraschall.GetAllMediaItemsBetween(sectionstart,sectionend,trackstring,inside)
  for i=1, A do
    local ItemStart=reaper.GetMediaItemInfo_Value(MediaItem[i], "D_POSITION")
    local ItemEnd=reaper.GetMediaItemInfo_Value(MediaItem[i], "D_LENGTH")
    local Takes=reaper.CountTakes(MediaItem[i])
    if ItemStart+newposition>=0 then reaper.SetMediaItemInfo_Value(MediaItem[i], "D_POSITION", ItemStart+newposition)
    elseif ItemStart+newposition<=0 then 
      if ItemEnd+newposition<0 then reaper.DeleteTrackMediaItem(reaper.GetMediaItem_Track(MediaItem[i]),MediaItem[i]) --reaper.MB("","",0)
      else 
        for k=0, Takes-1 do
          local Offset=reaper.GetMediaItemTakeInfo_Value(reaper.GetMediaItemTake(MediaItem[i], k), "D_STARTOFFS")
          reaper.SetMediaItemTakeInfo_Value(reaper.GetMediaItemTake(MediaItem[i], k), "D_STARTOFFS", Offset-newposition)
        end
      reaper.SetMediaItemInfo_Value(MediaItem[i], "D_LENGTH", ItemEnd+newposition)
      end
    end
  end
  return true
end

--A=ultraschall.MoveMediaItemsSectionTo(1, 3, 100, "ö", false)



function ultraschall.ChangeLengthOfMediaItems_FromArray(MediaItemArray, newlength)
-- changes width of all MediaItems in MediaItemArray to newlength
-- MediaItemArray - array with all MediaItems that shall be affected. Must not 
--                    include nil-entries, as they'll be interpreted as end of array.
-- number newlength - absolute new length of Items in seconds

--[[
<ApiDocBlocFunc>
<slug>
ChangeLengthOfMediaItems_FromArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.ChangeLengthOfMediaItems_FromArray(array MediaItemArray, number newlength)
</functionname>
<description>
Changes the length of the MediaItems in MediaItemArray to newlength.
They will all be set to the new length, regardless of their old length. If you want to change the length of the items not >to< newlength, but >by< newlength, use <a href"#ChangeDeltaLengthOfMediaItems_FromArray">ChangeDeltaLengthOfMediaItems_FromArray</a> instead.

Returns false in case of failure, true in case of success.
</description>
<parameters>
array MediaItemArray - an array with items to be changed. No nil entries allowed!
number newlength - the new length of the items in seconds
</parameters>
<retvals>
boolean retval - true in case of success; false in case of failure
</retvals>
<semanticcontext>
MediaItem Management
Manipulate
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, length
</tags>
</ApiDocBlocFunc>
]]
  if type(MediaItemArray)~="table" then return false end
  if tonumber(newlength)==nil then return false end
  local count=1
  while MediaItemArray[count]~=nil do
--    ItemStart=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_LENGTH")
    reaper.SetMediaItemInfo_Value(MediaItemArray[count], "D_LENGTH", newlength)
    count=count+1
  end
  return true
end

--  A,MediaItem=ultraschall.GetAllMediaItemsBetween(0,14,"1,2",false)
--AB=ultraschall.ChangeLengthOfMediaItems_FromArray(MediaItem,1)



function ultraschall.ChangeDeltaLengthOfMediaItems_FromArray(MediaItemArray, deltalength)
-- changes width of all MediaItems in MediaItemArray by deltalength
-- MediaItemArray - array with all MediaItems that shall be affected. Must not 
--                    include nil-entries, as they'll be interpreted as end of array.
-- number deltalength - in seconds, negative: item gets shorter, positive: item gets longer, 
--                      if item is shorter than deltalength, the length stays the same.

--[[
<ApiDocBlocFunc>
<slug>
ChangeDeltaLengthOfMediaItems_FromArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.ChangeDeltaLengthOfMediaItems_FromArray(array MediaItemArray, number deltalength)
</functionname>
<description>
Changes the length of the MediaItems in MediaItemArray by deltalength.
If you want to change the length of the items not >by< deltalength, but >to< deltalength, use <a href"#ChangeLengthOfMediaItems_FromArray">ChangeLengthOfMediaItems_FromArray</a> instead.

Returns false in case of failure, true in case of success.
</description>
<parameters>
array MediaItemArray - an array with items to be changed. No nil entries allowed!
number deltalength - the change of the length of the items in seconds, positive value - longer, negative value - shorter
</parameters>
<retvals>
boolean retval - true in case of success; false in case of failure
</retvals>
<semanticcontext>
MediaItem Management
Manipulate
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, length
</tags>
</ApiDocBlocFunc>
]]

  if type(MediaItemArray)~="table" then return false end
  if tonumber(deltalength)==nil then return false end
  local count=1
  local ItemLength
  while MediaItemArray[count]~=nil do
    ItemLength=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_LENGTH")
    reaper.SetMediaItemInfo_Value(MediaItemArray[count], "D_LENGTH", ItemLength+deltalength)
    count=count+1
  end    
  return true
end

--  A,MediaItem=ultraschall.GetAllMediaItemsBetween(0,14,"1,2,3",false)
--AB=  ultraschall.ChangeDeltaLengthOfMediaItems_FromArray(MediaItem,1)

function ultraschall.ChangeOffsetOfMediaItems_FromArray(MediaItemArray, newoffset)
-- changes offset of all MediaItem_Takes of the MediaItems in MediaItemArray to newoffset
-- MediaItemArray - array with all MediaItems that shall be affected. Must not 
--                    include nil-entries, as they'll be interpreted as end of array.
-- number newoffset - in seconds

--[[
<ApiDocBlocFunc>
<slug>
ChangeOffsetOfMediaItems_FromArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.ChangeOffsetOfMediaItems_FromArray(array MediaItemArray, number newoffset)
</functionname>
<description>
Changes the audio-offset of the MediaItems in MediaItemArray to newoffset.
It affects all(!) takes of the MediaItems have.
If you want to change the offset of the items not >to< newoffset, but >by< newoffset, use <a href"#ChangeDeltaOffsetOfMediaItems_FromArray">ChangeDeltaOffsetOfMediaItems_FromArray</a> instead.

Returns false in case of failure, true in case of success.
</description>
<parameters>
array MediaItemArray - an array with items to be changed. No nil entries allowed!
number newoffset - the new offset of the items in seconds
</parameters>
<retvals>
boolean retval - true in case of success; false in case of failure
</retvals>
<semanticcontext>
MediaItem Management
Manipulate
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, offset
</tags>
</ApiDocBlocFunc>
]]
  if type(MediaItemArray)~="table" then return false end
  if tonumber(newoffset)==nil then return false end
  local count=1
  local ItemLength
  local MediaItem_Take
--AP=MediaItemArray
  while MediaItemArray[count]~=nil do
    ItemLength=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_SNAPOFFSET")
    for i=0, reaper.CountTakes(MediaItemArray[count])-1 do
--    reaper.MB(i,count,0)
      MediaItem_Take=reaper.GetMediaItemTake(MediaItemArray[count], i)
--      ItemTakeOffset=reaper.GetMediaItemTakeInfo_Value(MediaItem_Take, "D_STARTOFFS")
      reaper.SetMediaItemTakeInfo_Value(MediaItem_Take, "D_STARTOFFS", newoffset)
    end
    count=count+1
  end    
  return true
end

--A,MediaItem=ultraschall.GetAllMediaItemsBetween(0,14,"1,2,3",false)
--AA,AAA = ultraschall.GetMediaItemsAtPosition(13, "1,2,3")
--AB=ultraschall.ChangeOffsetOfMediaItems_FromArray(AAA, "35.09")

function ultraschall.ChangeDeltaOffsetOfMediaItems_FromArray(MediaItemArray, deltaoffset)
-- changes offset of all MediaItem_Takes of the MediaItems in MediaItemArray by deltaoffset
-- MediaItemArray - array with all MediaItems that shall be affected. Must not 
--                    include nil-entries, as they'll be interpreted as end of array.
-- number newoffset - in seconds; negative: offset gets earlier, positive: item gets later

--[[
<ApiDocBlocFunc>
<slug>
ChangeDeltaOffsetOfMediaItems_FromArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.ChangeDeltaOffsetOfMediaItems_FromArray(array MediaItemArray, number deltaoffset)
</functionname>
<description>
Changes the audio-offset of the MediaItems in MediaItemArray by deltaoffset.
It affects all(!) takes of the MediaItems have.
If you want to change the offset of the items not >by< deltaoffset, but >to< deltaoffset, use <a href"#ChangeOffsetOfMediaItems_FromArray">ChangeOffsetOfMediaItems_FromArray</a> instead.

Returns false in case of failure, true in case of success.
</description>
<parameters>
array MediaItemArray - an array with items to be changed. No nil entries allowed!
number newoffset - the new offset of the items in seconds
</parameters>
<retvals>
boolean retval - true in case of success; false in case of failure
</retvals>
<semanticcontext>
MediaItem Management
Manipulate
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, offset
</tags>
</ApiDocBlocFunc>
]]

  if type(MediaItemArray)~="table" then return false end
  if tonumber(deltaoffset)==nil then return false end
  local count=1
  local ItemLength, MediaItem_Take, ItemTakeOffset
  while MediaItemArray[count]~=nil do
    ItemLength=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_SNAPOFFSET")
    for i=0, reaper.CountTakes(MediaItemArray[count])-1 do
      MediaItem_Take=reaper.GetMediaItemTake(MediaItem[count], i)
      ItemTakeOffset=reaper.GetMediaItemTakeInfo_Value(MediaItem_Take, "D_STARTOFFS")
      reaper.SetMediaItemTakeInfo_Value(MediaItem_Take, "D_STARTOFFS", ItemTakeOffset+deltaoffset)
    end
    count=count+1
  end
  return true    
end

--  A,MediaItem=ultraschall.GetAllMediaItemsBetween(1,30,"1,2,3",false)
--  L=ultraschall.ChangeDeltaOffsetOfMediaItems_FromArray(MediaItem, -1.2)
--  reaper.UpdateArrange()

function ultraschall.SectionCut(startposition, endposition, trackstring)
--cuts all items between startposition and endposition in the tracks, given with trackstring
--returns the number of deleted items as well as a table with the ItemStateChunks of all deleted Items

--[[
<ApiDocBlocFunc>
<slug>
SectionCut
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_items, array MediaItemArray_StateChunk = ultraschall.SectionCut(number startposition, number endposition, string trackstring)
</functionname>
<description>
Cuts out all items between startposition and endposition in the tracks given by trackstring.

Returns number of cut items as well as an array with the mediaitem-statechunks, which can be used with functions as <a href="#InsertMediaItem_MediaItemStateChunk">InsertMediaItem_MediaItemStateChunk</a>, reaper.GetItemStateChunk and reaper.SetItemStateChunk.
Returns -1 in case of failure.
</description>
<parameters>
number startposition - the startposition of the section in seconds
number endposition - the endposition of the section in seconds
string trackstring - the tracknumbers, separated by ,
</parameters>
<retvals>
integer number_items - the number of cut items
array MediaItemArray_StateChunk - an array with the mediaitem-states of the cut items.
</retvals>
<semanticcontext>
MediaItem Management
Edit
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, edit, section, cut
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(startposition)==nil then return -1 end
  if tonumber(endposition)==nil then return -1 end
  if tonumber(endposition)<tonumber(startposition) then return -1 end
  if trackstring==nil then return -1 end
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return -1 end
  local A,AA=ultraschall.SplitMediaItems_Position(startposition,trackstring, false)
  local B,BB=ultraschall.SplitMediaItems_Position(endposition,trackstring,false)
  local C,CC,CCC=ultraschall.GetAllMediaItemsBetween(startposition,endposition,trackstring,true)
  local D=ultraschall.DeleteMediaItemsFromArray(CC)
  return C, CCC
end

--A,AA=ultraschall.SectionCut(1,9,"ö")
--H=reaper.GetCursorPosition()
--reaper.UpdateArrange()

function ultraschall.SectionCut_Inverse(startposition, endposition, trackstring)
-- throws away everything before startpositon and after endposition in tracks defined in trackstring.
-- keeps only, what is inside selection
-- returns: 
-- number_of_cut_items_before_sectionstart
-- itemstatechunk_of_cut_items_before_sectionstart_as_table
-- number_of_cut_items_after_sectionend
-- itemstatechunk_of_cut_items_after_sectionend_as_table

--[[
<ApiDocBlocFunc>
<slug>
SectionCut_Inverse
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_items_beforestart, array MediaItemArray_StateChunk_beforestart, integer number_items_afterend, array MediaItemArray_StateChunk_afterend = ultraschall.SectionCut_Inverse(number startposition, number endposition, string trackstring)
</functionname>
<description>
Cuts out all items before(!) startposition and after(!) endposition in the tracks given by trackstring; it keeps all items inbetween startposition and endposition.

Returns number of cut items as well as an array with the mediaitem-statechunks, which can be used with functions as <a href="#InsertMediaItem_MediaItemStateChunk">InsertMediaItem_MediaItemStateChunk</a>, reaper.GetItemStateChunk and reaper.SetItemStateChunk.
Returns -1 in case of failure.
</description>
<parameters>
number startposition - the startposition of the section in seconds
number endposition - the endposition of the section in seconds
string trackstring - the tracknumbers, separated by ,
</parameters>
<retvals>
integer number_items_beforestart - the number of cut items before startposition
array MediaItemArray_StateChunk_beforestart - an array with the mediaitem-states of the cut items before startposition
integer number_items_afterend - the number of cut items after endposition
array MediaItemArray_StateChunk_afterend - an array with the mediaitem-states of the cut items after endposition
</retvals>
<semanticcontext>
MediaItem Management
Edit
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, edit, section, inverse, cut
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(startposition)==nil then return -1 end
  if tonumber(endposition)==nil then return -1 end
  if tonumber(endposition)<tonumber(startposition) then return -1 end
  if trackstring==nil then return -1 end
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return -1 end
  local A,AA=ultraschall.SplitMediaItems_Position(startposition,trackstring, false)
  local B,BB=ultraschall.SplitMediaItems_Position(endposition,trackstring,false) -- Buggy: needs to take care of autocrossfade!!
  local C,CC,CCC=ultraschall.GetAllMediaItemsBetween(0,startposition,trackstring,true)
  local C2,CC2,CCC2=ultraschall.GetAllMediaItemsBetween(endposition,reaper.GetProjectLength(),trackstring,true)
  local D=ultraschall.DeleteMediaItemsFromArray(CC)
  local D2=ultraschall.DeleteMediaItemsFromArray(CC2)
  return C,CCC,C2,CCC2
end

--A,AA,AAA,AAAA=ultraschall.SectionCut_Inverse(1,10,"ö,1")

function ultraschall.RippleCut(startposition, endposition, trackstring, movemarkers, moveenvelopepoints)
--[[
<ApiDocBlocFunc>
<slug>
RippleCut
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_items, array MediaItemArray_StateChunk = ultraschall.RippleCut(number startposition, number endposition, string trackstring, boolean movemarkers, boolean moveenvelopepoints)
</functionname>
<description>
Cuts out all items between startposition and endposition in the tracks given by trackstring. After cut, it moves the remaining items after(!) endposition toward projectstart, by the difference between start and endposition.

Returns number of cut items as well as an array with the mediaitem-statechunks, which can be used with functions as <a href="#InsertMediaItem_MediaItemStateChunk">InsertMediaItem_MediaItemStateChunk</a>, reaper.GetItemStateChunk and reaper.SetItemStateChunk.
Returns -1 in case of failure.
</description>
<parameters>
number startposition - the startposition of the section in seconds
number endposition - the endposition of the section in seconds
string trackstring - the tracknumbers, separated by ,
boolean movemarkers - moves markers/regions as well
boolean moveenvelopepoints - moves envelopepoints, if existing, as well
</parameters>
<retvals>
integer number_items - the number of cut items
array MediaItemArray_StateChunk - an array with the mediaitem-states of the cut items
</retvals>
<semanticcontext>
MediaItem Management
Edit
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, edit, ripple
</tags>
</ApiDocBlocFunc>
]]
  --trackstring=ultraschall.CreateTrackNumbersString(1,reaper.CountTracks(),1)
  --returns the number of deleted items as well as a table with the ItemStateChunks of all deleted Items  

  if tonumber(startposition)==nil then return -1 end
  if tonumber(endposition)==nil then return -1 end
  if tonumber(endposition)<tonumber(startposition) then return -1 end
  if trackstring==nil then return -1 end
  local trackstring,A2,A3=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring=="" then return -1 end
  local delta=endposition-startposition
  local A,AA=ultraschall.SplitMediaItems_Position(startposition,trackstring,false)
  local B,BB=ultraschall.SplitMediaItems_Position(endposition,trackstring,false)
  local C,CC,CCC=ultraschall.GetAllMediaItemsBetween(startposition,endposition,trackstring,true)
  local D=ultraschall.DeleteMediaItemsFromArray(CC) 
  if moveenvelopepoints==true then
    local CountTracks=reaper.CountTracks()
    for i=0, CountTracks-1 do
--    reaper.MB("","",0)
      for a=1,A3 do
      -- reaper.MB(A2[a],i,0)
        if tonumber(A2[a])==i+1 then
--          reaper.MB("Hmm","",0)
          local MediaTrack=reaper.GetTrack(0,i)
          retval = ultraschall.MoveTrackEnvelopePointsBy(endposition, reaper.GetProjectLength(), -delta, MediaTrack, true) 
        end
      end
    end
  end
  
  if movemarkers==true then
    ultraschall.MoveMarkers(endposition, reaper.GetProjectLength(), -delta, true)
  end
  ultraschall.MoveMediaItemsAfter_By(endposition, -delta, trackstring)
  return C,CCC
end

--MediaItem=reaper.GetMediaItem(0,0)
--Atest=reaper.GetMediaItemInfo_Value(MediaItem, "D_FADEOUTLEN_AUTO")

--A,AA=ultraschall.RippleCut(16,17,"1,2,3", true, true)
reaper.UpdateArrange()
--A,AA,AAA=ultraschall.GetAllMediaItemsBetween(0,2,"1,2,3",true)
--  ultraschall.MoveMediaItemsAfter_By(10, 5, "1,2,3")

--  A,AA=ultraschall.SplitMediaItems_Position(startposition,trackstring)
--  B,BB=ultraschall.SplitMediaItems_Position(endposition,trackstring)
--C,CC=ultraschall.GetAllMediaItemsBetween(0,24,"1,2,3",true)
--  D=ultraschall.DeleteMediaItemsFromArray(CC)
--ultraschall.MoveMediaItemsAfter_By(10, -1, "1,2,3")


function ultraschall.RippleCut_Reverse(startposition, endposition, trackstring, movemarkers, moveenvelopepoints)
  --trackstring=ultraschall.CreateTrackNumbersString(1,reaper.CountTracks(),1)
  --returns the number of deleted items as well as a table with the ItemStateChunks of all deleted Items  
--[[
<ApiDocBlocFunc>
<slug>
RippleCut_Reverse
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_items, array MediaItemArray_StateChunk = ultraschall.RippleCut_Reverse(number startposition, number endposition, string trackstring, boolean movemarkers, boolean moveenvelopepoints)
</functionname>
<description>
Cuts out all items between startposition and endposition in the tracks given by trackstring. After cut, it moves the remaining items before(!) startposition toward projectend, by the difference between start and endposition.

Returns number of cut items as well as an array with the mediaitem-statechunks, which can be used with functions as <a href="#InsertMediaItem_MediaItemStateChunk">InsertMediaItem_MediaItemStateChunk</a>, reaper.GetItemStateChunk and reaper.SetItemStateChunk.
Returns -1 in case of failure.
</description>
<parameters>
number startposition - the startposition of the section in seconds
number endposition - the endposition of the section in seconds
string trackstring - the tracknumbers, separated by ,
boolean movemarkers - moves markers/regions as well
boolean moveenvelopepoints - moves envelopepoints, if existing, as well
</parameters>
<retvals>
integer number_items - the number of cut items
array MediaItemArray_StateChunk - an array with the mediaitem-states of the cut items
</retvals>
<semanticcontext>
MediaItem Management
Edit
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, edit, ripple, reverse
</tags>
</ApiDocBlocFunc>
]]


  if tonumber(startposition)==nil then return -1 end
  if tonumber(endposition)==nil then return -1 end
  if tonumber(endposition)<tonumber(startposition) then return -1 end
  if trackstring==nil then return -1 end
  local trackstring,A2,A3=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return -1 end
  local delta=endposition-startposition
  local A,AA=ultraschall.SplitMediaItems_Position(startposition,trackstring,false)
  local B,BB=ultraschall.SplitMediaItems_Position(endposition,trackstring,false)
  local C,CC,CCC=ultraschall.GetAllMediaItemsBetween(startposition,endposition,trackstring,true)
  local D=ultraschall.DeleteMediaItemsFromArray(CC) 
  if moveenvelopepoints==true then
    local CountTracks=reaper.CountTracks()
    for i=0, CountTracks-1 do
--    reaper.MB("","",0)
      for a=1,A3 do
      -- reaper.MB(A2[a],i,0)
        if tonumber(A2[a])==i+1 then
--          reaper.MB("Hmm","",0)
          local MediaTrack=reaper.GetTrack(0,i)
          retval = ultraschall.MoveTrackEnvelopePointsBy(0, startposition, delta, MediaTrack, true) 
        end
      end
    end
  end
  
  if movemarkers==true then
    ultraschall.MoveMarkers(0, startposition, delta, true)
  end

  ultraschall.MoveMediaItemsBefore_By(endposition, delta, trackstring)  
  return C,CCC
end


--A,AA=ultraschall.RippleCut_Reverse(15,21,"1,2,3", true, true)


function ultraschall.InsertMediaItem_MediaItem(position, MediaItem, MediaTrack)
--[[
<ApiDocBlocFunc>
<slug>
InsertMediaItem_MediaItem
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval, MediaItem MediaItem, number startposition, number endposition, number length = ultraschall.InsertMediaItem_MediaItem(number position, MediaItem MediaItem, MediaTrack MediaTrack)
</functionname>
<description>
Inserts MediaItem in MediaTrack at position. Returns the newly created(or better: inserted) MediaItem as well as startposition, endposition and length of the inserted item.

Returns -1 in case of failure.
</description>
<parameters>
number position - the position of the newly created mediaitem
MediaItem MediaItem - the MediaItem that shall be inserted into a track
MediaTrack MediaTrack - the track, where the item shall be inserted to
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
MediaItem MediaItem - the newly created MediaItem
number startposition - the startposition of the inserted MediaItem in seconds
number endposition - the endposition of the inserted MediaItem in seconds
number length - the length of the inserted MediaItem in seconds
</retvals>
<semanticcontext>
MediaItem Management
Insert
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, insert
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(position)==nil then return -1 end
  if reaper.ValidatePtr(MediaItem, "MediaItem*")==false then return -1 end
  if reaper.ValidatePtr(MediaTrack, "MediaTrack*")==false then return -1 end
  local MediaItemNew=reaper.AddMediaItemToTrack(MediaTrack)
  local Aretval, Astr = reaper.GetItemStateChunk(MediaItem, "", true)
  Astr=Astr:match(".-POSITION ")..position..Astr:match(".-POSITION.-(%c.*)")
  local Aboolean = reaper.SetItemStateChunk(MediaItemNew, Astr, true)
  local start_position=reaper.GetMediaItemInfo_Value(MediaItemNew, "D_POSITION")
  local length=reaper.GetMediaItemInfo_Value(MediaItemNew, "D_LENGTH")
  
  return 1,MediaItemNew, start_position, start_position+length, length
end

--C,CC=ultraschall.GetAllMediaItemsBetween(0,5,"1,2,3,4,5",false)
--MT=reaper.GetTrack(0,0)
--A0,A,AA,AAA,AAAA=ultraschall.InsertMediaItem_MediaItem(42,CC[1],MT)

function ultraschall.InsertMediaItem_MediaItemStateChunk(position, MediaItemStateChunk, MediaTrack)
--[[
<ApiDocBlocFunc>
<slug>
InsertMediaItem_MediaItemStateChunk
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval, MediaItem MediaItem = ultraschall.InsertMediaItem_MediaItemStateChunk(number position, string MediaItemStateChunk, MediaTrack MediaTrack)
</functionname>
<description>
Inserts a new MediaItem in MediaTrack at position. Uses a mediaitem-state-chunk as created by functions like <a href="#GetAllMediaItemsBetween">GetAllMediaItemsBetween</a>, reaper.GetItemStateChunk and reaper.SetItemStateChunk.. Returns the newly created MediaItem.

Returns -1 in case of failure.
</description>
<parameters>
number position - the position of the newly created mediaitem
string MediaItemStatechunk - the Statechunk for the MediaItem, that shall be inserted into a track
MediaTrack MediaTrack - the track, where the item shall be inserted to
</parameters>
<retvals>
integer retval - -1 in case of error, 1 in case of success
MediaItem MediaItem - the newly created MediaItem
</retvals>
<semanticcontext>
MediaItem Management
Insert
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, insert
</tags>
</ApiDocBlocFunc>
]]
  if tonumber(position)==nil then return -1 end
  if MediaItemStateChunk==nil then return -1 end
  if reaper.ValidatePtr(MediaTrack, "MediaTrack*")==false then return -1 end
  MediaItemNew=reaper.AddMediaItemToTrack(MediaTrack)
  MediaItemStateChunk=MediaItemStateChunk:match(".-POSITION ")..position..MediaItemStateChunk:match(".-POSITION.-(%c.*)")
  Aboolean = reaper.SetItemStateChunk(MediaItemNew, MediaItemStateChunk, true)
  
  return 1, MediaItemNew
end

--C,CC=ultraschall.GetAllMediaItemsBetween(0,400,"1,2,3,4,5",false)
--MT=reaper.GetTrack(0,3)
--Aretval, Astr = reaper.GetItemStateChunk(CC[1], "", true)
--ALABASTER,ALHula=ultraschall.InsertMediaItem_MediaItemStateChunk(34,Astr, MT)

function ultraschall.InsertMediaItemArray(position, MediaItemArray, trackstring)
--[[
<ApiDocBlocFunc>
<slug>
InsertMediaItemArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_of_items, array MediaItemArray = ultraschall.InsertMediaItemArray(number position, array MediaItemArray, string trackstring)
</functionname>
<description>
Inserts the MediaItems from MediaItemArray at position into the tracks, as given by trackstring. 

Returns the number of newly created items, as well as an array with the newly create MediaItems.
Returns -1 in case of failure.

Note: this inserts the items only in the tracks, where the original items came from. Items from track 1 will be included into track 1. Trackstring only helps to include or exclude the items from inclusion into certain tracks.
If you have a MediaItemArray with items from track 1,2,3,4,5 and you give trackstring only the tracknumber for track 3 and 4 -> 3,4, then only the items, that were in tracks 3 and 4 originally, will be included, all the others will be ignored.
</description>
<parameters>
number position - the position of the newly created mediaitem
array MediaItemArray - an array with the MediaItems to be inserted
string trackstring - the numbers of the tracks, separated by a ,
</parameters>
<retvals>
integer number_of_items - the number of MediaItems created
array MediaItemArray - an array with the newly created MediaItems
</retvals>
<semanticcontext>
MediaItem Management
Insert
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, insert
</tags>
</ApiDocBlocFunc>
]]    
  if tonumber(position)==nil then return -1 end
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  if trackstring==-1 or trackstring==""  then return -1 end
  local count=1
  local i
  if type(MediaItemArray)~="table" then return -1 end
  local NewMediaItemArray={}
  local individual_values = ultraschall.CSV2IndividualLinesAsArray(trackstring) 
  local ItemStart=reaper.GetProjectLength()+1
  while MediaItemArray[count]~=nil do
    local ItemStart_temp=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION")
    if ItemStart>ItemStart_temp then ItemStart=ItemStart_temp end
    count=count+1
  end
  count=1
  while MediaItemArray[count]~=nil do
    local ItemStart_temp=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION")
    local MediaTrack=reaper.GetMediaItem_Track(MediaItemArray[count])
    --nur einfügen, wenn mediaitem aus nem Track stammt, der in trackstring vorkommt
    i=1
    while individual_values[i]~=nil do
--    reaper.MB("Yup"..i,individual_values[i],0)
    if reaper.GetTrack(0,individual_values[i]-1)==reaper.GetMediaItem_Track(MediaItemArray[count]) then 
    NewMediaItemArray[count]=ultraschall.InsertMediaItem_MediaItem(position+(ItemStart_temp-ItemStart),MediaItemArray[count],MediaTrack)
    end
    i=i+1
    end
    count=count+1
  end  
--  TrackArray[count]=reaper.GetMediaItem_Track(MediaItem)
--  MediaItem reaper.AddMediaItemToTrack(MediaTrack tr)
return count, NewMediaItemArray
end

--C,CC=ultraschall.GetAllMediaItemsBetween(1,60,"1,3",false)
--A,B=reaper.GetItemStateChunk(CC[1], "", true)
--reaper.ShowConsoleMsg(B)
--L,L2=ultraschall.InsertMediaItemArray("82", CC, "1")


function ultraschall.GetMediaItemStateChunksFromItems(MediaItemArray)
--[[
<ApiDocBlocFunc>
<slug>
GetMediaItemStateChunksFromItems
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_of_items, array MediaItemArray_StateChunks = ultraschall.GetMediaItemStateChunksFromItems(array MediaItemArray)
</functionname>
<description>
Returns the MediaItem-StateChunks for all MediaItems in MediaItemArray. It returns the number of items as well as an array, with each entry one MediaItemStateChunk.

StateChunks are used by the reaper-functions reaper.GetItemStateChunk and reaper.SetItemStateChunk.

Returns -1 in case of failure.
</description>
<parameters>
array MediaItemArray - an array with the MediaItems you want the statechunks of
</parameters>
<retvals>
integer number_of_items - the number of trackstatechunks, usually the same as MediaItems in MediaItemArray
array MediaItemArray_StateChunks - an array with the StateChunks of the MediaItems in MediaItemArray
</retvals>
<semanticcontext>
MediaItem Management
Assistance functions
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, statechunk, chunk
</tags>
</ApiDocBlocFunc>
]]
  if type(MediaItemArray)~="table" then return -1 end
  local count=1
  local L
  local MediaItemArray_StateChunk={}
  while MediaItemArray[count]~=nil do
    L, MediaItemArray_StateChunk[count]=reaper.GetItemStateChunk(MediaItemArray[count], "", true)
    count=count+1
  end
  return count-1, MediaItemArray_StateChunk
end

--C,CC=ultraschall.GetAllMediaItemsBetween(9,60,"1",true)
--PK,BA=ultraschall.CreateMediaItemStateChunksFromItems(CC)

function ultraschall.RippleInsert(position, MediaItemArray, trackstring, moveenvelopepoints, movemarkers)
--splits the items at position and inserts MediaItemArray at that position, and moves 
--all following toward the end, accordingly.
--position - the position of the earliest item in the MediaItemArray. All others will be relative to the earliest Item
--MediaItemArray - the MediaItems to be inserted
--trackstring - only the tracks in trackstring will be affected by insert and ripple, all others stay the way they are
--[[
<ApiDocBlocFunc>
<slug>
RippleInsert
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer number_of_items, array MediaItemArray, number endpos_inserted_items = ultraschall.RippleInsert(number position, array MediaItemArray, string trackstring)
</functionname>
<description>
It inserts the MediaItems from MediaItemArray at position into the tracks, as given by trackstring. It moves the items, that were there before, accordingly toward the end of the project.

Returns the number of newly created items, as well as an array with the newly create MediaItems and the endposition of the last(projectposition) inserted item into the project.
Returns -1 in case of failure.

Note: this inserts the items only in the tracks, where the original items came from. Items from track 1 will be included into track 1. Trackstring only helps to include or exclude the items from inclusion into certain tracks.
If you have a MediaItemArray with items from track 1,2,3,4,5 and you give trackstring only the tracknumber for track 3 and 4 -> 3,4, then only the items, that were in tracks 3 and 4 originally, will be included, all the others will be ignored.
</description>
<parameters>
number position - the position of the newly created mediaitem
array MediaItemArray - an array with the MediaItems to be inserted
string trackstring - the numbers of the tracks, separated by a ,
</parameters>
<retvals>
integer number_of_items - the number of newly created items
array MediaItemArray - an array with the newly created MediaItems
number endpos_inserted_items - the endposition of the last newly inserted MediaItem
</retvals>
<semanticcontext>
MediaItem Management
Insert
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, insert, ripple
</tags>
</ApiDocBlocFunc>
]]

  if tonumber(position)==nil then return -1 end
  if trackstring==nil then return -1 end
  local trackstring,AA,AAA=ultraschall.RemoveDuplicateTracksInTrackstring(trackstring)
  --reaper.MB(trackstring,"",0)
  if trackstring==-1 or trackstring=="" then return -1 end
  if type(MediaItemArray)~="table" then return -1 end
  if MediaItemArray[1]==nil then return -1 end
  local NumberOfItems
  local NewMediaItemArray={}
  local count=1
  local ItemStart=reaper.GetProjectLength()+1
  local ItemEnd=0
  local i
  local individual_values = ultraschall.CSV2IndividualLinesAsArray(trackstring)
  while MediaItemArray[count]~=nil do
    local ItemStart_temp=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION")
    local ItemEnd_temp=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_LENGTH")
    i=1
    while individual_values[i]~=nil do
      if reaper.GetTrack(0,individual_values[i]-1)==reaper.GetMediaItem_Track(MediaItemArray[count]) then 
--      reaper.MB("","",0)
        if ItemStart>ItemStart_temp then ItemStart=ItemStart_temp end
        if ItemEnd<ItemEnd_temp+ItemStart_temp then ItemEnd=ItemEnd_temp+ItemStart_temp end
      end
      i=i+1
    end
    count=count+1
  end
  
  --Create copy of the track-state-chunks
  local nums, MediaItemArray_Chunk=ultraschall.GetMediaItemStateChunksFromItems(MediaItemArray)
    
  local A,A2=ultraschall.SplitMediaItems_Position(position,trackstring,false)
--  reaper.MB(tostring(AA),"",0)

  if moveenvelopepoints==true then
    local CountTracks=reaper.CountTracks()
    for i=0, CountTracks-1 do
--    reaper.MB("","",0)
      for a=1,AAA do
      -- reaper.MB(A2[a],i,0)
        if tonumber(AA[a])==i+1 then
--          reaper.MB("Hmm","",0)
          local MediaTrack=reaper.GetTrack(0,i)
          retval = ultraschall.MoveTrackEnvelopePointsBy(position, reaper.GetProjectLength()+(ItemEnd-ItemStart), ItemEnd-ItemStart, MediaTrack, true) 
        end
      end
    end
  end
  
  if movemarkers==true then
    ultraschall.MoveMarkers(position, reaper.GetProjectLength()+(ItemEnd-ItemStart), ItemEnd-ItemStart, true)
  end
  ultraschall.MoveMediaItemsAfter_By(position, ItemEnd-ItemStart, trackstring)
--  reaper.MB("","",0)
  MediaItemArray=ultraschall.OnlyMediaItemsOfTracksInTrackstring(MediaItemArray, trackstring)
--  reaper.MB("","",0)
  count=1
  while MediaItemArray[count]~=nil do
    local Anumber=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION")
--    reaper.SetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION", Anumber-(ItemEnd-ItemStart))
    count=count+1
  end
    NumberOfItems, NewMediaItemArray=ultraschall.InsertMediaItemArray(position, MediaItemArray, trackstring)
  count=1
  while MediaItemArray[count]~=nil do
--  reaper.MB(count,"",0)
--    local Anumber=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION")
--    reaper.SetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION", Anumber+(ItemEnd-ItemStart))
    local length=MediaItemArray_Chunk[count]:match("LENGTH (.-)%c")
    reaper.SetMediaItemInfo_Value(NewMediaItemArray[count], "D_LENGTH", length)
--    reaper.MB(length,"",0)

    count=count+1
  end
  return NumberOfItems, NewMediaItemArray, position+ItemEnd
end

--C,CC=ultraschall.GetAllMediaItemsBetween(0,5,"1,2,3",true)
--D=ultraschall.DeleteMediaItemsFromArray(CC)
--track=reaper.GetMediaItem_Track(CC[1])
--PUHDERBAER, PUHDERBAER2, PUHDERBAER3=ultraschall.RippleInsert(21,CC,"1,2,3", true, true)


function ultraschall.MoveMediaItems_FromArray(MediaItemArray, newposition)
-- changes position of all MediaItems in MediaItemArray to position
-- if there are more than one mediaitems, it retains the relative-position to each 
-- other, putting the earliest item as position and the rest later, in relation to the earliest item
--
-- MediaItemArray - array with all MediaItems that shall be affected. Must not 
--                    include nil-entries, as they'll be interpreted as end of array.
-- number newposition - new position of Items
--reaper.MB(type(MediaItemArray),"",0)
--[[
<ApiDocBlocFunc>
<slug>
MoveMediaItems_FromArray
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
integer retval = ultraschall.MoveMediaItems_FromArray(array MediaItemArray, number newposition)
</functionname>
<description>
It changes the position of the MediaItems from MediaItemArray. It keeps the related position to each other, putting the earliest item at newposition, putting the others later, relative to their offset.

Returns -1 in case of failure.
</description>
<parameters>
array MediaItemArray - an array with the MediaItems to be inserted
number newposition - the new position in seconds
</parameters>
<retvals>
integer retval - -1 in case of error
</retvals>
<semanticcontext>
MediaItem Management
Manipulate
</semanticcontext>
<tags>
mediaitemmanagement, tracks, media, item, insert, ripple
</tags>
</ApiDocBlocFunc>
]]
  if MediaItemArray==nil then return -1 end
  if type(MediaItemArray)~="table" then return -1 end
  if tonumber(newposition)==nil then return -1 end
  local count=1
  local Earliest_time=reaper.GetProjectLength()+1
  local ItemStart
  while MediaItemArray[count]~=nil do
    ItemStart=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION")
    if ItemStart<Earliest_time then Earliest_time=ItemStart end
--    reaper.SetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION", ItemStart+newposition)
    count=count+1
  end    

  count=1
  while MediaItemArray[count]~=nil do
    ItemStart=reaper.GetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION")
    reaper.SetMediaItemInfo_Value(MediaItemArray[count], "D_POSITION", (ItemStart-Earliest_time)+newposition)
    count=count+1
  end    
end


--C,CC=ultraschall.GetAllMediaItemsBetween(1,20,"1,2",false)
--L=ultraschall.ChangePositionOfMediaItems_FromArray(CC, 1)

--tabletest={}
--tabletest[0]={}

--tabletest[0][1]=test


--[[
<ApiDocBlocFunc>
<slug>
Separator
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.Separator
</functionname>
<description>
Contains the correct separator for your system. / on Mac, \ on Windows. Use them, if you want to create windows and mac-compliant scripts that have file operations.
</description>
<semanticcontext>
API-Variables
</semanticcontext>
<tags>
api, variable, separator
</tags>
</ApiDocBlocFunc>
]]

--[[
<ApiDocBlocFunc>
<slug>
Script_Path
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
ultraschall.Script_Path
</functionname>
<description>
Contains the current script-path of Reaper.
</description>
<semanticcontext>
API-Variables
</semanticcontext>
<tags>
api, variable, script, path, scriptpath
</tags>
</ApiDocBlocFunc>
]]



function ultraschall.HelpSort(one,two,three)
--reaper.MB(tostring(one),"",0)
if one==nil then return false end
if two==nil then return false end
--a=one
--b=two
temps={}
--reaper.MB(one,two,0)
temps[1]=one:match("<semanticcontext>%c(.-)%c")
--reaper.MB(temp[0],"",0)
temps[2]=two:match("<semanticcontext>%c(.-)%c")
--reaper.MB(temp[0],temp[1],0)
--if temp[0]==nil or temp[1]==nil then return false end
table.sort(temps)
--reaper.MB(tostring(temp),"",0)
if temps[1]==one:match("<semanticcontext>%c(.-)%c") then return true
else return false end
--reaper.MB(a,b,0)
--a=one
--b=two

--  for i=1, string.len(a) do
--    if string.byte(a,i)==nil then return false end
--    if string.byte(b,i)==nil then return false end
--    if string.byte(a,i)<string.byte(b,i) then return true end
--  end
  return false
end

--LLL=ultraschall.HelpSort("<semanticcontext>\naltraschall Helpers\n</semanticcontext>","<semanticcontext>\naltraschall Helpers\n</semanticcontext>")





-----------------------------
---- Envelope Management ----
-----------------------------





function ultraschall.CreateUSApiDocs_HTML(filename_with_path,LLL)
--!!!TODO GFX-FILES müssen auch exportiert werden!!!---

--[[
<ApiDocBlocFunc>
<slug>
CreateUSApiDocs_HTML
</slug>
<requires>
Ultraschall=4.00
Reaper=5.40
SWS=2.8.8
</requires>
<functionname>
boolean retval = ultraschall.CreateUSApiDocs_HTML(string filename_with_path, string sourcefilename_with_path)
</functionname>
<description>
Creates a documentation-file for the Ultraschall-Api-Functions.
</description>
<retvals>
boolean retval - returns true, if help-creation worked; false if it failed
</retvals>
<parameters>
string filename_with_path - filename of the newly created helpfile
string sourcefilename_with_path - the name of the file, of which the docs shall be created from. nil - the Ultraschall Framework-Api
</parameters>
<semanticcontext>
Help and Documentation
Ultraschall Api-docs
</semanticcontext>
<tags>
api, docs, documentation, html, create
</tags>
</ApiDocBlocFunc>
]]
  local functionarray={}
  local count=1
  local counter=0
  local funcindex=""
  local funclist=""
  local A,B,C,D,E,F,G,H=reaper.get_action_context()
  local L, integer
  local apiversion,apidate,apibeta=ultraschall.GetApiVersion()
  local slug=""
  local tempparameters=""
  local scriptpath=reaper.GetResourcePath()..ultraschall.Separator.."Scripts"..ultraschall.Separator
  if LLL==nil then LLL=scriptpath.."Ultraschall_functions_api.lua" end
--  reaper.MB(LLL,"",0)
  local Path = ultraschall.GetPath(LLL, "(.*)/")
  if Path == "-1" then Path = ultraschall.GetPath(filename_with_path, "(.*)\\") end
  integer=reaper.RecursiveCreateDirectory(Path.."\\gfx", 0)
  
  if reaper.GetOS() == "Win32" or reaper.GetOS() == "Win64" then
    L=ultraschall.MakeCopyOfFile_Binary(scriptpath.."docgfx\\reaper5.40.png", Path.."gfx\\reaper5.40.png")
    L=ultraschall.MakeCopyOfFile_Binary(scriptpath.."docgfx\\SWS2.8.8.png", Path.."gfx\\SWS2.8.8.png")
    L=ultraschall.MakeCopyOfFile_Binary(scriptpath.."docgfx\\ultraschall4.00.png", Path.."gfx\\ultraschall4.00.png")
    L=ultraschall.MakeCopyOfFile_Binary(scriptpath.."docgfx\\us.png", Path.."gfx\\us.png")
  else
    L=ultraschall.MakeCopyOfFile_Binary(scriptpath.."docgfx/reaper5.40.png", Path.."gfx/reaper5.40.png")
    L=ultraschall.MakeCopyOfFile_Binary(scriptpath.."docgfx/SWS2.8.8.png", Path.."gfx/SWS2.8.8.png")
    L=ultraschall.MakeCopyOfFile_Binary(scriptpath.."docgfx/ultraschall4.00.png", Path.."gfx/ultraschall4.00.png")
    L=ultraschall.MakeCopyOfFile_Binary(scriptpath.."docgfx/us.png", Path.."gfx/us.png")
  end
    
  -- Read sourcefile and get all helpblocs
  infile=ultraschall.ReadValueFromFile(LLL)
--  infile=ultraschall.ReadValueFromFile(B)
  while infile~=nil do
    functionarray[count]=infile:match("<ApiDocBlocFunc>.-</ApiDocBlocFunc>")
    infile=infile:match("<ApiDocBlocFunc>.-</ApiDocBlocFunc>(.*)")
    if functionarray[count]==nil then infile=nil
    else
      count=count+1
    end
  end
  
--sort functions by semanticcontext
--  reaper.ShowConsoleMsg(functionarray[1])

  for i=1, count-1 do
--  reaper.MB(functionarray[i],i,0)
    if tostring(functionarray[i]:match("<semanticcontext>%c(.-)%c.-</semanticcontext>"))~=nil then 
--    if i==196 then reaper.MB(functionarray[i],i,0) end
      functionarray[i]=tostring(functionarray[i]:match("<semanticcontext>%c(.-)%c.-</semanticcontext>"))..functionarray[i]
    end
  end

  table.sort(functionarray)
  local startfile="<html><head><title>Ultraschall Framework-Lua-Api-docs "..apiversion.."</title></head><body>\n<img src=\"gfx/us.png\" alt=\"\"><h2>Ultraschall - Framework "..apiversion.."</h2>"..apibeta.." "..apidate.."<div style=\"padding-left:10%; width:80%;\">"

--for i=1, count-1 do
--  reaper.ShowConsoleMsg(functionarray[i]:match(".-(<functionname>.-</functionname>).-"))
--end

--creating index
  local funclistarray={}
  local tingle=0
  local currentindex, currentsubindex
  funcindex="<h3>The Functions Reference</h3><table style=\"font-size:10pt; width:100%;\">"
  for i=1, count-1 do
    if functionarray[i]:match("<functionname>(.-)</functionname>")~=nil or functionarray[i]:match("<chaptername>(.-)</chaptername>") then
      funclistarray[i]=functionarray[i]:match("(<semanticcontext>.-</semanticcontext>)")..functionarray[i]
    end
  end
  table.sort(funclistarray)
  count=1
  local firstrun=0
  while funclistarray[count]~=nil do
  if currentindex~=funclistarray[count]:match("<semanticcontext>%c(.-)%c.-</semanticcontext>") then
        currentindex=funclistarray[count]:match("<semanticcontext>%c(.-)%c.-</semanticcontext>")
        currentsubindex=funclistarray[count]:match("<semanticcontext>%c.-%c(.-)</semanticcontext>")
        if firstrun==1 then funcindex=funcindex.."<tr><td>&nbsp;</td></tr>" end
        if firstrun==0 then firstrun=1 end
        funcindex=funcindex.."<tr><td>&nbsp;</td></tr><tr><td><h3><u>"..currentindex.."</u></h3></td></tr><tr><td><strong>"..currentsubindex.."</strong></td></tr>"
        tingle=0
  elseif currentsubindex~=funclistarray[count]:match("<semanticcontext>%c.-%c(.-)</semanticcontext>") then
        currentsubindex=funclistarray[count]:match("<semanticcontext>%c.-%c(.-)</semanticcontext>")
        funcindex=funcindex.."<tr><td>&nbsp;</td></tr><tr><td><strong>"..currentsubindex.."</strong></td></tr>\n"
        tingle=0
  end
  tingle=tingle+1
--  reaper.MB(count,"",0)
if funclistarray[count]:match("<functionname>.-ultraschall.(.-)%(.-</functionname>")~=nil then
  funcindex=funcindex.."<td><a href=\"#"..tostring(funclistarray[count]:match("<slug>(.-)</slug>")).."\">"..tostring(funclistarray[count]:match("<functionname>.-ultraschall.(.-)%(.-</functionname>")).."</a>&nbsp;&nbsp;</td>"
elseif funclistarray[count]:match("<functionname>.-(ultraschall..-)</functionname>")~=nil then
--reaper.MB(tostring(funclistarray[count]:match("<functionname>.-(ultraschall..-)</functionname>")),"",0)
  funcindex=funcindex.."<td><a href=\"#"..tostring(funclistarray[count]:match("<slug>(.-)</slug>")).."\">"..tostring(funclistarray[count]:match("<functionname>.-ultraschall.(.-)</functionname>")).."</a>&nbsp;&nbsp;</td>"
else
--reaper.MB("","",0)
  funcindex=funcindex.."</tr><tr><td><a href=\"#"..tostring(funclistarray[count]:match("<slug>(.-)</slug>")).."\">"..tostring(funclistarray[count]:match("<chaptername>(.-)</chaptername>")).."</a></td></tr>"
end
--  reaper.MB(tostring(funclistarray[count]:match("<slug>(.-)</slug>")),"",0)
  if tingle==4 then tingle=0 funcindex=funcindex.."</tr>\n<tr>" end
--  reaper.MB(tingle,"",0)
  count=count+1
  end

  funcindex=funcindex.."</tr></table>"

--creating entries
  for i=1, count-1 do
  local usvers,ultraschallversion,reapvers,reaperversion,swsvers,swsversion,description
  local retvals=""  
  local parameters=""
  local tempretvals=""
  local begin=""
  tempparameters=""
    if functionarray[i]:match("<functionname>(.-)</functionname>")~=nil then
      if functionarray[i]:match("<requires>(.-)</requires>")~=nil then
        if functionarray[i]:match("<requires>.-Ultraschall=(.-)%c.-</requires>")~=nil then
            usvers=functionarray[i]:match("<requires>.-Ultraschall=(.-)%c.-</requires>")
            ultraschallversion="<img style=\"width:3%;\" src=\"gfx/ultraschall"..usvers..".png\" alt=\"Ultraschall version "..usvers.."\">"
        end
        if functionarray[i]:match("<slug>(.-)</slug>")~=nil then
          slug=functionarray[i]:match("<slug>(.-)</slug>")
--          if slug=="" then reaper.MB(slug,"",0) end
        else
          slug=""
        end
        if functionarray[i]:match("<requires>.-Reaper=(.-)%c.-</requires>")~=nil then
            reapvers=functionarray[i]:match("<requires>.-Reaper=(.-)%c.-</requires>")
            reaperversion="<img style=\"width:3%;\" src=\"gfx/reaper"..reapvers..".png\" alt=\"Reaper version "..reapvers.."\">"
        end
        if functionarray[i]:match("<requires>.-SWS=(.-)%c.-</requires>")~=nil then
            swsvers=functionarray[i]:match("<requires>.-SWS=(.-)%c.-</requires>")
            swsversion="<img style=\"width:3%;\" src=\"gfx/sws"..swsvers..".png\" alt=\"sws version "..swsvers.."\">"
        end
      end
      if functionarray[i]:match("<description>%c.-</description>")~=nil then
          description=tostring(functionarray[i]:match("<description>%c(.-)</description>"))        
          description=string.gsub(description, "\n", "<br>")
      elseif functionarray[i]:match("<description>.-</description>")~=nil then
          description=tostring(functionarray[i]:match("<description>(.-)</description>"))        
          description=string.gsub(description, "\n", "<br>")
      end      

      if functionarray[i]:match("<retvals>.-</retvals>")~=nil then
          tempretvals=functionarray[i]:match("<retvals>(.-</retvals>)")
--          reaper.MB(tempretvals,"",0)
--          while tempretvals~=nil do
--            retvals=retvals.."<i><div style=\"padding-left:4%;\">"..tostring(tempretvals:match("(.-)%-")).."</i>"..tostring(tempretvals:match("(%-.-)%c")).."</div>"
--            tempretvals=tostring(tempretvals:match(".-%c(.*)"))
--            if tempretvals=="" or tempretvals:match("-")==nil then tempretvals=nil end
--          end
--            tempretvals=string.gsub(tempparameters, "</retvals>", "</i>")
            tempretvals=string.gsub(tempretvals, "\n","</i><br><i>")
            tempretvals=string.gsub(tempretvals, " %- ", "</i> - ")
            tempretvals=string.gsub(tempretvals, "\n.-", "</i><br><i>")
            tempretvals=string.gsub(tempretvals, "<br><i>%-","<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
--            tempretvals=string.gsub(tempretvals, "%%%-", "-")

--            tempretvals=string.gsub(tempretvals, "\n", "</i><br><i>")
--            tempretvals=string.gsub(tempretvals, "<br><i>%-", "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
--            reaper.MB(tempretvals,"",0)
--        retvals=tempretvals
--reaper.MB(tempretvals:sub(9,-8),"",0)
            retvals=retvals.."<div style=\"padding-left:4%;\">"..tempretvals:sub(9,-11).."</i></div>"
      end      
      if functionarray[i]:match("<parameters>.-</parameters>")~=nil then
          tempparameters=functionarray[i]:match("<parameters>(.-</parameters>)")
--          reaper.MB(tempparameters,"",0)
--          tempparameters=string.gsub(tempparameters, "%c", " ")
          tempparameters=string.gsub(tempparameters, "</parameters>", "</i>")
          tempparameters=string.gsub(tempparameters, " %- ", "</i> - ")
          tempparameters=string.gsub(tempparameters, "\n.-", "</i><br><i>")
--          reaper.ShowConsoleMsg(tostring(tempparameters:match("<br><i>%-"),"",0))
          tempparameters=string.gsub(tempparameters, "<br><i>%-", "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
--          reaper.ShowConsoleMsg(tostring(tempparameters:match("<br><div style"),"",0))
--          if tempparameters:match("<br><div style") then tempparameters=tempparameters.."</div>" end
--          tempparameters=string.gsub(tempparameters, "%%%-", "-")
          tempparameters=tempparameters:sub(9,-1)
--          reaper.MB(tempparameters,"",0)
--          while tempparameters~=nil do
--          reaper.MB(tempparameters,"",0)
--            parameters=parameters.."<i><div style=\"padding-left:4%;\">"..tostring(tempparameters:match("(.-)%-")).."</i>"..tostring(tempparameters:match("(%-.-)%c")).."</div>"
            parameters=parameters.."<div style=\"padding-left:4%;\">"..tempparameters.."</div>"
--            tempparameters=tostring(tempparameters:match(" .- %c(.*)"))
--            if tempparameters=="" or tempparameters:match("-")==nil then tempparameters=nil end
--          end
--          reaper.MB(parameters.."test1","",0)
      end      
      slug=functionarray[i]:match("<slug>(.-)</slug>")
      if slug==nil then slug=""
--        reaper.MB(functionarray[i]:match(".-"),"",0)
      end
      slug=string.gsub(slug, "\n", "")
      if retvals~="" then retvals="<u>Returnvalues:</u><br>"..retvals end
      if parameters~="" then parameters="<u>Parameters:</u>"..parameters end
      if swsversion==nil then swsversion="" end
      if reaperversion==nil then reaperversion="" end
      if ultraschallversion==nil then ultraschallversion="" end
        funclist=funclist.."<a id=\""..slug.."\"><hr><br><i></a>"..ultraschallversion..reaperversion..swsversion.." "..functionarray[i]:match("<functionname>(.-)</functionname>").."</i><br><br>"..description.."<p></p>"..retvals.."<p></p>"..parameters.."<p></p>TAGS: "..functionarray[i]:match("<tags>(.-)</tags>").."<p></p>"
    end

--dok-chapters
    if functionarray[i]:match("<chaptername>(.-)</chaptername>")~=nil then
        if functionarray[i]:match("<slug>(.-)</slug>")~=nil then
          slug=functionarray[i]:match("<slug>(.-)</slug>")
        else
          slug=""
        end
      if functionarray[i]:match("<description>.-</description>")~=nil then
          description=tostring(functionarray[i]:match("<description>.-%c(.-)%c</description>"))
          description=string.gsub(description, "\n", "<br>")
      end      

      slug=functionarray[i]:match("<slug>(.-)</slug>")
      if slug==nil then slug=""
--        reaper.MB(functionarray[i]:match(".-"),"",0)
      end
      slug=string.gsub(slug, "\n", "")      
      if functionarray[i]:match("<begin></begin>")~=nil then
        begin="<hr>"
      else
        begin=""
      end
        funclist=funclist.."<a id=\""..slug.."\">"..begin.."</a><h4>"..functionarray[i]:match("<chaptername>(.-)</chaptername>").."</h4>"..description.."<p></p>"      
    end
    
  end

  --assembling helpfile
  local endfile="<hr><p align=\"right\"><i>API-documentation automatically created by Ultraschall-Framework version "..ultraschall.GetApiVersion().." "..apibeta.."</i></p></div></body></html>"
  local outfile=startfile..funcindex.."<p></p>"..funclist..endfile
  return ultraschall.WriteValueToFile(filename_with_path, outfile)
end


--ALABAMA=ultraschall.CreateUSApiDocs_HTML("c:\\testhelp-beta1-1.html", "c:\\US-Doku-beta1.txt")
--  local A,B,C,D,E,F,G,H=reaper.get_action_context()
--ALABAMA=ultraschall.CreateUSApiDocs_HTML("c:\\testhelp-beta2hulu.html", B)
--ALABAMA=ultraschall.CreateUSApiDocs_HTML("c:\\testhelp-beta2-1.html")
