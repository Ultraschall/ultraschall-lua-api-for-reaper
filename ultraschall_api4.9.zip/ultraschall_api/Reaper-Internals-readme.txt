compiled by Meo Mespotine(mespotine.de) for the ultraschall.fm-project

Documentation for Reaper-Internals 7.1 and Ultraschall Api 4.9 , SWS 2.13.2.0, JS-extension-plugin 1.31 and ReaPack

Written and compiled by Meo-Ada Mespotine (mespotine.de) for the Ultraschall.FM-project.
licensed under creative-commons by-sa-nc-license

Some docs are enhanced versions of the original docs and the Reaper-logo is by the Cockos Inc.
The SWS-logo is by SWS-extension.org

You can download the full Ultraschall-API-framework at ultraschall.fm/api
