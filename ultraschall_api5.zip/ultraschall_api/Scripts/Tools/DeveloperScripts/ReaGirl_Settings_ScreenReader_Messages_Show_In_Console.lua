reaper.SetExtState("ReaGirl", "osara_debug", tostring(true), true)
