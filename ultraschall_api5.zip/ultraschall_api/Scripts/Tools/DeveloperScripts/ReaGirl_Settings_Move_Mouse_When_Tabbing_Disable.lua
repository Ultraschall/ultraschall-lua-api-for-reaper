reaper.SetExtState("ReaGirl", "osara_move_mouse", tostring(false), true)
