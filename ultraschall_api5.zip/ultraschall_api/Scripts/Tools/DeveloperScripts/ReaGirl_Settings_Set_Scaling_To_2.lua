reaper.SetExtState("ReaGirl", "scaling_override", "2", true)
