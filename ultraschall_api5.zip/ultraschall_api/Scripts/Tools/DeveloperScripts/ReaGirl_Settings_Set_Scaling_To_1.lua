reaper.SetExtState("ReaGirl", "scaling_override", "1", true)
