reaper.SetExtState("ReaGirl", "scaling_override", "7", true)
