reaper.SetExtState("ReaGirl", "scaling_override", "", true)
