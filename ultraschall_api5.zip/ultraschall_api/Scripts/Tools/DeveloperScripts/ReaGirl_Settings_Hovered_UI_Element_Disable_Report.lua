reaper.SetExtState("ReaGirl", "osara_hover_mouse", tostring(false), true)
