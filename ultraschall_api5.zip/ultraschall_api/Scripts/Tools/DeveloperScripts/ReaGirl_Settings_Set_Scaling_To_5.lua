reaper.SetExtState("ReaGirl", "scaling_override", "5", true)
