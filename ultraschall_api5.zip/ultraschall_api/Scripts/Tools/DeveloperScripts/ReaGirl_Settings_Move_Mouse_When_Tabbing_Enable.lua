reaper.SetExtState("ReaGirl", "osara_move_mouse", tostring(true), true)
