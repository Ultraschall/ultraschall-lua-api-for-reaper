reaper.SetExtState("ReaGirl", "scaling_override", "8", true)
