reaper.SetExtState("ReaGirl", "scaling_override", "4", true)
