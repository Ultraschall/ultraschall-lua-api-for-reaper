reaper.SetExtState("ReaGirl", "show_tooltips", tostring(true), true)
