Runs a command by a filename. It internally registers the file temporarily as command, runs it and unregisters it again.<br>
This is especially helpful, when you want to run a command for sure without possible command-id-number-problems.<br>
<br>
It returns a unique script-identifier for this script, which can be used to communicate with this script-instance.<br>
The started script gets its script-identifier using [GetScriptIdentifier](#GetScriptIdentifier).<br>
You can use this script-identifier e.g. as extstate.<br>
<br>
Returns false in case of an error<br>
<br>
