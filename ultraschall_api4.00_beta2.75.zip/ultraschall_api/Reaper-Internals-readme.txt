compiled by Meo Mespotine(mespotine.de) for the ultraschall.fm-project

Documentation for Reaper-Internals 5.977 and Ultraschall Api 4.00-Beta 2.75, SWS 2.10.0.1, JS-extension-plugin 0.986 and ReaPack

Written and compiled by Meo Mespotine (mespotine.de) for the Ultraschall.FM-project.
licensed under creative-commons by-sa-nc-license

Some docs are enhanced versions of the original docs and the Reaper-logo is by the Cockos Inc.
The SWS-logo is by SWS-extension.org

You can download the full Ultraschall-API-framework at ultraschall.fm/api
