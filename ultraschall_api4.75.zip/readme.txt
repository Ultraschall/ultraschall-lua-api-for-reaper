reaper_www v0.?

put reaper_www.dll and reaper_www_root in your REAPER/Plugins dir.

Run REAPER. Then open a browser to http://localhost:8808/ (or your IP instead of localhost). Done.

Only tested on Firefox and iPhone so far.

If you want to edit the html/javascript/etc, see reaper_www_root/index.html and main.js. main.js has info on the API for 
accessing the web server.

If you want to change the port, add a password, change caching on items, etc, you can add a section to your reaper.ini:


[reaper_www]
userpass=login:password
port=8808
cacheexpire=secondsinfuture (default 3600)
wwwroot=path to wwwroot to use



That is all for now! Happy hacking
