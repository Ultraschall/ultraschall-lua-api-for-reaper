--reaper.SetExtState("us","devcount","-1",true) L=""
reaper.DeleteExtState("us", "mousecount", true) 
reaper.DeleteExtState("us", "mousestart", true)
