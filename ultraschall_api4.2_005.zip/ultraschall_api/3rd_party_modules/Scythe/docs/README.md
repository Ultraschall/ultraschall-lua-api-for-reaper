# Scythe

_This project is on an indefinite hiatus, which unfortunately includes any further work on the documentation. The [Ultraschall team](https://github.com/Ultraschall) have adopted [v2](https://github.com/Lokasenna_GUI) and are continuing development in their codebase._

This repository is the home of Scythe (formerly Lokasenna_GUI), a graphical framework and utility library for Lua scripts in the [Reaper](https://www.reaper.fm/) digital audio workstation.
