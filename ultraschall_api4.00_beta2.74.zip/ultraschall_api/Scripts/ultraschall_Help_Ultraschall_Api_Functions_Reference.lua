dofile(reaper.GetResourcePath().."/UserPlugins/ultraschall_api.lua")

ultraschall.OpenURL("file://"..ultraschall.Api_Path .."Documentation/US_Api_Functions.html")
